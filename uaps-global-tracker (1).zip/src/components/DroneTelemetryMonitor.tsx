import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Cpu, Activity, Battery, Wind, Navigation, ShieldCheck, Zap } from 'lucide-react';
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area 
} from 'recharts';

interface TelemetryRecord {
  drone_id: string;
  ts: string;
  battery: { soc_pct: number; temp_c: number };
  position: { alt_m: number };
  velocity: { vx_mps: number };
  safety: { current_mode: string };
}

export function DroneTelemetryMonitor() {
  const [telemetry, setTelemetry] = useState<TelemetryRecord[]>([]);
  const [ingestionStats, setIngestionStats] = useState({ total: 0, lastBatch: 0, status: 'IDLE' });

  useEffect(() => {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const ws = new WebSocket(`${protocol}//${window.location.host}`);

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type === 'telemetry_update' || data.type === 'telemetry_update_grpc') {
          const newRecord: TelemetryRecord = {
            drone_id: data.courierId,
            ts: data.location.timestamp,
            battery: data.battery,
            position: { alt_m: data.location.alt_m },
            velocity: data.velocity,
            safety: data.safety || { current_mode: 'AUTO' }
          };
          
          setTelemetry(prev => [newRecord, ...prev].slice(0, 50));
          setIngestionStats(prev => ({
            total: prev.total + 1,
            lastBatch: 1,
            status: data.type === 'telemetry_update_grpc' ? 'GRPC_ACCEPTED' : 'ACCEPTED'
          }));

          // Reset status after a brief flash
          setTimeout(() => setIngestionStats(prev => ({ ...prev, status: 'ACTIVE' })), 1000);
        }
      } catch (err) {
        console.error("Telemetry WS Error:", err);
      }
    };

    return () => ws.close();
  }, []);

  const chartData = [...telemetry].reverse().map(t => ({
    time: new Date(t.ts).toLocaleTimeString(),
    alt: t.position.alt_m,
    battery: t.battery.soc_pct,
    velocity: Math.abs(t.velocity?.vx_mps || 0)
  }));

  return (
    <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden flex flex-col h-full">
      <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-slate-50/50">
        <div className="flex items-center gap-2">
          <Cpu className="w-4 h-4 text-indigo-600" />
          <h3 className="text-sm font-bold text-[#1a365d] uppercase tracking-widest">Drone Telemetry Stream</h3>
        </div>
        <div className="flex items-center gap-3">
          <AnimatePresence mode="wait">
            {ingestionStats.status === 'ACCEPTED' && (
              <motion.span
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100"
              >
                ACCEPTED (+{ingestionStats.lastBatch})
              </motion.span>
            )}
            {ingestionStats.status === 'GRPC_ACCEPTED' && (
              <motion.span
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-100"
              >
                gRPC STREAM (+{ingestionStats.lastBatch})
              </motion.span>
            )}
          </AnimatePresence>
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${telemetry.length > 0 ? 'bg-emerald-500 animate-pulse' : 'bg-gray-300'}`} />
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">
              {telemetry.length > 0 ? 'Live Feed' : 'Waiting for Data'}
            </span>
          </div>
        </div>
      </div>

      <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Real-time Charts */}
        <div className="md:col-span-2 space-y-6">
          <div className="h-48 min-h-0 min-w-0">
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 flex items-center gap-2">
              <Navigation className="w-3 h-3" /> Altitude & Velocity (m/s)
            </p>
            <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorAlt" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="time" hide />
                <YAxis hide />
                <Tooltip 
                  contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  labelStyle={{ fontSize: '10px', fontWeight: 'bold' }}
                />
                <Area type="monotone" dataKey="alt" stroke="#6366f1" fillOpacity={1} fill="url(#colorAlt)" strokeWidth={2} />
                <Area type="monotone" dataKey="velocity" stroke="#f59e0b" fill="transparent" strokeWidth={2} strokeDasharray="5 5" />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="h-48 min-h-0 min-w-0">
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 flex items-center gap-2">
              <Battery className="w-3 h-3" /> Battery SoC (%)
            </p>
            <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="time" hide />
                <YAxis domain={[0, 100]} hide />
                <Tooltip 
                  contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Line type="monotone" dataKey="battery" stroke="#10b981" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Status Cards */}
        <div className="space-y-4">
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
            <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3">Active Drone Status</h4>
            {telemetry.length > 0 ? (
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-xs text-slate-600">Drone ID</span>
                  <span className="text-xs font-mono font-bold text-indigo-600">{telemetry[0].drone_id}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-slate-600">Flight Mode</span>
                  <span className="px-2 py-0.5 bg-indigo-100 text-indigo-700 text-[10px] font-bold rounded uppercase">
                    {telemetry[0].safety.current_mode}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-slate-600">Battery Temp</span>
                  <span className="text-xs font-bold text-slate-700">{telemetry[0].battery.temp_c}°C</span>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-8 opacity-30">
                <Activity className="w-8 h-8 mb-2" />
                <span className="text-[10px] font-bold uppercase">No Active Stream</span>
              </div>
            )}
          </div>

          <div className="bg-indigo-600 p-4 rounded-xl shadow-lg shadow-indigo-200">
            <h4 className="text-[10px] font-bold text-indigo-200 uppercase tracking-widest mb-1">Ingestion Engine</h4>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold text-white">{ingestionStats.total}</span>
              <span className="text-[10px] font-bold text-indigo-200 uppercase">Records</span>
            </div>
            <div className="mt-4 flex items-center gap-2">
              <Zap className="w-3 h-3 text-amber-400" />
              <span className="text-[10px] font-bold text-white uppercase tracking-tighter">Real-time Processing Active</span>
            </div>
          </div>

          <div className="bg-white p-4 rounded-xl border border-slate-100">
            <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3">Safety Compliance</h4>
            <div className="flex items-center gap-3">
              <div className="p-2 bg-emerald-50 rounded-lg">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
              </div>
              <div>
                <p className="text-xs font-bold text-slate-700">Remote ID Active</p>
                <p className="text-[9px] text-slate-400 font-bold uppercase">FAA Part 89 Compliant</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
