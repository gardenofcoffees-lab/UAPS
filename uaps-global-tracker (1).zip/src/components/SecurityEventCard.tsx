import React from 'react';
import { motion } from 'motion/react';
import { ShieldAlert, Lock, Radio, Navigation, RotateCcw, AlertCircle, ShieldCheck, Database, FileText, ExternalLink, Wind, Cloud, Fingerprint, Clock, Zap } from 'lucide-react';

interface SecurityEventProps {
  event: any; // Using any to handle various structures during transition
}

export function SecurityEventCard({ event: rawEvent }: SecurityEventProps) {
  // Data Normalization Logic
  const isEvidencePacket = rawEvent.type === 'SECURITY_INCIDENT';
  
  let data, metadata, context, hashes;

  if (isEvidencePacket) {
    data = rawEvent.incident;
    metadata = rawEvent.ingest_metadata;
    context = rawEvent.context;
    hashes = rawEvent.hashes;
  } else if (rawEvent.type === 'SECURITY') {
    data = {
      event_id: rawEvent.incident_id,
      drone_id: rawEvent.drone_id,
      delivery_id: rawEvent.delivery_id,
      flight_id: rawEvent.flight_id,
      ts: rawEvent.timestamp,
      category: rawEvent.category,
      severity: rawEvent.severity,
      indicators: {
        gps_vs_imu_delta_m: rawEvent.incident_details.gps_vs_imu_delta_m,
        signal_strength_anomaly: rawEvent.incident_details.signal_strength_anomaly,
        satellite_pattern_anomaly: rawEvent.incident_details.satellite_pattern_anomaly
      },
      response: {
        mode: rawEvent.incident_details.response_mode,
        gps_disabled: rawEvent.incident_details.gps_disabled,
        inertial_nav_enabled: rawEvent.incident_details.inertial_nav_enabled,
        comms_intact: rawEvent.incident_details.comms_intact
      },
      outcome: {
        status: rawEvent.incident_details.outcome_status,
        notes: rawEvent.incident_details.outcome_notes
      }
    };
    metadata = {
      validated_signature: rawEvent.integrity.signature_valid,
      drone_cert_id: 'N/A' // Not provided in this structure
    };
    context = rawEvent.flight_context;
    hashes = rawEvent.integrity;
  } else if (rawEvent.event === 'DELIVERY_SECURITY_FAILURE') {
    data = {
      event_id: `fail-${rawEvent.delivery_id}`,
      delivery_id: rawEvent.delivery_id,
      ts: rawEvent.timestamp,
      category: rawEvent.event,
      severity: 'CRITICAL',
      outcome: {
        status: rawEvent.details.package_status,
        notes: `${rawEvent.details.incident_type}. RTH Executed: ${rawEvent.details.rth_executed}`
      }
    };
    metadata = null;
    context = null;
    hashes = null;
  } else {
    // Normalize the event data for wrapped or legacy structures
    data = rawEvent.security_event || {
      event_id: rawEvent.event_id!,
      drone_id: rawEvent.drone_id!,
      delivery_id: rawEvent.delivery_id,
      flight_id: rawEvent.flight_id,
      ts: rawEvent.ts!,
      category: rawEvent.category!,
      severity: rawEvent.severity,
      parent_event_id: rawEvent.parent_event_id,
      indicators: rawEvent.indicators,
      response: rawEvent.response,
      outcome: rawEvent.outcome,
      source: rawEvent.source,
      ingested_at: rawEvent.ingested_at
    };
    metadata = rawEvent.ingest_metadata;
    context = null;
    hashes = null;
  }

  const isCritical = data.severity === 'CRITICAL' || data.severity === 'EMERGENCY';
  
  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className={`bg-[#1a365d] rounded-[32px] border ${isCritical ? 'border-red-500/30' : 'border-amber-500/30'} shadow-2xl overflow-hidden relative`}
    >
      {/* Background Glow */}
      <div className={`absolute top-0 right-0 w-64 h-64 ${isCritical ? 'bg-red-500/10' : 'bg-amber-500/10'} blur-[100px] -mr-32 -mt-32`} />
      
      <div className={`p-6 ${isCritical ? 'bg-red-500/10 border-red-500/20' : 'bg-amber-500/10 border-amber-500/20'} border-b flex items-center justify-between relative z-10`}>
        <div className="flex items-center gap-4">
          <div className={`w-12 h-12 ${isCritical ? 'bg-red-500/20 text-red-400' : 'bg-amber-500/20 text-amber-400'} rounded-2xl flex items-center justify-center`}>
            <ShieldAlert className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-sm font-black text-white uppercase tracking-tight">{data.category.replace('_', ' ')}</h3>
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
              <p className={`text-[10px] font-bold ${isCritical ? 'text-red-400/60' : 'text-amber-400/60'} uppercase tracking-widest`}>
                {data.severity || 'SECURITY ALERT'} • {data.event_id}
              </p>
              {data.flight_id && (
                <p className="text-[10px] font-bold text-blue-400/60 uppercase tracking-widest">
                  FLIGHT: {data.flight_id}
                </p>
              )}
              {data.source && (
                <p className="text-[10px] font-bold text-white/40 uppercase tracking-widest">
                  SOURCE: {data.source}
                </p>
              )}
              {data.parent_event_id && (
                <p className="text-[10px] font-bold text-emerald-400/60 uppercase tracking-widest">
                  FOLLOW-UP: {data.parent_event_id}
                </p>
              )}
            </div>
          </div>
        </div>
        <div className={`px-4 py-1.5 ${isCritical ? 'bg-red-500' : 'bg-amber-500'} text-white rounded-full text-[10px] font-black uppercase tracking-widest animate-pulse`}>
          {isCritical ? 'Active Threat' : 'Security Warning'}
        </div>
      </div>

      <div className="p-8 space-y-8 relative z-10">
        <div className="grid grid-cols-2 gap-8">
          <div className="space-y-2">
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Drone Asset</p>
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4 text-blue-400" />
              <span className="text-sm font-black text-white">{data.drone_id || rawEvent.drone_id}</span>
            </div>
            {metadata?.drone_cert_id && (
              <p className="text-[8px] font-bold text-emerald-400 uppercase tracking-widest">Cert: {metadata.drone_cert_id}</p>
            )}
          </div>
          <div className="space-y-2">
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Event Time</p>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-gray-400" />
              <span className="text-sm font-bold text-white">{new Date(data.ts).toLocaleTimeString()}</span>
            </div>
          </div>
        </div>

        {metadata && (
          <div className="flex items-center gap-4 p-4 bg-white/5 rounded-2xl border border-white/10">
            <div className="w-8 h-8 bg-emerald-500/20 rounded-lg flex items-center justify-center text-emerald-400">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div className="flex-1">
              <div className="flex justify-between items-center mb-1">
                <p className="text-[10px] font-black text-white uppercase tracking-widest">Validated Ingest</p>
                <span className="text-[8px] font-bold text-emerald-400 uppercase tracking-widest">Signature Verified</span>
              </div>
              <p className="text-[8px] font-bold text-gray-500 uppercase tracking-widest">Gateway: {rawEvent.created_by || 'Security Service'}</p>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {data.indicators && (
            <div className="p-6 bg-white/5 rounded-3xl border border-white/10 space-y-4">
              <h4 className="text-[10px] font-black text-blue-400 uppercase tracking-widest flex items-center gap-2">
                <Radio className="w-4 h-4" /> Threat Indicators
              </h4>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-bold text-gray-400">GPS/IMU Delta</span>
                  <span className="text-xs font-black text-red-400">{data.indicators.gps_vs_imu_delta_m}m</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs font-bold text-gray-400">Signal Anomaly</span>
                  <span className={`text-[10px] font-black uppercase px-2 py-1 rounded ${
                    data.indicators.signal_strength_anomaly ? 'bg-red-500/20 text-red-400' : 'bg-emerald-500/20 text-emerald-400'
                  }`}>
                    {data.indicators.signal_strength_anomaly ? 'DETECTED' : 'CLEAR'}
                  </span>
                </div>
                {data.indicators.satellite_pattern_anomaly !== undefined && (
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-bold text-gray-400">Sat Pattern</span>
                    <span className={`text-[10px] font-black uppercase px-2 py-1 rounded ${
                      data.indicators.satellite_pattern_anomaly ? 'bg-red-500/20 text-red-400' : 'bg-emerald-500/20 text-emerald-400'
                    }`}>
                      {data.indicators.satellite_pattern_anomaly ? 'ANOMALOUS' : 'NORMAL'}
                    </span>
                  </div>
                )}
              </div>
            </div>
          )}

          {data.response && (
            <div className="p-6 bg-white/5 rounded-3xl border border-white/10 space-y-4">
              <h4 className="text-[10px] font-black text-emerald-400 uppercase tracking-widest flex items-center gap-2">
                <Navigation className="w-4 h-4" /> System Response
              </h4>
              <div className="space-y-4">
                {data.response.mode && (
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-bold text-gray-400">Nav Mode</span>
                    <span className="text-xs font-black text-white uppercase">{data.response.mode.replace('_', ' ')}</span>
                  </div>
                )}
                {data.response.fallback && (
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-bold text-gray-400">Fallback</span>
                    <span className="text-xs font-black text-emerald-400 uppercase">{data.response.fallback.replace('_', ' ')}</span>
                  </div>
                )}
                <div className="flex flex-wrap gap-2 pt-2">
                  {data.response.gps_disabled && (
                    <span className="px-2 py-0.5 bg-red-500/20 text-red-400 text-[8px] font-black uppercase rounded">GPS Disabled</span>
                  )}
                  {data.response.inertial_nav_enabled && (
                    <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-400 text-[8px] font-black uppercase rounded">Inertial Nav</span>
                  )}
                  {data.response.comms_intact && (
                    <span className="px-2 py-0.5 bg-blue-500/20 text-blue-400 text-[8px] font-black uppercase rounded">Comms Intact</span>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>

        <div className={`flex items-center justify-between p-6 ${isCritical ? 'bg-red-500/5 border-red-500/20' : 'bg-amber-500/5 border-amber-500/20'} rounded-3xl border`}>
          <div className="flex items-center gap-4">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
              (data.response?.rth_initiated || data.response?.mode === 'RTH_INITIATED' || data.outcome?.status === 'RTH_COMPLETED') ? 'bg-red-500 text-white' : 'bg-gray-800 text-gray-500'
            }`}>
              <RotateCcw className="w-5 h-5" />
            </div>
            <div>
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Protocol Status</p>
              <p className="text-sm font-black text-white uppercase tracking-tight">
                {data.outcome?.status.replace('_', ' ') || (data.response?.rth_initiated ? 'Return To Home Initiated' : 'Standard Flight Continued')}
              </p>
            </div>
          </div>
          <div className={`flex items-center gap-2 ${isCritical ? 'text-red-400' : 'text-amber-400'}`}>
            <AlertCircle className="w-4 h-4" />
            <span className="text-[10px] font-black uppercase tracking-widest">{isCritical ? 'Emergency' : 'Warning'}</span>
          </div>
        </div>

        {rawEvent.reporting && (
          <div className="p-6 bg-blue-500/10 rounded-3xl border border-blue-500/20 space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-[10px] font-black text-blue-400 uppercase tracking-widest flex items-center gap-2">
                <ShieldCheck className="w-4 h-4" /> Regulatory Reporting
              </h4>
              <span className={`px-2 py-1 rounded text-[8px] font-black uppercase tracking-widest ${
                rawEvent.reporting.status === 'SUBMITTED' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400'
              }`}>
                {rawEvent.reporting.status}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-xs font-bold text-gray-400">Mandatory Report</span>
              <span className="text-xs font-black text-white">{rawEvent.reporting.mandatory_reporting ? 'YES' : 'NO'}</span>
            </div>
            {rawEvent.reporting.regulator_notified_at && (
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold text-gray-400">Notified At</span>
                <span className="text-xs font-black text-white">{new Date(rawEvent.reporting.regulator_notified_at).toLocaleTimeString()}</span>
              </div>
            )}
          </div>
        )}

        {context && (
          <div className="pt-8 border-t border-white/10 space-y-4">
            <div className="flex items-center gap-2">
              <Database className="w-4 h-4 text-blue-400" />
              <h4 className="text-[10px] font-black text-white uppercase tracking-widest">Evidence Context References</h4>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {(context.pre_event_telemetry_ref) && (
                <div className="p-3 bg-white/5 rounded-xl border border-white/10 flex items-center justify-between group/ref cursor-pointer hover:bg-blue-500/10 transition-colors">
                  <div className="flex items-center gap-3">
                    <FileText className="w-4 h-4 text-gray-400" />
                    <span className="text-[9px] font-bold text-gray-300 uppercase tracking-tight">Pre-Event Telemetry</span>
                  </div>
                  <ExternalLink className="w-3 h-3 text-gray-500 group-hover/ref:text-blue-400" />
                </div>
              )}
              {(context.post_event_telemetry_ref) && (
                <div className="p-3 bg-white/5 rounded-xl border border-white/10 flex items-center justify-between group/ref cursor-pointer hover:bg-blue-500/10 transition-colors">
                  <div className="flex items-center gap-3">
                    <FileText className="w-4 h-4 text-gray-400" />
                    <span className="text-[9px] font-bold text-gray-300 uppercase tracking-tight">Post-Event Telemetry</span>
                  </div>
                  <ExternalLink className="w-3 h-3 text-gray-500 group-hover/ref:text-blue-400" />
                </div>
              )}
              {(context.weather_ref) && (
                <div className="p-3 bg-white/5 rounded-xl border border-white/10 flex items-center justify-between group/ref cursor-pointer hover:bg-blue-500/10 transition-colors">
                  <div className="flex items-center gap-3">
                    <Wind className="w-4 h-4 text-gray-400" />
                    <span className="text-[9px] font-bold text-gray-300 uppercase tracking-tight">Weather Conditions</span>
                  </div>
                  <ExternalLink className="w-3 h-3 text-gray-500 group-hover/ref:text-blue-400" />
                </div>
              )}
              {(context.security_config_ref) && (
                <div className="p-3 bg-white/5 rounded-xl border border-white/10 flex items-center justify-between group/ref cursor-pointer hover:bg-blue-500/10 transition-colors">
                  <div className="flex items-center gap-3">
                    <Lock className="w-4 h-4 text-gray-400" />
                    <span className="text-[9px] font-bold text-gray-300 uppercase tracking-tight">Security Config</span>
                  </div>
                  <ExternalLink className="w-3 h-3 text-gray-500 group-hover/ref:text-blue-400" />
                </div>
              )}
            </div>
          </div>
        )}

        {hashes && (
          <div className="p-4 bg-black/40 rounded-2xl space-y-3 border border-white/5">
            <div className="flex items-center gap-2">
              <Fingerprint className="w-3 h-3 text-blue-400" />
              <span className="text-[8px] font-black text-blue-400 uppercase tracking-widest">Audit Hashes (SHA-256)</span>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[7px] font-bold text-gray-500 uppercase">Packet</span>
                <span className="text-[7px] font-mono text-gray-400 truncate ml-4">{hashes.packet_hash}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[7px] font-bold text-gray-500 uppercase">Telemetry</span>
                <span className="text-[7px] font-mono text-gray-400 truncate ml-4">{hashes.telemetry_hash}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[7px] font-bold text-gray-500 uppercase">Security</span>
                <span className="text-[7px] font-mono text-gray-400 truncate ml-4">{hashes.security_event_hash}</span>
              </div>
            </div>
          </div>
        )}

        {(data.outcome?.notes || data.ingested_at || metadata?.received_at || rawEvent.created_at) && (
          <div className="p-4 bg-white/5 rounded-2xl border border-white/10 flex justify-between items-end">
            <div>
              {data.outcome?.notes && <p className="text-[10px] font-bold text-gray-400 italic">"{data.outcome.notes}"</p>}
              {rawEvent.packet_id && <p className="text-[8px] font-black text-white/20 uppercase tracking-widest mt-2">Packet: {rawEvent.packet_id}</p>}
            </div>
            <div className="text-right">
              {data.ingested_at && (
                <p className="text-[8px] font-bold text-white/20 uppercase tracking-widest">
                  Ingested: {new Date(data.ingested_at).toLocaleTimeString()}
                </p>
              )}
              {(metadata?.received_at || rawEvent.created_at) && (
                <p className="text-[8px] font-bold text-white/10 uppercase tracking-widest">
                  {metadata?.received_at ? 'Received' : 'Created'}: {new Date(metadata?.received_at || rawEvent.created_at).toLocaleTimeString()}
                </p>
              )}
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}
