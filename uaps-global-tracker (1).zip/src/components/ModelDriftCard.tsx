import React from 'react';
import { motion } from 'motion/react';
import { Activity, AlertTriangle, BarChart3, Clock, Cpu, Layers, ShieldAlert, TrendingDown } from 'lucide-react';

interface ModelDriftProps {
  event: any;
}

export function ModelDriftCard({ event }: ModelDriftProps) {
  const { metrics, thresholds, window: analysisWindow } = event;
  
  const isCritical = metrics.input_psi > thresholds.input_psi_max || 
                     metrics.calibration_error > thresholds.calibration_error_max ||
                     metrics.unsafe_false_negative_rate > thresholds.unsafe_fn_rate_max;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-[32px] border border-gray-100 shadow-xl overflow-hidden"
    >
      <div className={`p-6 ${isCritical ? 'bg-amber-50 border-amber-100' : 'bg-blue-50 border-blue-100'} border-b flex items-center justify-between`}>
        <div className="flex items-center gap-4">
          <div className={`w-12 h-12 ${isCritical ? 'bg-amber-100 text-amber-600' : 'bg-blue-100 text-blue-600'} rounded-2xl flex items-center justify-center`}>
            <TrendingDown className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-sm font-black text-[#1a365d] uppercase tracking-tight">Model Drift Detected</h3>
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">
              {event.model_id} • {event.event_id}
            </p>
          </div>
        </div>
        <div className={`px-4 py-1.5 ${isCritical ? 'bg-amber-500' : 'bg-blue-500'} text-white rounded-full text-[10px] font-black uppercase tracking-widest`}>
          {isCritical ? 'Threshold Breach' : 'Drift Warning'}
        </div>
      </div>

      <div className="p-8 space-y-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="space-y-1">
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Model Type</p>
            <div className="flex items-center gap-2">
              <Cpu className="w-3.5 h-3.5 text-blue-500" />
              <span className="text-xs font-black text-[#1a365d]">{event.model_type}</span>
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Environment</p>
            <div className="flex items-center gap-2">
              <Layers className="w-3.5 h-3.5 text-emerald-500" />
              <span className="text-xs font-black text-[#1a365d] uppercase">{event.environment}</span>
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Current Version</p>
            <span className="text-xs font-black text-[#1a365d]">{event.current_version}</span>
          </div>
          <div className="space-y-1">
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Last Stable</p>
            <span className="text-xs font-black text-gray-400">{event.previous_stable_version}</span>
          </div>
        </div>

        <div className="space-y-4">
          <h4 className="text-[10px] font-black text-[#1a365d] uppercase tracking-widest flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-blue-600" /> Drift Metrics vs Thresholds
          </h4>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <MetricBox 
              label="Input PSI" 
              value={metrics.input_psi} 
              max={thresholds.input_psi_max} 
              format="0.00"
            />
            <MetricBox 
              label="Calibration Error" 
              value={metrics.calibration_error} 
              max={thresholds.calibration_error_max} 
              format="0.000"
            />
            <MetricBox 
              label="Unsafe FN Rate" 
              value={metrics.unsafe_false_negative_rate} 
              max={thresholds.unsafe_fn_rate_max} 
              format="0.0%"
              isPercent
            />
          </div>
        </div>

        <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Clock className="w-4 h-4 text-gray-400" />
            <div>
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Analysis Window</p>
              <p className="text-[10px] font-black text-[#1a365d]">
                {new Date(analysisWindow.start).toLocaleDateString()} - {new Date(analysisWindow.end).toLocaleDateString()}
              </p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Detected At</p>
            <p className="text-[10px] font-black text-[#1a365d]">{new Date(event.ts).toLocaleString()}</p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function MetricBox({ label, value, max, format, isPercent = false }: any) {
  const isBreached = value > max;
  const displayValue = isPercent ? `${(value * 100).toFixed(1)}%` : value.toFixed(format.length - 2);
  const displayMax = isPercent ? `${(max * 100).toFixed(1)}%` : max.toFixed(format.length - 2);

  return (
    <div className={`p-4 rounded-2xl border ${isBreached ? 'bg-amber-50 border-amber-200' : 'bg-white border-gray-100'} space-y-2`}>
      <div className="flex justify-between items-start">
        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{label}</span>
        {isBreached && <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />}
      </div>
      <div className="flex items-baseline gap-2">
        <span className={`text-lg font-black ${isBreached ? 'text-amber-600' : 'text-[#1a365d]'}`}>{displayValue}</span>
        <span className="text-[10px] font-bold text-gray-300">/ {displayMax}</span>
      </div>
      <div className="w-full h-1 bg-gray-100 rounded-full overflow-hidden">
        <div 
          className={`h-full rounded-full ${isBreached ? 'bg-amber-500' : 'bg-blue-500'}`}
          style={{ width: `${Math.min((value / max) * 100, 100)}%` }}
        />
      </div>
    </div>
  );
}
