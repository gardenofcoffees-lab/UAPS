import React, { useState } from "react";
import { optimizeRoute } from "../services/routeService";
import { motion, AnimatePresence } from "motion/react";
import { MapPin, Clock, Fuel, AlertTriangle, Info, Loader2, Sparkles } from "lucide-react";
import ReactMarkdown from "react-markdown";

interface RouteOptimizerProps {
  start: string;
  end: string;
  vehicle: string;
  traffic: string;
  roadData: any;
  onRouteOptimized?: (route: { lat: number; lng: number }[]) => void;
}

export function RouteOptimizer({ start, end, vehicle, traffic, roadData, onRouteOptimized }: RouteOptimizerProps) {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleOptimize = async () => {
    setLoading(true);
    setError(null);
    try {
      const text = await optimizeRoute({ start, end, vehicle, traffic, roadData });
      setResult(text || null);
      
      // If we have a callback, also get the points for the map
      if (onRouteOptimized) {
        const { getOptimizedRoutePoints } = await import("../services/routeService");
        const points = await getOptimizedRoutePoints({ start, end, vehicle, traffic, roadData });
        onRouteOptimized(points);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "An unknown error occurred");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden mt-4">
      <div className="p-4 border-b border-gray-100 bg-gray-50/50 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-purple-600" />
          <h2 className="font-semibold text-gray-800">AI Route Optimizer</h2>
        </div>
        <button
          onClick={handleOptimize}
          disabled={loading}
          className="px-4 py-1.5 bg-purple-600 text-white text-xs font-bold rounded-lg hover:bg-purple-700 transition-all disabled:bg-purple-300 flex items-center gap-2"
        >
          {loading ? (
            <>
              <Loader2 className="w-3 h-3 animate-spin" />
              OPTIMIZING...
            </>
          ) : (
            "OPTIMIZE ROUTE"
          )}
        </button>
      </div>

      <div className="p-4">
        <AnimatePresence mode="wait">
          {!result && !loading && !error && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="text-center py-8"
            >
              <div className="w-12 h-12 bg-purple-50 rounded-full flex items-center justify-center mx-auto mb-3">
                <Info className="w-6 h-6 text-purple-400" />
              </div>
              <p className="text-sm text-gray-500 max-w-xs mx-auto">
                Click the button above to generate an AI-optimized route based on current conditions.
              </p>
            </motion.div>
          )}

          {loading && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="text-center py-12"
            >
              <Loader2 className="w-8 h-8 text-purple-600 animate-spin mx-auto mb-4" />
              <p className="text-sm font-medium text-gray-600">Analyzing traffic and road conditions...</p>
              <p className="text-xs text-gray-400 mt-1">Gemini 3.1 Pro is calculating the optimal path</p>
            </motion.div>
          )}

          {error && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-red-50 border border-red-100 rounded-lg p-4 text-red-600 text-sm flex items-start gap-3"
            >
              <AlertTriangle className="w-5 h-5 flex-shrink-0" />
              <p>{error}</p>
            </motion.div>
          )}

          {result && !loading && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="prose prose-sm max-w-none"
            >
              <div className="bg-purple-50/30 rounded-lg p-4 border border-purple-100/50">
                <div className="markdown-body">
                  <ReactMarkdown>{result}</ReactMarkdown>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
