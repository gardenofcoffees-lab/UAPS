import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Key, Shield, Copy, CheckCircle2, Lock, Eye, EyeOff, RefreshCw, Terminal, Activity, AlertTriangle, FileText } from 'lucide-react';

interface PartnerDeveloperPortalProps {
  partnerId: string;
}

export function PartnerDeveloperPortal({ partnerId }: PartnerDeveloperPortalProps) {
  const [activeTab, setActiveTab] = useState<'credentials' | 'docs' | 'webhooks'>('credentials');
  const [apiKey, setApiKey] = useState<string | null>("pk_live_xxxx-xxxx-xxxx-xxxx");
  const [jwt, setJwt] = useState<string | null>(null);
  const [showKey, setShowKey] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const generateJWT = () => {
    setIsGenerating(true);
    // Simulate generation delay
    setTimeout(() => {
      // Mock JWT structure
      const header = btoa(JSON.stringify({ alg: "HS256", typ: "JWT" }));
      const payload = btoa(JSON.stringify({ 
        partnerId, 
        iss: "uaps-auth", 
        exp: Math.floor(Date.now() / 1000) + (60 * 60 * 24 * 365), // 1 year
        scopes: ["fleet:read", "fleet:write", "webhooks:manage"]
      }));
      const signature = btoa("mock-signature-hash").replace(/=/g, '');
      setJwt(`${header}.${payload}.${signature}`);
      setIsGenerating(false);
    }, 1500);
  };

  const copyToClipboard = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(type);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="bg-[#1a365d] p-6 text-white">
          <div className="flex items-center gap-3 mb-2">
            <Terminal className="w-6 h-6 text-[#c5a059]" />
            <h2 className="text-xl font-bold">Developer Portal</h2>
          </div>
          <p className="text-sm text-blue-200">Manage your API keys, JWT access tokens, and integration settings.</p>
        </div>

        <div className="flex border-b border-gray-200">
          {[
            { id: 'credentials', label: 'API Credentials' },
            { id: 'docs', label: 'Documentation' },
            { id: 'webhooks', label: 'Webhooks' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-6 py-4 text-sm font-bold uppercase tracking-widest border-b-2 transition-colors ${
                activeTab === tab.id
                  ? 'border-[#1a365d] text-[#1a365d]'
                  : 'border-transparent text-gray-400 hover:text-gray-600'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="p-8 bg-gray-50/50">
          {activeTab === 'credentials' && (
            <div className="space-y-8 max-w-4xl">
              
              {/* API Key Section */}
              <div className="bg-white p-6 border border-gray-200 rounded-xl space-y-4">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-lg font-bold text-[#1a365d] flex items-center gap-2">
                      <Key className="w-5 h-5 text-gray-400" /> API Key
                    </h3>
                    <p className="text-sm text-gray-500 mt-1">Use this key for static authentication on non-sensitive REST endpoints.</p>
                  </div>
                  <span className="px-2 py-1 bg-emerald-100 text-emerald-700 text-[10px] font-bold uppercase tracking-widest rounded">Active</span>
                </div>

                <div className="mt-4 flex items-center gap-4">
                  <div className="flex-1 relative">
                    <input 
                      type={showKey ? "text" : "password"} 
                      readOnly 
                      value={apiKey || ''} 
                      className="w-full bg-gray-50 border border-gray-200 rounded-lg pl-4 pr-12 py-3 text-sm font-mono text-gray-800 outline-none"
                    />
                    <button 
                      onClick={() => setShowKey(!showKey)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 p-1.5 text-gray-400 hover:text-gray-600 rounded-md transition-colors"
                    >
                      {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  <button 
                    onClick={() => apiKey && copyToClipboard(apiKey, 'api')}
                    className="flex items-center gap-2 px-4 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg text-sm font-bold transition-colors whitespace-nowrap"
                  >
                    {copiedKey === 'api' ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                    {copiedKey === 'api' ? 'Copied' : 'Copy'}
                  </button>
                  <button className="flex items-center gap-2 px-4 py-3 bg-red-50 hover:bg-red-100 text-red-600 rounded-lg text-sm font-bold transition-colors whitespace-nowrap">
                    Revoke
                  </button>
                </div>
              </div>

              {/* JWT Token Section */}
              <div className="bg-white p-6 border border-gray-200 rounded-xl space-y-4">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-lg font-bold text-[#1a365d] flex items-center gap-2">
                      <Shield className="w-5 h-5 text-gray-400" /> JWT Access Token
                    </h3>
                    <p className="text-sm text-gray-500 mt-1 flex items-center gap-2">
                      Required for live WebSockets and authenticated fleet routing. 
                      <span className="px-2 py-0.5 bg-blue-100 text-blue-700 text-[10px] uppercase font-bold rounded">PTC-Auth-001</span>
                    </p>
                  </div>
                </div>

                {!jwt ? (
                  <div className="mt-4 p-8 border-2 border-dashed border-gray-200 rounded-xl flex flex-col items-center justify-center text-center bg-gray-50">
                    <Lock className="w-8 h-8 text-gray-400 mb-4" />
                    <h4 className="text-sm font-bold text-gray-700 mb-2">No Active Token</h4>
                    <p className="text-xs text-gray-500 max-w-sm mb-6">Generate a long-lived JWT token to authenticate your microservices with UAPS.</p>
                    <button 
                      onClick={generateJWT}
                      disabled={isGenerating}
                      className="px-6 py-3 bg-[#1a365d] text-white rounded-lg text-sm font-bold shadow-md hover:bg-blue-900 transition-all flex items-center gap-2 disabled:opacity-70"
                    >
                      {isGenerating ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Key className="w-4 h-4" />}
                      Generate Token
                    </button>
                  </div>
                ) : (
                  <div className="mt-4">
                    <div className="relative">
                      <textarea 
                        readOnly 
                        value={jwt} 
                        rows={4}
                        className="w-full bg-gray-900 border border-gray-800 rounded-lg p-4 text-xs font-mono text-emerald-400 outline-none resize-none break-all"
                      />
                      <button 
                        onClick={() => copyToClipboard(jwt, 'jwt')}
                        className="absolute right-4 top-4 flex items-center gap-2 px-3 py-1.5 bg-white/10 hover:bg-white/20 text-white rounded-md text-xs font-bold transition-colors backdrop-blur-sm"
                      >
                        {copiedKey === 'jwt' ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                        {copiedKey === 'jwt' ? 'Copied' : 'Copy Token'}
                      </button>
                    </div>
                    <div className="flex items-center gap-2 mt-3 text-xs text-amber-600 font-medium bg-amber-50 p-3 rounded-lg border border-amber-100">
                      <AlertTriangle className="w-4 h-4 shrink-0" />
                      This token is shown only once. Please store it securely in your secrets manager.
                    </div>
                  </div>
                )}
              </div>

            </div>
          )}

          {activeTab === 'docs' && (
            <div className="py-12 text-center text-gray-500">
              <FileText className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p>Documentation rendering is external to this component sandbox.</p>
            </div>
          )}

          {activeTab === 'webhooks' && (
            <div className="py-12 text-center text-gray-500">
              <Activity className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p>No active webhooks configured for this partner application.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
