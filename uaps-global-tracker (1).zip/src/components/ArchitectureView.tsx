import React from 'react';
import { motion } from 'motion/react';
import { 
  Shield, Lock, Key, Database, Activity, Eye, EyeOff,
  Server, Globe, Cpu, Network, ShieldCheck, ShieldAlert,
  Zap, BarChart3, History, Layers, Fingerprint,
  UserCheck, Terminal, AlertTriangle, Brain, Bell,
  ArrowRight, LayoutDashboard, FileText, Users, ClipboardCheck,
  CheckCircle2, Circle, Cloud, Code, Settings, Link, PieChart, Workflow,
  BookOpen, Share2, TrendingUp, TrendingDown, AlertCircle, Gauge,
  Target, Scale, Clock, ChevronDown, ArrowDown, HardDrive,
  Compass, Map, Box, Heart, Handshake, FileSearch,
  RefreshCw, Search, ListTodo, Play, Folder, CircleDollarSign,
  Braces, KeyRound, Landmark, Briefcase, Radar,
  Plane, Navigation, Wind, CloudRain, Wrench
} from 'lucide-react';

export const ArchitectureView = () => {
  const [simLikelihood, setSimLikelihood] = React.useState(3);
  const [simImpact, setSimImpact] = React.useState(3);

  // Partner Scoring State
  const [scores, setScores] = React.useState({
    technical: 22,
    security: 24,
    operational: 20,
    governance: 18
  });

  const totalScore = scores.technical + scores.security + scores.operational + scores.governance;

  const simScore = simLikelihood * simImpact;
  const getSimColor = (s: number) => {
    if (s >= 15) return 'bg-rose-500';
    if (s >= 10) return 'bg-orange-500';
    if (s >= 5) return 'bg-amber-500';
    return 'bg-emerald-500';
  };

  const layers = [
    {
      id: 'idp',
      title: 'Identity Provider (IdP)',
      subtitle: 'OAuth2 / OIDC / MFA / SSO',
      icon: <Fingerprint className="w-6 h-6" />,
      color: 'bg-indigo-500',
      details: [
        'Centralized authentication for all partners and users',
        'Multi-Factor Authentication (MFA) enforced',
        'Single Sign-On (SSO) across federated nodes',
        'JSON Web Token (JWT) issuance and rotation'
      ]
    },
    {
      id: 'gateway',
      title: 'API Gateway',
      subtitle: 'mTLS, RBAC, AuthZ, Rate Limit, WAF',
      icon: <Shield className="w-6 h-6" />,
      color: 'bg-blue-500',
      details: [
        'Mutual TLS (mTLS) for partner authentication',
        'Role-Based Access Control (RBAC) enforcement',
        'Web Application Firewall (WAF) protection',
        'Intelligent Rate Limiting per partner ID'
      ]
    },
    {
      id: 'services',
      title: 'FLDPN Services',
      subtitle: 'Ingestion, ETA, Provenance, SLA',
      icon: <Cpu className="w-6 h-6" />,
      color: 'bg-cyan-500',
      details: [
        'Federated Logistics Data Processing Network',
        'Real-time event ingestion and validation',
        'AI-driven ETA and route optimization',
        'SLA monitoring and automated compliance'
      ]
    },
    {
      id: 'mesh',
      title: 'Service Mesh',
      subtitle: 'mTLS & Zero-Trust Policies',
      icon: <Network className="w-6 h-6" />,
      color: 'bg-teal-500',
      details: [
        'Internal service-to-service mTLS encryption',
        'Fine-grained traffic management and retries',
        'Observability and distributed tracing',
        'Zero-Trust network segmentation'
      ]
    },
    {
      id: 'data',
      title: 'Data Layer (Zero-Trust)',
      subtitle: 'Encrypted DBs, Immutable Ledger, HSM',
      icon: <Database className="w-6 h-6" />,
      color: 'bg-emerald-500',
      details: [
        'AES-256 encryption at rest and in transit',
        'Immutable Ledger for shipment provenance',
        'Hardware Security Module (HSM) for key storage',
        'Automated data lifecycle and retention'
      ]
    },
    {
      id: 'monitoring',
      title: 'Monitoring & Security',
      subtitle: 'SIEM, Behavioral Analytics, Threat Detection',
      icon: <Activity className="w-6 h-6" />,
      color: 'bg-rose-500',
      details: [
        'Security Information and Event Management (SIEM)',
        'Behavioral analytics for anomaly detection',
        'Real-time threat detection and mitigation',
        'Immutable audit logs for compliance'
      ]
    }
  ];

  return (
    <div className="p-4 md:p-8 bg-slate-50 min-h-screen">
      <div className="max-w-6xl mx-auto">
        <div className="mb-12 text-center">
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-100 text-blue-700 text-xs font-bold uppercase tracking-widest mb-4"
          >
            <ShieldCheck className="w-4 h-4" /> Zero-Trust Architecture
          </motion.div>
          <h2 className="text-4xl font-black text-slate-900 tracking-tight mb-4">FLDPN System Architecture</h2>
          <p className="text-slate-500 max-w-2xl mx-auto">
            A federated, secure, and resilient infrastructure designed for global logistics data processing 
            with multi-layered security and immutable provenance.
          </p>
        </div>

        {/* GRC Platform Navigation */}
        <div className="mb-12">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="bg-slate-900 py-3 px-6 text-center">
              <h3 className="text-sm font-black text-white uppercase tracking-[0.3em]">GRC Platform</h3>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-6 divide-x divide-slate-100">
              {[
                { label: 'Dashboard', icon: LayoutDashboard, color: 'text-blue-500' },
                { label: 'Controls', icon: ShieldCheck, color: 'text-emerald-500' },
                { label: 'Risks', icon: AlertTriangle, color: 'text-amber-500' },
                { label: 'Evidence', icon: FileText, color: 'text-purple-500' },
                { label: 'Partners', icon: Users, color: 'text-cyan-500' },
                { label: 'Audits', icon: ClipboardCheck, color: 'text-rose-500' }
              ].map((nav) => (
                <button 
                  key={nav.label}
                  className="flex flex-col items-center justify-center p-4 hover:bg-slate-50 transition-colors group"
                >
                  <nav.icon className={`w-5 h-5 ${nav.color} mb-2 group-hover:scale-110 transition-transform`} />
                  <span className="text-[10px] font-bold text-slate-600 uppercase tracking-widest">{nav.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* GRC Dashboard Summary */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-12">
          {[
            { 
              label: 'Compliance Score', 
              stats: [{ val: '92%', label: 'ISO' }, { val: '88%', label: 'SOC' }],
              icon: ShieldCheck, color: 'text-emerald-600', bg: 'bg-emerald-50'
            },
            { 
              label: 'Risk Heatmap', 
              stats: [{ val: '3', label: 'High' }, { val: '7', label: 'Med' }],
              icon: AlertTriangle, color: 'text-amber-600', bg: 'bg-amber-50'
            },
            { 
              label: 'Partner Status', 
              stats: [{ val: '4', label: 'Tier 1' }, { val: '12', label: 'Tier 2' }],
              icon: Users, color: 'text-blue-600', bg: 'bg-blue-50'
            },
            { 
              label: 'Open Issues', 
              stats: [{ val: '1', label: 'Critical' }, { val: '14', label: 'Total' }],
              icon: Activity, color: 'text-rose-600', bg: 'bg-rose-50'
            },
            { 
              label: 'Upcoming Audits', 
              stats: [{ val: '12', label: 'ISO Days' }, { val: '45', label: 'SOC Days' }],
              icon: ClipboardCheck, color: 'text-indigo-600', bg: 'bg-indigo-50'
            },
            { 
              label: 'Evidence Collected', 
              stats: [{ val: '87%', label: 'Complete' }, { val: '1.2k', label: 'Artifacts' }],
              icon: FileText, color: 'text-purple-600', bg: 'bg-purple-50'
            }
          ].map((card) => (
            <div key={card.label} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:border-slate-300 transition-colors">
              <div className="flex items-center gap-2 mb-4">
                <div className={`p-1.5 rounded-lg ${card.bg}`}>
                  <card.icon className={`w-3.5 h-3.5 ${card.color}`} />
                </div>
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{card.label}</span>
              </div>
              <div className="flex items-center justify-between">
                {card.stats.map((s, idx) => (
                  <div key={idx} className={idx === 1 ? 'text-right' : ''}>
                    <div className="text-xl font-black text-slate-900">{s.val}</div>
                    <div className="text-[9px] font-bold text-slate-400 uppercase tracking-tighter">{s.label}</div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* ISO 27001 Annex A Controls */}
        <div className="mb-12">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <h4 className="font-bold text-slate-900 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                ISO 27001 Annex A Controls
              </h4>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Compliance Status</span>
            </div>
            <div className="p-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                { id: 'A.5.1', label: 'InfoSec Policy', status: 'completed' },
                { id: 'A.5.2', label: 'Roles & Responsibilities', status: 'completed' },
                { id: 'A.8.8', label: 'Vulnerability Management', status: 'pending' },
                { id: 'A.8.21', label: 'Cryptography', status: 'completed' }
              ].map((control) => (
                <div key={control.id} className={`p-4 rounded-2xl border ${control.status === 'completed' ? 'bg-emerald-50/30 border-emerald-100' : 'bg-slate-50 border-slate-100'} flex items-start gap-3`}>
                  <div className="mt-0.5">
                    {control.status === 'completed' ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                    ) : (
                      <Circle className="w-4 h-4 text-slate-300" />
                    )}
                  </div>
                  <div>
                    <div className="text-[10px] font-black text-slate-400 uppercase tracking-tighter mb-0.5">{control.id}</div>
                    <div className={`text-xs font-bold ${control.status === 'completed' ? 'text-slate-900' : 'text-slate-500'}`}>
                      {control.label}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Risk Register */}
        <div className="mb-12">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <h4 className="font-bold text-slate-900 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-600" />
                Risk Register
              </h4>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Active Threats</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50/30 border-b border-slate-100">
                    <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Risk ID</th>
                    <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Description</th>
                    <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Score</th>
                    <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Owner</th>
                    <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {[
                    { id: 'R-001', desc: 'DDoS on API Gateway', score: 20, owner: 'CTO', status: 'Mitigated', color: 'bg-emerald-100 text-emerald-700' },
                    { id: 'R-003', desc: 'GPS Spoofing', score: 12, owner: 'Sec', status: 'Open', color: 'bg-rose-100 text-rose-700' }
                  ].map((risk) => (
                    <tr key={risk.id} className="hover:bg-slate-50/50 transition-colors">
                      <td className="px-6 py-4">
                        <span className="text-xs font-black text-slate-900">{risk.id}</span>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-xs font-bold text-slate-600">{risk.desc}</span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <div className="w-12 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                            <div 
                              className={`h-full ${risk.score >= 15 ? 'bg-rose-500' : 'bg-amber-500'}`} 
                              style={{ width: `${(risk.score / 25) * 100}%` }}
                            />
                          </div>
                          <span className="text-xs font-black text-slate-900">{risk.score}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-[10px] font-black px-2 py-1 bg-slate-100 rounded text-slate-600">{risk.owner}</span>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`text-[10px] font-black px-2 py-1 rounded-full uppercase tracking-tighter ${risk.color}`}>
                          {risk.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Model Complexity Risk Matrix */}
        <div className="mb-12">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <h4 className="font-bold text-slate-900 flex items-center gap-2">
                <PieChart className="w-4 h-4 text-blue-600" />
                Model Complexity Risk Matrix
              </h4>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">AI Risk Assessment</span>
            </div>
            <div className="p-8 flex flex-col items-center">
              <div className="relative inline-block">
                {/* Y-Axis Label */}
                <div className="absolute -left-12 top-1/2 -translate-y-1/2 -rotate-90 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                  Impact
                </div>
                
                {/* X-Axis Label */}
                <div className="text-center mb-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                  Model Complexity
                </div>

                <div className="grid grid-cols-5 gap-2">
                  {/* Header Row */}
                  <div className="w-16 h-10"></div>
                  {['Low', 'Med', 'High', 'Critical'].map(label => (
                    <div key={label} className="w-20 h-10 flex items-center justify-center text-[10px] font-black text-slate-500 uppercase">
                      {label}
                    </div>
                  ))}

                  {/* Matrix Rows */}
                  {[
                    { label: 'Low', values: ['L', 'L', 'M', 'M'] },
                    { label: 'Medium', values: ['L', 'M', 'M', 'H'] },
                    { label: 'High', values: ['M', 'M', 'H', 'C'] },
                    { label: 'Critical', values: ['M', 'H', 'C', 'C'] }
                  ].map((row) => (
                    <React.Fragment key={row.label}>
                      <div className="w-16 h-20 flex items-center justify-end pr-4 text-[10px] font-black text-slate-500 uppercase">
                        {row.label}
                      </div>
                      {row.values.map((val, idx) => (
                        <div 
                          key={idx} 
                          className={`w-20 h-20 rounded-xl flex flex-col items-center justify-center border-2 transition-all hover:scale-105 cursor-default
                            ${val === 'L' ? 'bg-emerald-50 border-emerald-100 text-emerald-700' : 
                              val === 'M' ? 'bg-amber-50 border-amber-100 text-amber-700' : 
                              val === 'H' ? 'bg-orange-50 border-orange-100 text-orange-700' : 
                              'bg-rose-50 border-rose-100 text-rose-700'}`}
                        >
                          <span className="text-xl font-black">{val}</span>
                          <span className="text-[8px] font-bold uppercase opacity-60">
                            {val === 'L' ? 'Low' : val === 'M' ? 'Medium' : val === 'H' ? 'High' : 'Critical'}
                          </span>
                        </div>
                      ))}
                    </React.Fragment>
                  ))}
                </div>
              </div>

              <div className="mt-8 flex gap-6">
                {[
                  { label: 'L: Low Risk', color: 'bg-emerald-500' },
                  { label: 'M: Medium Risk', color: 'bg-amber-500' },
                  { label: 'H: High Risk', color: 'bg-orange-500' },
                  { label: 'C: Critical Risk', color: 'bg-rose-500' }
                ].map(legend => (
                  <div key={legend.label} className="flex items-center gap-2">
                    <div className={`w-3 h-3 rounded-full ${legend.color}`} />
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-tighter">{legend.label}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Model Drift Monitoring Dashboard */}
        <div className="mb-12">
          <div className="bg-slate-900 rounded-3xl border border-slate-800 shadow-2xl overflow-hidden">
            {/* Header */}
            <div className="p-6 border-b border-slate-800 flex items-center justify-between bg-slate-900/50">
              <div>
                <h4 className="font-bold text-white flex items-center gap-2">
                  <Activity className="w-4 h-4 text-cyan-400" />
                  Model Drift Monitoring Dashboard
                </h4>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">
                  Model: Anomaly Detection Model (ADM v1.3)
                </p>
              </div>
              <div className="flex gap-2">
                <span className="px-2 py-1 bg-emerald-500/10 text-emerald-400 text-[10px] font-black rounded border border-emerald-500/20 uppercase">Live</span>
                <span className="px-2 py-1 bg-slate-800 text-slate-400 text-[10px] font-black rounded border border-slate-700 uppercase">v1.3.42</span>
              </div>
            </div>

            <div className="p-6 space-y-6">
              {/* ROW 1: High-Level Status */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-slate-800/50 rounded-2xl p-4 border border-slate-700 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center">
                      <Zap className="w-5 h-5 text-emerald-500" />
                    </div>
                    <div>
                      <div className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Performance</div>
                      <div className="text-sm font-bold text-white uppercase">Green</div>
                    </div>
                  </div>
                  <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.6)]" />
                </div>
                <div className="bg-slate-800/50 rounded-2xl p-4 border border-slate-700 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center">
                      <Activity className="w-5 h-5 text-amber-500" />
                    </div>
                    <div>
                      <div className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Drift Status</div>
                      <div className="text-sm font-bold text-white uppercase">Yellow</div>
                    </div>
                  </div>
                  <div className="w-2 h-2 rounded-full bg-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.6)]" />
                </div>
                <div className="bg-slate-800/50 rounded-2xl p-4 border border-slate-700 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-rose-500/10 flex items-center justify-center">
                      <Bell className="w-5 h-5 text-rose-500" />
                    </div>
                    <div>
                      <div className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Active Alerts</div>
                      <div className="text-sm font-bold text-white">3 Critical</div>
                    </div>
                  </div>
                  <div className="px-2 py-0.5 bg-rose-500 text-white text-[10px] font-black rounded-full">Action Required</div>
                </div>
              </div>

              {/* ROW 2: Performance Metrics */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[
                  { label: 'ROC-AUC (7d)', value: '0.92', trend: 'stable', color: 'text-emerald-400' },
                  { label: 'Precision@100 (7d)', value: '0.87', trend: '↓ 2%', color: 'text-amber-400' },
                  { label: 'Recall@100 (7d)', value: '0.81', trend: '↓ 4%', color: 'text-rose-400' }
                ].map((m, i) => (
                  <div key={i} className="bg-slate-800/30 rounded-2xl p-4 border border-slate-800/50">
                    <div className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">{m.label}</div>
                    <div className="flex items-end justify-between">
                      <div className="text-2xl font-black text-white">{m.value}</div>
                      <div className={`text-[10px] font-bold ${m.color} flex items-center gap-1`}>
                        {m.trend}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* ROW 3 & 4: Data Drift & Concept Drift */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Data Drift Heatmap */}
                <div className="bg-slate-800/30 rounded-2xl p-5 border border-slate-800/50">
                  <div className="flex items-center justify-between mb-4">
                    <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Feature Drift Heatmap</div>
                    <div className="text-[8px] text-slate-500 font-bold uppercase">Top 20 Features</div>
                  </div>
                  <div className="space-y-3">
                    {[
                      { name: 'Speed', shift: '+12%', status: 'warning', color: 'bg-amber-500' },
                      { name: 'RouteDeviation', shift: '+18%', status: 'critical', color: 'bg-rose-500' },
                      { name: 'EventTimeDelta', shift: '+3%', status: 'normal', color: 'bg-emerald-500' }
                    ].map((f, i) => (
                      <div key={i} className="flex items-center gap-4">
                        <div className="w-24 text-[10px] font-bold text-slate-400">{f.name}</div>
                        <div className="flex-1 h-1.5 bg-slate-700 rounded-full overflow-hidden">
                          <motion.div 
                            initial={{ width: 0 }}
                            animate={{ width: f.shift.replace('+', '') }}
                            className={`h-full ${f.color}`}
                          />
                        </div>
                        <div className="w-12 text-right text-[10px] font-black text-white">{f.shift}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Concept Drift */}
                <div className="bg-slate-800/30 rounded-2xl p-5 border border-slate-800/50">
                  <div className="flex items-center justify-between mb-4">
                    <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Concept Drift (30d)</div>
                    <div className="text-[8px] text-slate-500 font-bold uppercase">Prediction Distribution</div>
                  </div>
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <div className="p-1.5 bg-amber-500/10 rounded-lg">
                        <TrendingUp className="w-3 h-3 text-amber-500" />
                      </div>
                      <div>
                        <div className="text-[10px] font-bold text-white">Mean anomaly score trending upward</div>
                        <div className="text-[8px] text-slate-500 mt-0.5">Potential shift in baseline behavior detected</div>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="p-1.5 bg-rose-500/10 rounded-lg">
                        <AlertTriangle className="w-3 h-3 text-rose-500" />
                      </div>
                      <div>
                        <div className="text-[10px] font-bold text-white">FN rate increasing in Partner C corridor</div>
                        <div className="text-[8px] text-slate-500 mt-0.5">Model failing to identify known risk patterns</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* ROW 5: Partner Impact */}
              <div className="bg-slate-800/30 rounded-2xl border border-slate-800/50 overflow-hidden">
                <div className="px-5 py-3 border-b border-slate-800/50 bg-slate-800/20">
                  <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Partner Impact Analysis</div>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left">
                    <thead>
                      <tr className="border-b border-slate-800/50">
                        <th className="px-5 py-3 text-[8px] font-black text-slate-500 uppercase tracking-widest">Partner</th>
                        <th className="px-5 py-3 text-[8px] font-black text-slate-500 uppercase tracking-widest">FP Rate</th>
                        <th className="px-5 py-3 text-[8px] font-black text-slate-500 uppercase tracking-widest">FN Rate</th>
                        <th className="px-5 py-3 text-[8px] font-black text-slate-500 uppercase tracking-widest">Drift Score</th>
                        <th className="px-5 py-3 text-[8px] font-black text-slate-500 uppercase tracking-widest">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/30">
                      {[
                        { name: 'Partner A', fp: '1.2%', fn: '0.8%', drift: 'Low', status: 'Green', color: 'text-emerald-400' },
                        { name: 'Partner B', fp: '2.9%', fn: '1.7%', drift: 'Medium', status: 'Yellow', color: 'text-amber-400' },
                        { name: 'Partner C', fp: '4.8%', fn: '3.1%', drift: 'High', status: 'Red', color: 'text-rose-400' }
                      ].map((p, i) => (
                        <tr key={i} className="hover:bg-slate-800/20 transition-colors">
                          <td className="px-5 py-3 text-[10px] font-bold text-white">{p.name}</td>
                          <td className="px-5 py-3 text-[10px] text-slate-400">{p.fp}</td>
                          <td className="px-5 py-3 text-[10px] text-slate-400">{p.fn}</td>
                          <td className="px-5 py-3 text-[10px] font-bold text-slate-300">{p.drift}</td>
                          <td className="px-5 py-3">
                            <span className={`text-[8px] font-black px-2 py-0.5 rounded-full border border-current/20 ${p.color} uppercase`}>
                              {p.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* ROW 6: Alert Log */}
              <div className="bg-slate-800/30 rounded-2xl border border-slate-800/50 overflow-hidden">
                <div className="px-5 py-3 border-b border-slate-800/50 bg-slate-800/20 flex items-center justify-between">
                  <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Alert Log</div>
                  <div className="text-[8px] text-slate-500 font-bold uppercase">Last 24 Hours</div>
                </div>
                <div className="divide-y divide-slate-800/30">
                  {[
                    { time: '12:04 UTC', severity: 'High', desc: 'Feature drift >15% in route deviation', color: 'text-rose-400' },
                    { time: '09:22 UTC', severity: 'Medium', desc: 'FN spike in Partner C', color: 'text-amber-400' },
                    { time: '07:10 UTC', severity: 'Low', desc: 'Missing GPS accuracy field', color: 'text-blue-400' }
                  ].map((a, i) => (
                    <div key={i} className="px-5 py-3 flex items-center gap-4 hover:bg-slate-800/20 transition-colors">
                      <div className="text-[10px] font-mono text-slate-500 w-16">{a.time}</div>
                      <div className={`text-[8px] font-black px-2 py-0.5 rounded border border-current/20 ${a.color} uppercase w-16 text-center`}>
                        {a.severity}
                      </div>
                      <div className="text-[10px] font-medium text-slate-300">{a.desc}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Model Governance Executive Dashboard */}
        <div className="mb-12">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <h4 className="font-bold text-slate-900 flex items-center gap-2">
                <Target className="w-4 h-4 text-indigo-600" />
                Model Governance Executive Dashboard
              </h4>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Governance Oversight</span>
            </div>
            
            <div className="p-6 space-y-6">
              {/* SECTION 1: Governance Health */}
              <div>
                <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-3">Section 1 — Governance Health</div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {[
                    { label: 'Documentation Completeness', value: '96%', target: '100%', status: 'warning' },
                    { label: 'Validation Coverage', value: '88%', target: '95%', status: 'warning' },
                    { label: 'Models with Assigned Owners', value: '100%', target: '100%', status: 'success' }
                  ].map((kpi, i) => (
                    <div key={i} className="bg-slate-50 rounded-2xl p-4 border border-slate-100">
                      <div className="text-[10px] font-bold text-slate-500 mb-1">{kpi.label}</div>
                      <div className="flex items-end justify-between">
                        <div className={`text-xl font-black ${kpi.status === 'success' ? 'text-emerald-600' : 'text-amber-600'}`}>{kpi.value}</div>
                        <div className="text-[8px] font-black text-slate-400 uppercase">Target: {kpi.target}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* SECTION 2: Risk & Performance */}
              <div>
                <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-3">Section 2 — Risk & Performance</div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {[
                    { label: 'High-Risk Models', value: '3', target: '≤ 2', status: 'error' },
                    { label: 'Models in Drift', value: '2', target: '0', status: 'error' },
                    { label: 'FN Rate Deviation', value: '+6%', target: '≤ 5%', status: 'error' }
                  ].map((kpi, i) => (
                    <div key={i} className="bg-slate-50 rounded-2xl p-4 border border-slate-100">
                      <div className="text-[10px] font-bold text-slate-500 mb-1">{kpi.label}</div>
                      <div className="flex items-end justify-between">
                        <div className="text-xl font-black text-rose-600">{kpi.value}</div>
                        <div className="text-[8px] font-black text-slate-400 uppercase">Target: {kpi.target}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* SECTION 3: Fairness & Bias */}
              <div>
                <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-3">Section 3 — Fairness & Bias</div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {[
                    { label: 'Bias Flags', value: '1', target: '0', status: 'warning', icon: Scale },
                    { label: 'Fairness Tests Completed', value: '92%', target: '100%', status: 'warning', icon: ClipboardCheck },
                    { label: 'Mitigations in Progress', value: '2', target: '-', status: 'info', icon: Workflow }
                  ].map((kpi, i) => (
                    <div key={i} className="bg-slate-50 rounded-2xl p-4 border border-slate-100">
                      <div className="flex items-center gap-2 mb-1">
                        <kpi.icon className="w-3 h-3 text-slate-400" />
                        <div className="text-[10px] font-bold text-slate-500">{kpi.label}</div>
                      </div>
                      <div className="flex items-end justify-between">
                        <div className={`text-xl font-black ${kpi.status === 'warning' ? 'text-amber-600' : 'text-blue-600'}`}>{kpi.value}</div>
                        <div className="text-[8px] font-black text-slate-400 uppercase">Target: {kpi.target}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* SECTION 4: Security */}
              <div>
                <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-3">Section 4 — Security</div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {[
                    { label: 'Security Reviews Completed', value: '85%', target: '100%', status: 'warning' },
                    { label: 'Adversarial Test Coverage', value: '70%', target: '90%', status: 'warning' },
                    { label: 'Unauthorized Access Attempts', value: '0', target: '0', status: 'success' }
                  ].map((kpi, i) => (
                    <div key={i} className="bg-slate-50 rounded-2xl p-4 border border-slate-100">
                      <div className="text-[10px] font-bold text-slate-500 mb-1">{kpi.label}</div>
                      <div className="flex items-end justify-between">
                        <div className={`text-xl font-black ${kpi.status === 'success' ? 'text-emerald-600' : 'text-amber-600'}`}>{kpi.value}</div>
                        <div className="text-[8px] font-black text-slate-400 uppercase">Target: {kpi.target}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* SECTION 5: Operational */}
              <div>
                <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-3">Section 5 — Operational</div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {[
                    { label: 'Avg. Deployment Time', value: '3 days', target: '-', status: 'info', icon: Clock },
                    { label: 'Retraining Compliance', value: '78%', target: '90%', status: 'warning', icon: History },
                    { label: 'Incidents This Quarter', value: '1', target: '-', status: 'warning', icon: AlertCircle }
                  ].map((kpi, i) => (
                    <div key={i} className="bg-slate-50 rounded-2xl p-4 border border-slate-100">
                      <div className="flex items-center gap-2 mb-1">
                        <kpi.icon className="w-3 h-3 text-slate-400" />
                        <div className="text-[10px] font-bold text-slate-500">{kpi.label}</div>
                      </div>
                      <div className="flex items-end justify-between">
                        <div className={`text-xl font-black ${kpi.status === 'warning' ? 'text-amber-600' : 'text-blue-600'}`}>{kpi.value}</div>
                        <div className="text-[8px] font-black text-slate-400 uppercase">Target: {kpi.target}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Model Governance Hierarchy */}
        <div className="mb-12">
          <div className="bg-slate-50 rounded-3xl border border-slate-200 p-8 shadow-sm">
            <div className="text-center mb-10">
              <h3 className="text-xl font-black text-slate-900 uppercase tracking-[0.2em]">Model Governance Hierarchy</h3>
              <p className="text-slate-500 text-sm mt-2">Organizational oversight and functional accountability</p>
            </div>

            <div className="flex flex-col items-center gap-6">
              {/* Executive Risk Committee */}
              <div className="w-full max-w-md bg-slate-900 rounded-2xl p-5 text-white shadow-lg border border-white/10 text-center relative">
                <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-1">Level 1</div>
                <div className="text-sm font-black uppercase">Executive Risk Committee</div>
                <div className="text-[10px] text-slate-400 mt-1">Strategic Oversight & Risk Appetite</div>
                
                {/* Connector Down */}
                <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 w-px h-6 bg-slate-300" />
              </div>

              {/* Model Risk Committee (MRC) */}
              <div className="w-full max-w-md bg-white rounded-2xl p-5 border border-slate-200 shadow-sm text-center relative mt-2">
                <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-1">Level 2</div>
                <div className="text-sm font-black text-slate-900 uppercase">Model Risk Committee (MRC)</div>
                <div className="text-[10px] text-slate-500 mt-1">Policy Approval & High-Risk Review</div>
                
                {/* Connector Down */}
                <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 w-px h-6 bg-slate-300" />
              </div>

              {/* Model Review Board (MRB) */}
              <div className="w-full max-w-md bg-white rounded-2xl p-5 border border-slate-200 shadow-sm text-center relative mt-2">
                <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-1">Level 3</div>
                <div className="text-sm font-black text-slate-900 uppercase">Model Review Board (MRB)</div>
                <div className="text-[10px] text-slate-500 mt-1">Technical Validation & Compliance Check</div>
                
                {/* Connector Down */}
                <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 w-px h-6 bg-slate-300" />
              </div>

              {/* Functional Teams */}
              <div className="w-full mt-4">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {[
                    { title: 'Data Science', icon: Brain, color: 'text-blue-600 bg-blue-50' },
                    { title: 'Security', icon: Shield, color: 'text-rose-600 bg-rose-50' },
                    { title: 'Compliance', icon: ShieldCheck, color: 'text-emerald-600 bg-emerald-50' },
                    { title: 'Operations', icon: Settings, color: 'text-amber-600 bg-amber-50' }
                  ].map((team) => (
                    <div key={team.title} className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm flex flex-col items-center text-center gap-2">
                      <div className={`p-2 rounded-xl ${team.color}`}>
                        <team.icon className="w-5 h-5" />
                      </div>
                      <div className="text-[10px] font-black text-slate-900 uppercase tracking-tighter">{team.title}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Model Governance Platform Architecture */}
        <div className="mb-12">
          <div className="bg-slate-50 rounded-3xl border border-slate-200 p-8 shadow-sm">
            <div className="text-center mb-10">
              <h3 className="text-xl font-black text-slate-900 uppercase tracking-[0.2em]">Model Governance Platform</h3>
              <p className="text-slate-500 text-sm mt-2">End-to-end AI lifecycle governance and oversight</p>
            </div>

            <div className="flex flex-col gap-4">
              {/* Data Layer */}
              <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
                <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-4 text-center">Data Layer</div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {[
                    { title: 'Data Lake', icon: Database },
                    { title: 'Feature Store', icon: Cpu },
                    { title: 'Metadata Store', icon: Layers },
                    { title: 'Lineage Engine', icon: Network }
                  ].map((item) => (
                    <div key={item.title} className="bg-slate-50 rounded-xl p-3 border border-slate-100 flex flex-col items-center text-center gap-2">
                      <item.icon className="w-4 h-4 text-slate-600" />
                      <div className="text-[10px] font-bold text-slate-700">{item.title}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Model Layer */}
              <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
                <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-4 text-center">Model Layer</div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {[
                    { title: 'Model Registry', icon: ClipboardCheck },
                    { title: 'Experiment Tracking', icon: Activity },
                    { title: 'Version Control', icon: History }
                  ].map((item) => (
                    <div key={item.title} className="bg-slate-50 rounded-xl p-3 border border-slate-100 flex flex-col items-center text-center gap-2">
                      <item.icon className="w-4 h-4 text-slate-600" />
                      <div className="text-[10px] font-bold text-slate-700">{item.title}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Governance Layer */}
              <div className="bg-slate-900 rounded-2xl p-6 text-white shadow-lg border border-white/5">
                <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-4 text-center">Governance Layer</div>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {[
                    { title: 'Model Cards', icon: FileText },
                    { title: 'Validation Engine', icon: CheckCircle2 },
                    { title: 'Drift Detection', icon: Zap },
                    { title: 'Bias Testing', icon: Scale },
                    { title: 'Security Testing', icon: Shield },
                    { title: 'Monitoring Dashboards', icon: LayoutDashboard }
                  ].map((item) => (
                    <div key={item.title} className="bg-white/5 rounded-xl p-3 border border-white/10 flex flex-col items-center text-center gap-2">
                      <item.icon className="w-4 h-4 text-blue-400" />
                      <div className="text-[10px] font-bold">{item.title}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Workflow Layer */}
              <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
                <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-4 text-center">Workflow Layer</div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {[
                    { title: 'CI/CD Pipelines', icon: Code },
                    { title: 'Approval Workflows', icon: Workflow },
                    { title: 'Change Management', icon: Settings }
                  ].map((item) => (
                    <div key={item.title} className="bg-slate-50 rounded-xl p-3 border border-slate-100 flex flex-col items-center text-center gap-2">
                      <item.icon className="w-4 h-4 text-slate-600" />
                      <div className="text-[10px] font-bold text-slate-700">{item.title}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Integration Layer */}
              <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
                <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-4 text-center">Integration Layer</div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {[
                    { title: 'APIs', icon: Share2 },
                    { title: 'Event Bus', icon: Zap },
                    { title: 'Partner Systems', icon: Users },
                    { title: 'Logging & Telemetry', icon: Terminal }
                  ].map((item) => (
                    <div key={item.title} className="bg-slate-50 rounded-xl p-3 border border-slate-100 flex flex-col items-center text-center gap-2">
                      <item.icon className="w-4 h-4 text-slate-600" />
                      <div className="text-[10px] font-bold text-slate-700">{item.title}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* GRC Layer */}
              <div className="bg-blue-600 rounded-2xl p-6 text-white shadow-lg">
                <div className="text-[10px] font-black text-blue-200 uppercase tracking-[0.3em] mb-4 text-center">GRC Layer</div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {[
                    { title: 'Evidence Repository', icon: Database },
                    { title: 'Audit Logs', icon: History },
                    { title: 'Risk Register', icon: AlertTriangle },
                    { title: 'Policies', icon: BookOpen }
                  ].map((item) => (
                    <div key={item.title} className="bg-white/10 rounded-xl p-3 border border-white/20 flex flex-col items-center text-center gap-2">
                      <item.icon className="w-4 h-4 text-white" />
                      <div className="text-[10px] font-bold">{item.title}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Evidence Automation Layer */}
        <div className="mb-12">
          <div className="bg-slate-50 rounded-3xl border border-slate-200 p-8 shadow-sm">
            <div className="text-center mb-10">
              <h3 className="text-xl font-black text-slate-900 uppercase tracking-[0.2em]">Evidence Automation Layer</h3>
              <p className="text-slate-500 text-sm mt-2">Automated collection and validation of compliance artifacts</p>
            </div>

            <div className="flex flex-col gap-6">
              {/* Model Lifecycle Systems */}
              <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm relative">
                <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-4 text-center">Model Lifecycle Systems</div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {[
                    { title: 'Model Registry', icon: ClipboardCheck },
                    { title: 'Experiment Tracker', icon: Activity },
                    { title: 'CI/CD Pipelines', icon: Code }
                  ].map((item) => (
                    <div key={item.title} className="bg-slate-50 rounded-xl p-3 border border-slate-100 flex flex-col items-center text-center gap-2">
                      <item.icon className="w-4 h-4 text-slate-600" />
                      <div className="text-[10px] font-bold text-slate-700">{item.title}</div>
                    </div>
                  ))}
                </div>
                {/* Connector Down */}
                <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 w-px h-6 bg-slate-300" />
              </div>

              {/* Data & Monitoring Systems */}
              <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm relative mt-2">
                <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-4 text-center">Data & Monitoring Systems</div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {[
                    { title: 'Drift Engine', icon: Zap },
                    { title: 'Fairness Engine', icon: Scale },
                    { title: 'Security Testing', icon: Shield },
                    { title: 'Logging', icon: Terminal }
                  ].map((item) => (
                    <div key={item.title} className="bg-slate-50 rounded-xl p-3 border border-slate-100 flex flex-col items-center text-center gap-2">
                      <item.icon className="w-4 h-4 text-slate-600" />
                      <div className="text-[10px] font-bold text-slate-700">{item.title}</div>
                    </div>
                  ))}
                </div>
                {/* Connector Down */}
                <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 w-px h-6 bg-slate-300" />
              </div>

              {/* Automation Engine */}
              <div className="bg-indigo-600 rounded-2xl p-6 text-white shadow-lg relative mt-2">
                <div className="text-[10px] font-black text-indigo-200 uppercase tracking-[0.3em] mb-4 text-center">Automation Engine</div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {[
                    { title: 'Evidence Collector', icon: Database },
                    { title: 'Scheduler', icon: Clock },
                    { title: 'Validation Rules Engine', icon: CheckCircle2 }
                  ].map((item) => (
                    <div key={item.title} className="bg-white/10 rounded-xl p-3 border border-white/20 flex flex-col items-center text-center gap-2">
                      <item.icon className="w-4 h-4 text-white" />
                      <div className="text-[10px] font-bold">{item.title}</div>
                    </div>
                  ))}
                </div>
                {/* Connector Down */}
                <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 w-px h-6 bg-slate-300" />
              </div>

              {/* GRC Platform */}
              <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm mt-2">
                <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-4 text-center">GRC Platform</div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {[
                    { title: 'Evidence Repository', icon: Database },
                    { title: 'Audit Trail', icon: History },
                    { title: 'Compliance Dashboards', icon: LayoutDashboard }
                  ].map((item) => (
                    <div key={item.title} className="bg-slate-50 rounded-xl p-3 border border-slate-100 flex flex-col items-center text-center gap-2">
                      <item.icon className="w-4 h-4 text-slate-600" />
                      <div className="text-[10px] font-bold text-slate-700">{item.title}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Evidence Items */}
        <div className="mb-12">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <h4 className="font-bold text-slate-900 flex items-center gap-2">
                <FileText className="w-4 h-4 text-purple-600" />
                Evidence Repository
              </h4>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Compliance Artifacts</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50/30 border-b border-slate-100">
                    <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Evidence Item</th>
                    <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Control</th>
                    <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Date</th>
                    <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {[
                    { item: 'MFA Screenshot', control: 'CC6.1', date: 'Apr 8', status: 'Verified', color: 'text-emerald-600 bg-emerald-50' },
                    { item: 'Firewall Config', control: 'CC6.6', date: 'Apr 7', status: 'Pending', color: 'text-amber-600 bg-amber-50' },
                    { item: 'Pen Test Report', control: 'CC7.1', date: 'Apr 1', status: 'Verified', color: 'text-emerald-600 bg-emerald-50' }
                  ].map((evidence, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/50 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <FileText className="w-3.5 h-3.5 text-slate-400" />
                          <span className="text-xs font-bold text-slate-900">{evidence.item}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-[10px] font-black px-2 py-1 bg-slate-100 rounded text-slate-600">{evidence.control}</span>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-xs font-medium text-slate-500">{evidence.date}</span>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`text-[10px] font-black px-2 py-1 rounded-full uppercase tracking-tighter ${evidence.color}`}>
                          {evidence.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Partner Performance */}
        <div className="mb-12">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <h4 className="font-bold text-slate-900 flex items-center gap-2">
                <Users className="w-4 h-4 text-cyan-600" />
                Partner Performance
              </h4>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Federated Ecosystem</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50/30 border-b border-slate-100">
                    <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Partner</th>
                    <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Tier</th>
                    <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">SLA</th>
                    <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Security</th>
                    <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Data Quality</th>
                    <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Risk</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {[
                    { name: 'Partner A', tier: '1', sla: '98%', security: '92%', quality: '99%', risk: 'Low', color: 'text-emerald-600 bg-emerald-50' },
                    { name: 'Partner B', tier: '2', sla: '87%', security: '78%', quality: '91%', risk: 'Med', color: 'text-amber-600 bg-amber-50' },
                    { name: 'Partner C', tier: '3', sla: '62%', security: '55%', quality: '70%', risk: 'High', color: 'text-rose-600 bg-rose-50' }
                  ].map((p, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/50 transition-colors">
                      <td className="px-6 py-4">
                        <span className="text-xs font-black text-slate-900">{p.name}</span>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-[10px] font-black px-2 py-1 bg-slate-100 rounded text-slate-600">Tier {p.tier}</span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <div className="w-12 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                            <div 
                              className={`h-full ${parseInt(p.sla) > 90 ? 'bg-emerald-500' : parseInt(p.sla) > 70 ? 'bg-amber-500' : 'bg-rose-500'}`} 
                              style={{ width: p.sla }}
                            />
                          </div>
                          <span className="text-xs font-black text-slate-900">{p.sla}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-xs font-bold text-slate-600">{p.security}</span>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-xs font-bold text-slate-600">{p.quality}</span>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`text-[10px] font-black px-2 py-1 rounded-full uppercase tracking-tighter ${p.color}`}>
                          {p.risk}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Partner Portal — Home */}
        <div className="mb-12">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <h4 className="font-bold text-slate-900 flex items-center gap-2">
                <Globe className="w-4 h-4 text-blue-600" />
                Partner Portal — Home
              </h4>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">External Access</span>
            </div>
            
            <div className="p-8">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
                <div>
                  <h3 className="text-xl font-black text-slate-900">Welcome, PartnerName Co.</h3>
                  <p className="text-slate-500 text-xs font-medium mt-1 flex items-center gap-2">
                    <Clock className="w-3 h-3" />
                    Last Login: April 10, 2026
                  </p>
                </div>
                <div className="flex gap-2">
                  {[
                    { label: 'Alerts', icon: Bell, color: 'bg-rose-50 text-rose-600' },
                    { label: 'Fairness', icon: Scale, color: 'bg-amber-50 text-amber-600' },
                    { label: 'Drift', icon: Zap, color: 'bg-blue-50 text-blue-600' },
                    { label: 'Reports', icon: FileText, color: 'bg-slate-50 text-slate-600' }
                  ].map((btn) => (
                    <button key={btn.label} className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2 transition-all hover:scale-105 active:scale-95 ${btn.color}`}>
                      <btn.icon className="w-3.5 h-3.5" />
                      {btn.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="bg-slate-50 rounded-2xl p-6 border border-slate-100">
                <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4">Quick Stats</div>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                  {[
                    { label: 'Alerts This Week', value: '4', icon: Bell, color: 'text-rose-600' },
                    { label: 'High-Severity Alerts', value: '1', icon: AlertTriangle, color: 'text-rose-700' },
                    { label: 'FN/FP Deviation', value: '+3%', icon: Activity, color: 'text-amber-600' },
                    { label: 'Corridor Drift', value: 'Normal', icon: Zap, color: 'text-emerald-600' }
                  ].map((stat) => (
                    <div key={stat.label} className="flex flex-col gap-1">
                      <div className="flex items-center gap-2 text-[10px] font-bold text-slate-500 uppercase tracking-tighter">
                        <stat.icon className={`w-3 h-3 ${stat.color}`} />
                        {stat.label}
                      </div>
                      <div className={`text-xl font-black ${stat.color}`}>{stat.value}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ALERTS */}
        <div className="mb-12">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <h4 className="font-bold text-slate-900 flex items-center gap-2">
                <Bell className="w-4 h-4 text-rose-600" />
                ALERTS
              </h4>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Real-time Monitoring</span>
            </div>
            
            <div className="p-6 border-b border-slate-100 bg-slate-50/30 flex gap-2">
              {['Severity', 'Corridor', 'Date Range'].map((filter) => (
                <button key={filter} className="px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-[10px] font-bold text-slate-600 uppercase tracking-tighter flex items-center gap-2 hover:border-slate-300 transition-colors">
                  {filter}
                  <ChevronDown className="w-3 h-3 text-slate-400" />
                </button>
              ))}
            </div>

            <div className="divide-y divide-slate-100">
              {[
                {
                  id: '1241',
                  severity: 'High',
                  reasonCode: 'ROUTE_DEVIATION_HIGH',
                  anomalyScore: 0.94,
                  factors: ['Speed', 'RouteDeviation', 'EventTimeDelta'],
                  contributions: { speed: 0.42, routeDeviation: 0.33, eventTimeDelta: 0.18 },
                  explanation: "The event was flagged due to abnormal speed and route deviation.",
                  action: 'Verify courier route',
                  color: 'text-rose-600 bg-rose-50 border-rose-100'
                },
                {
                  id: '1238',
                  severity: 'Medium',
                  reasonCode: 'LATENCY_SPIKE',
                  anomalyScore: 0.78,
                  factors: ['NetworkLatency', 'ProcessingTime'],
                  action: 'Check regional node health',
                  color: 'text-amber-600 bg-amber-50 border-amber-100'
                }
              ].map((alert) => (
                <div key={alert.id} className="p-6 hover:bg-slate-50/50 transition-colors">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className={`px-2 py-1 rounded text-[10px] font-black uppercase tracking-widest border ${alert.color}`}>
                        {alert.severity}
                      </div>
                      <h5 className="font-black text-slate-900">Alert #{alert.id}</h5>
                    </div>
                    <button className="text-[10px] font-black text-blue-600 uppercase tracking-widest hover:underline">
                      View Details
                    </button>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-bold text-slate-400 uppercase w-32">Reason Code:</span>
                        <span className="text-xs font-mono font-bold text-slate-700">{alert.reasonCode}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-bold text-slate-400 uppercase w-32">Anomaly Score:</span>
                        <span className="text-xs font-black text-slate-900">{alert.anomalyScore}</span>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-start gap-2">
                        <span className="text-[10px] font-bold text-slate-400 uppercase w-32 pt-0.5">Top Factors:</span>
                        <div className="flex flex-wrap gap-1">
                          {alert.factors.map(f => (
                            <span key={f} className="text-[9px] font-bold px-1.5 py-0.5 bg-slate-100 text-slate-600 rounded">
                              {f}
                            </span>
                          ))}
                        </div>
                      </div>
                      {alert.contributions && (
                        <div className="flex flex-col gap-1 mt-2">
                          <span className="text-[10px] font-bold text-slate-400 uppercase">Feature Contributions:</span>
                          <div className="space-y-1">
                            {Object.entries(alert.contributions).map(([feature, value]) => (
                              <div key={feature} className="flex items-center gap-2">
                                <span className="text-[9px] font-bold text-slate-500 w-24 truncate">{feature}</span>
                                <div className="flex-1 h-1 bg-slate-100 rounded-full overflow-hidden">
                                  <div className="h-full bg-blue-500" style={{ width: `${(value as number) * 100}%` }} />
                                </div>
                                <span className="text-[9px] font-mono font-bold text-slate-700">{(value as number).toFixed(2)}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-bold text-slate-400 uppercase w-32">Recommended Action:</span>
                        <span className="text-xs font-bold text-slate-600 italic">{alert.action}</span>
                      </div>
                      {alert.explanation && (
                        <div className="mt-2 p-2 bg-slate-50 rounded border border-slate-100">
                          <span className="text-[9px] font-bold text-slate-400 uppercase block mb-1">Explanation:</span>
                          <p className="text-[10px] text-slate-600 leading-relaxed">{alert.explanation}</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* FAIRNESS & BIAS DASHBOARD */}
        <div className="mb-12">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <h4 className="font-bold text-slate-900 flex items-center gap-2">
                <Scale className="w-4 h-4 text-amber-600" />
                FAIRNESS & BIAS DASHBOARD
              </h4>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Parity Monitoring</span>
            </div>
            
            <div className="p-8">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
                {[
                  { label: 'FN Rate vs Network Baseline', value: '+4%', status: 'warning', icon: TrendingUp },
                  { label: 'FP Rate vs Network Baseline', value: '+2%', status: 'success', icon: TrendingUp },
                  { label: 'Bias Flags', value: 'None', status: 'success', icon: ShieldCheck }
                ].map((stat, i) => (
                  <div key={i} className="bg-slate-50 rounded-2xl p-5 border border-slate-100 flex flex-col gap-2">
                    <div className="flex items-center gap-2 text-[10px] font-bold text-slate-500 uppercase tracking-tighter">
                      <stat.icon className={`w-3.5 h-3.5 ${stat.status === 'success' ? 'text-emerald-500' : 'text-amber-500'}`} />
                      {stat.label}
                    </div>
                    <div className={`text-2xl font-black ${stat.status === 'success' ? 'text-emerald-600' : 'text-amber-600'}`}>
                      {stat.value}
                    </div>
                  </div>
                ))}
              </div>

              <div>
                <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-6 border-b border-slate-100 pb-2">Group Comparison</div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {[
                    { 
                      title: 'Urban vs Rural', 
                      metrics: [
                        { label: 'Urban FN', value: '0.08' },
                        { label: 'Rural FN', value: '0.12' },
                        { label: 'Parity Gap', value: '0.04', highlight: true }
                      ]
                    },
                    { 
                      title: 'Corridor-level fairness', 
                      metrics: [
                        { label: 'East Corridor', value: '0.92' },
                        { label: 'West Corridor', value: '0.91' },
                        { label: 'Variance', value: '0.01', highlight: false }
                      ]
                    },
                    { 
                      title: 'Partner-specific parity', 
                      metrics: [
                        { label: 'Partner FN Rate', value: '0.012' },
                        { label: 'Network Baseline', value: '0.011' },
                        { label: 'Bias Flag', value: 'None', highlight: false }
                      ]
                    }
                  ].map((group, i) => (
                    <div key={i} className="space-y-4">
                      <div className="text-xs font-black text-slate-900 flex items-center gap-2">
                        <div className="w-1 h-4 bg-indigo-500 rounded-full" />
                        {group.title}
                      </div>
                      <div className="space-y-3">
                        {group.metrics.map((m, j) => (
                          <div key={j} className="flex items-center justify-between text-[11px]">
                            <span className="font-bold text-slate-500">{m.label}</span>
                            <span className={`font-mono font-black ${m.highlight ? 'text-amber-600' : 'text-slate-900'}`}>{m.value}</span>
                          </div>
                        ))}
                      </div>
                      <div className="pt-2">
                        <div className="w-full h-1 bg-slate-100 rounded-full overflow-hidden">
                          <div className="w-3/4 h-full bg-indigo-500/20" />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* DRIFT MONITORING */}
        <div className="mb-12">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <h4 className="font-bold text-slate-900 flex items-center gap-2">
                <Zap className="w-4 h-4 text-blue-600" />
                DRIFT MONITORING
              </h4>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Model Stability</span>
            </div>
            
            <div className="p-8 grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Feature Drift (Top 5) */}
              <div>
                <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
                  <Activity className="w-3 h-3" />
                  Feature Drift (Top 5)
                </div>
                <div className="space-y-3">
                  {[
                    { feature: 'RouteDeviation', drift: '+8%', status: 'Normal', color: 'text-emerald-600 bg-emerald-50' },
                    { feature: 'Speed', drift: '+12%', status: 'Warning', color: 'text-amber-600 bg-amber-50' },
                    { feature: 'HubCode', drift: '+3%', status: 'Normal', color: 'text-emerald-600 bg-emerald-50' }
                  ].map((item, i) => (
                    <div key={i} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-100">
                      <div className="flex flex-col">
                        <span className="text-xs font-black text-slate-900">{item.feature}</span>
                        <span className="text-[10px] font-bold text-slate-500">{item.drift} shift</span>
                      </div>
                      <span className={`text-[10px] font-black px-2 py-1 rounded-full uppercase tracking-tighter ${item.color}`}>
                        {item.status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Concept Drift */}
              <div>
                <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
                  <TrendingUp className="w-3 h-3" />
                  Concept Drift
                </div>
                <div className="space-y-4">
                  {[
                    { label: 'Anomaly Score Mean Shift', value: '0.03', icon: Gauge },
                    { label: 'FN/FP Trend', value: 'Stable', icon: Activity }
                  ].map((item, i) => (
                    <div key={i} className="flex items-center justify-between p-4 bg-slate-900 rounded-2xl text-white shadow-lg">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-white/10 rounded-lg">
                          <item.icon className="w-4 h-4 text-blue-400" />
                        </div>
                        <span className="text-xs font-bold">{item.label}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
                        <span className="text-xs font-black uppercase tracking-widest text-emerald-400">{item.value}</span>
                      </div>
                    </div>
                  ))}
                  
                  <div className="mt-6 p-4 border border-dashed border-slate-200 rounded-2xl">
                    <div className="text-[10px] font-bold text-slate-400 uppercase mb-2">Monitoring Status</div>
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                      <span className="text-xs font-medium text-slate-600">Continuous validation active</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* REPORTS */}
        <div className="mb-12">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <h4 className="font-bold text-slate-900 flex items-center gap-2">
                <FileText className="w-4 h-4 text-indigo-600" />
                REPORTS
              </h4>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Compliance Documentation</span>
            </div>
            
            <div className="p-8">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[
                  { title: 'Q1 Transparency Report', size: '2.4 MB', date: 'Apr 1, 2026' },
                  { title: 'Fairness Report', size: '1.8 MB', date: 'Mar 28, 2026' },
                  { title: 'Drift Summary', size: '940 KB', date: 'Apr 9, 2026' }
                ].map((report, i) => (
                  <button 
                    key={i} 
                    className="group p-6 bg-slate-50 rounded-2xl border border-slate-100 flex flex-col items-start gap-4 transition-all hover:bg-white hover:shadow-md hover:border-indigo-200 text-left"
                  >
                    <div className="p-3 bg-white rounded-xl shadow-sm group-hover:bg-indigo-50 transition-colors">
                      <FileText className="w-5 h-5 text-indigo-600" />
                    </div>
                    <div>
                      <div className="text-sm font-black text-slate-900 mb-1">{report.title}</div>
                      <div className="flex items-center gap-3 text-[10px] font-bold text-slate-400 uppercase tracking-tighter">
                        <span>{report.size}</span>
                        <span className="w-1 h-1 bg-slate-200 rounded-full" />
                        <span>{report.date}</span>
                      </div>
                    </div>
                    <div className="mt-2 flex items-center gap-2 text-[10px] font-black text-indigo-600 uppercase tracking-widest group-hover:translate-x-1 transition-transform">
                      Download Report
                      <ArrowRight className="w-3 h-3" />
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* MODEL RISK APPETITE DASHBOARD */}
        <div className="mb-12">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <h4 className="font-bold text-slate-900 flex items-center gap-2">
                <Target className="w-4 h-4 text-indigo-600" />
                MODEL RISK APPETITE DASHBOARD
              </h4>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Strategic Alignment</span>
            </div>
            
            <div className="p-8">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* SECTION 1 — RISK APPETITE LIMITS */}
                <div className="bg-slate-50 rounded-2xl p-6 border border-slate-100">
                  <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
                    <Shield className="w-3 h-3 text-slate-400" />
                    SECTION 1 — RISK APPETITE LIMITS
                  </div>
                  <div className="space-y-3">
                    {[
                      { label: 'FN Rate Deviation Limit', value: '≤ 20%' },
                      { label: 'FP Rate Deviation Limit', value: '≤ 25%' },
                      { label: 'PSI Drift Limit', value: '≤ 0.2' },
                      { label: 'Bias Threshold', value: '≤ 2× baseline' },
                      { label: 'Security Incident Tolerance', value: '0 critical' }
                    ].map((limit, i) => (
                      <div key={i} className="flex items-center justify-between py-2 border-b border-slate-200 last:border-0">
                        <span className="text-xs font-bold text-slate-600">{limit.label}</span>
                        <span className="text-xs font-mono font-black text-slate-900 bg-white px-2 py-1 rounded border border-slate-200 shadow-sm">
                          {limit.value}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* SECTION 2 — CURRENT RISK EXPOSURE */}
                <div className="bg-slate-900 rounded-2xl p-6 text-white shadow-xl border border-white/5">
                  <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
                    <Activity className="w-3 h-3 text-blue-400" />
                    SECTION 2 — CURRENT RISK EXPOSURE
                  </div>
                  <div className="space-y-4">
                    {[
                      { label: 'FN Rate Deviation', value: '+6%', status: 'Within Appetite', color: 'text-emerald-400' },
                      { label: 'FP Rate Deviation', value: '+12%', status: 'Within Appetite', color: 'text-emerald-400' },
                      { label: 'PSI Drift', value: '0.18', status: 'Approaching Limit', color: 'text-amber-400' },
                      { label: 'Bias Flags', value: '1', status: 'Outside Appetite', color: 'text-rose-400' },
                      { label: 'Security Incidents', value: '0', status: 'Within Appetite', color: 'text-emerald-400' }
                    ].map((exposure, i) => (
                      <div key={i} className="flex items-center justify-between">
                        <div>
                          <div className="text-xs font-bold text-slate-300">{exposure.label}</div>
                          <div className="text-lg font-black">{exposure.value}</div>
                        </div>
                        <div className={`text-[10px] font-black uppercase tracking-widest px-2 py-1 rounded-full bg-white/5 border border-white/10 ${exposure.color}`}>
                          {exposure.status}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* SECTION 3 — TREND ANALYSIS */}
                <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
                  <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
                    <TrendingUp className="w-3 h-3 text-indigo-500" />
                    SECTION 3 — TREND ANALYSIS
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {[
                      { label: 'Drift Trend', value: '↑', desc: 'Moderate Increase', color: 'text-amber-600 bg-amber-50' },
                      { label: 'Fairness Trend', value: 'Stable', desc: 'No Change', color: 'text-emerald-600 bg-emerald-50' },
                      { label: 'Security Trend', value: 'Stable', desc: 'No Change', color: 'text-emerald-600 bg-emerald-50' }
                    ].map((trend, i) => (
                      <div key={i} className={`p-4 rounded-xl border flex flex-col items-center text-center gap-1 ${trend.color.split(' ').slice(1).join(' ')} ${trend.color.split(' ')[0].replace('text-', 'border-')}/20`}>
                        <div className="text-[10px] font-bold text-slate-500 uppercase">{trend.label}</div>
                        <div className={`text-xl font-black ${trend.color.split(' ')[0]}`}>{trend.value}</div>
                        <div className="text-[9px] font-bold text-slate-400">{trend.desc}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* SECTION 4 — ACTIONS REQUIRED */}
                <div className="bg-rose-50 rounded-2xl p-6 border border-rose-100">
                  <div className="text-[10px] font-black text-rose-400 uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
                    <AlertCircle className="w-3 h-3" />
                    SECTION 4 — ACTIONS REQUIRED
                  </div>
                  <ul className="space-y-3">
                    {[
                      'Investigate bias flag in Corridor 7',
                      'Recalibrate drift thresholds',
                      'Expand adversarial testing'
                    ].map((action, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <div className="w-1.5 h-1.5 rounded-full bg-rose-400 mt-1.5 shrink-0" />
                        <span className="text-xs font-bold text-rose-900">{action}</span>
                      </li>
                    ))}
                  </ul>
                  <button className="mt-6 w-full py-3 bg-rose-600 text-white rounded-xl text-[10px] font-black uppercase tracking-[0.2em] hover:bg-rose-700 transition-colors shadow-lg shadow-rose-200">
                    Initiate Remediation Workflow
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* MODEL GOVERNANCE HIERARCHY */}
        <div className="mb-12">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <h4 className="font-bold text-slate-900 flex items-center gap-2">
                <Users className="w-4 h-4 text-indigo-600" />
                MODEL GOVERNANCE HIERARCHY
              </h4>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Organizational Oversight</span>
            </div>
            
            <div className="p-12 flex flex-col items-center">
              {[
                { name: 'Executive Steering Committee (ESC)', icon: LayoutDashboard, color: 'bg-slate-900 text-white' },
                { name: 'Model Risk Committee (MRC)', icon: UserCheck, color: 'bg-indigo-600 text-white' },
                { name: 'Model Review Board (MRB)', icon: ClipboardCheck, color: 'bg-indigo-500 text-white' },
                { name: 'Model Governance Office (MGO)', icon: ShieldCheck, color: 'bg-indigo-400 text-white' }
              ].map((level, i, arr) => (
                <React.Fragment key={level.name}>
                  <div className={`w-full max-w-md p-5 rounded-2xl ${level.color} shadow-lg flex items-center gap-4 border border-white/10`}>
                    <div className="p-2 bg-white/10 rounded-xl">
                      <level.icon className="w-5 h-5" />
                    </div>
                    <span className="text-sm font-black uppercase tracking-wider">{level.name}</span>
                  </div>
                  {i < arr.length && (
                    <div className="py-4">
                      <ArrowDown className="w-5 h-5 text-slate-300" />
                    </div>
                  )}
                </React.Fragment>
              ))}

              <div className="w-full max-w-4xl mt-4">
                <div className="h-px bg-slate-200 w-full mb-8 relative">
                  <div className="absolute left-1/2 -top-1 -translate-x-1/2 w-2 h-2 bg-slate-200 rounded-full" />
                </div>
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {[
                    { name: 'Data Science', icon: Brain, color: 'text-blue-600 bg-blue-50 border-blue-100' },
                    { name: 'Security', icon: Shield, color: 'text-rose-600 bg-rose-50 border-rose-100' },
                    { name: 'Compliance', icon: Scale, color: 'text-amber-600 bg-amber-50 border-amber-100' },
                    { name: 'Operations', icon: Activity, color: 'text-emerald-600 bg-emerald-50' }
                  ].map((team) => (
                    <div key={team.name} className={`p-4 rounded-xl border flex flex-col items-center text-center gap-3 shadow-sm ${team.color}`}>
                      <div className="p-2 bg-white rounded-lg shadow-sm">
                        <team.icon className="w-4 h-4" />
                      </div>
                      <span className="text-[10px] font-black uppercase tracking-widest">{team.name}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* GOVERNANCE LEADERSHIP & TEAM STRUCTURE */}
        <div className="mb-12">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-indigo-600 rounded-lg text-white">
                  <Users className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 uppercase tracking-tight">GOVERNANCE LEADERSHIP & TEAM STRUCTURE</h4>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Global, Regional & Operational Oversight</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="px-3 py-1 bg-slate-100 text-slate-600 text-[9px] font-black uppercase tracking-widest rounded-full border border-slate-200">
                  Active Personnel
                </div>
              </div>
            </div>

            <div className="p-8">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 relative">
                {/* Connecting Lines (Desktop Only) */}
                <div className="hidden lg:block absolute top-1/2 left-[30%] right-[30%] h-px bg-slate-100 -translate-y-1/2 z-0" />
                
                {/* GLOBAL GOVERNANCE LEADERSHIP */}
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="relative z-10 space-y-6"
                >
                  <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] pb-2 border-b border-slate-100 flex items-center justify-between">
                    <span>Global Leadership</span>
                    <Globe className="w-3 h-3" />
                  </div>
                  <div className="p-6 rounded-2xl bg-slate-900 text-white shadow-xl border border-white/10">
                    <div className="space-y-4">
                      {[
                        'Global Head of Model Governance',
                        'Global Head of AI Security',
                        'Global Head of Compliance & Regulatory Affairs',
                        'Global Partner Governance Lead'
                      ].map((role, i) => (
                        <div key={i} className="flex items-center gap-3 group">
                          <div className="w-1.5 h-1.5 rounded-full bg-indigo-400 group-hover:scale-150 transition-transform" />
                          <span className="text-xs font-bold tracking-tight">{role}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>

                {/* REGIONAL GOVERNANCE TEAMS */}
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 }}
                  className="relative z-10 space-y-6"
                >
                  <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] pb-2 border-b border-slate-100 flex items-center justify-between">
                    <span>Regional Teams (EU, US, APAC, LATAM)</span>
                    <Map className="w-3 h-3" />
                  </div>
                  <div className="p-6 rounded-2xl bg-indigo-50 border border-indigo-100 shadow-sm">
                    <div className="space-y-4">
                      {[
                        'Regional Model Governance Managers',
                        'Regional Compliance Officers',
                        'Regional Security Analysts',
                        'Regional Partner Governance Managers'
                      ].map((role, i) => (
                        <div key={i} className="flex items-center gap-3 group">
                          <div className="w-1.5 h-1.5 rounded-full bg-indigo-500 group-hover:scale-150 transition-transform" />
                          <span className="text-xs font-bold text-indigo-900 tracking-tight">{role}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>

                {/* MODEL LIFECYCLE TEAMS */}
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  className="relative z-10 space-y-6"
                >
                  <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] pb-2 border-b border-slate-100 flex items-center justify-between">
                    <span>Model Lifecycle Teams</span>
                    <Cpu className="w-3 h-3" />
                  </div>
                  <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm">
                    <div className="space-y-4">
                      {[
                        'Model Owners',
                        'Data Scientists',
                        'ML Engineers',
                        'Data Engineers',
                        'Validation & QA Specialists'
                      ].map((role, i) => (
                        <div key={i} className="flex items-center gap-3 group">
                          <div className="w-1.5 h-1.5 rounded-full bg-slate-400 group-hover:scale-150 transition-transform" />
                          <span className="text-xs font-bold text-slate-700 tracking-tight">{role}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              </div>
            </div>
          </div>
        </div>

        {/* ENTERPRISE MODEL GOVERNANCE DASHBOARD */}
        <div className="mb-12">
          <div className="bg-slate-900 rounded-[2.5rem] p-10 shadow-2xl border border-white/10 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 blur-[120px] rounded-full -mr-48 -mt-48" />
            <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-500/10 blur-[120px] rounded-full -ml-48 -mb-48" />
            
            <div className="relative z-10">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
                <div>
                  <h3 className="text-2xl font-black text-white uppercase tracking-[0.4em]">Enterprise Model Governance</h3>
                  <p className="text-slate-400 text-sm mt-2 font-medium">Global Command Center — Real-time Oversight & Control</p>
                </div>
                <div className="flex items-center gap-4">
                  <div className="px-4 py-2 bg-white/5 border border-white/10 rounded-xl flex items-center gap-3">
                    <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
                    <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">System Status: Optimal</span>
                  </div>
                  <div className="px-4 py-2 bg-indigo-600 rounded-xl text-white text-[10px] font-black uppercase tracking-widest shadow-lg shadow-indigo-500/20">
                    Q1 2026 Report
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 xl:grid-cols-7 gap-4">
                {[
                  { label: 'Governance Health', value: '98.2%', trend: '+0.4%', icon: ShieldCheck, color: 'text-blue-400' },
                  { label: 'Risk & Performance', value: 'Low', trend: 'Stable', icon: Activity, color: 'text-emerald-400' },
                  { label: 'Fairness', value: 'Within Parity', trend: 'Optimal', icon: Scale, color: 'text-purple-400' },
                  { label: 'Security', value: 'Hardened', trend: 'No Gaps', icon: Lock, color: 'text-rose-400' },
                  { label: 'Operational Metrics', value: '99.9%', trend: 'Uptime', icon: Zap, color: 'text-amber-400' },
                  { label: 'Regional Breakdown', value: 'Global', trend: '4 Regions', icon: Globe, color: 'text-indigo-400' },
                  { label: 'Partner Impact', value: '96.4%', trend: 'SLA Compliant', icon: Handshake, color: 'text-blue-400' }
                ].map((metric, i) => (
                  <motion.div 
                    key={i}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.05 }}
                    className="bg-white/5 border border-white/10 rounded-2xl p-5 hover:bg-white/10 transition-all group cursor-pointer"
                  >
                    <div className={`p-2 rounded-lg bg-white/5 border border-white/10 ${metric.color} mb-4 group-hover:scale-110 transition-transform w-fit`}>
                      <metric.icon className="w-4 h-4" />
                    </div>
                    <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">{metric.label}</div>
                    <div className="text-lg font-black text-white mb-1">{metric.value}</div>
                    <div className="text-[9px] font-bold text-slate-500 uppercase tracking-tighter">{metric.trend}</div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* ENTERPRISE MODEL GOVERNANCE ARCHITECTURE */}
        <div className="mb-12">
          <div className="bg-slate-50 rounded-3xl border border-slate-200 p-8 shadow-sm">
            <div className="text-center mb-10">
              <h3 className="text-xl font-black text-slate-900 uppercase tracking-[0.2em]">Enterprise Model Governance Architecture</h3>
              <p className="text-slate-500 text-sm mt-2">Multi-layered strategic and operational framework</p>
            </div>

            <div className="flex flex-col gap-6">
              {/* GOVERNANCE LAYER */}
              <div className="bg-slate-900 rounded-2xl p-6 text-white shadow-lg border border-white/5">
                <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-4 text-center">GOVERNANCE LAYER</div>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                  {[
                    { title: 'ESC', desc: 'Executive Steering', icon: LayoutDashboard },
                    { title: 'MRC', desc: 'Model Risk Committee', icon: AlertTriangle },
                    { title: 'MRB', desc: 'Model Review Board', icon: ClipboardCheck },
                    { title: 'Risk Register', desc: 'Active Threat Tracking', icon: AlertCircle },
                    { title: 'Policy Engine', desc: 'Automated Guardrails', icon: Settings },
                    { title: 'Audit Readiness', desc: 'Compliance Platform', icon: ShieldCheck }
                  ].map((item) => (
                    <div key={item.title} className="bg-white/5 rounded-xl p-4 border border-white/10 flex flex-col items-center text-center gap-2 group hover:bg-white/10 transition-colors">
                      <div className="p-2 bg-white/10 rounded-lg group-hover:scale-110 transition-transform">
                        <item.icon className="w-4 h-4 text-blue-400" />
                      </div>
                      <div>
                        <div className="text-[10px] font-black uppercase tracking-tight">{item.title}</div>
                        <div className="text-[8px] text-slate-400 font-bold uppercase tracking-tighter">{item.desc}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* GOVERNANCE PLATFORM LAYER */}
              <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
                <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-4 text-center">GOVERNANCE PLATFORM LAYER</div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {[
                    { title: 'Model Registry', icon: Layers },
                    { title: 'Model Cards', icon: FileText },
                    { title: 'Validation Engine', icon: CheckCircle2 },
                    { title: 'Fairness Engine', icon: Scale },
                    { title: 'Drift Detection', icon: Zap },
                    { title: 'Security Testing Suite', icon: Shield },
                    { title: 'Evidence Automation', icon: Workflow },
                    { title: 'GRC Bridge', icon: Link }
                  ].map((item) => (
                    <div key={item.title} className="bg-slate-50 rounded-xl p-3 border border-slate-100 flex items-center gap-3 hover:border-indigo-200 transition-colors">
                      <item.icon className="w-4 h-4 text-indigo-600" />
                      <div className="text-[10px] font-bold text-slate-700">{item.title}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* ML PLATFORM LAYER */}
              <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
                <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-4 text-center">ML PLATFORM LAYER</div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {[
                    { title: 'Feature Store', icon: Database },
                    { title: 'Experiment Tracking', icon: Activity },
                    { title: 'Training Pipelines', icon: Workflow },
                    { title: 'CI/CD for ML', icon: Code },
                    { title: 'Deployment Engine', icon: Server },
                    { title: 'Monitoring Services', icon: Gauge },
                    { title: 'Model Catalog', icon: BookOpen }
                  ].map((item) => (
                    <div key={item.title} className="bg-slate-50 rounded-xl p-3 border border-slate-100 flex items-center gap-3 hover:border-blue-200 transition-colors">
                      <item.icon className="w-4 h-4 text-blue-600" />
                      <div className="text-[10px] font-bold text-slate-700">{item.title}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* DATA PLATFORM LAYER */}
              <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
                <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-4 text-center">DATA PLATFORM LAYER</div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {[
                    { title: 'Data Lake', icon: HardDrive },
                    { title: 'Data Warehouse', icon: Database },
                    { title: 'Metadata Catalog', icon: BookOpen },
                    { title: 'Lineage Engine', icon: Network },
                    { title: 'DQ Engine', icon: CheckCircle2 },
                    { title: 'Schema Validation', icon: ClipboardCheck },
                    { title: 'Partner Data Ingestion APIs', icon: Share2 }
                  ].map((item) => (
                    <div key={item.title} className="bg-slate-50 rounded-xl p-3 border border-slate-100 flex items-center gap-3 hover:border-emerald-200 transition-colors">
                      <item.icon className="w-4 h-4 text-emerald-600" />
                      <div className="text-[10px] font-bold text-slate-700">{item.title}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* SECURITY LAYER */}
              <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
                <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-4 text-center">SECURITY LAYER</div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {[
                    { title: 'IAM', icon: Users },
                    { title: 'Secrets Vault', icon: Settings },
                    { title: 'Encryption', icon: ShieldCheck },
                    { title: 'WAF', icon: Shield },
                    { title: 'API Gateway', icon: Globe },
                    { title: 'SIEM', icon: Terminal },
                    { title: 'Adversarial Defense', icon: ShieldAlert }
                  ].map((item) => (
                    <div key={item.title} className="bg-slate-50 rounded-xl p-3 border border-slate-100 flex items-center gap-3 hover:border-rose-200 transition-colors">
                      <item.icon className="w-4 h-4 text-rose-600" />
                      <div className="text-[10px] font-bold text-slate-700">{item.title}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* PARTNER & OPERATIONS LAYER */}
              <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
                <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-4 text-center">PARTNER & OPERATIONS LAYER</div>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {[
                    { title: 'Partner Portal', icon: Globe },
                    { title: 'Transparency Dashboards', icon: LayoutDashboard },
                    { title: 'SLA Monitoring', icon: Activity },
                    { title: 'Dispute Resolution', icon: ClipboardCheck },
                    { title: 'Corridor Analytics', icon: Map },
                    { title: 'Partner Fairness Certification Program', icon: ShieldCheck }
                  ].map((item) => (
                    <div key={item.title} className="bg-slate-50 rounded-xl p-3 border border-slate-100 flex items-center gap-3 hover:border-amber-200 transition-colors">
                      <item.icon className="w-4 h-4 text-amber-600" />
                      <div className="text-[10px] font-bold text-slate-700">{item.title}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* EXECUTIVE MODEL GOVERNANCE ARCHITECTURE */}
        <div className="mb-12">
          <div className="bg-slate-900 rounded-3xl p-10 shadow-2xl border border-white/10 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500/10 blur-[120px] rounded-full -mr-48 -mt-48" />
            <div className="absolute bottom-0 left-0 w-96 h-96 bg-indigo-500/10 blur-[120px] rounded-full -ml-48 -mb-48" />
            
            <div className="relative z-10">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
                <div>
                  <h3 className="text-2xl font-black text-white uppercase tracking-[0.3em]">Executive Model Governance Architecture</h3>
                  <p className="text-slate-400 text-sm mt-2 font-medium">High-level strategic framework for enterprise-wide AI oversight</p>
                </div>
                <div className="flex items-center gap-4">
                  <div className="px-4 py-2 bg-white/5 border border-white/10 rounded-xl">
                    <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">Strategic View v2.0</span>
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                {[
                  {
                    layer: 'STRATEGIC OVERSIGHT',
                    color: 'bg-white text-slate-900',
                    icon: ShieldCheck,
                    items: [
                      { label: 'ESC', desc: 'Executive Steering' },
                      { label: 'MRC', desc: 'Model Risk' },
                      { label: 'Global Compliance', desc: 'Regulatory' },
                      { label: 'Global Security', desc: 'Cyber/ML' },
                      { label: 'Global Partner Governance', desc: 'Ecosystem' }
                    ]
                  },
                  {
                    layer: 'GOVERNANCE PLATFORM',
                    color: 'bg-indigo-600 text-white',
                    icon: Workflow,
                    items: [
                      { label: 'Model Registry', desc: 'Central Catalog' },
                      { label: 'Validation Engine', desc: 'Automated QA' },
                      { label: 'Fairness Engine', desc: 'Bias Testing' },
                      { label: 'Drift Detection', desc: 'Performance' },
                      { label: 'Security Testing', desc: 'Red Teaming' },
                      { label: 'Evidence Automation', desc: 'Audit Trail' },
                      { label: 'GRC Integration', desc: 'Risk Bridge' }
                    ]
                  },
                  {
                    layer: 'ML PLATFORM',
                    color: 'bg-blue-600 text-white',
                    icon: Cpu,
                    items: [
                      { label: 'Feature Store', desc: 'Data Assets' },
                      { label: 'Training Pipelines', desc: 'Reproducibility' },
                      { label: 'CI/CD', desc: 'Automation' },
                      { label: 'Monitoring', desc: 'Observability' },
                      { label: 'Deployment Engine', desc: 'Inference' }
                    ]
                  },
                  {
                    layer: 'DATA PLATFORM',
                    color: 'bg-emerald-600 text-white',
                    icon: Database,
                    items: [
                      { label: 'Data Lake', desc: 'Raw Storage' },
                      { label: 'Metadata Catalog', desc: 'Discovery' },
                      { label: 'Lineage Engine', desc: 'Provenance' },
                      { label: 'Data Quality Engine', desc: 'Integrity' }
                    ]
                  },
                  {
                    layer: 'SECURITY PLATFORM',
                    color: 'bg-rose-600 text-white',
                    icon: Lock,
                    items: [
                      { label: 'IAM', desc: 'Access Control' },
                      { label: 'Secrets Vault', desc: 'Key Mgmt' },
                      { label: 'WAF', desc: 'Edge Defense' },
                      { label: 'API Gateway', desc: 'Traffic Mgmt' },
                      { label: 'SIEM', desc: 'Threat Intel' },
                      { label: 'Adversarial Defense', desc: 'Model Hardening' }
                    ]
                  },
                  {
                    layer: 'PARTNER & OPERATIONS',
                    color: 'bg-amber-600 text-white',
                    icon: Handshake,
                    items: [
                      { label: 'Partner Portal', desc: 'Self-Service' },
                      { label: 'Transparency Dashboards', desc: 'Trust' },
                      { label: 'SLA Monitoring', desc: 'Performance' },
                      { label: 'Dispute Resolution', desc: 'Arbitration' }
                    ]
                  }
                ].map((layer, i) => (
                  <motion.div 
                    key={layer.layer}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.1 }}
                    className={`p-6 rounded-2xl ${layer.color} shadow-xl border border-white/10 relative group overflow-hidden`}
                  >
                    <div className="absolute top-0 right-0 p-6 opacity-10 group-hover:opacity-20 transition-opacity">
                      <layer.icon className="w-16 h-16" />
                    </div>
                    <div className="relative z-10">
                      <div className="text-[10px] font-black uppercase tracking-[0.4em] mb-6 opacity-70">{layer.layer}</div>
                      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 xl:grid-cols-7 gap-4">
                        {layer.items.map((item, j) => (
                          <div key={j} className="flex flex-col gap-1">
                            <div className="text-[11px] font-black uppercase tracking-tight">{item.label}</div>
                            <div className="text-[9px] opacity-60 font-bold uppercase tracking-tighter">{item.desc}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* CIO EDITION — ENTERPRISE MODEL GOVERNANCE ARCHITECTURE */}
        <div className="mb-12">
          <div className="bg-slate-50 rounded-3xl border border-slate-200 p-8 shadow-sm">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-indigo-900 rounded-2xl text-white shadow-lg">
                  <LayoutDashboard className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xl font-black text-slate-900 uppercase tracking-[0.2em]">CIO Edition</h3>
                  <p className="text-slate-500 text-sm font-medium uppercase tracking-widest">Enterprise Model Governance Architecture</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="px-4 py-2 bg-indigo-50 text-indigo-700 text-[10px] font-black uppercase tracking-widest rounded-xl border border-indigo-100">
                  Infrastructure & Strategy Alignment
                </div>
              </div>
            </div>

            <div className="flex flex-col gap-4">
              {[
                {
                  layer: 'STRATEGIC LAYER',
                  color: 'bg-indigo-900 text-white',
                  icon: Target,
                  items: ['Enterprise AI Strategy', 'Technology Roadmap', 'Cloud Strategy', 'Data Strategy']
                },
                {
                  layer: 'GOVERNANCE PLATFORM',
                  color: 'bg-indigo-700 text-white',
                  icon: Workflow,
                  items: ['Model Registry', 'Validation Engine', 'Fairness Engine', 'Drift Detection', 'Security Testing', 'Evidence Automation', 'GRC Integration']
                },
                {
                  layer: 'ML PLATFORM',
                  color: 'bg-blue-600 text-white',
                  icon: Cpu,
                  items: ['Feature Store', 'Training Pipelines', 'CI/CD', 'Monitoring', 'Deployment Engine']
                },
                {
                  layer: 'DATA PLATFORM',
                  color: 'bg-emerald-600 text-white',
                  icon: Database,
                  items: ['Data Lake', 'Metadata Catalog', 'Lineage Engine', 'Data Quality Engine']
                },
                {
                  layer: 'SECURITY PLATFORM',
                  color: 'bg-rose-600 text-white',
                  icon: Lock,
                  items: ['IAM', 'Secrets Vault', 'WAF', 'API Gateway', 'SIEM', 'Adversarial Defense']
                },
                {
                  layer: 'INTEGRATION & OPERATIONS',
                  color: 'bg-amber-600 text-white',
                  icon: Share2,
                  items: ['Partner APIs', 'Transparency Dashboards', 'SLA Monitoring', 'Ticketing Systems']
                },
                {
                  layer: 'CLOUD & INFRASTRUCTURE',
                  color: 'bg-slate-800 text-white',
                  icon: Cloud,
                  items: ['Kubernetes', 'Serverless', 'Storage', 'Networking', 'Observability']
                }
              ].map((layer, i) => (
                <motion.div 
                  key={layer.layer}
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.05 }}
                  className={`p-5 rounded-2xl ${layer.color} shadow-md border border-white/10 relative group overflow-hidden`}
                >
                  <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                    <layer.icon className="w-10 h-10" />
                  </div>
                  <div className="relative z-10 flex flex-col md:flex-row md:items-center gap-6">
                    <div className="md:w-48 shrink-0">
                      <div className="text-[10px] font-black uppercase tracking-[0.3em] opacity-60 mb-1">{layer.layer}</div>
                      <div className="h-1 w-12 bg-white/20 rounded-full" />
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {layer.items.map((item, j) => (
                        <div key={j} className="px-3 py-1 bg-white/10 rounded-lg border border-white/10 text-[10px] font-bold tracking-tight hover:bg-white/20 transition-colors">
                          {item}
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        {/* CTO EDITION — ENTERPRISE MODEL GOVERNANCE ARCHITECTURE */}
        <div className="mb-12">
          <div className="bg-slate-900 rounded-3xl border border-white/5 p-8 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500/10 blur-[120px] rounded-full -mr-48 -mt-48" />
            
            <div className="relative z-10">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-blue-600 rounded-2xl text-white shadow-lg">
                    <Terminal className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-black text-white uppercase tracking-[0.2em]">CTO Edition</h3>
                    <p className="text-slate-400 text-sm font-medium uppercase tracking-widest">Enterprise Model Governance Architecture</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="px-4 py-2 bg-white/5 text-slate-300 text-[10px] font-black uppercase tracking-widest rounded-xl border border-white/10">
                    Control Plane & Execution Fabric
                  </div>
                </div>
              </div>

              <div className="flex flex-col gap-4">
                {[
                  {
                    layer: 'STRATEGIC TECHNOLOGY LAYER',
                    color: 'bg-white text-slate-900',
                    icon: Compass,
                    items: ['Cloud Architecture', 'Data Strategy', 'ML Platform Strategy', 'Security Strategy']
                  },
                  {
                    layer: 'GOVERNANCE CONTROL PLANE',
                    color: 'bg-indigo-600 text-white',
                    icon: ShieldCheck,
                    items: ['Model Registry', 'Validation Engine', 'Fairness Engine', 'Drift Detection', 'Security Testing', 'Evidence Automation', 'GRC Integration']
                  },
                  {
                    layer: 'ML EXECUTION PLANE',
                    color: 'bg-blue-600 text-white',
                    icon: Cpu,
                    items: ['Feature Store', 'Training Pipelines', 'CI/CD', 'Deployment Engine', 'Monitoring']
                  },
                  {
                    layer: 'DATA FOUNDATION',
                    color: 'bg-emerald-600 text-white',
                    icon: Database,
                    items: ['Data Lake', 'Data Warehouse', 'Metadata Catalog', 'Lineage Engine', 'DQ Engine']
                  },
                  {
                    layer: 'SECURITY FABRIC',
                    color: 'bg-rose-600 text-white',
                    icon: Lock,
                    items: ['IAM', 'Secrets Vault', 'WAF', 'API Gateway', 'SIEM', 'Adversarial Defense', 'Zero-Trust Network Segmentation', 'Partner Behavior Analytics']
                  },
                  {
                    layer: 'INTEGRATION & DELIVERY',
                    color: 'bg-cyan-600 text-white',
                    icon: Share2,
                    items: ['Partner APIs', 'Internal APIs', 'Event Bus', 'Streaming Pipelines', 'ETL/ELT']
                  },
                  {
                    layer: 'OBSERVABILITY & RELIABILITY',
                    color: 'bg-slate-800 text-white',
                    icon: Activity,
                    items: ['Logging', 'Metrics', 'Tracing', 'SLOs', 'Error Budgets', 'Chaos Testing']
                  }
                ].map((layer, i) => (
                  <motion.div 
                    key={layer.layer}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.05 }}
                    className={`p-5 rounded-2xl ${layer.color} shadow-md border border-white/10 relative group overflow-hidden`}
                  >
                    <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                      <layer.icon className="w-10 h-10" />
                    </div>
                    <div className="relative z-10 flex flex-col md:flex-row md:items-center gap-6">
                      <div className="md:w-56 shrink-0">
                        <div className="text-[10px] font-black uppercase tracking-[0.3em] opacity-60 mb-1">{layer.layer}</div>
                        <div className="h-1 w-12 bg-white/20 rounded-full" />
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {layer.items.map((item, j) => (
                          <div key={j} className="px-3 py-1 bg-white/10 rounded-lg border border-white/10 text-[10px] font-bold tracking-tight hover:bg-white/20 transition-colors">
                            {item}
                          </div>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* GLOBAL MODEL GOVERNANCE OPERATING MODEL */}
        <div className="mb-12">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-slate-900 rounded-lg text-white">
                  <Globe className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 uppercase tracking-tight">GLOBAL MODEL GOVERNANCE OPERATING MODEL</h4>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">End-to-End Governance Lifecycle & Execution</p>
                </div>
              </div>
              <div className="px-3 py-1 bg-indigo-50 text-indigo-600 text-[9px] font-black uppercase tracking-widest rounded-full border border-indigo-100">
                Operational Framework
              </div>
            </div>

            <div className="p-8 space-y-6">
              {/* GLOBAL OVERSIGHT */}
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="bg-slate-900 rounded-2xl p-6 text-white shadow-xl border border-white/10"
              >
                <div className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.3em] mb-4">GLOBAL OVERSIGHT</div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {[
                    { title: 'Executive Steering Committee (ESC)', icon: LayoutDashboard },
                    { title: 'Global Model Risk Committee (G-MRC)', icon: AlertTriangle },
                    { title: 'Global Compliance & Regulatory Affairs', icon: Scale }
                  ].map((item, i) => (
                    <div key={i} className="p-4 rounded-xl bg-white/5 border border-white/10 flex items-center gap-4 hover:bg-white/10 transition-colors">
                      <div className="p-2 bg-indigo-500/20 rounded-lg">
                        <item.icon className="w-4 h-4 text-indigo-400" />
                      </div>
                      <span className="text-xs font-bold tracking-tight">{item.title}</span>
                    </div>
                  ))}
                </div>
              </motion.div>

              {/* REGIONAL GOVERNANCE */}
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.1 }}
                className="bg-indigo-600 rounded-2xl p-6 text-white shadow-lg border border-indigo-500"
              >
                <div className="text-[10px] font-black text-indigo-200 uppercase tracking-[0.3em] mb-4">REGIONAL GOVERNANCE</div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                  {['EU-MRB', 'US-MRB', 'APAC-MRB', 'LATAM-MRB'].map((region, i) => (
                    <div key={i} className="p-3 rounded-xl bg-white/10 border border-white/10 text-center">
                      <span className="text-[10px] font-black uppercase tracking-widest">{region}</span>
                    </div>
                  ))}
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {[
                    { title: 'Regional Compliance Officers', icon: ShieldCheck },
                    { title: 'Regional Security Leads', icon: Lock }
                  ].map((item, i) => (
                    <div key={i} className="p-3 rounded-xl bg-white/10 border border-white/10 flex items-center gap-3">
                      <item.icon className="w-4 h-4 text-indigo-200" />
                      <span className="text-xs font-bold tracking-tight">{item.title}</span>
                    </div>
                  ))}
                </div>
              </motion.div>

              {/* LOCAL EXECUTION */}
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 }}
                className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm"
              >
                <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-4">LOCAL EXECUTION</div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {[
                    'Model Owners', 'Data Scientists', 'ML Engineers', 'Data Engineers',
                    'Security Analysts', 'Partner Governance Managers', 'Validation Specialists'
                  ].map((role, i) => (
                    <div key={i} className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-slate-400" />
                      <span className="text-[10px] font-bold text-slate-600 uppercase tracking-tight">{role}</span>
                    </div>
                  ))}
                </div>
              </motion.div>

              {/* GOVERNANCE PLATFORM */}
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.3 }}
                className="bg-slate-50 rounded-2xl p-6 border border-slate-200 shadow-inner"
              >
                <div className="text-[10px] font-black text-indigo-600 uppercase tracking-[0.3em] mb-4">GOVERNANCE PLATFORM</div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {[
                    { title: 'Model Registry', icon: Layers },
                    { title: 'Validation Engine', icon: CheckCircle2 },
                    { title: 'Fairness Engine', icon: Scale },
                    { title: 'Drift Detection', icon: Zap },
                    { title: 'Security Testing Suite', icon: Shield },
                    { title: 'Evidence Automation', icon: Workflow },
                    { title: 'GRC Integration', icon: Link }
                  ].map((item, i) => (
                    <div key={i} className="flex items-center gap-3 p-2 bg-white rounded-lg border border-slate-100 shadow-sm">
                      <item.icon className="w-3.5 h-3.5 text-indigo-500" />
                      <span className="text-[10px] font-bold text-slate-700">{item.title}</span>
                    </div>
                  ))}
                </div>
              </motion.div>

              {/* PARTNER & OPERATIONS */}
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.4 }}
                className="bg-amber-50 rounded-2xl p-6 border border-amber-100"
              >
                <div className="text-[10px] font-black text-amber-600 uppercase tracking-[0.3em] mb-4">PARTNER & OPERATIONS</div>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  {[
                    { title: 'Partner Portal', icon: Globe },
                    { title: 'Transparency Dashboards', icon: LayoutDashboard },
                    { title: 'SLA Monitoring', icon: Activity },
                    { title: 'Dispute Resolution', icon: ClipboardCheck }
                  ].map((item, i) => (
                    <div key={i} className="p-4 rounded-xl bg-white border border-amber-100 flex flex-col items-center text-center gap-3 shadow-sm hover:shadow-md transition-shadow">
                      <div className="p-2 bg-amber-50 rounded-lg">
                        <item.icon className="w-4 h-4 text-amber-600" />
                      </div>
                      <span className="text-[10px] font-black text-slate-700 uppercase tracking-widest">{item.title}</span>
                    </div>
                  ))}
                </div>
              </motion.div>
            </div>
          </div>
        </div>

        {/* GOVERNANCE POLICY HIERARCHY */}
        <div className="mb-12">
          <div className="bg-slate-50 rounded-3xl border border-slate-200 p-8 shadow-sm">
            <div className="text-center mb-12">
              <h3 className="text-xl font-black text-slate-900 uppercase tracking-[0.2em]">Governance Policy Hierarchy</h3>
              <p className="text-slate-500 text-sm mt-2 font-medium">Cascading framework from ethical principles to local execution</p>
            </div>

            <div className="max-w-3xl mx-auto flex flex-col items-center">
              {[
                { 
                  title: 'GLOBAL AI PRINCIPLES', 
                  desc: 'Ethical foundation and core values for AI development and use.',
                  icon: Heart,
                  color: 'bg-slate-900 text-white border-slate-800',
                  iconColor: 'text-rose-400'
                },
                { 
                  title: 'GLOBAL MODEL RISK POLICY', 
                  desc: 'Enterprise-wide mandate for identifying and managing model risks.',
                  icon: ShieldAlert,
                  color: 'bg-indigo-600 text-white border-indigo-500',
                  iconColor: 'text-indigo-200'
                },
                { 
                  title: 'MODEL GOVERNANCE SOPs', 
                  desc: 'Standard Operating Procedures for the model lifecycle.',
                  icon: ClipboardCheck,
                  color: 'bg-white text-slate-900 border-slate-200',
                  iconColor: 'text-indigo-600'
                },
                { 
                  title: 'REGIONAL PROCEDURES', 
                  desc: 'Localized procedures aligned with regional regulatory requirements.',
                  icon: Map,
                  color: 'bg-white text-slate-900 border-slate-200',
                  iconColor: 'text-blue-600'
                },
                { 
                  title: 'LOCAL WORK INSTRUCTIONS', 
                  desc: 'Step-by-step instructions for specific tasks and model types.',
                  icon: FileText,
                  color: 'bg-slate-50 text-slate-600 border-slate-100',
                  iconColor: 'text-slate-400'
                }
              ].map((level, i, arr) => (
                <React.Fragment key={level.title}>
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.1 }}
                    className={`w-full p-6 rounded-2xl border shadow-sm flex items-center gap-6 group hover:scale-[1.02] transition-transform ${level.color}`}
                  >
                    <div className={`p-3 rounded-xl bg-white/10 border border-white/10 ${level.iconColor} group-hover:scale-110 transition-transform shrink-0`}>
                      <level.icon className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="text-sm font-black uppercase tracking-widest mb-1">{level.title}</h4>
                      <p className="text-xs opacity-70 font-medium leading-relaxed">{level.desc}</p>
                    </div>
                  </motion.div>
                  
                  {i < arr.length - 1 && (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0 }}
                      whileInView={{ opacity: 1, scale: 1 }}
                      viewport={{ once: true }}
                      transition={{ delay: i * 0.1 + 0.2 }}
                      className="py-4 flex flex-col items-center"
                    >
                      <ArrowDown className="w-5 h-5 text-slate-300" />
                    </motion.div>
                  )}
                </React.Fragment>
              ))}
            </div>
          </div>
        </div>

        {/* GOVERNANCE AUTHORITY & REPORTING LINE */}
        <div className="mb-12">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-indigo-600 rounded-lg text-white">
                  <Workflow className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 uppercase tracking-tight">Governance Authority & Reporting Line</h4>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Chain of Command & Delegation Framework</p>
                </div>
              </div>
              <div className="px-3 py-1 bg-slate-100 text-slate-600 text-[9px] font-black uppercase tracking-widest rounded-full border border-slate-200">
                Authority Chain
              </div>
            </div>

            <div className="p-10">
              <div className="flex flex-col lg:flex-row items-center justify-between gap-4 relative">
                {/* Connecting Line (Desktop) */}
                <div className="hidden lg:block absolute top-1/2 left-0 w-full h-px bg-slate-100 -translate-y-1/2 z-0" />
                
                {[
                  { id: 'ESC', name: 'Executive Steering Committee', icon: LayoutDashboard, color: 'bg-slate-900 text-white', desc: 'Strategic Oversight' },
                  { id: 'MRC', name: 'Model Risk Committee', icon: AlertTriangle, color: 'bg-indigo-600 text-white', desc: 'Risk Governance' },
                  { id: 'MRB', name: 'Model Review Board', icon: ClipboardCheck, color: 'bg-indigo-50 text-white', desc: 'Technical Validation' },
                  { id: 'MGO', name: 'Model Governance Office', icon: ShieldCheck, color: 'bg-indigo-400 text-white', desc: 'Global Execution' },
                  { id: 'RMGO', name: 'Regional MGOs', icon: Map, color: 'bg-indigo-50 text-indigo-600 border-indigo-100', desc: 'Regional Oversight' },
                  { id: 'LET', name: 'Local Execution Teams', icon: Users, color: 'bg-slate-50 text-slate-600 border-slate-100', desc: 'On-the-ground' }
                ].map((node, i, arr) => (
                  <React.Fragment key={node.id}>
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.9 }}
                      whileInView={{ opacity: 1, scale: 1 }}
                      viewport={{ once: true }}
                      transition={{ delay: i * 0.1 }}
                      className="relative z-10 flex flex-col items-center gap-3 group"
                    >
                      <div className={`w-20 h-20 rounded-2xl ${node.color} shadow-lg flex items-center justify-center border border-white/10 group-hover:scale-110 transition-transform duration-300`}>
                        <node.icon className="w-8 h-8" />
                        <div className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-white text-slate-900 text-[10px] font-black flex items-center justify-center shadow-md border border-slate-100">
                          {i + 1}
                        </div>
                      </div>
                      <div className="text-center">
                        <div className="text-[10px] font-black uppercase tracking-widest text-slate-900">{node.id}</div>
                        <div className="text-[8px] font-bold text-slate-400 uppercase tracking-tighter whitespace-nowrap">{node.desc}</div>
                      </div>
                      
                      {/* Tooltip-style info */}
                      <div className="absolute top-full mt-4 w-48 p-3 bg-white rounded-xl shadow-xl border border-slate-100 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-20 text-center">
                        <div className="text-[10px] font-black text-slate-900 mb-1">{node.name}</div>
                        <div className="text-[9px] text-slate-500 font-medium leading-tight">Primary authority for {node.desc.toLowerCase()} across the model lifecycle.</div>
                      </div>
                    </motion.div>

                    {i < arr.length - 1 && (
                      <div className="lg:hidden py-2">
                        <ArrowDown className="w-4 h-4 text-slate-300" />
                      </div>
                    )}
                  </React.Fragment>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* GOVERNANCE EVIDENCE REPOSITORY */}
        <div className="mb-12">
          <div className="bg-slate-900 rounded-3xl p-8 shadow-xl border border-white/5 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 blur-[100px] rounded-full -mr-32 -mt-32" />
            
            <div className="relative z-10">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10">
                <div>
                  <h3 className="text-xl font-black text-white uppercase tracking-[0.2em]">Governance Evidence Repository</h3>
                  <p className="text-slate-400 text-sm mt-2 font-medium">Immutable audit trail and documentation directory</p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="px-4 py-2 bg-white/5 border border-white/10 rounded-xl flex items-center gap-3">
                    <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
                    <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">Sync Active</span>
                  </div>
                </div>
              </div>

              <div className="bg-black/40 rounded-2xl border border-white/10 p-8 font-mono">
                <div className="flex items-center gap-2 mb-8 pb-4 border-b border-white/5">
                  <Folder className="w-4 h-4 text-indigo-400" />
                  <span className="text-xs font-bold text-slate-300 tracking-wider">/Evidence</span>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-y-6 gap-x-12">
                  {[
                    { name: 'Model_Cards', count: 124, size: '42MB' },
                    { name: 'Validation', count: 86, size: '1.2GB' },
                    { name: 'Fairness', count: 42, size: '180MB' },
                    { name: 'Security', count: 215, size: '840MB' },
                    { name: 'Monitoring', count: 1042, size: '4.5GB' },
                    { name: 'Incidents', count: 12, size: '15MB' },
                    { name: 'Partner_Reports', count: 56, size: '310MB' },
                    { name: 'Approvals', count: 89, size: '12MB' },
                    { name: 'MRB_Minutes', count: 24, size: '8MB' }
                  ].map((folder, i) => (
                    <motion.div 
                      key={folder.name}
                      initial={{ opacity: 0, x: -10 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: i * 0.05 }}
                      className="flex items-center justify-between group cursor-pointer"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-4 h-px bg-slate-700" />
                        <Folder className="w-3.5 h-3.5 text-slate-500 group-hover:text-indigo-400 transition-colors" />
                        <span className="text-[11px] text-slate-400 group-hover:text-white transition-colors">/{folder.name}</span>
                      </div>
                      <div className="flex items-center gap-4 opacity-0 group-hover:opacity-100 transition-opacity">
                        <span className="text-[9px] text-slate-600 font-bold uppercase tracking-tighter">{folder.count} files</span>
                        <span className="text-[9px] text-slate-600 font-bold uppercase tracking-tighter">{folder.size}</span>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* MODEL GOVERNANCE CAPABILITY MAP */}
        <div className="mb-12">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <h4 className="font-bold text-slate-900 flex items-center gap-2">
                <Map className="w-4 h-4 text-indigo-600" />
                MODEL GOVERNANCE CAPABILITY MAP
              </h4>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Strategic Capability Framework</span>
            </div>
            
            <div className="p-8">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {[
                  {
                    title: 'STRATEGIC CAPABILITIES',
                    icon: Compass,
                    color: 'text-blue-600 bg-blue-50 border-blue-100',
                    items: ['Governance Strategy', 'Risk Appetite', 'Regulatory Alignment', 'Partner Governance', 'Enterprise AI Ethics']
                  },
                  {
                    title: 'GOVERNANCE & OVERSIGHT',
                    icon: ShieldCheck,
                    color: 'text-indigo-600 bg-indigo-50 border-indigo-100',
                    items: ['Model Risk Committee (MRC)', 'Model Review Board (MRB)', 'Policy Management', 'Exception Management', 'Audit Readiness']
                  },
                  {
                    title: 'MODEL LIFECYCLE',
                    icon: Box,
                    color: 'text-purple-600 bg-purple-50 border-purple-100',
                    items: ['Development Standards', 'Validation', 'Deployment Controls', 'Monitoring & Drift', 'Retraining', 'Retirement']
                  },
                  {
                    title: 'FAIRNESS & ETHICS',
                    icon: Heart,
                    color: 'text-rose-600 bg-rose-50 border-rose-100',
                    items: ['Bias Detection', 'Fairness Testing', 'Mitigation Planning', 'Partner Reporting', 'Ethical Risk Assessment']
                  },
                  {
                    title: 'SECURITY CAPABILITIES',
                    icon: Shield,
                    color: 'text-slate-600 bg-slate-50 border-slate-100',
                    items: ['Adversarial Testing', 'Data Poisoning Defense', 'Access Control', 'Integrity Verification', 'API Security']
                  },
                  {
                    title: 'DATA CAPABILITIES',
                    icon: Database,
                    color: 'text-emerald-600 bg-emerald-50 border-emerald-100',
                    items: ['Data Quality', 'Data Lineage', 'Metadata Management', 'Feature Store Governance', 'Freshness Monitoring']
                  },
                  {
                    title: 'EVIDENCE & COMPLIANCE',
                    icon: ClipboardCheck,
                    color: 'text-amber-600 bg-amber-50 border-amber-100',
                    items: ['Evidence Automation', 'Audit Trail Management', 'GRC Integration', 'SOC 2 / ISO 27001', 'ISO 42001 Alignment']
                  },
                  {
                    title: 'PARTNER & OPERATIONAL',
                    icon: Handshake,
                    color: 'text-orange-600 bg-orange-50 border-orange-100',
                    items: ['Partner Transparency', 'Partner Portal', 'Dispute Resolution', 'SLA Monitoring', 'Corridor Analytics']
                  }
                ].map((category, i) => (
                  <div key={i} className={`rounded-2xl border p-5 flex flex-col gap-4 ${category.color}`}>
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-white rounded-lg shadow-sm">
                        <category.icon className="w-4 h-4" />
                      </div>
                      <span className="text-[10px] font-black uppercase tracking-widest leading-tight">{category.title}</span>
                    </div>
                    <div className="space-y-2">
                      {category.items.map((item, j) => (
                        <div key={j} className="flex items-center justify-between group/item">
                          <div className="flex items-start gap-2">
                            <div className="w-1 h-1 rounded-full bg-current mt-1.5 shrink-0 opacity-40" />
                            <span className="text-[11px] font-bold leading-tight opacity-80">{item}</span>
                          </div>
                          <div className="flex items-center gap-1 opacity-0 group-hover/item:opacity-100 transition-opacity">
                            <div className="w-1 h-1 rounded-full bg-emerald-500" />
                            <span className="text-[8px] font-black uppercase tracking-tighter opacity-60">Active</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* ENTERPRISE ML GOVERNANCE CONTROLS MAP */}
        <div className="mb-12">
          <div className="bg-slate-50 rounded-3xl border border-slate-200 p-8 shadow-sm">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10">
              <div>
                <h3 className="text-xl font-black text-slate-900 uppercase tracking-[0.2em]">Enterprise ML Governance Controls Map</h3>
                <p className="text-slate-500 text-sm mt-2 font-medium">Comprehensive mapping of technical and operational controls</p>
              </div>
              <div className="flex items-center gap-3">
                <div className="px-3 py-1 bg-emerald-100 text-emerald-700 text-[10px] font-black uppercase tracking-widest rounded-full border border-emerald-200">
                  100% Coverage
                </div>
                <div className="px-3 py-1 bg-blue-100 text-blue-700 text-[10px] font-black uppercase tracking-widest rounded-full border border-blue-200">
                  ISO 42001 Ready
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                {
                  domain: 'MODEL INTEGRITY',
                  icon: Fingerprint,
                  color: 'text-blue-600',
                  bgColor: 'bg-blue-50',
                  controls: [
                    { label: 'Artifact Hashing', status: 'Active', desc: 'SHA-256 verification' },
                    { label: 'Digital Signatures', status: 'Active', desc: 'Provenance anchoring' },
                    { label: 'Version Control', status: 'Active', desc: 'Immutable history' }
                  ]
                },
                {
                  domain: 'DATA PRIVACY',
                  icon: EyeOff,
                  color: 'text-purple-600',
                  bgColor: 'bg-purple-50',
                  controls: [
                    { label: 'Differential Privacy', status: 'Active', desc: 'Noise injection' },
                    { label: 'PII Masking', status: 'Active', desc: 'Dynamic tokenization' },
                    { label: 'Secure Enclaves', status: 'Active', desc: 'TEE execution' }
                  ]
                },
                {
                  domain: 'ADVERSARIAL DEFENSE',
                  icon: ShieldAlert,
                  color: 'text-rose-600',
                  bgColor: 'bg-rose-50',
                  controls: [
                    { label: 'Robustness Testing', status: 'Active', desc: 'Evasion simulation' },
                    { label: 'Poisoning Detection', status: 'Active', desc: 'Anomaly filters' },
                    { label: 'Input Sanitization', status: 'Active', desc: 'Perturbation removal' }
                  ]
                },
                {
                  domain: 'SUPPLY CHAIN',
                  icon: Network,
                  color: 'text-indigo-600',
                  bgColor: 'bg-indigo-50',
                  controls: [
                    { label: 'SBOM Tracking', status: 'Active', desc: 'Software Bill of Materials' },
                    { label: 'SCA Scanning', status: 'Active', desc: 'Dependency analysis' },
                    { label: 'Signed Containers', status: 'Active', desc: 'Verified pipelines' }
                  ]
                },
                {
                  domain: 'RUNTIME GUARDRAILS',
                  icon: Zap,
                  color: 'text-amber-600',
                  bgColor: 'bg-amber-50',
                  controls: [
                    { label: 'Prompt Filters', status: 'Active', desc: 'Injection detection' },
                    { label: 'Output Validation', status: 'Active', desc: 'Safety checks' },
                    { label: 'Hallucination Check', status: 'Active', desc: 'Factuality verification' }
                  ]
                },
                {
                  domain: 'ZERO-TRUST IAM',
                  icon: UserCheck,
                  color: 'text-emerald-600',
                  bgColor: 'bg-emerald-50',
                  controls: [
                    { label: 'JIT Access', status: 'Active', desc: 'Just-In-Time provisioning' },
                    { label: 'ABAC Policies', status: 'Active', desc: 'Attribute-based control' },
                    { label: 'Continuous Auth', status: 'Active', desc: 'Session verification' }
                  ]
                }
              ].map((domain, i) => (
                <motion.div 
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.05 }}
                  className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm hover:shadow-md transition-all group"
                >
                  <div className="flex items-center gap-4 mb-6">
                    <div className={`p-3 rounded-xl ${domain.bgColor} ${domain.color} group-hover:scale-110 transition-transform`}>
                      <domain.icon className="w-5 h-5" />
                    </div>
                    <h4 className="font-black text-slate-900 text-sm uppercase tracking-wider">{domain.domain}</h4>
                  </div>
                  <div className="space-y-4">
                    {domain.controls.map((ctrl, j) => (
                      <div key={j} className="flex flex-col gap-1">
                        <div className="flex items-center justify-between">
                          <div className="text-[10px] font-black text-slate-700 uppercase tracking-tight">{ctrl.label}</div>
                          <div className="flex items-center gap-1">
                            <div className="w-1 h-1 rounded-full bg-emerald-500" />
                            <span className="text-[8px] font-black text-emerald-600 uppercase tracking-tighter">{ctrl.status}</span>
                          </div>
                        </div>
                        <div className="text-[10px] text-slate-500 font-medium leading-relaxed">{ctrl.desc}</div>
                      </div>
                    ))}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        {/* ML SECURITY ARCHITECTURE REFERENCE MODEL */}
        <div className="mb-12">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-rose-600 rounded-lg text-white">
                  <Shield className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 uppercase tracking-tight">ML SECURITY ARCHITECTURE REFERENCE MODEL</h4>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Defense-in-Depth Framework for AI/ML Assets</p>
                </div>
              </div>
              <div className="px-3 py-1 bg-rose-50 text-rose-600 text-[9px] font-black uppercase tracking-widest rounded-full border border-rose-100">
                Security Reference Model
              </div>
            </div>

            <div className="p-8 space-y-4">
              {[
                {
                  layer: 'IDENTITY LAYER',
                  color: 'bg-slate-900 text-white',
                  icon: UserCheck,
                  items: ['RBAC/ABAC', 'JIT Access', 'MFA', 'Continuous Authentication', 'Per-Model Policies']
                },
                {
                  layer: 'DATA LAYER',
                  color: 'bg-indigo-600 text-white',
                  icon: Database,
                  items: ['Encryption', 'Tokenization', 'Schema Validation', 'Lineage', 'DQ Engine', 'DP Options']
                },
                {
                  layer: 'MODEL LAYER',
                  color: 'bg-blue-600 text-white',
                  icon: Brain,
                  items: ['Secure Registry', 'Artifact Hashing', 'Watermarking', 'Adversarial Defense', 'Poisoning Detection', 'Output Obfuscation', 'Integrity Verification']
                },
                {
                  layer: 'PIPELINE LAYER',
                  color: 'bg-cyan-600 text-white',
                  icon: Workflow,
                  items: ['Signed Containers', 'Dependency Scanning', 'Secrets Vault', 'CI/CD Approvals', 'Build Provenance', 'Pipeline Segmentation']
                },
                {
                  layer: 'RUNTIME LAYER',
                  color: 'bg-emerald-600 text-white',
                  icon: Zap,
                  items: ['API Gateway', 'WAF', 'Rate Limiting', 'SIEM', 'Drift-Based Anomaly Detection', 'Partner Behavior Analytics', 'Zero-Trust Network Segmentation']
                },
                {
                  layer: 'INCIDENT RESPONSE LAYER',
                  color: 'bg-rose-600 text-white',
                  icon: AlertTriangle,
                  items: ['ML IR Playbook', 'Automated Containment', 'Forensics', 'Partner Notification', 'Post-Incident Fairness Review']
                }
              ].map((layer, i) => (
                <motion.div 
                  key={layer.layer}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.05 }}
                  className={`p-6 rounded-2xl ${layer.color} shadow-lg border border-white/10 relative group overflow-hidden`}
                >
                  <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                    <layer.icon className="w-12 h-12" />
                  </div>
                  <div className="relative z-10">
                    <div className="text-[10px] font-black uppercase tracking-[0.3em] mb-4 opacity-60">{layer.layer}</div>
                    <div className="flex flex-wrap gap-2">
                      {layer.items.map((item, j) => (
                        <div key={j} className="px-3 py-1.5 bg-white/10 rounded-lg border border-white/10 text-[10px] font-bold tracking-tight hover:bg-white/20 transition-colors">
                          {item}
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        {/* FULL ML SECURITY ARCHITECTURE BLUEPRINT */}
        <div className="mb-12">
          <div className="bg-slate-50 rounded-3xl border border-slate-200 p-8 shadow-sm relative overflow-hidden">
            {/* Blueprint Grid Overlay */}
            <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{ backgroundImage: 'radial-gradient(#000 1px, transparent 1px)', backgroundSize: '20px 20px' }} />
            
            <div className="relative z-10">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-rose-600 rounded-2xl text-white shadow-lg">
                    <ShieldAlert className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-black text-slate-900 uppercase tracking-[0.2em]">Full ML Security Architecture Blueprint</h3>
                    <p className="text-slate-500 text-sm font-medium uppercase tracking-widest">End-to-End Defense-in-Depth Schematic</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="px-4 py-2 bg-rose-50 text-rose-700 text-[10px] font-black uppercase tracking-widest rounded-xl border border-rose-100">
                    Security Blueprint v4.0
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Left Column: Input & Identity */}
                <div className="space-y-6">
                  <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm">
                    <div className="flex items-center gap-3 mb-6">
                      <div className="w-8 h-8 rounded-lg bg-slate-900 text-white flex items-center justify-center">
                        <UserCheck className="w-4 h-4" />
                      </div>
                      <div className="text-[11px] font-black text-slate-900 uppercase tracking-widest">Identity & Access Control</div>
                    </div>
                    <div className="space-y-3">
                      {[
                        { label: 'RBAC/ABAC', status: 'Enforced' },
                        { label: 'JIT Model Access', status: 'Active' },
                        { label: 'Continuous Auth', status: 'Enabled' },
                        { label: 'MFA for Model Ops', status: 'Mandatory' },
                        { label: 'Service Identity (SPIFFE)', status: 'Integrated' }
                      ].map((item) => (
                        <div key={item.label} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-100">
                          <span className="text-[10px] font-bold text-slate-600 uppercase">{item.label}</span>
                          <span className="text-[8px] font-black text-emerald-600 uppercase tracking-tighter bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-100">{item.status}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm">
                    <div className="flex items-center gap-3 mb-6">
                      <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center">
                        <Globe className="w-4 h-4" />
                      </div>
                      <div className="text-[11px] font-black text-slate-900 uppercase tracking-widest">Network & Perimeter</div>
                    </div>
                    <div className="space-y-3">
                      {[
                        { label: 'WAF / API Gateway', status: 'Edge' },
                        { label: 'mTLS Encryption', status: 'Transit' },
                        { label: 'DDoS Protection', status: 'Active' },
                        { label: 'Zero-Trust Segmentation', status: 'Internal' }
                      ].map((item) => (
                        <div key={item.label} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-100">
                          <span className="text-[10px] font-bold text-slate-600 uppercase">{item.label}</span>
                          <span className="text-[8px] font-black text-indigo-600 uppercase tracking-tighter bg-indigo-50 px-2 py-0.5 rounded-full border border-indigo-100">{item.status}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Center Column: Core ML Assets */}
                <div className="lg:col-span-1 space-y-6">
                  <div className="p-8 bg-slate-900 rounded-3xl border border-white/10 shadow-2xl relative overflow-hidden group">
                    <div className="absolute top-0 right-0 p-6 opacity-10 group-hover:opacity-20 transition-opacity">
                      <Brain className="w-24 h-24 text-white" />
                    </div>
                    <div className="relative z-10">
                      <div className="text-[10px] font-black text-rose-400 uppercase tracking-[0.4em] mb-8 text-center">CORE ML SECURITY FABRIC</div>
                      
                      <div className="space-y-4">
                        <div className="p-4 bg-white/5 rounded-2xl border border-white/10 backdrop-blur-sm">
                          <div className="text-[10px] font-black text-white uppercase mb-3 flex items-center gap-2">
                            <Lock className="w-3 h-3 text-rose-400" /> Model Integrity
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            {['Artifact Hashing', 'Signed Models', 'Watermarking', 'Version Pinning'].map(tag => (
                              <div key={tag} className="px-2 py-1 bg-white/5 rounded-md text-[8px] font-bold text-slate-400 uppercase border border-white/5">{tag}</div>
                            ))}
                          </div>
                        </div>

                        <div className="p-4 bg-white/5 rounded-2xl border border-white/10 backdrop-blur-sm">
                          <div className="text-[10px] font-black text-white uppercase mb-3 flex items-center gap-2">
                            <ShieldAlert className="w-3 h-3 text-rose-400" /> Adversarial Defense
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            {['Input Sanitization', 'Output Obfuscation', 'Poisoning Detection', 'Evasion Defense'].map(tag => (
                              <div key={tag} className="px-2 py-1 bg-white/5 rounded-md text-[8px] font-bold text-slate-400 uppercase border border-white/5">{tag}</div>
                            ))}
                          </div>
                        </div>

                        <div className="p-4 bg-white/5 rounded-2xl border border-white/10 backdrop-blur-sm">
                          <div className="text-[10px] font-black text-white uppercase mb-3 flex items-center gap-2">
                            <Database className="w-3 h-3 text-rose-400" /> Data Privacy
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            {['DP Training', 'PII Masking', 'Secure Enclaves', 'Homomorphic Enc'].map(tag => (
                              <div key={tag} className="px-2 py-1 bg-white/5 rounded-md text-[8px] font-bold text-slate-400 uppercase border border-white/5">{tag}</div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Right Column: Pipeline & Ops */}
                <div className="space-y-6">
                  <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm">
                    <div className="flex items-center gap-3 mb-6">
                      <div className="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center">
                        <Workflow className="w-4 h-4" />
                      </div>
                      <div className="text-[11px] font-black text-slate-900 uppercase tracking-widest">Secure ML Lifecycle</div>
                    </div>
                    <div className="space-y-3">
                      {[
                        { label: 'Dependency Scanning', status: 'SCA' },
                        { label: 'Container Hardening', status: 'CIS' },
                        { label: 'Secrets Management', status: 'Vault' },
                        { label: 'Build Provenance', status: 'SLSA' },
                        { label: 'Pipeline Auth', status: 'OIDC' }
                      ].map((item) => (
                        <div key={item.label} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-100">
                          <span className="text-[10px] font-bold text-slate-600 uppercase">{item.label}</span>
                          <span className="text-[8px] font-black text-blue-600 uppercase tracking-tighter bg-blue-50 px-2 py-0.5 rounded-full border border-blue-100">{item.status}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm">
                    <div className="flex items-center gap-3 mb-6">
                      <div className="w-8 h-8 rounded-lg bg-rose-600 text-white flex items-center justify-center">
                        <Activity className="w-4 h-4" />
                      </div>
                      <div className="text-[11px] font-black text-slate-900 uppercase tracking-widest">Monitoring & Response</div>
                    </div>
                    <div className="space-y-3">
                      {[
                        { label: 'SIEM / SOAR', status: 'Active' },
                        { label: 'Drift Anomaly Detection', status: 'Real-time' },
                        { label: 'ML IR Playbooks', status: 'Ready' },
                        { label: 'Forensic Logging', status: 'Immutable' }
                      ].map((item) => (
                        <div key={item.label} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-100">
                          <span className="text-[10px] font-bold text-slate-600 uppercase">{item.label}</span>
                          <span className="text-[8px] font-black text-rose-600 uppercase tracking-tighter bg-rose-50 px-2 py-0.5 rounded-full border border-rose-100">{item.status}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Bottom Legend / Status */}
              <div className="mt-12 pt-8 border-t border-slate-200 flex flex-wrap items-center justify-center gap-8">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em]">All Systems Operational</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-blue-500" />
                  <span className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em]">Zero-Trust Architecture</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-rose-500" />
                  <span className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em]">Defense-in-Depth Enforced</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* GLOBAL CONTROLS ORCHESTRATION ENGINE — ARCHITECTURE */}
        <div className="mb-12">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-indigo-600 rounded-lg text-white">
                  <Workflow className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 uppercase tracking-tight">Global Controls Orchestration Engine</h4>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Automated Control Execution & Evidence Lifecycle</p>
                </div>
              </div>
              <div className="px-3 py-1 bg-indigo-50 text-indigo-600 text-[9px] font-black uppercase tracking-widest rounded-full border border-indigo-100">
                Orchestration Architecture
              </div>
            </div>

            <div className="p-8 space-y-4">
              {[
                {
                  layer: 'CONTROL ORCHESTRATION LAYER',
                  color: 'bg-slate-900 text-white',
                  icon: Settings,
                  items: ['Scheduler', 'Trigger Engine', 'Control Executor', 'Exception Handler']
                },
                {
                  layer: 'EVIDENCE AUTOMATION LAYER',
                  color: 'bg-indigo-600 text-white',
                  icon: History,
                  items: ['Evidence Collector', 'Evidence Normalizer', 'Immutable Evidence Store']
                },
                {
                  layer: 'INTEGRATION LAYER',
                  color: 'bg-blue-600 text-white',
                  icon: Link,
                  items: ['Model Registry', 'Feature Store', 'CI/CD', 'SIEM', 'GRC Platform', 'Partner APIs']
                },
                {
                  layer: 'MONITORING & ALERTING LAYER',
                  color: 'bg-rose-600 text-white',
                  icon: Bell,
                  items: ['Drift Alerts', 'Fairness Alerts', 'Security Alerts', 'DQ Alerts']
                },
                {
                  layer: 'GOVERNANCE UI & AUDIT INTERFACE',
                  color: 'bg-emerald-600 text-white',
                  icon: LayoutDashboard,
                  items: ['Control Dashboard', 'Evidence Viewer', 'Audit Query Engine']
                }
              ].map((layer, i) => (
                <motion.div 
                  key={layer.layer}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.05 }}
                  className={`p-6 rounded-2xl ${layer.color} shadow-lg border border-white/10 relative group overflow-hidden`}
                >
                  <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                    <layer.icon className="w-12 h-12" />
                  </div>
                  <div className="relative z-10">
                    <div className="text-[10px] font-black uppercase tracking-[0.3em] mb-4 opacity-60">{layer.layer}</div>
                    <div className="flex flex-wrap gap-2">
                      {layer.items.map((item, j) => (
                        <div key={j} className="px-3 py-1.5 bg-white/10 rounded-lg border border-white/10 text-[10px] font-bold tracking-tight hover:bg-white/20 transition-colors">
                          {item}
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        {/* GLOBAL CONTROLS EXECUTION ENGINE — RUNTIME ARCHITECTURE */}
        <div className="mb-12">
          <div className="bg-slate-900 rounded-3xl border border-white/5 p-8 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 blur-[120px] rounded-full -mr-48 -mt-48" />
            
            <div className="relative z-10">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-indigo-600 rounded-2xl text-white shadow-lg">
                    <Zap className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-black text-white uppercase tracking-[0.2em]">Global Controls Execution Engine</h3>
                    <p className="text-slate-400 text-sm font-medium uppercase tracking-widest">Runtime Architecture & Policy Enforcement</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="px-4 py-2 bg-white/5 text-slate-300 text-[10px] font-black uppercase tracking-widest rounded-xl border border-white/10">
                    Runtime Architecture
                  </div>
                </div>
              </div>

              <div className="flex flex-col gap-4">
                {[
                  {
                    layer: 'RUNTIME ORCHESTRATION LAYER',
                    color: 'bg-white text-slate-900',
                    icon: Workflow,
                    items: ['Control Scheduler', 'Trigger Engine', 'Execution Engine', 'Exception Handler']
                  },
                  {
                    layer: 'CONTROL EXECUTION SANDBOX',
                    color: 'bg-indigo-600 text-white',
                    icon: Shield,
                    items: ['Isolated Runtimes', 'Policy Enforcement', 'Resource Quotas', 'Audit Logging']
                  },
                  {
                    layer: 'EVIDENCE PIPELINE',
                    color: 'bg-blue-600 text-white',
                    icon: History,
                    items: ['Evidence Collector', 'Metadata Annotator', 'Immutable Evidence Store']
                  },
                  {
                    layer: 'OBSERVABILITY & ALERTING',
                    color: 'bg-rose-600 text-white',
                    icon: Activity,
                    items: ['Metrics', 'Logs', 'Traces', 'Drift Alerts', 'Fairness Alerts', 'Security Alerts']
                  },
                  {
                    layer: 'INTEGRATION FABRIC',
                    color: 'bg-slate-800 text-white',
                    icon: Link,
                    items: ['Model Registry', 'Feature Store', 'CI/CD', 'SIEM', 'GRC', 'Partner APIs']
                  }
                ].map((layer, i) => (
                  <motion.div 
                    key={layer.layer}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.05 }}
                    className={`p-5 rounded-2xl ${layer.color} shadow-md border border-white/10 relative group overflow-hidden`}
                  >
                    <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                      <layer.icon className="w-10 h-10" />
                    </div>
                    <div className="relative z-10 flex flex-col md:flex-row md:items-center gap-6">
                      <div className="md:w-56 shrink-0">
                        <div className="text-[10px] font-black uppercase tracking-[0.3em] opacity-60 mb-1">{layer.layer}</div>
                        <div className="h-1 w-12 bg-white/20 rounded-full" />
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {layer.items.map((item, j) => (
                          <div key={j} className="px-3 py-1 bg-white/10 rounded-lg border border-white/10 text-[10px] font-bold tracking-tight hover:bg-white/20 transition-colors">
                            {item}
                          </div>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* GLOBAL CONTROLS RUNTIME API — ARCHITECTURE */}
        <div className="mb-12">
          <div className="bg-slate-900 rounded-3xl border border-white/5 p-8 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 opacity-50" />
            
            <div className="relative z-10">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-purple-600 rounded-2xl text-white shadow-lg">
                    <Braces className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-black text-white uppercase tracking-[0.2em]">Global Controls Runtime API</h3>
                    <p className="text-slate-400 text-sm font-medium uppercase tracking-widest">Interface Architecture & Endpoint Governance</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="px-4 py-2 bg-white/5 text-slate-300 text-[10px] font-black uppercase tracking-widest rounded-xl border border-white/10">
                    API Architecture v1.0
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4">
                {[
                  {
                    layer: 'AUTH & ACCESS',
                    color: 'bg-white text-slate-900',
                    icon: KeyRound,
                    items: ['OAuth 2.0', 'JIT Access', 'Per-Control Scopes', 'Audit Logging']
                  },
                  {
                    layer: 'CONTROL EXECUTION APIs',
                    color: 'bg-indigo-600 text-white',
                    icon: Play,
                    items: ['/controls/run/{id}', '/controls/status/{id}', '/controls/history/{id}']
                  },
                  {
                    layer: 'EVIDENCE APIs',
                    color: 'bg-blue-600 text-white',
                    icon: FileText,
                    items: ['/evidence/{controlId}/{runId}', '/evidence/search', '/evidence/metadata']
                  },
                  {
                    layer: 'MONITORING APIs',
                    color: 'bg-rose-600 text-white',
                    icon: Activity,
                    items: ['/alerts/drift', '/alerts/fairness', '/alerts/security', '/alerts/dq']
                  },
                  {
                    layer: 'ADMIN APIs',
                    color: 'bg-slate-800 text-white',
                    icon: Settings,
                    items: ['/controls/register', '/controls/update', '/controls/deprecate']
                  }
                ].map((layer, i) => (
                  <motion.div 
                    key={layer.layer}
                    initial={{ opacity: 0, y: 10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.05 }}
                    className={`p-5 rounded-2xl ${layer.color} shadow-md border border-white/10 relative group overflow-hidden`}
                  >
                    <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                      <layer.icon className="w-10 h-10" />
                    </div>
                    <div className="relative z-10 flex flex-col md:flex-row md:items-center gap-6">
                      <div className="md:w-64 shrink-0">
                        <div className="text-[10px] font-black uppercase tracking-[0.3em] opacity-60 mb-1">{layer.layer}</div>
                        <div className="h-1 w-12 bg-white/20 rounded-full" />
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {layer.items.map((item, j) => (
                          <div key={j} className="px-3 py-1 bg-white/10 rounded-lg border border-white/10 text-[10px] font-mono font-bold tracking-tight hover:bg-white/20 transition-colors">
                            {item}
                          </div>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* GLOBAL CONTROLS EXECUTION ENGINE — IMPLEMENTATION */}
        <div className="mb-12">
          <div className="bg-slate-900 rounded-3xl border border-white/5 p-8 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-full h-full bg-[radial-gradient(circle_at_top_right,rgba(99,102,241,0.05),transparent)] pointer-events-none" />
            
            <div className="relative z-10">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-emerald-600 rounded-2xl text-white shadow-lg">
                    <Terminal className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-black text-white uppercase tracking-[0.2em]">Global Controls Execution Engine</h3>
                    <p className="text-slate-400 text-sm font-medium uppercase tracking-widest">Implementation Architecture & Technical Stack</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="px-4 py-2 bg-emerald-500/10 text-emerald-400 text-[10px] font-black uppercase tracking-widest rounded-xl border border-emerald-500/20">
                    Implementation v1.0
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4">
                {[
                  {
                    layer: 'CONTROL ORCHESTRATION LAYER',
                    color: 'bg-white text-slate-900',
                    icon: Workflow,
                    items: ['Scheduler', 'Trigger Engine', 'Execution Engine', 'Exception Handler']
                  },
                  {
                    layer: 'CONTROL EXECUTION SANDBOX',
                    color: 'bg-indigo-600 text-white',
                    icon: Shield,
                    items: ['Isolated Runtimes', 'Policy Enforcement', 'Resource Quotas', 'Audit Logging']
                  },
                  {
                    layer: 'EVIDENCE PIPELINE',
                    color: 'bg-blue-600 text-white',
                    icon: Database,
                    items: ['Evidence Collector', 'Metadata Annotator', 'Immutable Evidence Store']
                  },
                  {
                    layer: 'OBSERVABILITY & ALERTING',
                    color: 'bg-rose-600 text-white',
                    icon: Activity,
                    items: ['Metrics', 'Logs', 'Traces', 'Drift Alerts', 'Fairness Alerts', 'Security Alerts']
                  },
                  {
                    layer: 'INTEGRATION FABRIC',
                    color: 'bg-slate-800 text-white',
                    icon: Link,
                    items: ['Model Registry', 'Feature Store', 'CI/CD', 'SIEM', 'GRC', 'Partner APIs']
                  }
                ].map((layer, i) => (
                  <motion.div 
                    key={layer.layer}
                    initial={{ opacity: 0, x: 20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.05 }}
                    className={`p-5 rounded-2xl ${layer.color} shadow-md border border-white/10 relative group overflow-hidden`}
                  >
                    <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                      <layer.icon className="w-10 h-10" />
                    </div>
                    <div className="relative z-10 flex flex-col md:flex-row md:items-center gap-6">
                      <div className="md:w-64 shrink-0">
                        <div className="text-[10px] font-black uppercase tracking-[0.3em] opacity-60 mb-1">{layer.layer}</div>
                        <div className="h-1 w-12 bg-white/20 rounded-full" />
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {layer.items.map((item, j) => (
                          <div key={j} className="px-3 py-1 bg-white/10 rounded-lg border border-white/10 text-[10px] font-bold tracking-tight hover:bg-white/20 transition-colors">
                            {item}
                          </div>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* PARTNER INTEGRATION ARCHITECTURE */}
        <div className="mb-12">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-amber-600 rounded-lg text-white">
                  <Handshake className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 uppercase tracking-tight">Partner Integration Architecture</h4>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Secure & Governed Ecosystem Connectivity</p>
                </div>
              </div>
              <div className="px-3 py-1 bg-amber-50 text-amber-600 text-[9px] font-black uppercase tracking-widest rounded-full border border-amber-100">
                Ecosystem Architecture
              </div>
            </div>

            <div className="p-8 space-y-4">
              {[
                {
                  layer: 'PARTNER SYSTEMS',
                  color: 'bg-slate-900 text-white',
                  icon: Globe,
                  items: ['Partner Data Systems', 'Partner APIs', 'Partner Dashboards']
                },
                {
                  layer: 'PARTNER INTEGRATION LAYER',
                  color: 'bg-indigo-600 text-white',
                  icon: Link,
                  items: ['API Gateway', 'Schema Validator', 'DQ Engine', 'Authentication & Authorization']
                },
                {
                  layer: 'GOVERNANCE CONTROL PLANE',
                  color: 'bg-blue-600 text-white',
                  icon: ShieldCheck,
                  items: ['Fairness Engine', 'Validation Engine', 'Drift Detection', 'Security Testing']
                },
                {
                  layer: 'DATA & MODEL PLATFORMS',
                  color: 'bg-emerald-600 text-white',
                  icon: Database,
                  items: ['Data Lake', 'Feature Store', 'Model Registry', 'Monitoring Services']
                },
                {
                  layer: 'PARTNER EXPERIENCE LAYER',
                  color: 'bg-amber-600 text-white',
                  icon: LayoutDashboard,
                  items: ['Transparency Dashboards', 'Explainability APIs', 'SLA Monitoring', 'Disputes']
                }
              ].map((layer, i) => (
                <motion.div 
                  key={layer.layer}
                  initial={{ opacity: 0, x: 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.05 }}
                  className={`p-6 rounded-2xl ${layer.color} shadow-lg border border-white/10 relative group overflow-hidden`}
                >
                  <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                    <layer.icon className="w-12 h-12" />
                  </div>
                  <div className="relative z-10">
                    <div className="text-[10px] font-black uppercase tracking-[0.3em] mb-4 opacity-60">{layer.layer}</div>
                    <div className="flex flex-wrap gap-2">
                      {layer.items.map((item, j) => (
                        <div key={j} className="px-3 py-1.5 bg-white/10 rounded-lg border border-white/10 text-[10px] font-bold tracking-tight hover:bg-white/20 transition-colors">
                          {item}
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        {/* PARTNER FAIRNESS OPERATING MODEL */}
        <div className="mb-12">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-rose-600 rounded-lg text-white">
                  <Scale className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 uppercase tracking-tight">Partner Fairness Operating Model</h4>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Bias Mitigation & Equitable Ecosystem Governance</p>
                </div>
              </div>
              <div className="px-3 py-1 bg-rose-50 text-rose-600 text-[9px] font-black uppercase tracking-widest rounded-full border border-rose-100">
                Fairness Framework
              </div>
            </div>

            <div className="p-8 space-y-4">
              {[
                {
                  layer: 'FAIRNESS GOVERNANCE',
                  color: 'bg-slate-900 text-white',
                  icon: ShieldCheck,
                  items: ['Fairness Policy', 'Fairness Standards', 'MRB', 'Partner Governance Office']
                },
                {
                  layer: 'FAIRNESS OPERATIONS',
                  color: 'bg-rose-600 text-white',
                  icon: Activity,
                  items: ['Fairness Testing', 'Drift Monitoring', 'Corridor Parity', 'Bias Flag Review']
                },
                {
                  layer: 'PARTNER EXPERIENCE',
                  color: 'bg-indigo-600 text-white',
                  icon: LayoutDashboard,
                  items: ['Fairness Dashboards', 'Transparency Reports', 'Explainability APIs']
                },
                {
                  layer: 'ESCALATION & REMEDIATION',
                  color: 'bg-amber-600 text-white',
                  icon: AlertTriangle,
                  items: ['Bias Mitigation', 'Partner Review', 'MRB Escalation', 'MRC Oversight']
                }
              ].map((layer, i) => (
                <motion.div 
                  key={layer.layer}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.05 }}
                  className={`p-6 rounded-2xl ${layer.color} shadow-lg border border-white/10 relative group overflow-hidden`}
                >
                  <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                    <layer.icon className="w-12 h-12" />
                  </div>
                  <div className="relative z-10">
                    <div className="text-[10px] font-black uppercase tracking-[0.3em] mb-4 opacity-60">{layer.layer}</div>
                    <div className="flex flex-wrap gap-2">
                      {layer.items.map((item, j) => (
                        <div key={j} className="px-3 py-1.5 bg-white/10 rounded-lg border border-white/10 text-[10px] font-bold tracking-tight hover:bg-white/20 transition-colors">
                          {item}
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        {/* PARTNER TRUST & TRANSPARENCY OPERATING SYSTEM */}
        <div className="mb-12">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-emerald-600 rounded-lg text-white">
                  <Heart className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 uppercase tracking-tight">Partner Trust & Transparency OS</h4>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Intelligence-Driven Governance & Ecosystem Trust</p>
                </div>
              </div>
              <div className="px-3 py-1 bg-emerald-50 text-emerald-600 text-[9px] font-black uppercase tracking-widest rounded-full border border-emerald-100">
                Trust Operating System
              </div>
            </div>

            <div className="p-8 space-y-4">
              {[
                {
                  layer: 'TRUST INTELLIGENCE',
                  color: 'bg-slate-900 text-white',
                  icon: Brain,
                  items: ['Trust Index', 'Fairness Risk', 'Transparency Engagement', 'Data Quality Scores']
                },
                {
                  layer: 'TRANSPARENCY DELIVERY',
                  color: 'bg-indigo-600 text-white',
                  icon: LayoutDashboard,
                  items: ['Dashboards', 'Explainability APIs', 'Reason Codes', 'Fairness Reports']
                },
                {
                  layer: 'FAIRNESS GOVERNANCE',
                  color: 'bg-rose-600 text-white',
                  icon: Scale,
                  items: ['Testing', 'Drift Monitoring', 'Bias Flags', 'Mitigation Workflows']
                },
                {
                  layer: 'PARTNER OPERATIONS',
                  color: 'bg-emerald-600 text-white',
                  icon: Handshake,
                  items: ['SLA Monitoring', 'Disputes', 'Certification', 'Onboarding']
                }
              ].map((layer, i) => (
                <motion.div 
                  key={layer.layer}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.05 }}
                  className={`p-6 rounded-2xl ${layer.color} shadow-lg border border-white/10 relative group overflow-hidden`}
                >
                  <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                    <layer.icon className="w-12 h-12" />
                  </div>
                  <div className="relative z-10">
                    <div className="text-[10px] font-black uppercase tracking-[0.3em] mb-4 opacity-60">{layer.layer}</div>
                    <div className="flex flex-wrap gap-2">
                      {layer.items.map((item, j) => (
                        <div key={j} className="px-3 py-1.5 bg-white/10 rounded-lg border border-white/10 text-[10px] font-bold tracking-tight hover:bg-white/20 transition-colors">
                          {item}
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        {/* SOC 2.0 — ML SECURITY OPERATIONS ARCHITECTURE */}
        <div className="mb-12">
          <div className="bg-slate-900 rounded-3xl border border-white/5 p-8 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-full h-full bg-[radial-gradient(circle_at_top_right,rgba(244,63,94,0.05),transparent)] pointer-events-none" />
            
            <div className="relative z-10">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-rose-600 rounded-2xl text-white shadow-lg">
                    <ShieldAlert className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-black text-white uppercase tracking-[0.2em]">SOC 2.0 — ML Security Operations</h3>
                    <p className="text-slate-400 text-sm font-medium uppercase tracking-widest">Adversarial Defense & Runtime Security Architecture</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="px-4 py-2 bg-rose-500/10 text-rose-400 text-[10px] font-black uppercase tracking-widest rounded-xl border border-rose-500/20">
                    Security Architecture v2.0
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4">
                {[
                  {
                    layer: 'THREAT INTELLIGENCE',
                    color: 'bg-white text-slate-900',
                    icon: Brain,
                    items: ['MITRE ATLAS', 'Partner Signals', 'Drift Signals', 'Red-Team Intelligence']
                  },
                  {
                    layer: 'DETECTION FABRIC',
                    color: 'bg-rose-600 text-white',
                    icon: Eye,
                    items: ['Adversarial Detection', 'Poisoning Detection', 'Runtime Anomaly Detection', 'Partner Behavior Analytics', 'Drift-Based Exploitation Detection']
                  },
                  {
                    layer: 'RESPONSE ENGINE',
                    color: 'bg-indigo-600 text-white',
                    icon: Zap,
                    items: ['Automated Containment', 'Playbooks', 'Forensics', 'Partner Notification']
                  },
                  {
                    layer: 'OBSERVABILITY',
                    color: 'bg-blue-600 text-white',
                    icon: Activity,
                    items: ['SIEM', 'Logs', 'Metrics', 'Traces', 'Model Integrity Monitoring']
                  },
                  {
                    layer: 'INTEGRATION LAYER',
                    color: 'bg-slate-800 text-white',
                    icon: Link,
                    items: ['Model Registry', 'CI/CD', 'Feature Store', 'Partner APIs', 'GRC Platform']
                  }
                ].map((layer, i) => (
                  <motion.div 
                    key={layer.layer}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.05 }}
                    className={`p-5 rounded-2xl ${layer.color} shadow-md border border-white/10 relative group overflow-hidden`}
                  >
                    <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                      <layer.icon className="w-10 h-10" />
                    </div>
                    <div className="relative z-10 flex flex-col md:flex-row md:items-center gap-6">
                      <div className="md:w-64 shrink-0">
                        <div className="text-[10px] font-black uppercase tracking-[0.3em] opacity-60 mb-1">{layer.layer}</div>
                        <div className="h-1 w-12 bg-white/20 rounded-full" />
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {layer.items.map((item, j) => (
                          <div key={j} className="px-3 py-1 bg-white/10 rounded-lg border border-white/10 text-[10px] font-bold tracking-tight hover:bg-white/20 transition-colors">
                            {item}
                          </div>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* BOARD EDITION — ENTERPRISE MODEL GOVERNANCE */}
        <div className="mb-12">
          <div className="bg-slate-900 rounded-3xl p-10 shadow-2xl border border-white/10 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-full h-full bg-gradient-to-br from-indigo-500/5 via-transparent to-rose-500/5 pointer-events-none" />
            
            <div className="relative z-10">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
                <div className="flex items-center gap-5">
                  <div className="p-4 bg-white rounded-2xl text-slate-900 shadow-xl">
                    <ShieldCheck className="w-8 h-8" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-black text-white uppercase tracking-[0.4em]">Board Edition</h3>
                    <p className="text-slate-400 text-sm mt-1 font-medium uppercase tracking-widest">Enterprise Model Governance & Risk Oversight</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="px-5 py-2.5 bg-white/5 border border-white/10 rounded-2xl backdrop-blur-md">
                    <span className="text-[10px] font-black text-slate-300 uppercase tracking-[0.3em]">Fiduciary Oversight v1.0</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-6">
                {[
                  {
                    layer: 'STRATEGIC OVERSIGHT',
                    color: 'bg-white text-slate-900',
                    icon: Users,
                    items: ['Board of Directors', 'Executive Steering Committee', 'Global Risk Committee']
                  },
                  {
                    layer: 'GOVERNANCE CONTROL PLANE',
                    color: 'bg-indigo-600 text-white',
                    icon: Workflow,
                    items: ['Model Registry', 'Validation', 'Fairness', 'Drift', 'Security', 'Evidence Automation']
                  },
                  {
                    layer: 'ML PLATFORM',
                    color: 'bg-blue-600 text-white',
                    icon: Cpu,
                    items: ['Feature Store', 'Training Pipelines', 'CI/CD', 'Monitoring', 'Deployment Engine']
                  },
                  {
                    layer: 'DATA PLATFORM',
                    color: 'bg-emerald-600 text-white',
                    icon: Database,
                    items: ['Data Lake', 'Metadata Catalog', 'Lineage Engine', 'Data Quality Engine']
                  },
                  {
                    layer: 'SECURITY PLATFORM',
                    color: 'bg-rose-600 text-white',
                    icon: Lock,
                    items: ['Zero-Trust IAM', 'WAF', 'API Gateway', 'SIEM', 'Adversarial Defense']
                  },
                  {
                    layer: 'PARTNER & TRANSPARENCY',
                    color: 'bg-amber-600 text-white',
                    icon: Globe,
                    items: ['Partner Portal', 'Transparency Dashboards', 'Fairness Certification']
                  }
                ].map((layer, i) => (
                  <motion.div 
                    key={layer.layer}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.1 }}
                    className={`p-8 rounded-3xl ${layer.color} shadow-2xl border border-white/10 relative group overflow-hidden`}
                  >
                    <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:opacity-20 transition-opacity">
                      <layer.icon className="w-20 h-20" />
                    </div>
                    <div className="relative z-10 flex flex-col lg:flex-row lg:items-center gap-8">
                      <div className="lg:w-72 shrink-0">
                        <div className="text-[11px] font-black uppercase tracking-[0.5em] opacity-60 mb-2">{layer.layer}</div>
                        <div className="h-1.5 w-16 bg-current opacity-20 rounded-full" />
                      </div>
                      <div className="flex flex-wrap gap-3">
                        {layer.items.map((item, j) => (
                          <div key={j} className="px-5 py-2 bg-white/10 rounded-xl border border-white/10 text-[11px] font-black uppercase tracking-wider hover:bg-white/20 transition-colors">
                            {item}
                          </div>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>

              <div className="mt-12 flex items-center justify-center gap-12 opacity-50">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full bg-emerald-500" />
                  <span className="text-[10px] font-black text-white uppercase tracking-[0.3em]">Continuous Compliance</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full bg-blue-500" />
                  <span className="text-[10px] font-black text-white uppercase tracking-[0.3em]">Strategic Alignment</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full bg-rose-500" />
                  <span className="text-[10px] font-black text-white uppercase tracking-[0.3em]">Risk Mitigation</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* CFO EDITION — ENTERPRISE MODEL GOVERNANCE */}
        <div className="mb-12">
          <div className="bg-slate-900 rounded-3xl p-10 shadow-2xl border border-white/10 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-full h-full bg-gradient-to-br from-emerald-500/5 via-transparent to-blue-500/5 pointer-events-none" />
            
            <div className="relative z-10">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
                <div className="flex items-center gap-5">
                  <div className="p-4 bg-white rounded-2xl text-slate-900 shadow-xl">
                    <CircleDollarSign className="w-8 h-8" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-black text-white uppercase tracking-[0.4em]">CFO Edition</h3>
                    <p className="text-slate-400 text-sm mt-1 font-medium uppercase tracking-widest">Financial Oversight & Model Risk Capitalization</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="px-5 py-2.5 bg-white/5 border border-white/10 rounded-2xl backdrop-blur-md">
                    <span className="text-[10px] font-black text-slate-300 uppercase tracking-[0.3em]">Financial Governance v1.0</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-6">
                {[
                  {
                    layer: 'FINANCIAL OVERSIGHT',
                    color: 'bg-white text-slate-900',
                    icon: BarChart3,
                    items: ['Cost Governance', 'Risk Capital Allocation', 'Regulatory Exposure', 'ROI Modeling']
                  },
                  {
                    layer: 'GOVERNANCE CONTROL PLANE',
                    color: 'bg-indigo-600 text-white',
                    icon: Workflow,
                    items: ['Validation', 'Fairness', 'Drift', 'Security', 'Evidence Automation']
                  },
                  {
                    layer: 'ML PLATFORM',
                    color: 'bg-blue-600 text-white',
                    icon: Cpu,
                    items: ['Feature Store', 'Pipelines', 'Monitoring', 'Deployment Engine']
                  },
                  {
                    layer: 'DATA PLATFORM',
                    color: 'bg-emerald-600 text-white',
                    icon: Database,
                    items: ['Data Lake', 'Metadata', 'Lineage', 'Data Quality']
                  },
                  {
                    layer: 'SECURITY PLATFORM',
                    color: 'bg-rose-600 text-white',
                    icon: Lock,
                    items: ['IAM', 'WAF', 'SIEM', 'Adversarial Defense', 'Zero-Trust Network']
                  },
                  {
                    layer: 'PARTNER & TRANSPARENCY',
                    color: 'bg-amber-600 text-white',
                    icon: Globe,
                    items: ['Partner Dashboards', 'SLA Monitoring', 'Fairness Certification']
                  }
                ].map((layer, i) => (
                  <motion.div 
                    key={layer.layer}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.1 }}
                    className={`p-8 rounded-3xl ${layer.color} shadow-2xl border border-white/10 relative group overflow-hidden`}
                  >
                    <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:opacity-20 transition-opacity">
                      <layer.icon className="w-20 h-20" />
                    </div>
                    <div className="relative z-10 flex flex-col lg:flex-row lg:items-center gap-8">
                      <div className="lg:w-72 shrink-0">
                        <div className="text-[11px] font-black uppercase tracking-[0.5em] opacity-60 mb-2">{layer.layer}</div>
                        <div className="h-1.5 w-16 bg-current opacity-20 rounded-full" />
                      </div>
                      <div className="flex flex-wrap gap-3">
                        {layer.items.map((item, j) => (
                          <div key={j} className="px-5 py-2 bg-white/10 rounded-xl border border-white/10 text-[11px] font-black uppercase tracking-wider hover:bg-white/20 transition-colors">
                            {item}
                          </div>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>

              <div className="mt-12 flex items-center justify-center gap-12 opacity-50">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full bg-emerald-500" />
                  <span className="text-[10px] font-black text-white uppercase tracking-[0.3em]">Capital Efficiency</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full bg-blue-500" />
                  <span className="text-[10px] font-black text-white uppercase tracking-[0.3em]">Risk Quantification</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full bg-rose-500" />
                  <span className="text-[10px] font-black text-white uppercase tracking-[0.3em]">Regulatory Compliance</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* CHRO EDITION — ENTERPRISE MODEL GOVERNANCE */}
        <div className="mb-12">
          <div className="bg-slate-900 rounded-3xl p-10 shadow-2xl border border-white/10 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-full h-full bg-gradient-to-br from-purple-500/5 via-transparent to-emerald-500/5 pointer-events-none" />
            
            <div className="relative z-10">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
                <div className="flex items-center gap-5">
                  <div className="p-4 bg-white rounded-2xl text-slate-900 shadow-xl">
                    <UserCheck className="w-8 h-8" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-black text-white uppercase tracking-[0.4em]">CHRO Edition</h3>
                    <p className="text-slate-400 text-sm mt-1 font-medium uppercase tracking-widest">Workforce Strategy & Responsible AI Culture</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="px-5 py-2.5 bg-white/5 border border-white/10 rounded-2xl backdrop-blur-md">
                    <span className="text-[10px] font-black text-slate-300 uppercase tracking-[0.3em]">Workforce Governance v1.0</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-6">
                {[
                  {
                    layer: 'WORKFORCE STRATEGY',
                    color: 'bg-white text-slate-900',
                    icon: Users,
                    items: ['Skills Framework', 'Role Definitions', 'Workforce Planning', 'Talent Pipelines']
                  },
                  {
                    layer: 'GOVERNANCE CONTROL PLANE',
                    color: 'bg-indigo-600 text-white',
                    icon: Workflow,
                    items: ['Validation', 'Fairness', 'Drift', 'Security', 'Evidence Automation']
                  },
                  {
                    layer: 'PEOPLE OPERATIONS',
                    color: 'bg-purple-600 text-white',
                    icon: RefreshCw,
                    items: ['Training', 'Certification', 'Change Management', 'Communication']
                  },
                  {
                    layer: 'CULTURE & ETHICS',
                    color: 'bg-emerald-600 text-white',
                    icon: Heart,
                    items: ['Ethical AI Principles', 'Responsible AI Culture', 'Leadership Enablement']
                  },
                  {
                    layer: 'ORGANIZATIONAL READINESS',
                    color: 'bg-blue-600 text-white',
                    icon: Gauge,
                    items: ['Capability Maturity', 'Adoption Metrics', 'Readiness Assessments']
                  },
                  {
                    layer: 'PARTNER & STAKEHOLDER ENGAGEMENT',
                    color: 'bg-slate-800 text-white',
                    icon: Globe,
                    items: ['Partner Training', 'Transparency Programs', 'Fairness Certification']
                  }
                ].map((layer, i) => (
                  <motion.div 
                    key={layer.layer}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.1 }}
                    className={`p-8 rounded-3xl ${layer.color} shadow-2xl border border-white/10 relative group overflow-hidden`}
                  >
                    <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:opacity-20 transition-opacity">
                      <layer.icon className="w-20 h-20" />
                    </div>
                    <div className="relative z-10 flex flex-col lg:flex-row lg:items-center gap-8">
                      <div className="lg:w-72 shrink-0">
                        <div className="text-[11px] font-black uppercase tracking-[0.5em] opacity-60 mb-2">{layer.layer}</div>
                        <div className="h-1.5 w-16 bg-current opacity-20 rounded-full" />
                      </div>
                      <div className="flex flex-wrap gap-3">
                        {layer.items.map((item, j) => (
                          <div key={j} className="px-5 py-2 bg-white/10 rounded-xl border border-white/10 text-[11px] font-black uppercase tracking-wider hover:bg-white/20 transition-colors">
                            {item}
                          </div>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>

              <div className="mt-12 flex items-center justify-center gap-12 opacity-50">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full bg-purple-500" />
                  <span className="text-[10px] font-black text-white uppercase tracking-[0.3em]">Talent Mobility</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full bg-emerald-500" />
                  <span className="text-[10px] font-black text-white uppercase tracking-[0.3em]">Ethical Culture</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full bg-blue-500" />
                  <span className="text-[10px] font-black text-white uppercase tracking-[0.3em]">Future Readiness</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* CEO EDITION — ENTERPRISE MODEL GOVERNANCE */}
        <div className="mb-12">
          <div className="bg-slate-900 rounded-3xl p-10 shadow-2xl border border-white/10 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-full h-full bg-gradient-to-br from-amber-500/5 via-transparent to-indigo-500/5 pointer-events-none" />
            
            <div className="relative z-10">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
                <div className="flex items-center gap-5">
                  <div className="p-4 bg-white rounded-2xl text-slate-900 shadow-xl">
                    <Brain className="w-8 h-8" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-black text-white uppercase tracking-[0.4em]">CEO Edition</h3>
                    <p className="text-slate-400 text-sm mt-1 font-medium uppercase tracking-widest">Enterprise Model Governance & Strategic Value Creation</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="px-5 py-2.5 bg-white/5 border border-white/10 rounded-2xl backdrop-blur-md">
                    <span className="text-[10px] font-black text-slate-300 uppercase tracking-[0.3em]">Strategic Governance v1.0</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-6">
                {[
                  {
                    layer: 'STRATEGIC OVERSIGHT',
                    color: 'bg-white text-slate-900',
                    icon: Users,
                    items: ['CEO', 'Board', 'Executive Steering Committee', 'Global Risk Committee']
                  },
                  {
                    layer: 'GOVERNANCE CONTROL PLANE',
                    color: 'bg-indigo-600 text-white',
                    icon: Workflow,
                    items: ['Validation', 'Fairness', 'Drift', 'Security', 'Evidence Automation']
                  },
                  {
                    layer: 'AI VALUE CREATION LAYER',
                    color: 'bg-amber-600 text-white',
                    icon: Zap,
                    items: ['Product AI', 'Operational AI', 'Partner AI', 'Predictive AI']
                  },
                  {
                    layer: 'ML PLATFORM',
                    color: 'bg-blue-600 text-white',
                    icon: Cpu,
                    items: ['Feature Store', 'Pipelines', 'Monitoring', 'Deployment Engine']
                  },
                  {
                    layer: 'DATA PLATFORM',
                    color: 'bg-emerald-600 text-white',
                    icon: Database,
                    items: ['Data Lake', 'Metadata', 'Lineage', 'Data Quality']
                  },
                  {
                    layer: 'SECURITY PLATFORM',
                    color: 'bg-rose-600 text-white',
                    icon: Lock,
                    items: ['Zero-Trust IAM', 'WAF', 'SIEM', 'Adversarial Defense', 'Partner Behavior Analytics']
                  },
                  {
                    layer: 'TRUST & TRANSPARENCY',
                    color: 'bg-slate-800 text-white',
                    icon: Globe,
                    items: ['Partner Dashboards', 'Fairness Certification', 'Explainability APIs']
                  }
                ].map((layer, i) => (
                  <motion.div 
                    key={layer.layer}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.1 }}
                    className={`p-8 rounded-3xl ${layer.color} shadow-2xl border border-white/10 relative group overflow-hidden`}
                  >
                    <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:opacity-20 transition-opacity">
                      <layer.icon className="w-20 h-20" />
                    </div>
                    <div className="relative z-10 flex flex-col lg:flex-row lg:items-center gap-8">
                      <div className="lg:w-72 shrink-0">
                        <div className="text-[11px] font-black uppercase tracking-[0.5em] opacity-60 mb-2">{layer.layer}</div>
                        <div className="h-1.5 w-16 bg-current opacity-20 rounded-full" />
                      </div>
                      <div className="flex flex-wrap gap-3">
                        {layer.items.map((item, j) => (
                          <div key={j} className="px-5 py-2 bg-white/10 rounded-xl border border-white/10 text-[11px] font-black uppercase tracking-wider hover:bg-white/20 transition-colors">
                            {item}
                          </div>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>

              <div className="mt-12 flex items-center justify-center gap-12 opacity-50">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full bg-amber-500" />
                  <span className="text-[10px] font-black text-white uppercase tracking-[0.3em]">Value Realization</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full bg-blue-500" />
                  <span className="text-[10px] font-black text-white uppercase tracking-[0.3em]">Strategic Trust</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full bg-emerald-500" />
                  <span className="text-[10px] font-black text-white uppercase tracking-[0.3em]">Ethical Leadership</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* DRONE DELIVERY PLATFORM (DDP) ARCHITECTURE */}
        <div className="mb-12">
          <div className="bg-slate-900 rounded-3xl p-10 shadow-2xl border border-white/10 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-full h-full bg-[radial-gradient(circle_at_top_right,rgba(56,189,248,0.05),transparent)] pointer-events-none" />
            
            <div className="relative z-10">
              <div className="text-center mb-16">
                <div className="inline-flex items-center gap-3 px-4 py-2 bg-sky-500/10 border border-sky-500/20 rounded-full mb-6">
                  <Plane className="w-4 h-4 text-sky-400" />
                  <span className="text-[10px] font-black text-sky-300 uppercase tracking-[0.3em]">Autonomous Logistics v2.4</span>
                </div>
                <h3 className="text-3xl font-black text-white uppercase tracking-[0.4em] mb-4">Drone Delivery Platform</h3>
                <p className="text-slate-400 text-sm font-medium uppercase tracking-widest max-w-2xl mx-auto">Next-Generation Autonomous Aerial Fulfillment & Fleet Intelligence</p>
              </div>

              <div className="flex flex-col items-center gap-8 relative">
                {/* Platform Core */}
                <motion.div 
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  className="w-full max-w-md p-8 rounded-3xl bg-sky-600 text-white shadow-2xl shadow-sky-500/20 border border-white/20 text-center relative z-20"
                >
                  <div className="absolute -top-6 left-1/2 -translate-x-1/2 p-4 bg-white rounded-2xl text-sky-600 shadow-xl">
                    <Plane className="w-8 h-8" />
                  </div>
                  <div className="mt-4">
                    <div className="text-[10px] font-black uppercase tracking-[0.4em] opacity-60 mb-1">Core Platform</div>
                    <div className="text-xl font-black uppercase tracking-widest">Drone Delivery Platform (DDP)</div>
                  </div>
                </motion.div>

                {/* Connection Lines */}
                <div className="absolute top-32 bottom-0 left-1/2 w-px bg-gradient-to-b from-sky-500/50 via-slate-700 to-transparent -translate-x-1/2 z-0" />

                {/* Intelligence Layer */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full relative z-10">
                  {[
                    { label: 'Navigation Engine', icon: Navigation, desc: 'Real-time spatial awareness & pathfinding' },
                    { label: 'Obstacle Detection', icon: Eye, desc: 'Computer vision & LiDAR collision avoidance' },
                    { label: 'Weather Risk Model', icon: CloudRain, desc: 'Dynamic atmospheric risk assessment' }
                  ].map((item, i) => (
                    <motion.div
                      key={item.label}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.1 }}
                      className="p-6 rounded-2xl bg-slate-800 border border-white/10 text-center group hover:border-sky-500/50 transition-colors"
                    >
                      <div className="w-12 h-12 rounded-xl bg-sky-500/10 border border-sky-500/20 flex items-center justify-center mx-auto mb-4 text-sky-400 group-hover:scale-110 transition-transform">
                        <item.icon className="w-6 h-6" />
                      </div>
                      <div className="text-xs font-black text-white uppercase tracking-widest mb-2">{item.label}</div>
                      <div className="text-[10px] text-slate-400 font-medium leading-relaxed">{item.desc}</div>
                    </motion.div>
                  ))}
                </div>

                {/* Optimization & Auth */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full max-w-2xl relative z-10">
                  {[
                    { label: 'Flight Path Optimization', icon: TrendingUp, desc: 'Efficiency-driven route recalculation' },
                    { label: 'Package Auth Module', icon: ShieldCheck, desc: 'Secure delivery verification & chain of custody' }
                  ].map((item, i) => (
                    <motion.div
                      key={item.label}
                      initial={{ opacity: 0, scale: 0.95 }}
                      whileInView={{ opacity: 1, scale: 1 }}
                      transition={{ delay: 0.3 + i * 0.1 }}
                      className="p-6 rounded-2xl bg-slate-800/50 backdrop-blur-md border border-white/10 flex items-center gap-5 group hover:bg-slate-800 transition-colors"
                    >
                      <div className="p-3 rounded-xl bg-indigo-500/10 text-indigo-400 group-hover:rotate-12 transition-transform">
                        <item.icon className="w-6 h-6" />
                      </div>
                      <div>
                        <div className="text-xs font-black text-white uppercase tracking-widest">{item.label}</div>
                        <div className="text-[9px] text-slate-500 font-bold uppercase tracking-tighter mt-1">{item.desc}</div>
                      </div>
                    </motion.div>
                  ))}
                </div>

                {/* Identity & Telemetry */}
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  className="w-full max-w-md p-6 rounded-2xl bg-emerald-600 text-white shadow-xl border border-white/10 flex items-center justify-center gap-4 relative z-10"
                >
                  <Fingerprint className="w-6 h-6" />
                  <div className="text-sm font-black uppercase tracking-[0.3em]">Drone Identity & Telemetry</div>
                </motion.div>

                <ArrowDown className="w-6 h-6 text-slate-700 animate-bounce" />

                {/* Fleet Management */}
                <motion.div 
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  className="w-full max-w-lg p-8 rounded-3xl bg-slate-800 border-2 border-sky-500/30 shadow-2xl text-center relative z-10"
                >
                  <div className="text-[10px] font-black text-sky-400 uppercase tracking-[0.5em] mb-2">Control Layer</div>
                  <div className="text-2xl font-black text-white uppercase tracking-[0.3em]">Fleet Management System</div>
                </motion.div>

                {/* Operational Layer */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 w-full relative z-10">
                  {[
                    { label: 'Maintenance Scheduler', icon: Wrench, color: 'text-amber-400' },
                    { label: 'SLA Engine', icon: Clock, color: 'text-emerald-400' },
                    { label: 'Transparency Dashboards', icon: FileText, color: 'text-blue-400' }
                  ].map((item, i) => (
                    <motion.div
                      key={item.label}
                      initial={{ opacity: 0, x: i === 0 ? -20 : i === 2 ? 20 : 0 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.5 + i * 0.1 }}
                      className="p-5 rounded-2xl bg-white/5 border border-white/5 flex flex-col items-center gap-3 hover:bg-white/10 transition-colors"
                    >
                      <item.icon className={`w-5 h-5 ${item.color}`} />
                      <div className="text-[10px] font-black text-white uppercase tracking-widest text-center">{item.label}</div>
                    </motion.div>
                  ))}
                </div>
              </div>

              <div className="mt-16 flex items-center justify-center gap-12 opacity-30">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-sky-500" />
                  <span className="text-[9px] font-black text-white uppercase tracking-[0.2em]">Telemetry Stream</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-500" />
                  <span className="text-[9px] font-black text-white uppercase tracking-[0.2em]">Identity Auth</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-amber-500" />
                  <span className="text-[9px] font-black text-white uppercase tracking-[0.2em]">Maintenance Loop</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* GOVERNANCE HIERARCHY & COMMAND CHAIN */}
        <div className="mb-12">
          <div className="bg-slate-900 rounded-3xl p-10 shadow-2xl border border-white/10 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_bottom_left,rgba(99,102,241,0.05),transparent)] pointer-events-none" />
            
            <div className="relative z-10">
              <div className="text-center mb-16">
                <div className="inline-flex items-center gap-3 px-4 py-2 bg-white/5 border border-white/10 rounded-full mb-6">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span className="text-[10px] font-black text-slate-300 uppercase tracking-[0.3em]">Governance Command Chain v1.0</span>
                </div>
                <h3 className="text-3xl font-black text-white uppercase tracking-[0.4em] mb-4">Governance Hierarchy</h3>
                <p className="text-slate-400 text-sm font-medium uppercase tracking-widest max-w-2xl mx-auto">Formalized escalation paths and oversight structures for enterprise AI/ML integrity</p>
              </div>

              <div className="max-w-4xl mx-auto flex flex-col items-center gap-4 relative">
                {/* Vertical Connecting Line */}
                <div className="absolute top-0 bottom-0 left-1/2 w-px bg-gradient-to-b from-indigo-500/50 via-slate-700 to-indigo-500/50 -translate-x-1/2 z-0" />

                {[
                  { id: 'BOARD', label: 'Board of Directors', icon: Landmark, color: 'bg-white text-slate-900', shadow: 'shadow-white/10', desc: 'Fiduciary oversight & strategic risk appetite' },
                  { id: 'ESC', label: 'Executive Steering Committee (ESC)', icon: Users, color: 'bg-slate-800 text-white', shadow: 'shadow-indigo-500/20', desc: 'Policy approval & cross-functional alignment' },
                  { id: 'GRC', label: 'Global Risk Committee (GRC)', icon: ShieldAlert, color: 'bg-rose-600 text-white', shadow: 'shadow-rose-500/20', desc: 'Enterprise risk monitoring & mitigation' },
                  { id: 'MRC', label: 'Model Risk Committee (MRC)', icon: Scale, color: 'bg-indigo-600 text-white', shadow: 'shadow-indigo-500/20', desc: 'Technical risk assessment & validation standards' },
                  { id: 'MRB', label: 'Model Review Board (MRB)', icon: ClipboardCheck, color: 'bg-blue-600 text-white', shadow: 'shadow-blue-500/20', desc: 'Independent validation & peer review' },
                  { id: 'MGO', label: 'Model Governance Office (MGO)', icon: Briefcase, color: 'bg-emerald-600 text-white', shadow: 'shadow-emerald-500/20', desc: 'Centralized policy execution & automation' },
                  { id: 'REGIONAL', label: 'Regional MGOs', icon: Globe, color: 'bg-slate-800 text-white', shadow: 'shadow-slate-500/20', desc: 'Regional regulatory compliance & localization' },
                  { id: 'LOCAL', label: 'Local Execution Teams', icon: Zap, color: 'bg-amber-600 text-white', shadow: 'shadow-amber-500/20', desc: 'Model development & continuous monitoring' },
                  { id: 'PARTNER', label: 'Partner Governance Office', icon: Handshake, color: 'bg-slate-700 text-white', shadow: 'shadow-slate-500/20', desc: 'Third-party integrity & ecosystem trust' }
                ].map((node, i) => (
                  <React.Fragment key={node.id}>
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: i * 0.05 }}
                      className="relative z-10 w-full"
                    >
                      <div className={`group p-6 rounded-3xl ${node.color} ${node.shadow} border border-white/10 flex items-center gap-6 hover:scale-[1.02] transition-all cursor-pointer`}>
                        <div className="p-4 rounded-2xl bg-black/10 backdrop-blur-sm group-hover:scale-110 transition-transform">
                          <node.icon className="w-6 h-6" />
                        </div>
                        <div className="flex-1">
                          <div className="text-[10px] font-black uppercase tracking-[0.3em] opacity-60 mb-1">{node.id}</div>
                          <div className="text-sm font-black uppercase tracking-widest">{node.label}</div>
                          <div className="text-[10px] opacity-70 mt-1 font-medium italic">{node.desc}</div>
                        </div>
                        <div className="opacity-0 group-hover:opacity-100 transition-opacity">
                          <ArrowRight className="w-5 h-5" />
                        </div>
                      </div>
                    </motion.div>
                    {i < 8 && (
                      <motion.div 
                        initial={{ opacity: 0 }}
                        whileInView={{ opacity: 1 }}
                        className="z-10"
                      >
                        <ArrowDown className="w-4 h-4 text-slate-600" />
                      </motion.div>
                    )}
                  </React.Fragment>
                ))}
              </div>

              <div className="mt-16 pt-8 border-t border-white/5 flex flex-wrap justify-center gap-8 opacity-40">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-indigo-500" />
                  <span className="text-[9px] font-black text-white uppercase tracking-[0.2em]">Escalation Path</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-500" />
                  <span className="text-[9px] font-black text-white uppercase tracking-[0.2em]">Oversight Flow</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-rose-500" />
                  <span className="text-[9px] font-black text-white uppercase tracking-[0.2em]">Risk Reporting</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* UNIFIED ENTERPRISE MODEL GOVERNANCE ARCHITECTURE */}
        <div className="mb-12">
          <div className="bg-slate-900 rounded-3xl p-10 shadow-2xl border border-white/10 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-full h-full bg-[radial-gradient(circle_at_top_right,rgba(99,102,241,0.05),transparent)] pointer-events-none" />
            
            <div className="relative z-10">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
                <div className="flex items-center gap-5">
                  <div className="p-4 bg-white rounded-2xl text-slate-900 shadow-xl">
                    <Globe className="w-8 h-8" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-black text-white uppercase tracking-[0.4em]">Unified Enterprise Architecture</h3>
                    <p className="text-slate-400 text-sm mt-1 font-medium uppercase tracking-widest">Cross-Functional Model Governance & Strategic Alignment</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="px-5 py-2.5 bg-white/5 border border-white/10 rounded-2xl backdrop-blur-md">
                    <span className="text-[10px] font-black text-slate-300 uppercase tracking-[0.3em]">Unified Governance v1.0</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-6">
                {[
                  {
                    layer: 'CEO — STRATEGY & TRUST',
                    color: 'bg-white text-slate-900',
                    icon: Brain,
                    items: ['AI Strategy', 'Risk Appetite', 'Ethical AI', 'Partner Trust', 'Regulatory Posture']
                  },
                  {
                    layer: 'CIO — TECHNOLOGY & PLATFORM',
                    color: 'bg-indigo-600 text-white',
                    icon: Server,
                    items: ['ML Platform', 'Data Platform', 'Cloud Architecture', 'Observability']
                  },
                  {
                    layer: 'CTO — ENGINEERING & DELIVERY',
                    color: 'bg-blue-600 text-white',
                    icon: Cpu,
                    items: ['Pipelines', 'Deployment', 'Feature Store', 'CI/CD', 'Reliability Engineering']
                  },
                  {
                    layer: 'CHRO — PEOPLE & CULTURE',
                    color: 'bg-purple-600 text-white',
                    icon: Users,
                    items: ['Skills Framework', 'Training', 'Change Management', 'Responsible AI Culture']
                  },
                  {
                    layer: 'CISO — SECURITY & RESILIENCE',
                    color: 'bg-rose-600 text-white',
                    icon: Shield,
                    items: ['Zero-Trust ML Security', 'Adversarial Defense', 'SOC 2.0', 'Partner Behavior']
                  },
                  {
                    layer: 'GOVERNANCE CONTROL PLANE (CENTRAL)',
                    color: 'bg-emerald-600 text-white',
                    icon: Workflow,
                    items: ['Validation', 'Fairness', 'Drift', 'Security', 'Evidence Automation', 'GRC Bridge']
                  },
                  {
                    layer: 'PARTNER & TRANSPARENCY LAYER',
                    color: 'bg-slate-800 text-white',
                    icon: Globe,
                    items: ['Dashboards', 'Explainability APIs', 'Fairness Certification', 'SLA Monitoring']
                  }
                ].map((layer, i) => (
                  <motion.div 
                    key={layer.layer}
                    initial={{ opacity: 0, x: i % 2 === 0 ? -20 : 20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.05 }}
                    className={`p-8 rounded-3xl ${layer.color} shadow-2xl border border-white/10 relative group overflow-hidden`}
                  >
                    <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:opacity-20 transition-opacity">
                      <layer.icon className="w-20 h-20" />
                    </div>
                    <div className="relative z-10 flex flex-col lg:flex-row lg:items-center gap-8">
                      <div className="lg:w-72 shrink-0">
                        <div className="text-[11px] font-black uppercase tracking-[0.5em] opacity-60 mb-2">{layer.layer}</div>
                        <div className="h-1.5 w-16 bg-current opacity-20 rounded-full" />
                      </div>
                      <div className="flex flex-wrap gap-3">
                        {layer.items.map((item, j) => (
                          <div key={j} className="px-5 py-2 bg-white/10 rounded-xl border border-white/10 text-[11px] font-black uppercase tracking-wider hover:bg-white/20 transition-colors">
                            {item}
                          </div>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>

              <div className="mt-12 flex items-center justify-center gap-12 opacity-50">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full bg-indigo-500" />
                  <span className="text-[10px] font-black text-white uppercase tracking-[0.3em]">Unified Command</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full bg-emerald-500" />
                  <span className="text-[10px] font-black text-white uppercase tracking-[0.3em]">Cross-Functional Trust</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full bg-rose-500" />
                  <span className="text-[10px] font-black text-white uppercase tracking-[0.3em]">Enterprise Resilience</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* SOC 2.0 — AUTONOMOUS DEFENSE ARCHITECTURE */}
        <div className="mb-12">
          <div className="bg-slate-900 rounded-3xl p-10 shadow-2xl border border-white/10 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-full h-full bg-[radial-gradient(circle_at_top_right,rgba(244,63,94,0.05),transparent)] pointer-events-none" />
            
            <div className="relative z-10">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
                <div className="flex items-center gap-5">
                  <div className="p-4 bg-rose-600 rounded-2xl text-white shadow-xl shadow-rose-500/20">
                    <ShieldAlert className="w-8 h-8" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-black text-white uppercase tracking-[0.4em]">Autonomous Defense</h3>
                    <p className="text-slate-400 text-sm mt-1 font-medium uppercase tracking-widest">SOC 2.0 — Real-time Threat Containment & Self-Healing</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="px-5 py-2.5 bg-rose-500/10 border border-rose-500/20 rounded-2xl backdrop-blur-md">
                    <span className="text-[10px] font-black text-rose-400 uppercase tracking-[0.3em]">Defense v2.0</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-6">
                {[
                  {
                    layer: 'PREDICTIVE INTELLIGENCE',
                    color: 'bg-slate-800 text-white',
                    icon: Brain,
                    items: ['Drift Forecasting', 'Threat Prediction', 'Partner Risk Modeling'],
                    accent: 'border-indigo-500/30'
                  },
                  {
                    layer: 'AUTONOMOUS DETECTION FABRIC',
                    color: 'bg-slate-800 text-white',
                    icon: Radar,
                    items: ['Adversarial Detection', 'Poisoning Detection', 'Runtime Anomaly Detection'],
                    accent: 'border-emerald-500/30'
                  },
                  {
                    layer: 'AUTONOMOUS RESPONSE ENGINE',
                    color: 'bg-rose-600 text-white shadow-rose-500/20',
                    icon: Zap,
                    items: ['Auto-Containment', 'Auto-Rollback', 'Auto-Patching', 'Auto-Revalidation'],
                    accent: 'border-white/20'
                  },
                  {
                    layer: 'SELF-HEALING PIPELINES',
                    color: 'bg-slate-800 text-white',
                    icon: RefreshCw,
                    items: ['Pipeline Regeneration', 'Dependency Repair', 'Secrets Rotation'],
                    accent: 'border-blue-500/30'
                  },
                  {
                    layer: 'OBSERVABILITY & FORENSICS',
                    color: 'bg-slate-900 text-white',
                    icon: FileSearch,
                    items: ['SIEM', 'Integrity Logs', 'Evidence Snapshots', 'Forensic Replay'],
                    accent: 'border-slate-700'
                  }
                ].map((layer, i) => (
                  <motion.div 
                    key={layer.layer}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.1 }}
                    className={`p-8 rounded-3xl ${layer.color} shadow-2xl border ${layer.accent} relative group overflow-hidden`}
                  >
                    <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:opacity-20 transition-opacity">
                      <layer.icon className="w-20 h-20" />
                    </div>
                    <div className="relative z-10 flex flex-col lg:flex-row lg:items-center gap-8">
                      <div className="lg:w-72 shrink-0">
                        <div className="text-[11px] font-black uppercase tracking-[0.5em] opacity-60 mb-2">{layer.layer}</div>
                        <div className="h-1.5 w-16 bg-current opacity-20 rounded-full" />
                      </div>
                      <div className="flex flex-wrap gap-3">
                        {layer.items.map((item, j) => (
                          <div key={j} className="px-5 py-2 bg-white/5 rounded-xl border border-white/10 text-[11px] font-black uppercase tracking-wider hover:bg-white/10 transition-colors">
                            {item}
                          </div>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>

              <div className="mt-12 flex items-center justify-center gap-12 opacity-50">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full bg-rose-500 animate-pulse" />
                  <span className="text-[10px] font-black text-white uppercase tracking-[0.3em]">Active Defense</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full bg-emerald-500" />
                  <span className="text-[10px] font-black text-white uppercase tracking-[0.3em]">Zero-Trust Detection</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full bg-blue-500" />
                  <span className="text-[10px] font-black text-white uppercase tracking-[0.3em]">Self-Healing Loop</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* GOVERNANCE CONTINUOUS IMPROVEMENT LIFECYCLE */}
        <div className="mb-12">
          <div className="bg-slate-900 rounded-3xl p-8 shadow-xl border border-white/5 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 blur-[100px] rounded-full -mr-32 -mt-32" />
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-500/10 blur-[100px] rounded-full -ml-32 -mb-32" />
            
            <div className="relative z-10">
              <div className="text-center mb-12">
                <h3 className="text-xl font-black text-white uppercase tracking-[0.3em]">Governance Lifecycle</h3>
                <p className="text-slate-400 text-sm mt-2 font-medium">Continuous improvement loop for AI/ML oversight</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4 relative">
                {/* Connecting Line (Desktop) */}
                <div className="hidden lg:block absolute top-1/2 left-0 w-full h-px bg-gradient-to-r from-transparent via-slate-700 to-transparent -translate-y-1/2 z-0" />
                
                {[
                  { label: 'ASSESS', icon: Search, color: 'text-blue-400', bg: 'bg-blue-400/10', border: 'border-blue-400/20', desc: 'Risk & Impact' },
                  { label: 'PLAN', icon: ListTodo, color: 'text-indigo-400', bg: 'bg-indigo-400/10', border: 'border-indigo-400/20', desc: 'Controls & Policy' },
                  { label: 'IMPLEMENT', icon: Play, color: 'text-purple-400', bg: 'bg-purple-400/10', border: 'border-purple-400/20', desc: 'Technical Integration' },
                  { label: 'MONITOR', icon: Activity, color: 'text-emerald-400', bg: 'bg-emerald-400/10', border: 'border-emerald-400/20', desc: 'Real-time Drift' },
                  { label: 'REVIEW', icon: FileSearch, color: 'text-amber-400', bg: 'bg-amber-400/10', border: 'border-amber-400/20', desc: 'Audit & Validation' },
                  { label: 'IMPROVE', icon: TrendingUp, color: 'text-rose-400', bg: 'bg-rose-400/10', border: 'border-rose-400/20', desc: 'Optimization' }
                ].map((step, i) => (
                  <motion.div 
                    key={step.label}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.1 }}
                    className="relative z-10"
                  >
                    <div className={`p-6 rounded-2xl border ${step.border} ${step.bg} backdrop-blur-sm flex flex-col items-center text-center gap-4 group hover:scale-105 transition-transform cursor-pointer`}>
                      <div className={`p-3 rounded-xl bg-white/5 border border-white/10 ${step.color} group-hover:scale-110 transition-transform`}>
                        <step.icon className="w-6 h-6" />
                      </div>
                      <div>
                        <div className={`text-xs font-black tracking-widest ${step.color} mb-1`}>{step.label}</div>
                        <div className="text-[10px] text-slate-400 font-bold uppercase tracking-tighter leading-tight">{step.desc}</div>
                      </div>
                      
                      {/* Arrow for next step (except last) */}
                      {i < 5 && (
                        <div className="hidden lg:block absolute -right-3 top-1/2 -translate-y-1/2 z-20">
                          <ArrowRight className="w-4 h-4 text-slate-600" />
                        </div>
                      )}
                      
                      {/* Loop back arrow for last step */}
                      {i === 5 && (
                        <div className="hidden lg:block absolute -right-4 top-1/2 -translate-y-1/2 translate-x-full">
                          <RefreshCw className="w-4 h-4 text-rose-400/40 animate-spin-slow" />
                        </div>
                      )}
                    </div>
                  </motion.div>
                ))}
              </div>
              
              <div className="mt-12 flex justify-center">
                <div className="bg-white/5 border border-white/10 rounded-full px-6 py-2 flex items-center gap-3">
                  <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Cycle Active: Iteration #142</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* MODEL GOVERNANCE MATURITY HEATMAP */}
        <div className="mb-12">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <h4 className="font-bold text-slate-900 flex items-center gap-2">
                <Gauge className="w-4 h-4 text-indigo-600" />
                MODEL GOVERNANCE MATURITY HEATMAP
              </h4>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-6 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-indigo-600" />
                    <span>Current</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full border-2 border-indigo-600 bg-white" />
                    <span>Target</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-8">
              {/* Maturity Legend */}
              <div className="grid grid-cols-5 gap-4 mb-10">
                {[
                  { level: 1, label: 'Ad Hoc', desc: 'Manual & Reactive' },
                  { level: 2, label: 'Emerging', desc: 'Initial Processes' },
                  { level: 3, label: 'Defined', desc: 'Standardized' },
                  { level: 4, label: 'Managed', desc: 'Measured & Controlled' },
                  { level: 5, label: 'Optimized', desc: 'Continuous Improvement' }
                ].map((m) => (
                  <div key={m.level} className="text-center">
                    <div className="text-lg font-black text-slate-900 mb-1">{m.level}</div>
                    <div className="text-[10px] font-black text-slate-600 uppercase tracking-tighter mb-1">{m.label}</div>
                    <div className="text-[8px] text-slate-400 font-medium leading-tight">{m.desc}</div>
                  </div>
                ))}
              </div>

              <div className="space-y-4">
                {[
                  { domain: 'Governance Structure', current: 4, target: 5 },
                  { domain: 'Risk Management', current: 3, target: 4 },
                  { domain: 'Model Lifecycle Controls', current: 3, target: 4 },
                  { domain: 'Validation & Testing', current: 3, target: 4 },
                  { domain: 'Monitoring & Drift', current: 3, target: 4 },
                  { domain: 'Fairness & Bias', current: 3, target: 4 },
                  { domain: 'Security', current: 2, target: 4 },
                  { domain: 'Data Quality', current: 3, target: 4 },
                  { domain: 'Evidence & Compliance', current: 4, target: 5 },
                  { domain: 'Partner Transparency', current: 3, target: 4 },
                  { domain: 'Automation & Tooling', current: 2, target: 4 },
                  { domain: 'Continuous Improvement', current: 3, target: 5 }
                ].map((row, i) => (
                  <div key={i} className="flex items-center gap-6 group">
                    <div className="w-48 shrink-0">
                      <div className="text-xs font-bold text-slate-700 group-hover:text-indigo-600 transition-colors">{row.domain}</div>
                    </div>
                    
                    <div className="flex-1 h-8 bg-slate-50 rounded-lg border border-slate-100 flex items-center px-2 relative">
                      {/* Maturity Track */}
                      <div className="absolute inset-0 grid grid-cols-5 divide-x divide-slate-100/50 pointer-events-none" />
                      
                      {/* Current Level Bar */}
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${(row.current / 5) * 100}%` }}
                        className="h-4 bg-indigo-600 rounded-md shadow-sm relative z-10"
                      >
                        <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 w-2 h-2 rounded-full bg-white shadow-sm border border-indigo-600" />
                      </motion.div>

                      {/* Target Indicator */}
                      <div 
                        className="absolute top-1/2 -translate-y-1/2 w-4 h-4 rounded-full border-2 border-indigo-600 bg-white shadow-md z-20 flex items-center justify-center"
                        style={{ left: `calc(${(row.target / 5) * 100}% - 8px)` }}
                      >
                        <div className="w-1 h-1 rounded-full bg-indigo-600" />
                      </div>
                    </div>

                    <div className="w-24 shrink-0 flex items-center justify-end gap-4">
                      <div className="text-center">
                        <div className="text-[8px] font-black text-slate-400 uppercase tracking-tighter">Current</div>
                        <div className="text-xs font-black text-slate-900">{row.current}</div>
                      </div>
                      <div className="text-center">
                        <div className="text-[8px] font-black text-slate-400 uppercase tracking-tighter">Target</div>
                        <div className="text-xs font-black text-indigo-600">{row.target}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* PARTNER RISK & FAIRNESS DASHBOARD */}
        <div className="mb-12">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-indigo-600 rounded-lg text-white">
                  <Handshake className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 uppercase tracking-tight">PARTNER RISK & FAIRNESS DASHBOARD</h4>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Comprehensive Risk & Compliance Oversight</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2 px-3 py-1 bg-amber-50 text-amber-700 text-[9px] font-black uppercase tracking-widest rounded-full border border-amber-100">
                  Risk Level: Medium
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
                  <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">SLA Compliant (96%)</span>
                </div>
              </div>
            </div>

            <div className="p-8">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
                
                {/* SECTION 1 — OVERALL RISK SCORE */}
                <div className="space-y-6">
                  <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] pb-2 border-b border-slate-100">OVERALL RISK SCORE</div>
                  <div className="space-y-4">
                    <div className="p-4 bg-slate-900 rounded-2xl text-center">
                      <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Partner Risk Score</div>
                      <div className="text-2xl font-black text-amber-400">2.4</div>
                      <div className="text-[9px] font-bold text-slate-500 uppercase">Medium Risk</div>
                    </div>
                    <div className="space-y-3">
                      {[
                        { label: 'Data Quality Risk', value: '1.8', color: 'text-emerald-500' },
                        { label: 'Fairness Risk', value: '2.9', color: 'text-amber-500' },
                        { label: 'Drift Exposure', value: '2.1', color: 'text-emerald-500' },
                        { label: 'Security Risk', value: '1.2', color: 'text-emerald-500' }
                      ].map((risk, i) => (
                        <div key={i} className="flex justify-between items-center">
                          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-tight">{risk.label}</span>
                          <span className={`text-xs font-black ${risk.color}`}>{risk.value}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* SECTION 2 — FAIRNESS METRICS */}
                <div className="space-y-6">
                  <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] pb-2 border-b border-slate-100">FAIRNESS METRICS</div>
                  <div className="space-y-4">
                    {[
                      { label: 'FN Rate', value: '1.2%', baseline: '1.1%', status: 'warning' },
                      { label: 'FP Rate', value: '2.4%', baseline: '2.3%', status: 'warning' },
                      { label: 'Corridor Parity', value: '±8%', baseline: 'Within', status: 'success' },
                      { label: 'Bias Flags', value: '0', baseline: 'None', status: 'success' }
                    ].map((item, i) => (
                      <div key={i} className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                        <div className="flex justify-between items-center mb-1">
                          <span className="text-xs font-bold text-slate-600">{item.label}</span>
                          <span className={`text-xs font-black ${item.status === 'warning' ? 'text-amber-600' : 'text-emerald-600'}`}>{item.value}</span>
                        </div>
                        <div className="text-[9px] text-slate-400 font-medium uppercase tracking-tighter">Baseline: {item.baseline}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* SECTION 3 — DATA QUALITY */}
                <div className="space-y-6">
                  <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] pb-2 border-b border-slate-100">DATA QUALITY</div>
                  <div className="space-y-4">
                    {[
                      { label: 'Missing Data', value: '1.1%', sla: '≤ 2%', status: 'success' },
                      { label: 'Schema Errors', value: '0.3%', sla: '≤ 0.5%', status: 'success' },
                      { label: 'Duplicate Rate', value: '0.6%', sla: '≤ 1%', status: 'success' },
                      { label: 'Timeliness', value: '98.7%', sla: 'On-time', status: 'success' }
                    ].map((item, i) => (
                      <div key={i} className="flex flex-col gap-1">
                        <div className="flex justify-between items-center">
                          <span className="text-xs font-bold text-slate-600">{item.label}</span>
                          <span className="text-xs font-black text-slate-900">{item.value}</span>
                        </div>
                        <div className="w-full h-1 bg-slate-100 rounded-full overflow-hidden">
                          <div className="h-full bg-indigo-500 rounded-full" style={{ width: item.value }} />
                        </div>
                        <div className="text-[9px] text-slate-400 font-medium uppercase tracking-tighter">SLA: {item.sla}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* SECTION 4 — DRIFT & PERFORMANCE */}
                <div className="space-y-6">
                  <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] pb-2 border-b border-slate-100">DRIFT & PERFORMANCE</div>
                  <div className="space-y-4">
                    <div className="p-4 rounded-2xl bg-amber-50 border border-amber-100">
                      <div className="flex items-center gap-3 mb-2">
                        <Zap className="w-4 h-4 text-amber-600" />
                        <span className="text-xs font-black text-amber-900 uppercase">Feature Drift</span>
                      </div>
                      <div className="text-lg font-black text-amber-700">1 Event</div>
                      <div className="text-[9px] font-bold text-amber-600/70 uppercase">Medium Severity Detected</div>
                    </div>
                    <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-100">
                      <div className="flex items-center gap-3 mb-2">
                        <RefreshCw className="w-4 h-4 text-emerald-600" />
                        <span className="text-xs font-black text-emerald-900 uppercase">Concept Drift</span>
                      </div>
                      <div className="text-lg font-black text-emerald-700">0 Events</div>
                      <div className="text-[9px] font-bold text-emerald-600/70 uppercase">Performance Stable</div>
                    </div>
                  </div>
                </div>

                {/* SECTION 5 — OPERATIONAL METRICS */}
                <div className="space-y-6">
                  <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] pb-2 border-b border-slate-100">OPERATIONAL METRICS</div>
                  <div className="grid grid-cols-1 gap-3">
                    {[
                      { label: 'Alerts (QTR)', value: '42', icon: Bell, color: 'text-slate-600' },
                      { label: 'High Severity', value: '3', icon: AlertTriangle, color: 'text-rose-600' },
                      { label: 'Disputes Filed', value: '0', icon: Scale, color: 'text-emerald-600' },
                      { label: 'SLA Compliance', value: '96%', icon: CheckCircle2, color: 'text-indigo-600' }
                    ].map((item, i) => (
                      <div key={i} className="flex items-center gap-4 p-3 rounded-xl bg-white border border-slate-100 shadow-sm">
                        <div className={`p-2 rounded-lg bg-slate-50 ${item.color}`}>
                          <item.icon className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{item.label}</div>
                          <div className="text-sm font-black text-slate-900">{item.value}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

              </div>
            </div>
          </div>
        </div>

        {/* SECTION 5 — UPCOMING IMPROVEMENTS */}
              <div className="mt-10 p-6 rounded-2xl bg-indigo-50 border border-indigo-100">
                <div className="flex items-center gap-3 mb-4">
                  <Zap className="w-4 h-4 text-indigo-600" />
                  <span className="text-[10px] font-black text-indigo-600 uppercase tracking-[0.2em]">Upcoming Improvements</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {[
                    'Predictive drift detection rollout',
                    'Enhanced fairness dashboards',
                    'Corridor-specific explainability'
                  ].map((text, i) => (
                    <div key={i} className="flex items-center gap-3">
                      <div className="w-1.5 h-1.5 rounded-full bg-indigo-400" />
                      <span className="text-xs font-bold text-indigo-900/70">{text}</span>
                    </div>
                  ))}
                </div>
              </div>

        {/* ZERO-TRUST ML SECURITY ARCHITECTURE */}
        <div className="mb-12">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-slate-900 rounded-lg text-white">
                  <Lock className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 uppercase tracking-tight">ZERO-TRUST ML SECURITY ARCHITECTURE</h4>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Defense-in-Depth Security Framework</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="px-3 py-1 bg-slate-900 text-white text-[9px] font-black uppercase tracking-widest rounded-full">
                  Secure by Design
                </div>
              </div>
            </div>

            <div className="p-8">
              <div className="flex flex-col gap-4">
                {[
                  {
                    layer: 'IDENTITY LAYER',
                    items: ['Continuous authentication', 'RBAC/ABAC', 'JIT access', 'MFA'],
                    color: 'bg-blue-600',
                    lightColor: 'bg-blue-50',
                    borderColor: 'border-blue-100',
                    textColor: 'text-blue-700'
                  },
                  {
                    layer: 'DATA LAYER',
                    items: ['Encryption', 'Tokenization', 'Lineage', 'DQ engine', 'Schema guard'],
                    color: 'bg-indigo-600',
                    lightColor: 'bg-indigo-50',
                    borderColor: 'border-indigo-100',
                    textColor: 'text-indigo-700'
                  },
                  {
                    layer: 'MODEL LAYER',
                    items: ['Secure registry', 'Artifact hashing', 'Watermarking', 'DP options', 'Adversarial defense', 'Poisoning detection', 'Integrity checks'],
                    color: 'bg-purple-600',
                    lightColor: 'bg-purple-50',
                    borderColor: 'border-purple-100',
                    textColor: 'text-purple-700'
                  },
                  {
                    layer: 'PIPELINE LAYER',
                    items: ['Signed containers', 'CI/CD approvals', 'Secrets vault', 'SCA'],
                    color: 'bg-rose-600',
                    lightColor: 'bg-rose-50',
                    borderColor: 'border-rose-100',
                    textColor: 'text-rose-700'
                  },
                  {
                    layer: 'RUNTIME LAYER',
                    items: ['API gateway', 'WAF', 'Rate limiting', 'Drift anomaly detection', 'SIEM integration', 'Zero-trust network segmentation'],
                    color: 'bg-emerald-600',
                    lightColor: 'bg-emerald-50',
                    borderColor: 'border-emerald-100',
                    textColor: 'text-emerald-700'
                  },
                  {
                    layer: 'INCIDENT RESPONSE LAYER',
                    items: ['ML-specific IR playbook', 'Forensics', 'Partner notification'],
                    color: 'bg-amber-600',
                    lightColor: 'bg-amber-50',
                    borderColor: 'border-amber-100',
                    textColor: 'text-amber-700'
                  }
                ].map((layer, i) => (
                  <motion.div 
                    key={i}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.1 }}
                    className={`relative rounded-2xl border ${layer.borderColor} ${layer.lightColor} overflow-hidden group hover:shadow-md transition-all`}
                  >
                    <div className="flex flex-col md:flex-row">
                      <div className={`md:w-64 ${layer.color} p-4 flex items-center shrink-0`}>
                        <h5 className="text-[10px] font-black text-white uppercase tracking-widest leading-tight">
                          {layer.layer}
                        </h5>
                      </div>
                      <div className="p-4 flex flex-wrap gap-2">
                        {layer.items.map((item, j) => (
                          <div 
                            key={j} 
                            className={`px-3 py-1.5 bg-white rounded-lg border ${layer.borderColor} ${layer.textColor} text-[10px] font-bold shadow-sm group-hover:border-slate-300 transition-colors`}
                          >
                            {item}
                          </div>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* DEEP-DIVE ML SECURITY ARCHITECTURE */}
        <div className="mb-12">
          <div className="bg-slate-50 rounded-3xl border border-slate-200 p-8 shadow-sm">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10">
              <div>
                <h3 className="text-xl font-black text-slate-900 uppercase tracking-[0.2em]">Deep-Dive ML Security Architecture</h3>
                <p className="text-slate-500 text-sm mt-2">Granular technical controls and defense mechanisms</p>
              </div>
              <div className="flex items-center gap-3">
                <div className="px-3 py-1 bg-indigo-100 text-indigo-700 text-[10px] font-black uppercase tracking-widest rounded-full">
                  Technical Blueprint
                </div>
                <div className="px-3 py-1 bg-emerald-100 text-emerald-700 text-[10px] font-black uppercase tracking-widest rounded-full">
                  Active Defense
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                {
                  title: 'Model Integrity & Provenance',
                  icon: Fingerprint,
                  color: 'text-blue-600',
                  bgColor: 'bg-blue-50',
                  borderColor: 'border-blue-100',
                  details: [
                    { label: 'Artifact Hashing', desc: 'SHA-256 content anchoring' },
                    { label: 'Digital Watermarking', desc: 'Embedded ownership verification' },
                    { label: 'Signed Metadata', desc: 'Immutable lineage records' }
                  ]
                },
                {
                  title: 'Adversarial Defense',
                  icon: ShieldAlert,
                  color: 'text-rose-600',
                  bgColor: 'bg-rose-50',
                  borderColor: 'border-rose-100',
                  details: [
                    { label: 'Robustness Testing', desc: 'Automated evasion simulation' },
                    { label: 'Poisoning Detection', desc: 'Training data anomaly filters' },
                    { label: 'Input Sanitization', desc: 'Adversarial perturbation removal' }
                  ]
                },
                {
                  title: 'Data Privacy & Confidentiality',
                  icon: EyeOff,
                  color: 'text-purple-600',
                  bgColor: 'bg-purple-50',
                  borderColor: 'border-purple-100',
                  details: [
                    { label: 'Differential Privacy', desc: 'Noise injection for epsilon-guarantees' },
                    { label: 'PII Masking', desc: 'Dynamic tokenization at inference' },
                    { label: 'Secure Enclaves', desc: 'TEE-based model execution' }
                  ]
                },
                {
                  title: 'Supply Chain Security',
                  icon: Network,
                  color: 'text-indigo-600',
                  bgColor: 'bg-indigo-50',
                  borderColor: 'border-indigo-100',
                  details: [
                    { label: 'SBOM Generation', desc: 'Software Bill of Materials tracking' },
                    { label: 'SCA Scanning', desc: 'Dependency vulnerability analysis' },
                    { label: 'Signed Containers', desc: 'Verified build-to-deploy pipeline' }
                  ]
                },
                {
                  title: 'Runtime Guardrails',
                  icon: Zap,
                  color: 'text-amber-600',
                  bgColor: 'bg-amber-50',
                  borderColor: 'border-amber-100',
                  details: [
                    { label: 'Prompt Filters', desc: 'Injection and jailbreak detection' },
                    { label: 'Output Validation', desc: 'Content safety and hallucination checks' },
                    { label: 'Drift Anomaly', desc: 'Real-time PSI/KL-divergence monitoring' }
                  ]
                },
                {
                  title: 'Zero-Trust IAM',
                  icon: UserCheck,
                  color: 'text-emerald-600',
                  bgColor: 'bg-emerald-50',
                  borderColor: 'border-emerald-100',
                  details: [
                    { label: 'JIT Provisioning', desc: 'Just-In-Time model access' },
                    { label: 'ABAC Policies', desc: 'Attribute-based dynamic control' },
                    { label: 'Continuous Auth', desc: 'Session-based identity verification' }
                  ]
                }
              ].map((domain, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className={`p-6 rounded-2xl border ${domain.borderColor} bg-white shadow-sm hover:shadow-md transition-all group`}
                >
                  <div className="flex items-center gap-4 mb-6">
                    <div className={`p-3 rounded-xl ${domain.bgColor} ${domain.color} group-hover:scale-110 transition-transform`}>
                      <domain.icon className="w-5 h-5" />
                    </div>
                    <h4 className="font-black text-slate-900 text-sm uppercase tracking-wider">{domain.title}</h4>
                  </div>
                  <div className="space-y-4">
                    {domain.details.map((detail, j) => (
                      <div key={j} className="flex flex-col gap-1">
                        <div className="text-[10px] font-black text-slate-700 uppercase tracking-tight">{detail.label}</div>
                        <div className="text-[10px] text-slate-500 font-medium leading-relaxed">{detail.desc}</div>
                      </div>
                    ))}
                  </div>
                </motion.div>
              ))}
            </div>

            {/* SECURITY TECHNICAL FLOW VISUALIZATION */}
            <div className="mt-12 p-8 bg-slate-900 rounded-3xl border border-white/10 shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 blur-[80px] rounded-full" />
              <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-500/5 blur-[80px] rounded-full" />
              
              <div className="relative z-10">
                <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-8 text-center">
                  End-to-End Security Technical Flow
                </div>
                
                <div className="flex flex-col lg:flex-row items-center justify-between gap-4">
                  {[
                    { step: '01', label: 'Ingress', icon: Globe, color: 'text-blue-400', controls: ['WAF', 'Rate Limiting'] },
                    { step: '02', label: 'Identity', icon: UserCheck, color: 'text-indigo-400', controls: ['MFA', 'JIT Access'] },
                    { step: '03', label: 'Sanitize', icon: ShieldAlert, color: 'text-rose-400', controls: ['Input Filtering', 'Adversarial Check'] },
                    { step: '04', label: 'Inference', icon: Brain, color: 'text-purple-400', controls: ['Model Hashing', 'DP Noise'] },
                    { step: '05', label: 'Validate', icon: Zap, color: 'text-amber-400', controls: ['Output Safety', 'Hallucination Check'] },
                    { step: '06', label: 'Monitor', icon: Activity, color: 'text-emerald-400', controls: ['SIEM', 'Drift Detection'] }
                  ].map((flow, i, arr) => (
                    <React.Fragment key={i}>
                      <motion.div 
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: i * 0.1 }}
                        className="flex flex-col items-center gap-4 w-full lg:w-40"
                      >
                        <div className={`p-4 rounded-2xl bg-white/5 border border-white/10 ${flow.color} shadow-lg relative group`}>
                          <div className="absolute -top-2 -right-2 w-5 h-5 bg-slate-800 rounded-full border border-white/20 flex items-center justify-center text-[8px] font-black text-white">
                            {flow.step}
                          </div>
                          <flow.icon className="w-6 h-6" />
                        </div>
                        <div className="text-center">
                          <div className="text-[10px] font-black text-white uppercase tracking-widest mb-2">{flow.label}</div>
                          <div className="space-y-1">
                            {flow.controls.map((ctrl, j) => (
                              <div key={j} className="text-[8px] font-bold text-slate-500 uppercase tracking-tighter">{ctrl}</div>
                            ))}
                          </div>
                        </div>
                      </motion.div>
                      {i < arr.length - 1 && (
                        <div className="hidden lg:flex items-center">
                          <ArrowRight className="w-4 h-4 text-slate-700" />
                        </div>
                      )}
                    </React.Fragment>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* GLOBAL AI COMPLIANCE HEATMAP */}
        <div className="mb-12">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-indigo-600 rounded-lg text-white">
                  <Globe className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 uppercase tracking-tight">GLOBAL AI COMPLIANCE HEATMAP</h4>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Regulatory Alignment & Standards Tracking</p>
                </div>
              </div>
              <div className="flex items-center gap-6">
                <div className="flex items-center gap-4 text-[9px] font-black uppercase tracking-widest">
                  <div className="flex items-center gap-1.5">
                    <div className="w-2 h-2 rounded-full bg-emerald-500" />
                    <span className="text-slate-500">Strong</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <div className="w-2 h-2 rounded-full bg-amber-500" />
                    <span className="text-slate-500">Partial</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <div className="w-2 h-2 rounded-full bg-rose-500" />
                    <span className="text-slate-500">Gap</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50/50 border-b border-slate-100">
                    <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Regulation / Standard</th>
                    <th className="px-4 py-4 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] text-center">Governance</th>
                    <th className="px-4 py-4 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] text-center">Fairness</th>
                    <th className="px-4 py-4 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] text-center">Security</th>
                    <th className="px-4 py-4 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] text-center">Documentation</th>
                    <th className="px-4 py-4 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] text-center">Risk Mgmt</th>
                    <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] text-center">Overall</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {[
                    { name: 'EU AI Act (High-Risk)', gov: 'yellow', fair: 'yellow', sec: 'yellow', doc: 'green', risk: 'yellow', overall: 'yellow' },
                    { name: 'NIST AI RMF', gov: 'green', fair: 'yellow', sec: 'yellow', doc: 'green', risk: 'green', overall: 'green' },
                    { name: 'ISO 42001', gov: 'yellow', fair: 'yellow', sec: 'yellow', doc: 'yellow', risk: 'yellow', overall: 'yellow' },
                    { name: 'SOC 2 (Security/Avail/Conf)', gov: 'green', fair: 'na', sec: 'green', doc: 'green', risk: 'green', overall: 'green' },
                    { name: 'ISO 27001', gov: 'green', fair: 'na', sec: 'green', doc: 'green', risk: 'green', overall: 'green' },
                    { name: 'Singapore AI Governance', gov: 'green', fair: 'green', sec: 'yellow', doc: 'green', risk: 'green', overall: 'green' },
                    { name: 'Canada AIDA', gov: 'yellow', fair: 'yellow', sec: 'yellow', doc: 'yellow', risk: 'yellow', overall: 'yellow' },
                    { name: 'UK Pro-Innovation Framework', gov: 'green', fair: 'yellow', sec: 'yellow', doc: 'green', risk: 'green', overall: 'green' }
                  ].map((row, i) => (
                    <tr key={i} className="group hover:bg-slate-50/50 transition-colors">
                      <td className="px-6 py-4">
                        <div className="text-xs font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">{row.name}</div>
                      </td>
                      {[row.gov, row.fair, row.sec, row.doc, row.risk, row.overall].map((status, j) => (
                        <td key={j} className="px-4 py-4 text-center">
                          <div className="flex justify-center">
                            {status === 'na' ? (
                              <span className="text-[9px] font-black text-slate-300 uppercase tracking-tighter">N/A</span>
                            ) : (
                              <div className={`w-6 h-6 rounded-lg flex items-center justify-center shadow-sm border ${
                                status === 'green' ? 'bg-emerald-500 border-emerald-600' :
                                status === 'yellow' ? 'bg-amber-500 border-amber-600' :
                                'bg-rose-500 border-rose-600'
                              }`}>
                                <div className="w-1.5 h-1.5 rounded-full bg-white/40" />
                              </div>
                            )}
                          </div>
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            
            <div className="p-6 bg-slate-50/50 border-t border-slate-100">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-indigo-500 rounded-full animate-pulse" />
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Last Compliance Scan: Today, 14:30 UTC</span>
                </div>
                <button className="flex items-center gap-2 text-[10px] font-black text-indigo-600 uppercase tracking-[0.2em] hover:underline">
                  <FileText className="w-3 h-3" /> Generate Compliance Report
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* AI GOVERNANCE ORGANIZATIONAL HIERARCHY */}
        <div className="mb-12">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-indigo-600 rounded-lg text-white">
                  <Network className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 uppercase tracking-tight">AI GOVERNANCE ORGANIZATIONAL HIERARCHY</h4>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Enterprise Oversight & Accountability Structure</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="px-3 py-1 bg-indigo-50 text-indigo-700 text-[9px] font-black uppercase tracking-widest rounded-full border border-indigo-100">
                  Global Oversight
                </div>
              </div>
            </div>

            <div className="p-12 bg-slate-50/30">
              <div className="max-w-4xl mx-auto flex flex-col items-center gap-6">
                
                {/* Level 1: G-ESC */}
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="w-full max-w-md bg-slate-900 text-white p-6 rounded-2xl shadow-xl border border-white/10 text-center relative z-10"
                >
                  <div className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.2em] mb-2">Strategic Leadership</div>
                  <h5 className="text-sm font-black tracking-tight">GLOBAL EXECUTIVE STEERING COMMITTEE (G-ESC)</h5>
                  <p className="text-[10px] text-slate-400 mt-2 font-medium">Enterprise AI Strategy, Risk Appetite & Capital Allocation</p>
                  
                  {/* Connector Down */}
                  <div className="absolute top-full left-1/2 -translate-x-1/2 h-6 w-px bg-slate-300" />
                </motion.div>

                {/* Level 2: G-MRC */}
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 }}
                  className="w-full max-w-md bg-white p-6 rounded-2xl shadow-md border border-slate-200 text-center relative z-10"
                >
                  <div className="text-[10px] font-black text-indigo-600 uppercase tracking-[0.2em] mb-2">Global Oversight</div>
                  <h5 className="text-sm font-black text-slate-900 tracking-tight">GLOBAL MODEL RISK COMMITTEE (G-MRC)</h5>
                  <p className="text-[10px] text-slate-500 mt-2 font-medium">Policy Setting, Global Standards & High-Risk Model Approval</p>
                  
                  {/* Connector Down */}
                  <div className="absolute top-full left-1/2 -translate-x-1/2 h-6 w-px bg-slate-300" />
                </motion.div>

                {/* Level 3: Regional MRBs */}
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  className="w-full grid grid-cols-1 md:grid-cols-4 gap-3 relative z-10"
                >
                  {['EU-MRB', 'US-MRB', 'APAC-MRB', 'LATAM-MRB'].map((mrb, i) => (
                    <div key={i} className="bg-indigo-50 p-4 rounded-xl border border-indigo-100 text-center group hover:bg-indigo-600 transition-all cursor-default">
                      <div className="text-[8px] font-black text-indigo-400 uppercase tracking-widest mb-1 group-hover:text-indigo-200">Regional Board</div>
                      <h6 className="text-[10px] font-black text-indigo-900 group-hover:text-white">{mrb}</h6>
                    </div>
                  ))}
                  {/* Label for the row */}
                  <div className="absolute -left-32 top-1/2 -translate-y-1/2 hidden xl:block">
                    <div className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] rotate-180 [writing-mode:vertical-lr]">Regional Review Boards</div>
                  </div>
                  {/* Connector Down (Center) */}
                  <div className="absolute top-full left-1/2 -translate-x-1/2 h-6 w-px bg-slate-300" />
                </motion.div>

                {/* Level 4: Regional MGOs */}
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  className="w-full grid grid-cols-1 md:grid-cols-4 gap-3 relative z-10"
                >
                  {['EU-MGO', 'US-MGO', 'APAC-MGO', 'LATAM-MGO'].map((mgo, i) => (
                    <div key={i} className="bg-white p-4 rounded-xl border border-slate-200 text-center shadow-sm">
                      <div className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1">Governance Office</div>
                      <h6 className="text-[10px] font-black text-slate-900">{mgo}</h6>
                    </div>
                  ))}
                  {/* Label for the row */}
                  <div className="absolute -left-32 top-1/2 -translate-y-1/2 hidden xl:block">
                    <div className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] rotate-180 [writing-mode:vertical-lr]">Governance Offices</div>
                  </div>
                  {/* Connector Down (Center) */}
                  <div className="absolute top-full left-1/2 -translate-x-1/2 h-6 w-px bg-slate-300" />
                </motion.div>

                {/* Level 5: Local Teams */}
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                  className="w-full bg-slate-50 p-6 rounded-2xl border border-dashed border-slate-300 text-center"
                >
                  <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4">Operational Execution</div>
                  <div className="flex flex-wrap justify-center gap-4">
                    {[
                      { label: 'Data Science', icon: Brain },
                      { label: 'Security', icon: Shield },
                      { label: 'Compliance', icon: ClipboardCheck },
                      { label: 'Partner Governance', icon: Handshake }
                    ].map((team, i) => (
                      <div key={i} className="flex items-center gap-2 px-4 py-2 bg-white rounded-full border border-slate-200 shadow-sm">
                        <team.icon className="w-3 h-3 text-indigo-600" />
                        <span className="text-[10px] font-bold text-slate-700">{team.label} Teams</span>
                      </div>
                    ))}
                  </div>
                </motion.div>

              </div>
            </div>
            
            <div className="p-6 bg-slate-50/50 border-t border-slate-100 flex justify-center">
              <div className="flex items-center gap-8">
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-slate-900" />
                  <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Reporting Line</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-indigo-400" />
                  <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Advisory Line</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* GOVERNANCE EVIDENCE REPOSITORY */}
        <div className="mb-12">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-indigo-600 rounded-lg text-white">
                  <Database className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 uppercase tracking-tight">GOVERNANCE EVIDENCE REPOSITORY</h4>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Automated Compliance Artifact Storage</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="px-3 py-1 bg-emerald-50 text-emerald-700 text-[9px] font-black uppercase tracking-widest rounded-full border border-emerald-100">
                  Immutable Storage
                </div>
              </div>
            </div>

            <div className="p-8 bg-slate-50/30">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                {[
                  { path: '/Evidence', items: ['Model_Cards', 'Validation', 'Fairness'], icon: Folder, color: 'text-indigo-600' },
                  { path: '/Security', items: ['Vulnerability_Scans', 'Pen_Tests', 'Encryption_Keys'], icon: Shield, color: 'text-rose-600' },
                  { path: '/Monitoring', items: ['Drift_Logs', 'Anomaly_Reports', 'Performance_SLA'], icon: Activity, color: 'text-emerald-600' },
                  { path: '/Incidents', items: ['Root_Cause', 'Playbooks', 'Notifications'], icon: AlertTriangle, color: 'text-amber-600' },
                  { path: '/Approvals', items: ['MRB_Minutes', 'Partner_Reports', 'Sign_Offs'], icon: CheckCircle2, color: 'text-blue-600' }
                ].map((folder, i) => (
                  <motion.div 
                    key={i}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.05 }}
                    className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm hover:border-indigo-300 transition-all group cursor-pointer"
                  >
                    <div className="flex items-center gap-3 mb-4">
                      <div className={`p-2 rounded-lg bg-slate-50 ${folder.color} group-hover:scale-110 transition-transform`}>
                        <folder.icon className="w-4 h-4" />
                      </div>
                      <span className="text-xs font-black text-slate-900 tracking-tight">{folder.path}</span>
                    </div>
                    <div className="space-y-2">
                      {folder.items.map((item, j) => (
                        <div key={j} className="flex items-center gap-2 px-2 py-1.5 rounded-lg hover:bg-slate-50 transition-colors">
                          <FileText className="w-3 h-3 text-slate-400" />
                          <span className="text-[10px] font-bold text-slate-600">{item}</span>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                ))}
              </div>
              
              <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl bg-indigo-50 border border-indigo-100 flex items-center gap-4">
                  <div className="p-3 bg-white rounded-xl shadow-sm">
                    <History className="w-5 h-5 text-indigo-600" />
                  </div>
                  <div>
                    <div className="text-[10px] font-black text-indigo-600 uppercase tracking-widest mb-1">Retention Policy</div>
                    <div className="text-xs font-bold text-indigo-900/70">7-Year Immutable Audit Trail (Standard)</div>
                  </div>
                </div>
                <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-100 flex items-center gap-4">
                  <div className="p-3 bg-white rounded-xl shadow-sm">
                    <Fingerprint className="w-5 h-5 text-emerald-600" />
                  </div>
                  <div>
                    <div className="text-[10px] font-black text-emerald-600 uppercase tracking-widest mb-1">Integrity Verification</div>
                    <div className="text-xs font-bold text-emerald-900/70">SHA-256 Content Hashing & Blockchain Anchoring</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Visual Diagram - Layout matching the ASCII art */}
        <div className="mb-16 relative">
          <div className="flex flex-col items-center gap-8">
            
            {/* Top: IdP */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="w-full max-w-md"
            >
              <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 text-center relative">
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 w-8 h-8 rounded-lg bg-indigo-500 flex items-center justify-center text-white shadow-lg">
                  <Fingerprint className="w-4 h-4" />
                </div>
                <h3 className="font-bold text-slate-900 mt-2">Identity Provider (IdP)</h3>
                <p className="text-xs text-slate-500 font-medium">OAuth2 / OIDC / MFA / SSO</p>
                
                {/* Connector Down */}
                <div className="absolute top-full left-1/2 -translate-x-1/2 h-8 w-0.5 bg-slate-300" />
                <div className="absolute top-[calc(100%+28px)] left-1/2 -translate-x-1/2 border-l-4 border-r-4 border-t-4 border-transparent border-t-slate-300" />
              </div>
            </motion.div>

            {/* Middle Row: Partner Systems <-> API Gateway <-> FLDPN Services */}
            <div className="flex flex-col lg:flex-row items-center justify-center gap-8 w-full">
              
              {/* Left: Partner Systems */}
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.1 }}
                className="w-full lg:w-64"
              >
                <div className="bg-slate-100 p-6 rounded-2xl border border-slate-200 text-center relative">
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 w-8 h-8 rounded-lg bg-slate-400 flex items-center justify-center text-white shadow-lg">
                    <Globe className="w-4 h-4" />
                  </div>
                  <h3 className="font-bold text-slate-700 mt-2">Partner Systems</h3>
                  <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Carriers, Hubs</p>
                  
                  {/* Connector Right (Desktop) */}
                  <div className="hidden lg:block absolute top-1/2 -right-8 -translate-y-1/2 w-8 h-0.5 bg-slate-300" />
                </div>
              </motion.div>

              {/* Center: API Gateway */}
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.2 }}
                className="w-full max-w-md relative"
              >
                <div className="bg-white p-8 rounded-3xl shadow-xl border-2 border-blue-500 text-center relative z-10">
                  <div className="absolute -top-6 left-1/2 -translate-x-1/2 w-12 h-12 rounded-xl bg-blue-500 flex items-center justify-center text-white shadow-xl">
                    <Shield className="w-6 h-6" />
                  </div>
                  <h3 className="font-black text-slate-900 text-xl mt-4">API Gateway</h3>
                  <p className="text-xs text-blue-600 font-bold uppercase tracking-widest mb-4">mTLS, RBAC, AuthZ, Rate Limit, WAF</p>
                  
                  <div className="grid grid-cols-2 gap-2 text-[10px] text-slate-400 font-bold uppercase tracking-tighter">
                    <div className="bg-slate-50 p-2 rounded-lg border border-slate-100">AuthZ</div>
                    <div className="bg-slate-50 p-2 rounded-lg border border-slate-100">Rate Limit</div>
                    <div className="bg-slate-50 p-2 rounded-lg border border-slate-100">mTLS</div>
                    <div className="bg-slate-50 p-2 rounded-lg border border-slate-100">WAF</div>
                  </div>

                  {/* Connector Down */}
                  <div className="absolute top-full left-1/2 -translate-x-1/2 h-8 w-0.5 bg-slate-300" />
                  <div className="absolute top-[calc(100%+28px)] left-1/2 -translate-x-1/2 border-l-4 border-r-4 border-t-4 border-transparent border-t-slate-300" />
                </div>
              </motion.div>

              {/* Right: FLDPN Services */}
              <motion.div 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 }}
                className="w-full lg:w-64"
              >
                <div className="bg-cyan-50 p-6 rounded-2xl border border-cyan-100 text-center relative">
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 w-8 h-8 rounded-lg bg-cyan-500 flex items-center justify-center text-white shadow-lg">
                    <Cpu className="w-4 h-4" />
                  </div>
                  <h3 className="font-bold text-cyan-900 mt-2">FLDPN Services</h3>
                  <p className="text-[10px] text-cyan-600 font-bold uppercase tracking-widest">Ingestion, ETA, Provenance</p>
                  
                  {/* Connector Left (Desktop) */}
                  <div className="hidden lg:block absolute top-1/2 -left-8 -translate-y-1/2 w-8 h-0.5 bg-slate-300" />
                </div>
              </motion.div>

            </div>

            {/* Service Mesh */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="w-full max-w-sm"
            >
              <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 text-center relative">
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 w-8 h-8 rounded-lg bg-teal-500 flex items-center justify-center text-white shadow-lg">
                  <Network className="w-4 h-4" />
                </div>
                <h3 className="font-bold text-slate-900 mt-2">Service Mesh (mTLS)</h3>
                <p className="text-xs text-slate-500 font-medium">Zero-Trust Policies</p>
                
                {/* Connector Down */}
                <div className="absolute top-full left-1/2 -translate-x-1/2 h-8 w-0.5 bg-slate-300" />
                <div className="absolute top-[calc(100%+28px)] left-1/2 -translate-x-1/2 border-l-4 border-r-4 border-t-4 border-transparent border-t-slate-300" />
              </div>
            </motion.div>

            {/* Data Layer */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="w-full max-w-md"
            >
              <div className="bg-emerald-50 p-6 rounded-2xl border border-emerald-100 text-center relative">
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 w-8 h-8 rounded-lg bg-emerald-500 flex items-center justify-center text-white shadow-lg">
                  <Database className="w-4 h-4" />
                </div>
                <h3 className="font-bold text-emerald-900 mt-2">Data Layer (Zero-Trust)</h3>
                <p className="text-xs text-emerald-600 font-medium">Encrypted DBs, Immutable Ledger, Key Vault</p>
                
                {/* Connector Down */}
                <div className="absolute top-full left-1/2 -translate-x-1/2 h-8 w-0.5 bg-slate-300" />
                <div className="absolute top-[calc(100%+28px)] left-1/2 -translate-x-1/2 border-l-4 border-r-4 border-t-4 border-transparent border-t-slate-300" />
              </div>
            </motion.div>

            {/* Monitoring Layer */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="w-full max-w-lg"
            >
              <div className="bg-slate-900 p-8 rounded-3xl shadow-2xl text-center relative border border-slate-800">
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 w-8 h-8 rounded-lg bg-rose-500 flex items-center justify-center text-white shadow-lg">
                  <Activity className="w-4 h-4" />
                </div>
                <h3 className="font-bold text-white mt-2">Monitoring & Security Layer</h3>
                <p className="text-xs text-slate-400 font-medium mb-4">SIEM, Behavioral Analytics, Threat Detection, Immutable Logs</p>
                
                <div className="flex flex-wrap justify-center gap-2">
                  {['SIEM', 'Analytics', 'Threat Detection', 'Audit Logs'].map(tag => (
                    <span key={tag} className="px-2 py-1 rounded bg-white/5 border border-white/10 text-[9px] font-bold text-slate-400 uppercase tracking-widest">
                      {tag}
                    </span>
                  ))}
                </div>

                {/* Connector Down to Compliance */}
                <div className="absolute top-full left-1/2 -translate-x-1/2 h-8 w-0.5 bg-slate-300" />
                <div className="absolute top-[calc(100%+28px)] left-1/2 -translate-x-1/2 border-l-4 border-r-4 border-t-4 border-transparent border-t-slate-300" />
              </div>
            </motion.div>

            {/* Compliance Automation Platform */}
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.7 }}
              className="w-full max-w-4xl"
            >
              <div className="bg-white rounded-[2.5rem] p-1 shadow-2xl border border-slate-200 overflow-hidden">
                <div className="bg-slate-50 p-6 text-center border-b border-slate-200">
                  <h3 className="text-xl font-black text-slate-900 flex items-center justify-center gap-2">
                    <BarChart3 className="w-6 h-6 text-blue-600" />
                    Compliance Automation Platform
                  </h3>
                </div>
                
                <div className="p-8">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {/* Evidence Collection */}
                    <div className="space-y-4">
                      <div className="bg-blue-50 p-4 rounded-2xl border border-blue-100 text-center">
                        <h4 className="text-xs font-black text-blue-900 uppercase tracking-widest mb-1">Evidence Collection</h4>
                        <div className="flex flex-col gap-2 mt-4">
                          {['API Collectors', 'Log Harvesters', 'Cloud Connectors'].map(item => (
                            <div key={item} className="bg-white p-2 rounded-lg text-[10px] font-bold text-slate-600 border border-blue-100 shadow-sm">
                              {item}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Control Monitoring */}
                    <div className="space-y-4">
                      <div className="bg-emerald-50 p-4 rounded-2xl border border-emerald-100 text-center">
                        <h4 className="text-xs font-black text-emerald-900 uppercase tracking-widest mb-1">Control Monitoring</h4>
                        <div className="flex flex-col gap-2 mt-4">
                          {['SIEM Integrator', 'Config Scanners', 'SLA Monitors'].map(item => (
                            <div key={item} className="bg-white p-2 rounded-lg text-[10px] font-bold text-slate-600 border border-emerald-100 shadow-sm">
                              {item}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Audit Automation */}
                    <div className="space-y-4">
                      <div className="bg-indigo-50 p-4 rounded-2xl border border-indigo-100 text-center">
                        <h4 className="text-xs font-black text-indigo-900 uppercase tracking-widest mb-1">Audit Automation</h4>
                        <div className="flex flex-col gap-2 mt-4">
                          {['Workflow Engine', 'Reporting Layer', 'Partner Scoring'].map(item => (
                            <div key={item} className="bg-white p-2 rounded-lg text-[10px] font-bold text-slate-600 border border-indigo-100 shadow-sm">
                              {item}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Data Lake / Evidence Repository */}
                  <div className="mt-8 relative">
                    <div className="absolute -top-4 left-1/2 -translate-x-1/2 h-4 w-0.5 bg-slate-200" />
                    <div className="bg-slate-900 p-6 rounded-2xl text-center border border-slate-800 shadow-xl">
                      <div className="flex items-center justify-center gap-2 mb-2">
                        <Database className="w-4 h-4 text-blue-400" />
                        <h4 className="text-sm font-bold text-white uppercase tracking-widest">Data Lake / Evidence Repository</h4>
                      </div>
                      <div className="flex flex-wrap justify-center gap-3 mt-4">
                        {['Identity', 'Access', 'Ledger', 'Events'].map(tag => (
                          <span key={tag} className="px-3 py-1 rounded-full bg-white/5 border border-white/10 text-[10px] font-bold text-slate-400">
                            {tag}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>

          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
          {/* Details Panel */}
          <div className="space-y-6">
            <div className="bg-slate-900 rounded-3xl p-8 text-white shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 right-0 p-8 opacity-10">
                <Layers className="w-32 h-32" />
              </div>
              
              <div className="relative z-10">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center border border-blue-500/30">
                    <Terminal className="w-5 h-5 text-blue-400" />
                  </div>
                  <div>
                    <h4 className="font-bold text-lg">Security Specifications</h4>
                    <p className="text-xs text-slate-400">Zero-Trust Enforcement Policies</p>
                  </div>
                </div>

                <div className="space-y-8">
                  {layers.map((layer) => (
                    <div key={layer.id} className="group">
                      <div className="flex items-center gap-3 mb-3">
                        <div className={`w-2 h-2 rounded-full ${layer.color}`} />
                        <span className="text-sm font-bold uppercase tracking-widest text-slate-300">{layer.title}</span>
                      </div>
                      <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {layer.details.map((detail, i) => (
                          <li key={i} className="flex items-start gap-2 text-xs text-slate-400 group-hover:text-slate-200 transition-colors">
                            <div className="mt-1 w-1 h-1 rounded-full bg-slate-700 shrink-0" />
                            {detail}
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Live Status Simulation */}
            <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm">
              <div className="flex items-center justify-between mb-6">
                <h4 className="font-bold text-slate-900 flex items-center gap-2">
                  <Activity className="w-4 h-4 text-emerald-500" />
                  Live Security Pulse
                </h4>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-widest">System Healthy</span>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {[
                  { label: 'mTLS Handshakes', value: '1,242', unit: 'req/m', icon: Lock },
                  { label: 'WAF Blocks', value: '14', unit: 'today', icon: Shield },
                  { label: 'Ledger Commits', value: '892', unit: 'today', icon: History },
                  { label: 'Auth Latency', value: '42', unit: 'ms', icon: Zap }
                ].map((stat, i) => (
                  <div key={i} className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
                    <div className="text-slate-400 mb-2">
                      <stat.icon className="w-4 h-4" />
                    </div>
                    <div className="text-xl font-black text-slate-900">{stat.value}</div>
                    <div className="text-[10px] font-bold text-slate-400 uppercase tracking-tight">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Risk Assessment Panel */}
          <div className="space-y-6">
            <div className="bg-white rounded-3xl p-8 border border-slate-100 shadow-sm">
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h4 className="font-bold text-slate-900 flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-500" />
                    Risk Assessment Matrix
                  </h4>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">
                    Risk Score = Likelihood × Impact
                  </p>
                </div>
                <div className="px-3 py-1 rounded-full bg-slate-100 text-slate-600 text-[10px] font-bold uppercase tracking-widest">
                  Q2 2026 Update
                </div>
              </div>

              <div className="space-y-6">
                {[
                  { name: 'Unauthorized API Access', likelihood: 3, impact: 5, color: 'text-rose-600', bg: 'bg-rose-50' },
                  { name: 'Partner Data Breach', likelihood: 2, impact: 5, color: 'text-orange-600', bg: 'bg-orange-50' },
                  { name: 'DDoS on Gateway', likelihood: 4, impact: 3, color: 'text-amber-600', bg: 'bg-amber-50' },
                  { name: 'Ledger Integrity Failure', likelihood: 1, impact: 5, color: 'text-emerald-600', bg: 'bg-emerald-50' },
                  { name: 'MFA Bypass Attempt', likelihood: 3, impact: 4, color: 'text-orange-600', bg: 'bg-orange-50' }
                ].map((risk, i) => {
                  const score = risk.likelihood * risk.impact;
                  const getScoreColor = (s: number) => {
                    if (s >= 15) return 'bg-rose-500';
                    if (s >= 10) return 'bg-orange-500';
                    if (s >= 5) return 'bg-amber-500';
                    return 'bg-emerald-500';
                  };

                  return (
                    <div key={i} className="group">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-bold text-slate-700">{risk.name}</span>
                        <div className="flex items-center gap-3">
                          <span className={`text-[10px] font-black px-2 py-0.5 rounded ${risk.bg} ${risk.color}`}>
                            SCORE: {score}
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="flex-1 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                          <motion.div 
                            initial={{ width: 0 }}
                            animate={{ width: `${(score / 25) * 100}%` }}
                            className={`h-full ${getScoreColor(score)}`}
                          />
                        </div>
                        <div className="flex gap-4 text-[9px] font-bold text-slate-400 uppercase tracking-tighter">
                          <span>L: {risk.likelihood}</span>
                          <span>I: {risk.impact}</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="mt-8 pt-8 border-t border-slate-100">
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
                    <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Avg Risk Score</div>
                    <div className="text-2xl font-black text-slate-900">11.4</div>
                    <div className="text-[9px] font-bold text-orange-600 uppercase mt-1">Medium Exposure</div>
                  </div>
                  <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
                    <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Mitigated Risks</div>
                    <div className="text-2xl font-black text-slate-900">84%</div>
                    <div className="text-[9px] font-bold text-emerald-600 uppercase mt-1">+2.4% this month</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Risk Simulator */}
            <div className="bg-slate-900 rounded-3xl p-8 text-white shadow-xl border border-white/5">
              <div className="flex items-center justify-between mb-6">
                <h4 className="font-bold text-lg flex items-center gap-2">
                  <Zap className="w-5 h-5 text-amber-400" />
                  Interactive Risk Simulator
                </h4>
                <div className={`px-3 py-1 rounded-full ${getSimColor(simScore)} text-white text-[10px] font-black uppercase tracking-widest animate-pulse`}>
                  Score: {simScore}
                </div>
              </div>

              <div className="space-y-8">
                <div>
                  <div className="flex justify-between mb-4">
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Likelihood (1-5)</span>
                    <span className="text-xl font-black text-white">{simLikelihood}</span>
                  </div>
                  <input 
                    type="range" 
                    min="1" 
                    max="5" 
                    step="1"
                    value={simLikelihood}
                    onChange={(e) => setSimLikelihood(parseInt(e.target.value))}
                    className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
                  />
                  <div className="flex justify-between mt-2 text-[8px] font-bold text-slate-600 uppercase tracking-tighter">
                    <span>Rare</span>
                    <span>Frequent</span>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between mb-4">
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Impact (1-5)</span>
                    <span className="text-xl font-black text-white">{simImpact}</span>
                  </div>
                  <input 
                    type="range" 
                    min="1" 
                    max="5" 
                    step="1"
                    value={simImpact}
                    onChange={(e) => setSimImpact(parseInt(e.target.value))}
                    className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
                  />
                  <div className="flex justify-between mt-2 text-[8px] font-bold text-slate-600 uppercase tracking-tighter">
                    <span>Negligible</span>
                    <span>Catastrophic</span>
                  </div>
                </div>

                <div className="p-6 rounded-2xl bg-white/5 border border-white/10 text-center">
                  <div className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.3em] mb-2">Calculation Result</div>
                  <div className="flex items-center justify-center gap-4">
                    <div className="text-3xl font-black text-white">{simLikelihood}</div>
                    <div className="text-slate-600">×</div>
                    <div className="text-3xl font-black text-white">{simImpact}</div>
                    <div className="text-slate-600">=</div>
                    <div className={`text-4xl font-black px-4 py-1 rounded-xl ${getSimColor(simScore)} text-white shadow-lg`}>
                      {simScore}
                    </div>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-4 font-medium italic">
                    {simScore >= 15 ? "Immediate mitigation required. High priority." :
                     simScore >= 10 ? "Significant risk detected. Monitor closely." :
                     simScore >= 5 ? "Moderate risk. Standard controls apply." :
                     "Low risk. Maintain existing protocols."}
                  </p>
                </div>
              </div>
            </div>

            {/* Partner Trust Score Dashboard */}
            <div className="bg-white rounded-3xl p-8 border border-slate-100 shadow-sm">
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h4 className="font-bold text-slate-900 flex items-center gap-2">
                    <UserCheck className="w-4 h-4 text-blue-500" />
                    Partner Trust Score
                  </h4>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">
                    Total Score = Technical + Security + Operational + Governance
                  </p>
                </div>
                <div className={`text-3xl font-black ${totalScore >= 80 ? 'text-emerald-600' : totalScore >= 60 ? 'text-blue-600' : 'text-amber-600'}`}>
                  {totalScore}<span className="text-sm text-slate-300 font-bold">/100</span>
                </div>
              </div>

              <div className="space-y-6">
                {[
                  { id: 'technical', label: 'Technical Infrastructure', icon: Cpu, color: 'blue' },
                  { id: 'security', label: 'Security Compliance', icon: Shield, color: 'emerald' },
                  { id: 'operational', label: 'Operational Excellence', icon: Zap, color: 'amber' },
                  { id: 'governance', label: 'Governance & Risk', icon: Lock, color: 'indigo' }
                ].map((comp) => (
                  <div key={comp.id}>
                    <div className="flex justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className={`text-${comp.color}-500`}>
                          <comp.icon className="w-3 h-3" />
                        </div>
                        <span className="text-xs font-bold text-slate-600">{comp.label}</span>
                      </div>
                      <span className="text-xs font-black text-slate-900">{scores[comp.id as keyof typeof scores]}</span>
                    </div>
                    <input 
                      type="range" 
                      min="0" 
                      max="25" 
                      step="1"
                      value={scores[comp.id as keyof typeof scores]}
                      onChange={(e) => setScores({ ...scores, [comp.id]: parseInt(e.target.value) })}
                      className={`w-full h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-${comp.color}-500`}
                    />
                  </div>
                ))}
              </div>

              <div className="mt-8 p-4 rounded-2xl bg-slate-50 border border-slate-100">
                <div className="flex items-center gap-3">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-white shadow-lg ${
                    totalScore >= 80 ? 'bg-emerald-500' : totalScore >= 60 ? 'bg-blue-500' : 'bg-amber-500'
                  }`}>
                    <ShieldCheck className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Trust Classification</div>
                    <div className="text-lg font-black text-slate-900">
                      {totalScore >= 90 ? 'Strategic Partner' : 
                       totalScore >= 80 ? 'Trusted Node' : 
                       totalScore >= 60 ? 'Verified Partner' : 
                       'Probationary Access'}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Mitigation Strategies */}
            <div className="bg-slate-900 rounded-3xl p-8 text-white shadow-xl">
              <h4 className="font-bold text-lg mb-6 flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
                Mitigation Roadmap
              </h4>
              <div className="space-y-4">
                {[
                  { title: 'mTLS Enforcement', status: 'Completed', progress: 100 },
                  { title: 'HSM Key Rotation', status: 'In Progress', progress: 65 },
                  { title: 'Behavioral SIEM', status: 'Planning', progress: 15 }
                ].map((item, i) => (
                  <div key={i}>
                    <div className="flex justify-between text-xs mb-2">
                      <span className="text-slate-300 font-medium">{item.title}</span>
                      <span className="text-slate-500 font-bold uppercase tracking-widest text-[9px]">{item.status}</span>
                    </div>
                    <div className="h-1 bg-white/10 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-emerald-500 rounded-full" 
                        style={{ width: `${item.progress}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Partner Compliance Dashboard */}
        <div className="mt-12">
          <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <h4 className="font-bold text-slate-900 flex items-center gap-2">
                <UserCheck className="w-4 h-4 text-blue-500" />
                Partner Compliance Dashboard
              </h4>
              <div className="px-3 py-1 rounded-full bg-blue-100 text-blue-700 text-[10px] font-bold uppercase tracking-widest">
                Real-time Monitoring
              </div>
            </div>
            <div className="p-0 overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-widest">
                  <tr>
                    <th className="px-6 py-3">Partner Tier</th>
                    <th className="px-6 py-3 text-center">SLA Score</th>
                    <th className="px-6 py-3 text-center">Security Score</th>
                    <th className="px-6 py-3 text-center">Data Quality</th>
                    <th className="px-6 py-3 text-center">Risk</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {[
                    { name: 'Partner A', sla: '98%', security: '92%', quality: '99%', risk: 'Low' },
                    { name: 'Partner B', sla: '87%', security: '78%', quality: '91%', risk: 'Med' },
                    { name: 'Partner C', sla: '62%', security: '55%', quality: '70%', risk: 'High' }
                  ].map((partner, i) => (
                    <tr key={i} className="hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold ${
                            partner.risk === 'Low' ? 'bg-emerald-100 text-emerald-700' :
                            partner.risk === 'Med' ? 'bg-amber-100 text-amber-700' :
                            'bg-rose-100 text-rose-700'
                          }`}>
                            {partner.name.split(' ')[1]}
                          </div>
                          <span className="font-bold text-slate-700">{partner.name}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-center font-mono font-bold text-slate-600">{partner.sla}</td>
                      <td className="px-6 py-4 text-center font-mono font-bold text-slate-600">{partner.security}</td>
                      <td className="px-6 py-4 text-center font-mono font-bold text-slate-600">{partner.quality}</td>
                      <td className="px-6 py-4 text-center">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          partner.risk === 'Low' ? 'bg-emerald-100 text-emerald-700' :
                          partner.risk === 'Med' ? 'bg-amber-100 text-amber-700' :
                          'bg-rose-100 text-rose-700'
                        }`}>
                          {partner.risk}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* AI Threat Intelligence Pipeline */}
        <div className="mt-12">
          <div className="bg-slate-900 rounded-3xl p-8 text-white shadow-2xl relative overflow-hidden border border-white/5">
            <div className="absolute top-0 right-0 p-8 opacity-5">
              <Brain className="w-64 h-64" />
            </div>

            <div className="relative z-10">
              <div className="flex items-center justify-between mb-12">
                <div>
                  <h4 className="font-bold text-xl flex items-center gap-2">
                    <Brain className="w-6 h-6 text-purple-400" />
                    AI Threat Intelligence Pipeline
                  </h4>
                  <p className="text-xs text-slate-400 mt-1">Real-time Behavioral Analytics & Anomaly Detection</p>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-purple-500 animate-ping" />
                  <span className="text-[10px] font-bold text-purple-400 uppercase tracking-widest">ML Engine Active</span>
                </div>
              </div>

              <div className="flex flex-col lg:flex-row items-center justify-between gap-4 lg:gap-2">
                {[
                  { label: 'Event', icon: Activity, color: 'text-blue-400', bg: 'bg-blue-500/10' },
                  { label: 'Schema Validation', icon: ShieldCheck, color: 'text-emerald-400', bg: 'bg-emerald-500/10' },
                  { label: 'Feature Vector', icon: Cpu, color: 'text-cyan-400', bg: 'bg-cyan-500/10' },
                  { label: 'ML Model', icon: Brain, color: 'text-purple-400', bg: 'bg-purple-500/10' },
                  { label: 'Score', icon: Zap, color: 'text-amber-400', bg: 'bg-amber-500/10' },
                  { label: 'Alert', icon: Bell, color: 'text-rose-400', bg: 'bg-rose-500/10' }
                ].map((step, i, arr) => (
                  <React.Fragment key={step.label}>
                    <motion.div 
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.1 }}
                      className="flex flex-col items-center gap-4 w-32"
                    >
                      <div className={`w-14 h-14 rounded-2xl ${step.bg} border border-white/10 flex items-center justify-center relative group hover:border-white/20 transition-colors shadow-lg`}>
                        <step.icon className={`w-7 h-7 ${step.color}`} />
                        <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-slate-800 border border-white/10 flex items-center justify-center text-[10px] font-black text-slate-400">
                          0{i + 1}
                        </div>
                      </div>
                      <div className="text-center">
                        <div className="text-[10px] font-black text-white uppercase tracking-widest mb-1">{step.label}</div>
                        <div className="text-[8px] text-slate-500 font-bold uppercase tracking-tighter">
                          {i === 0 ? 'Raw Ingestion' : 
                           i === 1 ? 'JSON/mTLS' : 
                           i === 2 ? 'Vectorization' : 
                           i === 3 ? 'Inference' : 
                           i === 4 ? 'Ensemble' : 'Notification'}
                        </div>
                      </div>
                    </motion.div>
                    {i < arr.length - 1 && (
                      <div className="hidden lg:flex items-center text-slate-700">
                        <ArrowRight className="w-5 h-5 animate-pulse" />
                      </div>
                    )}
                  </React.Fragment>
                ))}
              </div>

              <div className="mt-8 p-4 rounded-2xl bg-white/5 border border-white/10 text-center">
                <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">Ensemble Scoring Logic</div>
                <code className="text-xs font-mono text-purple-300">
                  final_score = 0.6 * autoencoder_score + 0.4 * isolation_forest_score
                </code>
              </div>

              <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
                {[
                  { label: 'Model Accuracy', value: '99.4%', trend: '+0.2%' },
                  { label: 'Inference Latency', value: '12ms', trend: '-2ms' },
                  { label: 'Daily Anomalies', value: '124', trend: 'Stable' }
                ].map((stat) => (
                  <div key={stat.label} className="bg-white/5 border border-white/10 rounded-2xl p-4">
                    <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">{stat.label}</div>
                    <div className="flex items-end gap-2">
                      <div className="text-xl font-black text-white">{stat.value}</div>
                      <div className="text-[9px] font-bold text-emerald-400 mb-1">{stat.trend}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Audit Log Simulation */}
        <div className="mt-12">
          <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <h4 className="font-bold text-slate-900 flex items-center gap-2">
                <History className="w-4 h-4 text-slate-500" />
                Immutable Audit Trail
              </h4>
              <button className="text-[10px] font-bold text-blue-600 uppercase tracking-widest hover:underline">
                Export Full Log
              </button>
            </div>
            <div className="p-0">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-widest">
                  <tr>
                    <th className="px-6 py-3">Timestamp</th>
                    <th className="px-6 py-3">Service</th>
                    <th className="px-6 py-3">Action</th>
                    <th className="px-6 py-3">Partner ID</th>
                    <th className="px-6 py-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {[
                    { time: '2026-04-10 04:30:12', service: 'Ingestion', action: 'Event Accepted', partner: 'DHL-KE', status: 'SUCCESS' },
                    { time: '2026-04-10 04:29:45', service: 'AuthZ', action: 'Token Rotated', partner: 'SYSTEM', status: 'SUCCESS' },
                    { time: '2026-04-10 04:28:10', service: 'Gateway', action: 'Rate Limit Triggered', partner: 'FEDEX-NG', status: 'THROTTLED' },
                    { time: '2026-04-10 04:27:55', service: 'Ledger', action: 'Block Committed', partner: 'SYSTEM', status: 'SUCCESS' },
                    { time: '2026-04-10 04:26:30', service: 'WAF', action: 'SQLi Attempt Blocked', partner: 'UNKNOWN', status: 'BLOCKED' }
                  ].map((log, i) => (
                    <tr key={i} className="hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4 font-mono text-slate-400">{log.time}</td>
                      <td className="px-6 py-4 font-bold text-slate-700">{log.service}</td>
                      <td className="px-6 py-4 text-slate-600">{log.action}</td>
                      <td className="px-6 py-4 font-mono text-slate-500">{log.partner}</td>
                      <td className="px-6 py-4">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          log.status === 'SUCCESS' ? 'bg-emerald-100 text-emerald-700' :
                          log.status === 'BLOCKED' ? 'bg-rose-100 text-rose-700' :
                          'bg-amber-100 text-amber-700'
                        }`}>
                          {log.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
