import React from 'react';
import { Box, Zap } from 'lucide-react';

interface LogoProps {
  className?: string;
  variant?: 'light' | 'dark';
  size?: 'sm' | 'md' | 'lg';
}

export const Logo: React.FC<LogoProps> = ({ className = '', variant = 'dark', size = 'md' }) => {
  const sizes = {
    sm: 'h-6',
    md: 'h-8',
    lg: 'h-12'
  };

  const textSizes = {
    sm: 'text-lg',
    md: 'text-2xl',
    lg: 'text-4xl'
  };

  const iconSizes = {
    sm: 16,
    md: 24,
    lg: 32
  };

  const textColor = variant === 'dark' ? 'text-[#1a365d]' : 'text-white';
  const accentColor = variant === 'dark' ? 'text-blue-600' : 'text-blue-400';

  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <div className={`relative flex items-center justify-center ${variant === 'dark' ? 'bg-[#1a365d]' : 'bg-white'} rounded-xl p-1.5 shadow-lg`}>
        <Box size={iconSizes[size]} className={variant === 'dark' ? 'text-white' : 'text-[#1a365d]'} />
        <div className="absolute -top-1 -right-1 bg-blue-500 rounded-full p-0.5 border-2 border-white">
          <Zap size={iconSizes[size] / 2} className="text-white fill-current" />
        </div>
      </div>
      <span className={`${textSizes[size]} font-black tracking-tighter uppercase ${textColor}`}>
        UA<span className={accentColor}>PS</span>
      </span>
    </div>
  );
};
