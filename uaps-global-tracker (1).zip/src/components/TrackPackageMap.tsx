import { MapContainer, TileLayer, Marker, Popup, Polyline } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";
import { useEffect, useState } from "react";
import { CourierRoute } from "./CourierRoute";
import { DeliveryTimeline } from "./DeliveryTimeline";
import { computeEta } from "../services/etaService";

const courierIcon = L.icon({
  iconUrl: "https://cdn-icons-png.flaticon.com/512/684/684908.png",
  iconSize: [32, 32],
});

export function TrackPackageMap({ trackingId, shipment }: { trackingId: string; shipment?: any }) {
  const [data, setData] = useState<any>(shipment || null);

  useEffect(() => {
    if (shipment) {
      setData(shipment);
    }
  }, [shipment]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch(`/api/track/${trackingId}`);
        const __jsonBody = await res.json();
      const json = __jsonBody.data || __jsonBody;
        let shipmentData;
        if (json.shipments && json.shipments.length > 0) {
          shipmentData = json.shipments[0];
        } else {
          shipmentData = json;
        }
        setData(shipmentData);
      } catch (error) {
        console.error("Failed to fetch tracking info:", error);
      }
    };

    if (!shipment) {
      fetchData();
    }
    
    const interval = setInterval(fetchData, 5000); // Poll less frequently if we have WebSockets

    return () => clearInterval(interval);
  }, [trackingId, shipment]);

  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const ws = new WebSocket(`${protocol}//${window.location.host}`);

    ws.onopen = () => {
      ws.send(JSON.stringify({ type: "subscribe", trackingId }));
    };

    ws.onmessage = (event) => {
      try {
        const payload = JSON.parse(event.data);
        if (payload.type === "status_update") {
          setData((prev: any) => {
            if (!prev) return prev;
            return {
              ...prev,
              status: payload.status,
              statusHistory: [...(prev.statusHistory || []), { status: payload.status.status, timestamp: payload.timestamp }]
            };
          });
        }
      } catch (err) {
        console.error("WS Message Error:", err);
      }
    };

    return () => ws.close();
  }, [trackingId]);

  const [aiEta, setAiEta] = useState<{ etaMinutes: number; reason: string } | null>(null);

  useEffect(() => {
    if (data?.courier?.location && data?.destination?.location) {
      const fetchAiEta = async () => {
        try {
          const eta = await computeEta({
            start: data.courier.location,
            end: data.destination.location,
            city: data.destination.location.address?.addressLocality || "Nairobi",
            vehicle: data.courier.vehicle || "bike",
            timeOfDay: new Date().getHours() < 12 ? "morning" : "afternoon"
          });
          setAiEta(eta);
        } catch (error) {
          console.error("Failed to fetch AI ETA:", error);
        }
      };
      fetchAiEta();
    }
  }, [data?.courier?.location?.lat, data?.courier?.location?.lng]);

  if (!data) return <div className="p-8 text-center text-gray-500">Loading tracking info…</div>;
  
  const courier = data.courier;
  if (!courier || !courier.location) return <div className="p-8 text-center text-gray-500 italic">Courier not yet assigned or location unavailable.</div>;

  const { lat, lng } = courier.location;
  const status = data.status?.status || data.status || "Unknown";

  let etaText = aiEta ? (aiEta.etaMinutes < 1 ? "Arriving now" : `${aiEta.etaMinutes} mins`) : "";
  let distanceText = "";

  if (data.destination?.location) {
    const destLat = data.destination.location.lat;
    const destLng = data.destination.location.lng;
    
    const R = 6371;
    const dLat = (destLat - lat) * Math.PI / 180;
    const dLng = (destLng - lng) * Math.PI / 180;
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(lat * Math.PI / 180) * Math.cos(destLat * Math.PI / 180) * 
      Math.sin(dLng/2) * Math.sin(dLng/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const distanceKm = R * c;
    distanceText = `${distanceKm.toFixed(1)} km`;
  }

  return (
    <div className="w-full h-full relative z-0">
      <div className="absolute top-4 right-4 z-[1000] flex flex-col gap-2">
        {etaText && (
          <div className="bg-white/90 backdrop-blur shadow-xl rounded-xl p-4 border border-blue-100 flex items-center gap-3 animate-in fade-in slide-in-from-top-2">
            <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
            </div>
            <div>
              <p className="text-[10px] font-bold uppercase tracking-widest text-blue-600/60 leading-none mb-1">Estimated Arrival</p>
              <p className="text-xl font-black text-blue-900 leading-none">{etaText}</p>
              {aiEta?.reason && (
                <p className="text-[9px] text-blue-400 mt-1 max-w-[150px] leading-tight italic">{aiEta.reason}</p>
              )}
            </div>
          </div>
        )}
        
        {distanceText && (
          <div className="bg-white/90 backdrop-blur shadow-xl rounded-xl p-4 border border-blue-100 flex items-center gap-3 animate-in fade-in slide-in-from-top-2 delay-100">
            <div className="w-10 h-10 bg-emerald-600 rounded-full flex items-center justify-center text-white">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
            </div>
            <div>
              <p className="text-[10px] font-bold uppercase tracking-widest text-emerald-600/60 leading-none mb-1">Distance Remaining</p>
              <p className="text-xl font-black text-emerald-900 leading-none">{distanceText}</p>
            </div>
          </div>
        )}
      </div>

      <div className="absolute bottom-4 left-4 z-[1000] bg-white/90 backdrop-blur shadow-xl rounded-xl p-4 border border-blue-100 animate-in fade-in slide-in-from-bottom-2">
        <p className="text-[10px] font-bold uppercase tracking-widest text-blue-600/60 leading-none mb-3">Delivery Progress</p>
        <DeliveryTimeline history={data.statusHistory || []} />
      </div>

      <MapContainer
        center={[lat, lng]}
        zoom={13}
        style={{ height: "100%", width: "100%", background: '#0f172a' }}
        zoomControl={true}
      >
        <TileLayer
          url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
        />

        {data.coordinates && data.coordinates.length > 0 && (
          <Polyline 
            positions={data.coordinates} 
            color="#3b82f6" 
            weight={4} 
            dashArray="10, 10"
            opacity={0.7}
          />
        )}

        {courier?.locationHistory && courier.locationHistory.length > 0 && (
          <Polyline 
            positions={courier.locationHistory.map((loc: any) => [loc.lat, loc.lng])} 
            color="#10b981" 
            weight={4} 
            dashArray="5, 5"
            opacity={0.8}
          />
        )}

        {courier?.id && <CourierRoute courierId={courier.id} />}

        <Marker position={[lat, lng]} icon={courierIcon}>
          <Popup>
            <div className="p-1">
              <p className="font-bold text-blue-600">Courier is here</p>
              <p className="text-xs text-gray-600 mt-1">Status: <span className="font-medium text-gray-800">{status}</span></p>
            </div>
          </Popup>
        </Marker>
      </MapContainer>
    </div>
  );
}
