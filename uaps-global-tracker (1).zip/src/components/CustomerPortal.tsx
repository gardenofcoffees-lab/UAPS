import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Package, 
  Truck, 
  CheckCircle2, 
  Clock, 
  Plus, 
  Search, 
  ChevronRight, 
  MapPin, 
  Calendar,
  User,
  Settings,
  Bell,
  LogOut,
  ArrowUpRight,
  ShieldCheck,
  CreditCard,
  History,
  ArrowLeft,
  Info,
  Globe,
  Shield,
  Zap,
  Activity,
  Navigation
} from 'lucide-react';
import { Logo } from './Logo';
import { DeliveryTimeline } from './DeliveryTimeline';
import { TrackMyCourierMap } from './TrackMyCourierMap';
import { CustomsClearanceForm } from './CustomsClearanceForm';
import { SafetyEventCard } from './SafetyEventCard';
import { SecurityEventCard } from './SecurityEventCard';
import { TelemetryAnomalyCard } from './TelemetryAnomalyCard';
import { ModelDriftCard } from './ModelDriftCard';
import { ModelRollbackCard } from './ModelRollbackCard';
import { ModelRollbackResultCard } from './ModelRollbackResultCard';
import { ModelDriftRollbackCard } from './ModelDriftRollbackCard';
import { ModelGovernanceCard } from './ModelGovernanceCard';
import { ModelRecoverySummaryCard } from './ModelRecoverySummaryCard';
import { RiskAssessmentCard } from './RiskAssessmentCard';
import { ModelCard } from './ModelCard';
import safetyEventsData from '../data/safety_events.json';

interface Shipment {
  id: string;
  status: string;
  origin: string;
  destination: string;
  date: string;
  type: string;
  history: { status: string; timestamp: number }[];
  createdAt: string;
  courierId?: string;
  shipment_options?: {
    delivery_mode?: string;
    speed: string;
    delivery_window?: {
      start: string;
      end: string;
    };
    handling: string[];
    dropoff_mode: string;
    privacy_mode: string;
    sla_tier: string;
  };
  routing_constraints?: {
    fragile_handling?: string;
    delivery_window?: string;
    [key: string]: any;
  };
  risk_scores?: any;
  model_outputs?: any;
  routing_decision?: any;
  routing_weights?: {
    w_t: number;
    w_r: number;
    w_b: number;
    w_w: number;
    w_s: number;
  };
  mode_execution?: {
    actual_mode: string;
    handoff_point: any;
  };
  route_summary?: {
    distance_m: number;
    eta: string;
  };
  mode_rationale?: {
    reason: string;
    alternatives_considered: string[];
    final_score: number;
  };
  handoff_details?: {
    location: { lat: number; lon: number };
    timestamp: string;
  };
  ground_robot_route?: {
    route_id: string;
    robot_id: string;
    start: any;
    end: any;
    waypoints: any[];
    constraints: any;
    execution_telemetry: any;
  };
  proofOfDelivery?: {
    signature?: string;
    photo?: string;
    timestamp: string;
  };
  summary?: {
    flight_path?: any;
    weather?: any;
    battery_summary?: any;
    safety_summary?: any;
  };
  dropoff_location?: {
    lat: number;
    lon: number;
    locker_id?: string;
  };
  estimatedDeliveryTime?: string;
  actualDeliveryTime?: string;
  courierContact?: {
    name: string;
    phone: string;
    email?: string;
  };
}

const AFRICAN_COUNTRIES = [
  "Algeria", "Angola", "Benin", "Botswana", "Burkina Faso", "Burundi", "Cabo Verde", "Cameroon", 
  "Central African Republic", "Chad", "Comoros", "Congo", "Democratic Republic of the Congo", 
  "Djibouti", "Egypt", "Equatorial Guinea", "Eritrea", "Eswatini", "Ethiopia", "Gabon", "Gambia", 
  "Ghana", "Guinea", "Guinea-Bissau", "Ivory Coast", "Kenya", "Lesotho", "Liberia", "Libya", 
  "Madagascar", "Malawi", "Mali", "Mauritania", "Mauritius", "Morocco", "Mozambique", "Namibia", 
  "Niger", "Nigeria", "Rwanda", "Sao Tome and Principe", "Senegal", "Seychelles", "Sierra Leone", 
  "Somalia", "South Africa", "South Sudan", "Sudan", "Tanzania", "Togo", "Tunisia", "Uganda", 
  "Zambia", "Zimbabwe"
];

export function CustomerPortal({ onTrack }: { onTrack: (id: string) => void }) {
  const [view, setView] = useState<'dashboard' | 'shipments' | 'new' | 'profile' | 'details' | 'customs' | 'safety'>('dashboard');
  const [shipments, setShipments] = useState<Shipment[]>([]);
  const [selectedShipment, setSelectedShipment] = useState<Shipment | null>(null);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  const fetchShipments = async () => {
    try {
      const res = await fetch('/api/shipments');
      if (res.ok) {
        const __dataBody = await res.json();
      const data = __dataBody.data || __dataBody;
        // Map backend Delivery to frontend Shipment interface
        const mappedData: Shipment[] = data.map((d: any) => ({
          id: d.id,
          status: d.status,
          origin: d.pickupAddress,
          destination: d.dropoffAddress,
          date: d.createdAt ? new Date(d.createdAt).toLocaleDateString() : new Date().toLocaleDateString(),
          type: d.shipment_options?.speed || "Express",
          history: [],
          courierId: d.courierId,
          shipment_options: d.shipment_options,
          routing_constraints: d.routing_constraints,
          risk_scores: d.risk_scores,
          model_outputs: d.model_outputs,
          routing_decision: d.routing_decision,
          routing_weights: d.routing_weights,
          mode_execution: d.mode_execution,
          route_summary: d.route_summary,
          mode_rationale: d.mode_rationale,
          handoff_details: d.handoff_details,
          ground_robot_route: d.ground_robot_route,
          proofOfDelivery: d.proofOfDelivery,
          summary: d.summary,
          dropoff_location: d.dropoff_location,
          createdAt: d.createdAt || new Date().toISOString()
        })).sort((a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        setShipments(mappedData);
      }
    } catch (error) {
      console.error("Failed to fetch shipments:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchShipments();
  }, []);

  const stats = {
    total: shipments.length,
    active: shipments.filter(s => s.status !== 'DELIVERED').length,
    delivered: shipments.filter(s => s.status === 'DELIVERED').length
  };

  const filteredShipments = shipments.filter(s => 
    s.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.destination.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const [formData, setFormData] = useState({
    pickupAddress: '',
    pickupCity: '',
    pickupCountry: 'Eritrea',
    senderName: '',
    senderPhone: '',
    dropoffAddress: '',
    dropoffCity: '',
    dropoffCountry: 'Eritrea',
    receiverName: '',
    receiverPhone: '',
    weight: '',
    dimensions: '',
    type: 'Express (1-2 days)',
    deliveryMode: 'AIR_DRONE',
    speed: 'STANDARD',
    deliveryWindowStart: '',
    deliveryWindowEnd: '',
    handling: [] as string[],
    dropoffMode: 'DOORSTEP',
    privacyMode: 'NORMAL',
    slaTier: 'BRONZE'
  });

  const handleCreateShipment = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/shipments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });
      if (res.ok) {
        const __dataBody = await res.json();
      const data = __dataBody.data || __dataBody;
        alert(`Shipment created! Tracking ID: ${data.id}`);
        await fetchShipments();
        setView('shipments');
        setFormData({
          pickupAddress: '',
          pickupCity: '',
          pickupCountry: 'Eritrea',
          senderName: '',
          senderPhone: '',
          dropoffAddress: '',
          dropoffCity: '',
          dropoffCountry: 'Eritrea',
          receiverName: '',
          receiverPhone: '',
          weight: '',
          dimensions: '',
          type: 'Express (1-2 days)',
          deliveryMode: 'AIR_DRONE',
          speed: 'STANDARD',
          deliveryWindowStart: '',
          deliveryWindowEnd: '',
          handling: [],
          dropoffMode: 'DOORSTEP',
          privacyMode: 'NORMAL',
          slaTier: 'BRONZE'
        });
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleModifyDelivery = async () => {
    if (!selectedShipment) return;
    
    const payload = {
      requested_changes: {
        delivery_window: {
          start: "2026-04-11T16:00:00Z",
          end: "2026-04-11T18:00:00Z"
        },
        dropoff_mode: "SECURE_LOCKER",
        dropoff_location: {
          lat: 43.015,
          lon: -89.417,
          locker_id: "locker-123"
        }
      }
    };

    try {
      const res = await fetch(`/api/shipments/${selectedShipment.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      
      const __dataBody = await res.json();
      const data = __dataBody.data || __dataBody;
      
      if (res.ok) {
        alert('Delivery modified successfully!');
        await fetchShipments();
        // Since the backend no longer returns the full shipment object in data.shipment,
        // we just refetch the shipments and update the selected shipment from the new list.
        const updatedRes = await fetch('/api/shipments');
        const __updatedDataBody = await updatedRes.json();
      const updatedData = __updatedDataBody.data || __updatedDataBody;
        const updatedShipment = updatedData.find((s: any) => s.id === selectedShipment.id);
        if (updatedShipment) {
          setSelectedShipment(updatedShipment);
        }
      } else {
        if (data.status === 'OPTIONS_REJECTED') {
          alert(`Modification Rejected: ${data.reason.replace(/_/g, ' ')}`);
        } else {
          alert('Failed to modify delivery.');
        }
      }
    } catch (err) {
      console.error(err);
      alert('Error modifying delivery.');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <aside className="w-64 bg-[#1a365d] text-white flex flex-col">
        <div className="p-8">
          <Logo variant="light" size="sm" />
        </div>

        <nav className="flex-1 px-4 py-4 space-y-2">
          <button 
            onClick={() => setView('dashboard')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-all ${view === 'dashboard' ? 'bg-white/10 text-white' : 'text-blue-100/60 hover:bg-white/5'}`}
          >
            <Package className="w-5 h-5" /> Dashboard
          </button>
          <button 
            onClick={() => setView('shipments')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-all ${view === 'shipments' ? 'bg-white/10 text-white' : 'text-blue-100/60 hover:bg-white/5'}`}
          >
            <Truck className="w-5 h-5" /> My Shipments
          </button>
          <button 
            onClick={() => setView('new')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-all ${view === 'new' ? 'bg-white/10 text-white' : 'text-blue-100/60 hover:bg-white/5'}`}
          >
            <Plus className="w-5 h-5" /> New Shipment
          </button>
          <button 
            onClick={() => setView('profile')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-all ${view === 'profile' ? 'bg-white/10 text-white' : 'text-blue-100/60 hover:bg-white/5'}`}
          >
            <User className="w-5 h-5" /> Profile
          </button>
        </nav>

        <div className="p-4 border-t border-white/10">
          <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold text-red-400 hover:bg-red-500/10 transition-all">
            <LogOut className="w-5 h-5" /> Logout
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 px-8 py-4 flex justify-between items-center sticky top-0 z-10">
          <h1 className="text-xl font-black text-[#1a365d] uppercase tracking-tight">
            {view === 'dashboard' && 'Customer Dashboard'}
            {view === 'shipments' && 'My Shipments'}
            {view === 'new' && 'Create New Shipment'}
            {view === 'profile' && 'My Profile'}
            {view === 'details' && 'Shipment Details'}
            {view === 'customs' && 'Customs Declaration'}
            {view === 'safety' && 'Safety Log'}
          </h1>
          <div className="flex items-center gap-4">
            <button className="p-2 text-gray-400 hover:text-[#1a365d] transition-colors relative">
              <Bell className="w-5 h-5" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full border-2 border-white" />
            </button>
            <div className="flex items-center gap-3 pl-4 border-l border-gray-100">
              <div className="text-right">
                <p className="text-xs font-black text-[#1a365d]">Aaron Abraha</p>
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Premium Member</p>
              </div>
              <div className="w-10 h-10 bg-blue-50 rounded-full flex items-center justify-center text-blue-600 font-black text-sm">
                AA
              </div>
            </div>
          </div>
        </header>

        <div className="p-8">
          {view === 'details' && selectedShipment && (
            <div className="space-y-8 max-w-6xl mx-auto">
              <button 
                onClick={() => setView('shipments')}
                className="flex items-center gap-2 text-xs font-black text-blue-600 hover:text-blue-700 transition-colors uppercase tracking-widest"
              >
                <ArrowLeft className="w-4 h-4" /> Back to Shipments
              </button>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 space-y-8">
                  {/* Map Section */}
                  <div className="bg-white rounded-[40px] shadow-xl border border-gray-100 overflow-hidden">
                    <div className="p-8 border-b border-gray-50 flex justify-between items-center">
                      <div>
                        <h3 className="text-lg font-black text-[#1a365d] uppercase tracking-tight">Live Tracking</h3>
                        <p className="text-xs text-gray-400 font-bold uppercase tracking-widest">Real-time courier location</p>
                      </div>
                      <div className="flex items-center gap-2 px-4 py-2 bg-emerald-50 text-emerald-600 rounded-xl text-[10px] font-black uppercase tracking-widest">
                        <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
                        Live Updates
                      </div>
                    </div>
                    <div className="h-[500px] bg-gray-900 relative">
                      {selectedShipment.courierId ? (
                        <TrackMyCourierMap trackingId={selectedShipment.id} />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-center p-12">
                          <div>
                            <div className="w-16 h-16 bg-gray-800 rounded-2xl flex items-center justify-center text-gray-600 mx-auto mb-4">
                              <MapPin className="w-8 h-8" />
                            </div>
                            <h4 className="text-white font-black uppercase tracking-widest mb-2">No Live Data</h4>
                            <p className="text-gray-500 text-sm max-w-xs mx-auto">This shipment is not currently assigned to a live courier or is in a processing stage.</p>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Shipment Info */}
                  <div className="bg-white p-10 rounded-[40px] shadow-xl border border-gray-100">
                    <div className="flex items-center gap-4 mb-8">
                      <div className="w-12 h-12 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600">
                        <Package className="w-6 h-6" />
                      </div>
                      <div>
                        <h3 className="text-xl font-black text-[#1a365d]">{selectedShipment.id}</h3>
                        <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">{selectedShipment.type} Shipment</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                      <div className="space-y-6">
                        <div>
                          <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Origin</p>
                          <div className="flex items-start gap-3">
                            <div className="w-8 h-8 bg-gray-50 rounded-lg flex items-center justify-center text-gray-400 mt-0.5">
                              <MapPin className="w-4 h-4" />
                            </div>
                            <p className="text-sm font-bold text-[#1a365d] leading-relaxed">{selectedShipment.origin}</p>
                          </div>
                        </div>
                        <div>
                          <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Destination</p>
                          <div className="flex items-start gap-3">
                            <div className="w-8 h-8 bg-emerald-50 rounded-lg flex items-center justify-center text-emerald-600 mt-0.5">
                              <Truck className="w-4 h-4" />
                            </div>
                            <p className="text-sm font-bold text-[#1a365d] leading-relaxed">{selectedShipment.destination}</p>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-6">
                        <div className="p-6 bg-gray-50 rounded-3xl border border-gray-100">
                          <div className="flex justify-between items-center mb-4">
                            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Status</span>
                            <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${
                              selectedShipment.status === 'DELIVERED' ? 'bg-emerald-100 text-emerald-700' : 
                              selectedShipment.status === 'FAILED_SECURITY_EVENT' ? 'bg-red-100 text-red-700' :
                              'bg-blue-100 text-blue-700'
                            }`}>
                              {selectedShipment.status.replace('_', ' ')}
                            </span>
                          </div>
                          <div className="flex items-center gap-3">
                            <Clock className="w-4 h-4 text-blue-600" />
                            <span className="text-xs font-bold text-[#1a365d]">Created on {selectedShipment.date}</span>
                          </div>
                        </div>

                        {selectedShipment.proofOfDelivery && (
                          <div className="p-6 bg-emerald-50 rounded-3xl border border-emerald-100">
                            <h4 className="text-[10px] font-black text-emerald-700 uppercase tracking-widest mb-4 flex items-center gap-2">
                              <ShieldCheck className="w-4 h-4" /> Proof of Delivery
                            </h4>
                            {selectedShipment.proofOfDelivery.photo && (
                              <img 
                                src={selectedShipment.proofOfDelivery.photo} 
                                alt="Delivery Proof" 
                                className="w-full h-32 object-cover rounded-2xl mb-4 shadow-sm"
                                referrerPolicy="no-referrer"
                              />
                            )}
                            <p className="text-[10px] font-bold text-emerald-600">Delivered at: {new Date(selectedShipment.proofOfDelivery.timestamp).toLocaleString()}</p>
                          </div>
                        )}
                      </div>
                    </div>

                    {selectedShipment.shipment_options && (
                      <div className="mt-12 pt-12 border-t border-gray-50">
                        <h4 className="text-sm font-black text-[#1a365d] uppercase tracking-widest mb-6 flex items-center gap-2">
                          <Settings className="w-4 h-4 text-blue-600" /> Advanced Shipment Options
                        </h4>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-8">
                          <div>
                            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Delivery Mode</p>
                            <p className="text-xs font-black text-[#1a365d]">{selectedShipment.shipment_options.delivery_mode || 'AIR_DRONE'}</p>
                          </div>
                          <div>
                            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Speed</p>
                            <p className="text-xs font-black text-[#1a365d]">{selectedShipment.shipment_options.speed}</p>
                          </div>
                          <div>
                            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Dropoff Mode</p>
                            <p className="text-xs font-black text-[#1a365d]">{selectedShipment.shipment_options.dropoff_mode}</p>
                          </div>
                          <div>
                            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">SLA Tier</p>
                            <span className={`px-2 py-0.5 rounded-full text-[9px] font-black ${
                              selectedShipment.shipment_options.sla_tier === 'GOLD' ? 'bg-amber-100 text-amber-700' :
                              selectedShipment.shipment_options.sla_tier === 'SILVER' ? 'bg-gray-100 text-gray-700' :
                              'bg-orange-100 text-orange-700'
                            }`}>
                              {selectedShipment.shipment_options.sla_tier}
                            </span>
                          </div>
                          {selectedShipment.shipment_options.delivery_window && (
                            <div className="col-span-2">
                              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Delivery Window</p>
                              <p className="text-xs font-black text-[#1a365d]">
                                {new Date(selectedShipment.shipment_options.delivery_window.start).toLocaleString()} - {new Date(selectedShipment.shipment_options.delivery_window.end).toLocaleString()}
                              </p>
                            </div>
                          )}
                          {selectedShipment.dropoff_location && (
                            <div className="col-span-2">
                              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Dropoff Location</p>
                              <p className="text-xs font-black text-[#1a365d]">
                                {selectedShipment.dropoff_location.locker_id ? `Locker: ${selectedShipment.dropoff_location.locker_id} ` : ''}
                                ({selectedShipment.dropoff_location.lat.toFixed(4)}, {selectedShipment.dropoff_location.lon.toFixed(4)})
                              </p>
                            </div>
                          )}
                          <div>
                            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Privacy Mode</p>
                            <p className="text-xs font-black text-[#1a365d]">{selectedShipment.shipment_options.privacy_mode}</p>
                          </div>
                          {selectedShipment.shipment_options.handling.length > 0 && (
                            <div className="col-span-full">
                              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Special Handling</p>
                              <div className="flex flex-wrap gap-2">
                                {selectedShipment.shipment_options.handling.map(h => (
                                  <span key={h} className="px-2 py-1 bg-blue-50 text-blue-600 rounded-lg text-[9px] font-black uppercase tracking-widest border border-blue-100">
                                    {h}
                                  </span>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    )}

                    {selectedShipment.routing_constraints && (
                      <div className="mt-12 pt-12 border-t border-gray-50">
                        <h4 className="text-sm font-black text-[#1a365d] uppercase tracking-widest mb-6 flex items-center gap-2">
                          <Truck className="w-4 h-4 text-blue-600" /> Routing Constraints
                        </h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                          <div className="p-4 bg-gray-50 rounded-2xl">
                            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Fragile Handling</p>
                            <p className="text-xs font-black text-[#1a365d]">{selectedShipment.routing_constraints.fragile_handling}</p>
                          </div>
                          <div className="p-4 bg-gray-50 rounded-2xl">
                            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Routing Window</p>
                            <p className="text-xs font-black text-[#1a365d]">{selectedShipment.routing_constraints.delivery_window}</p>
                          </div>
                        </div>
                      </div>
                    )}

                    {selectedShipment.routing_decision && (
                      <div className="mt-12 pt-12 border-t border-gray-50">
                        <h4 className="text-sm font-black text-[#1a365d] uppercase tracking-widest mb-6 flex items-center gap-2">
                          <Globe className="w-4 h-4 text-emerald-600" /> Routing Decision
                        </h4>
                        <div className="p-6 bg-emerald-50 rounded-3xl border border-emerald-100">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            <div>
                              <p className="text-[10px] font-bold text-emerald-600/60 uppercase tracking-widest mb-1">Decision Strategy</p>
                              <p className="text-sm font-black text-emerald-900 uppercase tracking-tight">
                                {selectedShipment.routing_decision.strategy || 'OPTIMIZED_FLIGHT_PATH'}
                              </p>
                            </div>
                            <div>
                              <p className="text-[10px] font-bold text-emerald-600/60 uppercase tracking-widest mb-1">Confidence Score</p>
                              <p className="text-sm font-black text-emerald-900 uppercase tracking-tight">
                                {(selectedShipment.routing_decision.confidence * 100).toFixed(1)}%
                              </p>
                            </div>
                          </div>
                          {selectedShipment.routing_decision.reasoning && (
                            <div className="mt-4 pt-4 border-t border-emerald-100">
                              <p className="text-[10px] font-bold text-emerald-600/60 uppercase tracking-widest mb-1">Reasoning</p>
                              <p className="text-xs font-medium text-emerald-800 italic">"{selectedShipment.routing_decision.reasoning}"</p>
                            </div>
                          )}
                        </div>
                      </div>
                    )}

                    {selectedShipment.routing_weights && (
                      <div className="mt-12 pt-12 border-t border-gray-50">
                        <h4 className="text-sm font-black text-[#1a365d] uppercase tracking-widest mb-6 flex items-center gap-2">
                          <Zap className="w-4 h-4 text-amber-500" /> Optimization Weights
                        </h4>
                        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                          <WeightCard label="Time" value={selectedShipment.routing_weights.w_t} color="text-blue-600" bg="bg-blue-50" />
                          <WeightCard label="Risk" value={selectedShipment.routing_weights.w_r} color="text-rose-600" bg="bg-rose-50" />
                          <WeightCard label="Battery" value={selectedShipment.routing_weights.w_b} color="text-emerald-600" bg="bg-emerald-50" />
                          <WeightCard label="Weather" value={selectedShipment.routing_weights.w_w} color="text-amber-600" bg="bg-amber-50" />
                          <WeightCard label="Safety" value={selectedShipment.routing_weights.w_s} color="text-purple-600" bg="bg-purple-50" />
                        </div>
                      </div>
                    )}

                    {selectedShipment.mode_execution && (
                      <div className="mt-12 pt-12 border-t border-gray-50">
                        <h4 className="text-sm font-black text-[#1a365d] uppercase tracking-widest mb-6 flex items-center gap-2">
                          <Activity className="w-4 h-4 text-blue-600" /> Execution Mode
                        </h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                          <div className="p-4 bg-blue-50/50 rounded-2xl border border-blue-100">
                            <p className="text-[10px] font-bold text-blue-600/60 uppercase tracking-widest mb-1">Actual Mode</p>
                            <p className="text-sm font-black text-blue-900 uppercase tracking-tight">
                              {selectedShipment.mode_execution.actual_mode}
                            </p>
                          </div>
                          <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100">
                            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Handoff Point</p>
                            <p className="text-sm font-black text-gray-900 uppercase tracking-tight">
                              {selectedShipment.mode_execution.handoff_point || 'DIRECT DELIVERY'}
                            </p>
                          </div>
                        </div>
                      </div>
                    )}

                    {selectedShipment.mode_rationale && (
                      <div className="mt-12 pt-12 border-t border-gray-50">
                        <h4 className="text-sm font-black text-[#1a365d] uppercase tracking-widest mb-6 flex items-center gap-2">
                          <Info className="w-4 h-4 text-blue-600" /> Mode Rationale
                        </h4>
                        <div className="p-6 bg-blue-50 rounded-3xl border border-blue-100">
                          <p className="text-[10px] font-bold text-blue-600/60 uppercase tracking-widest mb-2">Decision Reason</p>
                          <p className="text-sm font-medium text-blue-900 italic mb-4">"{selectedShipment.mode_rationale.reason}"</p>
                          <div className="grid grid-cols-2 gap-4 pt-4 border-t border-blue-100">
                            <div>
                              <p className="text-[10px] font-bold text-blue-600/60 uppercase tracking-widest mb-1">Alternatives</p>
                              <div className="flex gap-2">
                                {selectedShipment.mode_rationale.alternatives_considered.map(alt => (
                                  <span key={alt} className="px-2 py-0.5 bg-white rounded-lg text-[9px] font-black text-blue-600 border border-blue-100">{alt}</span>
                                ))}
                              </div>
                            </div>
                            <div>
                              <p className="text-[10px] font-bold text-blue-600/60 uppercase tracking-widest mb-1">Final Score</p>
                              <p className="text-xs font-black text-blue-900">{selectedShipment.mode_rationale.final_score}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {selectedShipment.handoff_details && (
                      <div className="mt-12 pt-12 border-t border-gray-50">
                        <h4 className="text-sm font-black text-[#1a365d] uppercase tracking-widest mb-6 flex items-center gap-2">
                          <Navigation className="w-4 h-4 text-purple-600" /> Handoff Details
                        </h4>
                        <div className="p-6 bg-purple-50 rounded-3xl border border-purple-100">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            <div>
                              <p className="text-[10px] font-bold text-purple-600/60 uppercase tracking-widest mb-1">Coordinates</p>
                              <p className="text-sm font-black text-purple-900">
                                {selectedShipment.handoff_details.location.lat.toFixed(4)}, {selectedShipment.handoff_details.location.lon.toFixed(4)}
                              </p>
                            </div>
                            <div>
                              <p className="text-[10px] font-bold text-purple-600/60 uppercase tracking-widest mb-1">Handoff Time</p>
                              <p className="text-sm font-black text-purple-900">
                                {new Date(selectedShipment.handoff_details.timestamp).toLocaleString()}
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {selectedShipment.route_summary && (
                      <div className="mt-12 pt-12 border-t border-gray-50">
                        <h4 className="text-sm font-black text-[#1a365d] uppercase tracking-widest mb-6 flex items-center gap-2">
                          <MapPin className="w-4 h-4 text-emerald-600" /> Route Summary
                        </h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                          <div className="p-4 bg-emerald-50/50 rounded-2xl border border-emerald-100">
                            <p className="text-[10px] font-bold text-emerald-600/60 uppercase tracking-widest mb-1">Total Distance</p>
                            <p className="text-sm font-black text-emerald-900 uppercase tracking-tight">
                              {(selectedShipment.route_summary.distance_m / 1000).toFixed(2)} km
                            </p>
                          </div>
                          <div className="p-4 bg-emerald-50/50 rounded-2xl border border-emerald-100">
                            <p className="text-[10px] font-bold text-emerald-600/60 uppercase tracking-widest mb-1">Estimated Arrival (ETA)</p>
                            <p className="text-sm font-black text-emerald-900 uppercase tracking-tight">
                              {new Date(selectedShipment.route_summary.eta).toLocaleString()}
                            </p>
                          </div>
                        </div>
                      </div>
                    )}

                    {selectedShipment.ground_robot_route && (
                      <div className="mt-12 pt-12 border-t border-gray-50">
                        <h4 className="text-sm font-black text-[#1a365d] uppercase tracking-widest mb-6 flex items-center gap-2">
                          <Truck className="w-4 h-4 text-blue-600" /> Ground Robot Route
                        </h4>
                        <div className="space-y-6">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100">
                              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Robot ID</p>
                              <p className="text-sm font-black text-[#1a365d]">{selectedShipment.ground_robot_route.robot_id}</p>
                            </div>
                            <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100">
                              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Route ID</p>
                              <p className="text-sm font-black text-[#1a365d]">{selectedShipment.ground_robot_route.route_id}</p>
                            </div>
                          </div>

                          <div className="p-6 bg-blue-50/30 rounded-3xl border border-blue-100/50">
                            <h5 className="text-[10px] font-black text-blue-600 uppercase tracking-widest mb-4">Waypoints ({selectedShipment.ground_robot_route.waypoints.length})</h5>
                            <div className="space-y-3">
                              {selectedShipment.ground_robot_route.waypoints.map((wp: any) => (
                                <div key={wp.seq} className="flex items-center gap-4 p-3 bg-white rounded-xl border border-blue-100/50 shadow-sm">
                                  <div className="w-6 h-6 bg-blue-600 text-white rounded-lg flex items-center justify-center text-[10px] font-black">
                                    {wp.seq}
                                  </div>
                                  <div className="flex-1">
                                    <div className="flex justify-between items-center">
                                      <p className="text-[10px] font-black text-[#1a365d] uppercase tracking-widest">{wp.type}</p>
                                      <p className="text-[9px] font-bold text-gray-400">{wp.lat.toFixed(5)}, {wp.lon.toFixed(5)}</p>
                                    </div>
                                    {wp.constraints && (
                                      <div className="flex gap-2 mt-1">
                                        {Object.entries(wp.constraints).map(([key, val]: [string, any]) => (
                                          <span key={key} className="text-[8px] font-bold text-blue-500 bg-blue-50 px-1.5 py-0.5 rounded uppercase">
                                            {key.replace(/_/g, ' ')}: {val.toString()}
                                          </span>
                                        ))}
                                      </div>
                                    )}
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>

                          {selectedShipment.ground_robot_route.constraints && (
                            <div className="p-4 bg-amber-50/30 rounded-2xl border border-amber-100/50">
                              <p className="text-[10px] font-black text-amber-600 uppercase tracking-widest mb-2">Route Constraints</p>
                              <div className="flex flex-wrap gap-4">
                                <div>
                                  <p className="text-[9px] font-bold text-gray-400 uppercase tracking-widest">Max Slope</p>
                                  <p className="text-xs font-black text-amber-900">{selectedShipment.ground_robot_route.constraints.max_slope_pct}%</p>
                                </div>
                                {selectedShipment.ground_robot_route.constraints.avoid_zones?.length > 0 && (
                                  <div>
                                    <p className="text-[9px] font-bold text-gray-400 uppercase tracking-widest">Avoid Zones</p>
                                    <p className="text-xs font-black text-amber-900">{selectedShipment.ground_robot_route.constraints.avoid_zones.length} Detected</p>
                                  </div>
                                )}
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    )}

                    {selectedShipment.summary && (
                      <div className="mt-12 pt-12 border-t border-gray-50">
                        <h4 className="text-sm font-black text-[#1a365d] uppercase tracking-widest mb-6 flex items-center gap-2">
                          <Zap className="w-4 h-4 text-amber-500" /> Flight Summary
                        </h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                          <div className="space-y-4">
                            <div className="flex justify-between items-center p-4 bg-gray-50 rounded-2xl">
                              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Battery Usage</span>
                              <span className="text-xs font-black text-[#1a365d]">
                                {selectedShipment.summary.battery_summary ? 
                                  `${selectedShipment.summary.battery_summary.start_soc_pct}% → ${selectedShipment.summary.battery_summary.end_soc_pct}%` : 
                                  'N/A'}
                              </span>
                            </div>
                            <div className="flex justify-between items-center p-4 bg-gray-50 rounded-2xl">
                              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Weather Conditions</span>
                              <span className="text-xs font-black text-[#1a365d]">
                                {selectedShipment.summary.weather ? 
                                  `${selectedShipment.summary.weather.avg_wind_speed_kts} kts wind, ${selectedShipment.summary.weather.condition}` : 
                                  'N/A'}
                              </span>
                            </div>
                          </div>
                          <div className="space-y-4">
                            <div className="flex justify-between items-center p-4 bg-gray-50 rounded-2xl">
                              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Safety Events</span>
                              <span className={`text-xs font-black ${selectedShipment.summary.safety_summary?.events?.length > 0 ? 'text-amber-600' : 'text-emerald-600'}`}>
                                {selectedShipment.summary.safety_summary?.events?.length || 0} Events
                              </span>
                            </div>
                            <div className="flex justify-between items-center p-4 bg-gray-50 rounded-2xl">
                              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Flight Distance</span>
                              <span className="text-xs font-black text-[#1a365d]">
                                {selectedShipment.summary.flight_path?.total_distance_km?.toFixed(2) || 'N/A'} km
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                <div className="space-y-8">
                  <div className="bg-[#1a365d] p-8 rounded-[40px] text-white shadow-xl">
                    <h3 className="text-sm font-black uppercase tracking-widest mb-6 flex items-center gap-2">
                      <Info className="w-4 h-4 text-blue-400" /> Shipment Actions
                    </h3>
                    <div className="space-y-3">
                      <button 
                        onClick={() => onTrack(selectedShipment.id)}
                        className="w-full py-4 bg-blue-600 hover:bg-blue-700 rounded-2xl text-xs font-black uppercase tracking-widest transition-all shadow-lg flex items-center justify-center gap-2"
                      >
                        <ArrowUpRight className="w-4 h-4" /> Global Tracking View
                      </button>
                      <button 
                        onClick={() => setView('customs')}
                        className="w-full py-4 bg-white/10 hover:bg-white/20 rounded-2xl text-xs font-black uppercase tracking-widest transition-all border border-white/10 flex items-center justify-center gap-2"
                      >
                        <Globe className="w-4 h-4 text-blue-400" /> Customs Declaration
                      </button>
                      <button 
                        onClick={() => setView('safety')}
                        className="w-full py-4 bg-white/10 hover:bg-white/20 rounded-2xl text-xs font-black uppercase tracking-widest transition-all border border-white/10 flex items-center justify-center gap-2"
                      >
                        <ShieldCheck className="w-4 h-4 text-emerald-400" /> Safety Log
                      </button>
                      <button className="w-full py-4 bg-white/10 hover:bg-white/20 rounded-2xl text-xs font-black uppercase tracking-widest transition-all border border-white/10">
                        Download Invoice
                      </button>
                      <button className="w-full py-4 bg-white/10 hover:bg-white/20 rounded-2xl text-xs font-black uppercase tracking-widest transition-all border border-white/10">
                        Contact Support
                      </button>
                      <button 
                        onClick={handleModifyDelivery}
                        className="w-full py-4 bg-white/10 hover:bg-white/20 rounded-2xl text-xs font-black uppercase tracking-widest transition-all border border-white/10"
                      >
                        Modify Delivery
                      </button>
                    </div>
                  </div>

                  <div className="bg-white p-8 rounded-[40px] shadow-xl border border-gray-100">
                    <h3 className="text-sm font-black text-[#1a365d] uppercase tracking-widest mb-6">Courier Info</h3>
                    {selectedShipment.courierId ? (
                      <div className="space-y-6">
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600 font-black">
                            {selectedShipment.courierId.slice(-2).toUpperCase()}
                          </div>
                          <div>
                            <p className="text-sm font-black text-[#1a365d]">UAPS Courier</p>
                            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">ID: {selectedShipment.courierId}</p>
                          </div>
                        </div>
                        <div className="pt-6 border-t border-gray-50 space-y-4">
                          <div className="flex justify-between items-center">
                            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Vehicle</span>
                            <span className="text-xs font-bold text-[#1a365d]">Motorbike</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Rating</span>
                            <span className="text-xs font-bold text-[#1a365d]">4.9 / 5.0</span>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <p className="text-xs text-gray-400 font-medium italic">No courier assigned yet.</p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {view === 'customs' && (
            <div className="space-y-8">
              <button 
                onClick={() => setView('details')}
                className="flex items-center gap-2 text-xs font-black text-blue-600 hover:text-blue-700 transition-colors uppercase tracking-widest"
              >
                <ArrowLeft className="w-4 h-4" /> Back to Shipment Details
              </button>
              <CustomsClearanceForm 
                shipmentId={selectedShipment?.id} 
                onCancel={() => setView('details')}
                onComplete={() => {
                  // In a real app, we'd update the shipment status or metadata
                  setTimeout(() => setView('details'), 3000);
                }}
              />
            </div>
          )}

          {view === 'safety' && (
            <div className="space-y-8">
              <button 
                onClick={() => setView('details')}
                className="flex items-center gap-2 text-xs font-black text-blue-600 hover:text-blue-700 transition-colors uppercase tracking-widest"
              >
                <ArrowLeft className="w-4 h-4" /> Back to Shipment Details
              </button>
              
              <div className="max-w-3xl mx-auto space-y-8">
                <div className="bg-white p-10 rounded-[40px] shadow-2xl border border-gray-100">
                  <div className="flex items-center gap-4 mb-8">
                    <div className="w-12 h-12 bg-emerald-50 rounded-2xl flex items-center justify-center text-emerald-600">
                      <ShieldCheck className="w-6 h-6" />
                    </div>
                    <div>
                      <h2 className="text-2xl font-black text-[#1a365d] uppercase tracking-tight">Safety & Compliance Log</h2>
                      <p className="text-xs text-gray-400 font-bold uppercase tracking-widest">Real-time safety events for shipment {selectedShipment?.id}</p>
                    </div>
                  </div>

                  <div className="space-y-6">
                    {(() => {
                      const dynamicEvents = selectedShipment?.summary?.safety_summary?.events || [];
                      const displayEvents = dynamicEvents.length > 0 ? dynamicEvents : safetyEventsData;
                      
                      return displayEvents.map((event: any, index: number) => {
                        const eventId = event.event_id || event.risk_id || event.security_event?.event_id || event.incident_id || event.packet_id || (event.event === 'DELIVERY_SECURITY_FAILURE' ? `fail-${event.delivery_id}` : null) || Math.random().toString(36).substr(2, 9);
                        const uniqueKey = `${eventId}-${index}`;
                        if (event.event_type === 'security' || event.type === 'SECURITY_INCIDENT' || event.type === 'SECURITY' || event.event === 'DELIVERY_SECURITY_FAILURE') {
                          return <SecurityEventCard key={uniqueKey} event={event} />;
                        }
                        if (event.event_type === 'telemetry_anomaly') {
                          return <TelemetryAnomalyCard key={uniqueKey} event={event} />;
                        }
                        if (event.event_type === 'model_drift') {
                          return <ModelDriftCard key={uniqueKey} event={event} />;
                        }
                        if (event.event_type === 'model_rollback') {
                          return <ModelRollbackCard key={uniqueKey} event={event} />;
                        }
                        if (event.event_type === 'model_rollback_result') {
                          return <ModelRollbackResultCard key={uniqueKey} event={event} />;
                        }
                        if (event.type === 'MODEL_DRIFT_ROLLBACK' && !event.governance_event_id) {
                          return <ModelDriftRollbackCard key={uniqueKey} event={event} />;
                        }
                        if (event.governance_event_id) {
                          return <ModelGovernanceCard key={uniqueKey} event={event} />;
                        }
                        if (event.event_type === 'model_recovery_summary') {
                          return <ModelRecoverySummaryCard key={uniqueKey} event={event} />;
                        }
                        if (event.risk_id || event.event_type === 'risk_assessment') {
                          return <RiskAssessmentCard key={uniqueKey} event={event} />;
                        }
                        if (event.event_type === 'model_card') {
                          return <ModelCard key={uniqueKey} event={event} />;
                        }
                        return <SafetyEventCard key={uniqueKey} event={event} />;
                      });
                    })()}
                    
                    {(!selectedShipment?.summary?.safety_summary?.events?.length && safetyEventsData.length === 0) && (
                      <div className="text-center py-20 bg-gray-50 rounded-[40px] border border-dashed border-gray-200">
                        <Shield className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                        <p className="text-sm font-bold text-gray-400 uppercase tracking-widest">No safety events recorded for this flight.</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {view === 'dashboard' && (
            <div className="space-y-8">
              {/* Stats Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
                  <div className="w-12 h-12 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600 mb-4">
                    <Package className="w-6 h-6" />
                  </div>
                  <p className="text-3xl font-black text-[#1a365d]">{stats.total}</p>
                  <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Total Shipments</p>
                </div>
                <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
                  <div className="w-12 h-12 bg-amber-50 rounded-2xl flex items-center justify-center text-amber-600 mb-4">
                    <Truck className="w-6 h-6" />
                  </div>
                  <p className="text-3xl font-black text-[#1a365d]">{stats.active}</p>
                  <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Active Shipments</p>
                </div>
                <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
                  <div className="w-12 h-12 bg-emerald-50 rounded-2xl flex items-center justify-center text-emerald-600 mb-4">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <p className="text-3xl font-black text-[#1a365d]">{stats.delivered}</p>
                  <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Delivered</p>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Recent Activity */}
                <div className="lg:col-span-2 space-y-6">
                  <div className="flex justify-between items-center">
                    <h2 className="text-lg font-black text-[#1a365d] uppercase tracking-tight">Recent Activity</h2>
                    <button onClick={() => setView('shipments')} className="text-xs font-bold text-blue-600 hover:underline">View All</button>
                  </div>
                  <div className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
                    {loading ? (
                      <div className="p-12 flex justify-center">
                        <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
                      </div>
                    ) : (
                      <div className="divide-y divide-gray-50">
                        {shipments.map(shipment => (
                          <div 
                            key={shipment.id} 
                            className="p-6 hover:bg-gray-50 transition-colors group cursor-pointer"
                            onClick={() => {
                              setSelectedShipment(shipment);
                              setView('details');
                            }}
                          >
                            <div className="flex justify-between items-start mb-4">
                              <div className="flex items-center gap-4">
                                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${shipment.status === 'DELIVERED' ? 'bg-emerald-50 text-emerald-600' : 'bg-blue-50 text-blue-600'}`}>
                                  <Package className="w-5 h-5" />
                                </div>
                                <div>
                                  <p className="text-sm font-black text-[#1a365d]">{shipment.id}</p>
                                  <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{shipment.type} Shipment</p>
                                </div>
                              </div>
                              <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${
                                shipment.status === 'DELIVERED' ? 'bg-emerald-100 text-emerald-700' : 
                                shipment.status === 'FAILED_SECURITY_EVENT' ? 'bg-red-100 text-red-700' :
                                'bg-blue-100 text-blue-700'
                              }`}>
                                {shipment.status.replace('_', ' ')}
                              </span>
                            </div>
                            <div className="grid grid-cols-2 gap-4 mb-4">
                              <div>
                                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">From</p>
                                <p className="text-xs font-bold text-[#1a365d]">{shipment.origin}</p>
                              </div>
                              <div>
                                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">To</p>
                                <p className="text-xs font-bold text-[#1a365d]">{shipment.destination}</p>
                              </div>
                            </div>
                            <div className="flex justify-between items-center pt-4 border-t border-gray-50">
                              <div className="flex items-center gap-2 text-[10px] font-bold text-gray-400">
                                <Calendar className="w-3 h-3" /> {shipment.date}
                              </div>
                              <button 
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onTrack(shipment.id);
                                }}
                                className="flex items-center gap-1 text-xs font-black text-blue-600 group-hover:translate-x-1 transition-transform"
                              >
                                Track Now <ChevronRight className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* Quick Actions & Profile Summary */}
                <div className="space-y-8">
                  <div className="bg-[#1a365d] p-8 rounded-3xl text-white shadow-xl relative overflow-hidden">
                    <div className="absolute -right-8 -bottom-8 w-32 h-32 bg-white/10 rounded-full blur-2xl" />
                    <h3 className="text-lg font-black uppercase tracking-tight mb-4">Need to send something?</h3>
                    <p className="text-sm text-blue-100/60 mb-8 font-medium">Create a new shipment request in seconds and track it in real-time.</p>
                    <button 
                      onClick={() => setView('new')}
                      className="w-full bg-white text-[#1a365d] py-4 rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-blue-50 transition-all flex items-center justify-center gap-2"
                    >
                      <Plus className="w-5 h-5" /> New Shipment
                    </button>
                  </div>

                  <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
                    <h3 className="text-sm font-black text-[#1a365d] uppercase tracking-widest mb-6">Saved Addresses</h3>
                    <div className="space-y-4">
                      {[
                        { label: 'Home', address: 'Asmara, ER', icon: MapPin },
                        { label: 'Office', address: 'Massawa Port, ER', icon: Truck }
                      ].map((addr, i) => (
                        <div key={i} className="flex items-center gap-4 p-3 rounded-2xl hover:bg-gray-50 transition-colors cursor-pointer">
                          <div className="w-10 h-10 bg-gray-50 rounded-xl flex items-center justify-center text-gray-400">
                            <addr.icon className="w-5 h-5" />
                          </div>
                          <div>
                            <p className="text-xs font-black text-[#1a365d]">{addr.label}</p>
                            <p className="text-[10px] font-bold text-gray-400">{addr.address}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {view === 'shipments' && (
            <div className="space-y-6">
              <div className="flex flex-col md:flex-row justify-between items-center gap-4">
                <div className="relative w-full md:w-96">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input 
                    type="text" 
                    placeholder="Search by ID or destination..."
                    className="w-full pl-12 pr-4 py-3 bg-white border border-gray-200 rounded-2xl text-sm focus:ring-2 focus:ring-blue-600 outline-none transition-all"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={() => {
                      setLoading(true);
                      fetchShipments();
                    }}
                    className="px-4 py-2 bg-blue-600 text-white rounded-xl text-xs font-bold hover:bg-blue-700 transition-all flex items-center gap-2"
                  >
                    <History className="w-4 h-4" /> Refresh
                  </button>
                  <button className="px-4 py-2 bg-white border border-gray-200 rounded-xl text-xs font-bold text-gray-600 hover:bg-gray-50 transition-all">All</button>
                  <button className="px-4 py-2 bg-white border border-gray-200 rounded-xl text-xs font-bold text-gray-600 hover:bg-gray-50 transition-all">Active</button>
                  <button className="px-4 py-2 bg-white border border-gray-200 rounded-xl text-xs font-bold text-gray-600 hover:bg-gray-50 transition-all">Delivered</button>
                </div>
              </div>

              <div className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
                <table className="w-full text-left">
                  <thead>
                    <tr className="bg-gray-50 text-[10px] uppercase tracking-widest text-gray-400 font-bold">
                      <th className="px-8 py-4">Shipment ID</th>
                      <th className="px-8 py-4">Destination</th>
                      <th className="px-8 py-4">Date</th>
                      <th className="px-8 py-4">Status</th>
                      <th className="px-8 py-4 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    {filteredShipments.map(shipment => (
                      <tr 
                        key={shipment.id} 
                        className="hover:bg-gray-50 transition-colors cursor-pointer"
                        onClick={() => {
                          setSelectedShipment(shipment);
                          setView('details');
                        }}
                      >
                        <td className="px-8 py-6">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 bg-blue-50 rounded-lg flex items-center justify-center text-blue-600">
                              <Package className="w-4 h-4" />
                            </div>
                            <span className="text-sm font-black text-[#1a365d]">{shipment.id}</span>
                          </div>
                        </td>
                        <td className="px-8 py-6">
                          <p className="text-sm font-bold text-[#1a365d]">{shipment.destination}</p>
                          <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">To: {shipment.origin}</p>
                        </td>
                        <td className="px-8 py-6">
                          <span className="text-xs font-bold text-gray-500">{shipment.date}</span>
                        </td>
                        <td className="px-8 py-6">
                          <div className="flex items-center gap-2">
                            <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${
                              shipment.status === 'DELIVERED' ? 'bg-emerald-100 text-emerald-700' : 'bg-blue-100 text-blue-700'
                            }`}>
                              {shipment.status.replace('_', ' ')}
                            </span>
                            {shipment.status === 'DELIVERED' && (
                              <ShieldCheck className="w-4 h-4 text-emerald-500" />
                            )}
                          </div>
                        </td>
                        <td className="px-8 py-6 text-right">
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              onTrack(shipment.id);
                            }}
                            className="p-2 hover:bg-blue-50 rounded-xl text-blue-600 transition-colors"
                          >
                            <ArrowUpRight className="w-5 h-5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {view === 'new' && (
            <div className="max-w-4xl mx-auto">
              <div className="bg-white rounded-[40px] shadow-2xl border border-gray-100 overflow-hidden">
                <div className="bg-[#1a365d] p-12 text-white relative overflow-hidden">
                  <div className="absolute right-0 top-0 w-64 h-64 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl" />
                  <h2 className="text-3xl font-black uppercase tracking-tight mb-4">Ship with UAPS</h2>
                  <p className="text-blue-100/60 font-medium max-w-md">Enter the details of your shipment and we'll handle the rest with our global logistics network.</p>
                </div>
                
                <form onSubmit={handleCreateShipment} className="p-12 space-y-10">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                    <div className="space-y-6">
                      <h3 className="text-sm font-black text-[#1a365d] uppercase tracking-widest flex items-center gap-2">
                        <div className="w-6 h-6 bg-blue-50 rounded-lg flex items-center justify-center text-blue-600">
                          <MapPin className="w-3.5 h-3.5" />
                        </div>
                        Pickup Details
                      </h3>
                      <div className="space-y-4">
                        <div>
                          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 block">Pickup Address</label>
                          <input 
                            type="text" 
                            required
                            className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-2xl text-sm focus:ring-2 focus:ring-blue-600 outline-none transition-all" 
                            placeholder="Street address..." 
                            value={formData.pickupAddress}
                            onChange={(e) => setFormData({ ...formData, pickupAddress: e.target.value })}
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 block">City</label>
                            <input 
                              type="text" 
                              required
                              className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-2xl text-sm focus:ring-2 focus:ring-blue-600 outline-none transition-all" 
                              placeholder="City..." 
                              value={formData.pickupCity}
                              onChange={(e) => setFormData({ ...formData, pickupCity: e.target.value })}
                            />
                          </div>
                          <div>
                            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 block">Country</label>
                            <select 
                              className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-2xl text-sm focus:ring-2 focus:ring-blue-600 outline-none transition-all appearance-none"
                              value={formData.pickupCountry}
                              onChange={(e) => setFormData({ ...formData, pickupCountry: e.target.value })}
                            >
                              {AFRICAN_COUNTRIES.map(country => (
                                <option key={country} value={country}>{country}</option>
                              ))}
                            </select>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 block">Sender Name</label>
                            <input 
                              type="text" 
                              required
                              className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-2xl text-sm focus:ring-2 focus:ring-blue-600 outline-none transition-all" 
                              placeholder="Full Name" 
                              value={formData.senderName}
                              onChange={(e) => setFormData({ ...formData, senderName: e.target.value })}
                            />
                          </div>
                          <div>
                            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 block">Sender Phone</label>
                            <input 
                              type="tel" 
                              required
                              className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-2xl text-sm focus:ring-2 focus:ring-blue-600 outline-none transition-all" 
                              placeholder="+291 ..." 
                              value={formData.senderPhone}
                              onChange={(e) => setFormData({ ...formData, senderPhone: e.target.value })}
                            />
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-6">
                      <h3 className="text-sm font-black text-[#1a365d] uppercase tracking-widest flex items-center gap-2">
                        <div className="w-6 h-6 bg-emerald-50 rounded-lg flex items-center justify-center text-emerald-600">
                          <Truck className="w-3.5 h-3.5" />
                        </div>
                        Delivery Details
                      </h3>
                      <div className="space-y-4">
                        <div>
                          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 block">Dropoff Address</label>
                          <input 
                            type="text" 
                            required
                            className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-2xl text-sm focus:ring-2 focus:ring-blue-600 outline-none transition-all" 
                            placeholder="Street address..." 
                            value={formData.dropoffAddress}
                            onChange={(e) => setFormData({ ...formData, dropoffAddress: e.target.value })}
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 block">City</label>
                            <input 
                              type="text" 
                              required
                              className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-2xl text-sm focus:ring-2 focus:ring-blue-600 outline-none transition-all" 
                              placeholder="City..." 
                              value={formData.dropoffCity}
                              onChange={(e) => setFormData({ ...formData, dropoffCity: e.target.value })}
                            />
                          </div>
                          <div>
                            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 block">Country</label>
                            <select 
                              className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-2xl text-sm focus:ring-2 focus:ring-blue-600 outline-none transition-all appearance-none"
                              value={formData.dropoffCountry}
                              onChange={(e) => setFormData({ ...formData, dropoffCountry: e.target.value })}
                            >
                              {AFRICAN_COUNTRIES.map(country => (
                                <option key={country} value={country}>{country}</option>
                              ))}
                            </select>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 block">Receiver Name</label>
                            <input 
                              type="text" 
                              required
                              className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-2xl text-sm focus:ring-2 focus:ring-blue-600 outline-none transition-all" 
                              placeholder="Full Name" 
                              value={formData.receiverName}
                              onChange={(e) => setFormData({ ...formData, receiverName: e.target.value })}
                            />
                          </div>
                          <div>
                            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 block">Receiver Phone</label>
                            <input 
                              type="tel" 
                              required
                              className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-2xl text-sm focus:ring-2 focus:ring-blue-600 outline-none transition-all" 
                              placeholder="+254 ..." 
                              value={formData.receiverPhone}
                              onChange={(e) => setFormData({ ...formData, receiverPhone: e.target.value })}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-6">
                    <h3 className="text-sm font-black text-[#1a365d] uppercase tracking-widest flex items-center gap-2">
                      <div className="w-6 h-6 bg-purple-50 rounded-lg flex items-center justify-center text-purple-600">
                        <Package className="w-3.5 h-3.5" />
                      </div>
                      Package Info
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div>
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 block">Dimensions (L x W x H cm)</label>
                        <input 
                          type="text" 
                          className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-2xl text-sm focus:ring-2 focus:ring-blue-600 outline-none transition-all" 
                          placeholder="e.g. 30x20x15"
                          value={formData.dimensions}
                          onChange={(e) => setFormData({ ...formData, dimensions: e.target.value })}
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 block">Weight (kg)</label>
                        <input 
                          type="number" 
                          className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-2xl text-sm focus:ring-2 focus:ring-blue-600 outline-none transition-all" 
                          value={formData.weight}
                          onChange={(e) => setFormData({ ...formData, weight: e.target.value })}
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 block">Service Type</label>
                        <select 
                          className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-2xl text-sm focus:ring-2 focus:ring-blue-600 outline-none transition-all appearance-none"
                          value={formData.type}
                          onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                        >
                          <option>Express (1-2 days)</option>
                          <option>Standard (3-5 days)</option>
                          <option>Economy (7+ days)</option>
                        </select>
                      </div>
                      <div>
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 block">Insurance</label>
                        <div className="flex items-center h-[46px] px-4 bg-gray-50 border border-gray-100 rounded-2xl">
                          <input type="checkbox" className="w-4 h-4 text-blue-600 rounded focus:ring-blue-600" />
                          <span className="ml-2 text-xs font-bold text-gray-600">Add Insurance</span>
                        </div>
                      </div>
                    </div>

                    <div className="pt-6 border-t border-gray-100">
                      <h3 className="text-sm font-black text-[#1a365d] uppercase tracking-widest flex items-center gap-2 mb-6">
                        <div className="w-6 h-6 bg-blue-50 rounded-lg flex items-center justify-center text-blue-600">
                          <Settings className="w-3.5 h-3.5" />
                        </div>
                        Advanced Shipment Options
                      </h3>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div>
                          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 block">Delivery Mode</label>
                          <select 
                            className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-2xl text-sm focus:ring-2 focus:ring-blue-600 outline-none transition-all appearance-none font-bold text-[#1a365d]"
                            value={formData.deliveryMode}
                            onChange={(e) => setFormData({ ...formData, deliveryMode: e.target.value })}
                          >
                            <option value="AIR_DRONE">AIR DRONE</option>
                            <option value="GROUND_ROBOT">GROUND ROBOT</option>
                            <option value="HYBRID">HYBRID</option>
                          </select>
                        </div>

                        <div>
                          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 block">Delivery Speed</label>
                          <select 
                            className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-2xl text-sm focus:ring-2 focus:ring-blue-600 outline-none transition-all appearance-none font-bold text-[#1a365d]"
                            value={formData.speed}
                            onChange={(e) => setFormData({ ...formData, speed: e.target.value })}
                          >
                            <option value="STANDARD">STANDARD</option>
                            <option value="PRIORITY">PRIORITY</option>
                            <option value="EXPRESS">EXPRESS</option>
                          </select>
                        </div>

                        <div>
                          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 block">Dropoff Mode</label>
                          <select 
                            className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-2xl text-sm focus:ring-2 focus:ring-blue-600 outline-none transition-all appearance-none font-bold text-[#1a365d]"
                            value={formData.dropoffMode}
                            onChange={(e) => setFormData({ ...formData, dropoffMode: e.target.value })}
                          >
                            <option value="DOORSTEP">DOORSTEP</option>
                            <option value="BACKYARD">BACKYARD</option>
                            <option value="SECURE_BOX">SECURE_BOX</option>
                            <option value="ROOFTOP_PAD">ROOFTOP_PAD</option>
                          </select>
                        </div>

                        <div>
                          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 block">SLA Tier</label>
                          <select 
                            className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-2xl text-sm focus:ring-2 focus:ring-blue-600 outline-none transition-all appearance-none font-bold text-[#1a365d]"
                            value={formData.slaTier}
                            onChange={(e) => setFormData({ ...formData, slaTier: e.target.value })}
                          >
                            <option value="BRONZE">BRONZE</option>
                            <option value="SILVER">SILVER</option>
                            <option value="GOLD">GOLD</option>
                          </select>
                        </div>

                        <div>
                          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 block">Delivery Window Start</label>
                          <input 
                            type="datetime-local" 
                            className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-2xl text-sm focus:ring-2 focus:ring-blue-600 outline-none transition-all font-bold text-[#1a365d]"
                            value={formData.deliveryWindowStart}
                            onChange={(e) => setFormData({ ...formData, deliveryWindowStart: e.target.value })}
                          />
                        </div>

                        <div>
                          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 block">Delivery Window End</label>
                          <input 
                            type="datetime-local" 
                            className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-2xl text-sm focus:ring-2 focus:ring-blue-600 outline-none transition-all font-bold text-[#1a365d]"
                            value={formData.deliveryWindowEnd}
                            onChange={(e) => setFormData({ ...formData, deliveryWindowEnd: e.target.value })}
                          />
                        </div>

                        <div>
                          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 block">Privacy Mode</label>
                          <select 
                            className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-2xl text-sm focus:ring-2 focus:ring-blue-600 outline-none transition-all appearance-none font-bold text-[#1a365d]"
                            value={formData.privacyMode}
                            onChange={(e) => setFormData({ ...formData, privacyMode: e.target.value })}
                          >
                            <option value="NORMAL">NORMAL</option>
                            <option value="REDUCED">REDUCED (Minimal Data)</option>
                          </select>
                        </div>

                        <div className="md:col-span-3">
                          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-3 block">Special Handling</label>
                          <div className="flex flex-wrap gap-3">
                            {['FRAGILE', 'MEDICAL', 'TEMPERATURE_SENSITIVE'].map(type => (
                              <button
                                key={type}
                                type="button"
                                onClick={() => {
                                  const newHandling = formData.handling.includes(type)
                                    ? formData.handling.filter(h => h !== type)
                                    : [...formData.handling, type];
                                  setFormData({ ...formData, handling: newHandling });
                                }}
                                className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all border ${
                                  formData.handling.includes(type)
                                    ? 'bg-blue-600 text-white border-blue-600 shadow-lg shadow-blue-600/20'
                                    : 'bg-white text-gray-400 border-gray-100 hover:border-blue-200'
                                }`}
                              >
                                {type.replace('_', ' ')}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="pt-10 flex justify-end gap-4">
                    <button type="button" onClick={() => setView('dashboard')} className="px-8 py-4 rounded-2xl text-sm font-black uppercase tracking-widest text-gray-400 hover:bg-gray-50 transition-all">Cancel</button>
                    <button type="submit" className="px-12 py-4 bg-[#1a365d] text-white rounded-2xl text-sm font-black uppercase tracking-widest hover:bg-blue-900 transition-all shadow-xl shadow-blue-900/20">Create Shipment</button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {view === 'profile' && (
            <div className="max-w-4xl mx-auto space-y-8">
              <div className="bg-white p-12 rounded-[40px] shadow-xl border border-gray-100 flex flex-col md:flex-row items-center gap-12">
                <div className="w-32 h-32 bg-blue-50 rounded-[40px] flex items-center justify-center text-blue-600 text-4xl font-black shadow-inner">
                  AA
                </div>
                <div className="flex-1 text-center md:text-left">
                  <h2 className="text-3xl font-black text-[#1a365d] mb-2">Aaron Abraha</h2>
                  <p className="text-gray-400 font-bold uppercase tracking-[0.2em] text-xs mb-6">Premium Member since 2023</p>
                  <div className="flex flex-wrap justify-center md:justify-start gap-4">
                    <div className="flex items-center gap-2 px-4 py-2 bg-gray-50 rounded-xl border border-gray-100 text-[10px] font-bold text-gray-600">
                      <ShieldCheck className="w-4 h-4 text-emerald-500" /> Verified Account
                    </div>
                    <div className="flex items-center gap-2 px-4 py-2 bg-gray-50 rounded-xl border border-gray-100 text-[10px] font-bold text-gray-600">
                      <CreditCard className="w-4 h-4 text-blue-500" /> Default Card: **** 4242
                    </div>
                  </div>
                </div>
                <button className="px-8 py-4 bg-gray-50 text-[#1a365d] rounded-2xl text-xs font-black uppercase tracking-widest hover:bg-gray-100 transition-all border border-gray-100">Edit Profile</button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="bg-white p-10 rounded-[40px] shadow-xl border border-gray-100">
                  <h3 className="text-sm font-black text-[#1a365d] uppercase tracking-widest mb-8 flex items-center gap-3">
                    <div className="w-8 h-8 bg-blue-50 rounded-xl flex items-center justify-center text-blue-600">
                      <Settings className="w-4 h-4" />
                    </div>
                    Account Settings
                  </h3>
                  <div className="space-y-4">
                    {[
                      { label: 'Email Notifications', status: 'Enabled' },
                      { label: 'SMS Alerts', status: 'Enabled' },
                      { label: 'Two-Factor Auth', status: 'Disabled' },
                      { label: 'Marketing Emails', status: 'Disabled' }
                    ].map((setting, i) => (
                      <div key={i} className="flex justify-between items-center p-4 rounded-2xl hover:bg-gray-50 transition-colors">
                        <span className="text-xs font-bold text-gray-600">{setting.label}</span>
                        <span className={`text-[10px] font-black uppercase tracking-widest ${setting.status === 'Enabled' ? 'text-emerald-600' : 'text-gray-400'}`}>{setting.status}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-white p-10 rounded-[40px] shadow-xl border border-gray-100">
                  <h3 className="text-sm font-black text-[#1a365d] uppercase tracking-widest mb-8 flex items-center gap-3">
                    <div className="w-8 h-8 bg-amber-50 rounded-xl flex items-center justify-center text-amber-600">
                      <History className="w-4 h-4" />
                    </div>
                    Recent Payments
                  </h3>
                  <div className="space-y-4">
                    {[
                      { id: '#INV-9281', amount: '$45.00', date: 'Mar 05, 2024' },
                      { id: '#INV-8827', amount: '$120.50', date: 'Feb 28, 2024' },
                      { id: '#INV-7712', amount: '$32.00', date: 'Feb 15, 2024' }
                    ].map((inv, i) => (
                      <div key={i} className="flex justify-between items-center p-4 rounded-2xl hover:bg-gray-50 transition-colors">
                        <div>
                          <p className="text-xs font-black text-[#1a365d]">{inv.id}</p>
                          <p className="text-[10px] font-bold text-gray-400">{inv.date}</p>
                        </div>
                        <span className="text-xs font-black text-[#1a365d]">{inv.amount}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

function WeightCard({ label, value, color, bg }: any) {
  return (
    <div className={`p-4 ${bg} rounded-2xl border border-gray-100`}>
      <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">{label}</p>
      <p className={`text-sm font-black ${color}`}>{value.toFixed(1)}</p>
    </div>
  );
}
