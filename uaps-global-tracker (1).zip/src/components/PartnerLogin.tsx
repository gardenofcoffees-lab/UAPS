import React, { useState } from 'react';
import { Logo } from './Logo';
import { motion } from 'motion/react';
import { LogIn, Shield, Lock, Mail, ChevronRight, Globe, Activity, Database, ArrowLeft, CheckCircle2, Building2, Truck, FileText } from 'lucide-react';

interface PartnerLoginProps {
  onLogin: (success: boolean) => void;
}

export function PartnerLogin({ onLogin }: PartnerLoginProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [view, setView] = useState<'login' | 'apply'>('login');
  const [applyStatus, setApplyStatus] = useState<'idle' | 'submitting' | 'success'>('idle');
  const [applyForm, setApplyForm] = useState({
    companyName: '',
    operatingCountries: '',
    contactEmail: ''
  });

  const handleApplySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setApplyStatus('submitting');
    try {
      const res = await fetch('/api/partner-applications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(applyForm)
      });
      if (res.ok) {
        setApplyStatus('success');
      } else {
        setApplyStatus('idle');
      }
    } catch (err) {
      console.error(err);
      setApplyStatus('idle');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    // Simulated authentication
    setTimeout(() => {
      if (email === 'partner@uaps.africa' && password === 'partner2024') {
        onLogin(true);
      } else {
        setError('Invalid credentials. Please use partner@uaps.africa / partner2024 for demo access.');
        setIsLoading(false);
      }
    }, 1500);
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center p-6 bg-gray-50">
      <div className="max-w-5xl w-full grid grid-cols-1 lg:grid-cols-2 bg-white rounded-[40px] shadow-2xl overflow-hidden border border-gray-100">
        {/* Left Side: Branding & Info */}
        <div className="bg-[#1a365d] p-12 text-white relative overflow-hidden hidden lg:flex flex-col justify-between">
          <div className="absolute top-0 right-0 w-full h-full opacity-10 pointer-events-none">
            <svg viewBox="0 0 800 800" className="w-full h-full">
              <pattern id="grid-login" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" strokeWidth="0.5" />
              </pattern>
              <rect width="100%" height="100%" fill="url(#grid-login)" />
            </svg>
          </div>

          <div className="relative z-10">
            <div className="mb-12">
              <Logo variant="light" size="md" />
              <p className="text-[8px] font-bold uppercase tracking-[0.3em] text-[#c5a059] mt-2 ml-1">Partner Gateway</p>
            </div>

            <h2 className="text-4xl font-bold mb-6 leading-tight">
              Empowering Africa's <br />
              <span className="text-[#c5a059]">Logistics Future</span>
            </h2>
            <p className="text-blue-100/60 text-sm leading-relaxed mb-12 max-w-sm">
              Access the unified postal infrastructure of 54 nations. Manage global shipments, track real-time telemetry, and orchestrate last-mile delivery across the continent.
            </p>

            <div className="space-y-6">
              {[
                { icon: Globe, title: "Global Integration", desc: "Seamless handoff with UPS, FedEx, and DHL." },
                { icon: Activity, title: "Real-time Telemetry", desc: "Live tracking of air and ground assets." },
                { icon: Database, title: "Unified API", desc: "Single integration point for all African postal services." }
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center">
                    <item.icon className="w-5 h-5 text-[#c5a059]" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold">{item.title}</h4>
                    <p className="text-[10px] text-blue-100/40">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="relative z-10 pt-12 border-t border-white/10">
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">
              © 2024 United Africa Postal Service. All rights reserved.
            </p>
          </div>
        </div>

        {/* Right Side: Login or Apply Form */}
        <div className="p-12 lg:p-20 flex flex-col justify-center">
          {view === 'login' ? (
            <>
              <div className="mb-10">
                <h3 className="text-2xl font-bold text-[#1a365d] mb-2">Partner Login</h3>
                <p className="text-gray-500 text-sm">Enter your credentials to access the dashboard.</p>
              </div>

              {error && (
                <motion.div 
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-red-50 border-l-4 border-red-500 p-4 mb-8 flex items-center gap-3"
                >
                  <Shield className="w-5 h-5 text-red-500" />
                  <p className="text-red-700 text-xs font-medium">{error}</p>
                </motion.div>
              )}

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest ml-1">Email Address</label>
                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-300" />
                    <input 
                      type="email" 
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="partner@uaps.africa"
                      className="w-full bg-gray-50 border border-gray-200 rounded-2xl pl-12 pr-6 py-4 text-sm focus:outline-none focus:ring-2 focus:ring-[#1a365d] transition-all"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between items-center ml-1">
                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Password</label>
                    <button type="button" className="text-[10px] font-bold text-[#c5a059] uppercase tracking-widest hover:underline">Forgot Password?</button>
                  </div>
                  <div className="relative">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-300" />
                    <input 
                      type="password" 
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full bg-gray-50 border border-gray-200 rounded-2xl pl-12 pr-6 py-4 text-sm focus:outline-none focus:ring-2 focus:ring-[#1a365d] transition-all"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-2 ml-1">
                  <input type="checkbox" id="remember" className="rounded border-gray-300 text-[#1a365d] focus:ring-[#1a365d]" />
                  <label htmlFor="remember" className="text-[10px] font-bold text-gray-500 uppercase tracking-widest cursor-pointer">Remember this device</label>
                </div>

                <button 
                  type="submit" 
                  disabled={isLoading}
                  className="w-full bg-[#1a365d] text-white py-4 rounded-2xl font-bold text-sm uppercase tracking-widest hover:bg-blue-900 transition-all shadow-xl shadow-blue-900/20 flex items-center justify-center gap-2 group"
                >
                  {isLoading ? (
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <>
                      Secure Login <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </>
                  )}
                </button>
              </form>

              <div className="mt-12 pt-8 border-t border-gray-100 text-center">
                <p className="text-xs text-gray-500">
                  Don't have a partner account? <button onClick={() => setView('apply')} className="text-[#c5a059] font-bold hover:underline">Apply to Join UAPS</button>
                </p>
              </div>
            </>
          ) : (
            <>
              <button 
                onClick={() => setView('login')}
                className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-8 flex items-center gap-1 hover:text-[#1a365d] transition-colors"
              >
                <ArrowLeft className="w-3 h-3" /> Back to Login
              </button>
              
              <div className="mb-8">
                <h3 className="text-2xl font-bold text-[#1a365d] mb-2">Apply to Join UAPS</h3>
                <p className="text-gray-500 text-sm">Become part of Africa's unified logistics network.</p>
              </div>

              {applyStatus === 'success' ? (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-center py-12"
                >
                  <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <CheckCircle2 className="w-8 h-8 text-emerald-600" />
                  </div>
                  <h4 className="text-xl font-bold text-[#1a365d] mb-2">Application Received</h4>
                  <p className="text-gray-500 text-sm">
                    Our partnership team will review your application and contact you within 3-5 business days.
                  </p>
                </motion.div>
              ) : (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                >
                  <div className="bg-blue-50/50 border border-blue-100 rounded-xl p-4 mb-8">
                    <h4 className="text-xs font-bold text-[#1a365d] uppercase tracking-widest mb-3">Partner Requirements</h4>
                    <ul className="space-y-2">
                      <li className="flex items-start gap-2 text-sm text-gray-600">
                        <FileText className="w-4 h-4 text-[#c5a059] shrink-0 mt-0.5" />
                        <span>Valid logistics/courier license in operating countries</span>
                      </li>
                      <li className="flex items-start gap-2 text-sm text-gray-600">
                        <Truck className="w-4 h-4 text-[#c5a059] shrink-0 mt-0.5" />
                        <span>Minimum fleet size of 10 vehicles (or drone equivalent)</span>
                      </li>
                      <li className="flex items-start gap-2 text-sm text-gray-600">
                        <Database className="w-4 h-4 text-[#c5a059] shrink-0 mt-0.5" />
                        <span>Ability to integrate with UAPS REST/gRPC APIs</span>
                      </li>
                    </ul>
                  </div>

                  <form onSubmit={handleApplySubmit} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest ml-1">Company Name</label>
                        <div className="relative mt-1">
                          <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-300" />
                          <input 
                            required 
                            type="text" 
                            value={applyForm.companyName}
                            onChange={(e) => setApplyForm({...applyForm, companyName: e.target.value})}
                            className="w-full bg-gray-50 border border-gray-200 rounded-xl pl-10 pr-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-[#1a365d] transition-all" 
                            placeholder="Acme Logistics" 
                          />
                        </div>
                      </div>
                      <div>
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest ml-1">Operating Countries</label>
                        <div className="relative mt-1">
                          <Globe className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-300" />
                          <input 
                            required 
                            type="text" 
                            value={applyForm.operatingCountries}
                            onChange={(e) => setApplyForm({...applyForm, operatingCountries: e.target.value})}
                            className="w-full bg-gray-50 border border-gray-200 rounded-xl pl-10 pr-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-[#1a365d] transition-all" 
                            placeholder="Kenya, Rwanda..." 
                          />
                        </div>
                      </div>
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest ml-1">Contact Email</label>
                      <div className="relative mt-1">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-300" />
                        <input 
                          required 
                          type="email" 
                          value={applyForm.contactEmail}
                          onChange={(e) => setApplyForm({...applyForm, contactEmail: e.target.value})}
                          className="w-full bg-gray-50 border border-gray-200 rounded-xl pl-10 pr-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-[#1a365d] transition-all" 
                          placeholder="contact@company.com" 
                        />
                      </div>
                    </div>

                    <button 
                      type="submit" 
                      disabled={applyStatus === 'submitting'}
                      className="w-full bg-[#1a365d] text-white py-3 rounded-xl font-bold text-sm uppercase tracking-widest hover:bg-blue-900 transition-all shadow-xl shadow-blue-900/20 flex items-center justify-center gap-2 mt-4"
                    >
                      {applyStatus === 'submitting' ? (
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      ) : (
                        'Submit Application'
                      )}
                    </button>
                  </form>
                </motion.div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
