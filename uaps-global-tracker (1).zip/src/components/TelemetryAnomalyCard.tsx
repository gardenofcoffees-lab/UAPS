import React from 'react';
import { motion } from 'motion/react';
import { Activity, Battery, AlertCircle, TrendingDown, Cpu, Gauge } from 'lucide-react';

interface TelemetryAnomalyProps {
  event: {
    event_id: string;
    drone_id: string;
    ts: string;
    signal: string;
    value: number;
    expected_range: [number, number];
    anomaly_score: number;
    model_version: string;
  };
}

export function TelemetryAnomalyCard({ event }: TelemetryAnomalyProps) {
  const isCritical = event.anomaly_score > 0.8;

  return (
    <motion.div 
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      className="bg-white rounded-[32px] border border-gray-100 shadow-xl overflow-hidden group hover:border-purple-200 transition-all"
    >
      <div className={`p-6 flex items-center justify-between ${
        isCritical ? 'bg-purple-50' : 'bg-blue-50'
      }`}>
        <div className="flex items-center gap-4">
          <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${
            isCritical ? 'bg-purple-100 text-purple-600' : 'bg-blue-100 text-blue-600'
          }`}>
            <Activity className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-sm font-black text-[#1a365d] uppercase tracking-tight">Telemetry Anomaly Detected</h3>
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Signal: {event.signal} • {event.event_id}</p>
          </div>
        </div>
        <div className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest ${
          isCritical ? 'bg-purple-200 text-purple-800' : 'bg-blue-200 text-blue-800'
        }`}>
          Score: {(event.anomaly_score * 100).toFixed(0)}%
        </div>
      </div>

      <div className="p-8 space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100">
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Current Value</p>
            <div className="flex items-center gap-2">
              <Battery className={`w-4 h-4 ${event.value < 50 ? 'text-red-500' : 'text-emerald-500'}`} />
              <span className="text-lg font-black text-[#1a365d]">{event.value}%</span>
            </div>
          </div>
          
          <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100">
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Expected Range</p>
            <div className="flex items-center gap-2">
              <Gauge className="w-4 h-4 text-blue-500" />
              <span className="text-lg font-black text-[#1a365d]">{event.expected_range[0]}-{event.expected_range[1]}%</span>
            </div>
          </div>

          <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100">
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Model Engine</p>
            <div className="flex items-center gap-2">
              <Cpu className="w-4 h-4 text-purple-500" />
              <span className="text-xs font-black text-[#1a365d] uppercase">{event.model_version}</span>
            </div>
          </div>
        </div>

        <div className="p-6 bg-purple-50/50 rounded-3xl border border-purple-100 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-purple-100 rounded-xl flex items-center justify-center text-purple-600">
              <TrendingDown className="w-5 h-5" />
            </div>
            <div>
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Deviation Analysis</p>
              <p className="text-xs font-black text-purple-900 uppercase tracking-tight">Significant degradation detected in battery discharge profile</p>
            </div>
          </div>
          <AlertCircle className="w-5 h-5 text-purple-400" />
        </div>
      </div>
    </motion.div>
  );
}
