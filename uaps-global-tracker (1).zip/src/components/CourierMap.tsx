import React, { useEffect, useState } from "react";
import { MapContainer, TileLayer, Marker, Popup, Polyline } from "react-leaflet";
import { OptimizedRoute } from "./OptimizedRoute";
import { CourierRoute } from "./CourierRoute";
import "leaflet/dist/leaflet.css";
import L from "leaflet";

const courierIcon = L.icon({
  iconUrl: "https://cdn-icons-png.flaticon.com/512/684/684908.png",
  iconSize: [32, 32],
  iconAnchor: [16, 32],
  popupAnchor: [0, -32],
});

export function CourierMap({ courierId, optimizedPoints = [] }: { courierId: string; optimizedPoints?: { lat: number; lng: number }[] }) {
  const [pos, setPos] = useState<{ lat: number; lng: number } | null>(null);

  useEffect(() => {
    const fetchLocation = async () => {
      try {
        const res = await fetch(`/api/courier/location/${courierId}`);
        const __dataBody = await res.json();
      const data = __dataBody.data || __dataBody;
        if (data) {
          setPos(data);
        }
      } catch (error) {
        console.error("Failed to fetch courier location:", error);
      }
    };

    fetchLocation(); // Initial fetch
    const interval = setInterval(fetchLocation, 3000); // update every 3 seconds

    return () => clearInterval(interval);
  }, [courierId]);

  if (!pos) return <div className="text-sm text-gray-500 p-4 bg-gray-50 rounded-lg border border-gray-100 italic text-center">Waiting for location data...</div>;

  return (
    <div className="rounded-xl overflow-hidden border border-gray-200 shadow-sm z-0 relative">
      <MapContainer
        center={[pos.lat, pos.lng]}
        zoom={14}
        style={{ height: "400px", width: "100%" }}
        scrollWheelZoom={false}
      >
        <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
        
        {/* Actual Path Taken */}
        <CourierRoute courierId={courierId} />
        
        {/* AI Optimized Planned Route (if provided) */}
        {optimizedPoints.length > 0 && (
          <Polyline 
            positions={optimizedPoints.map(p => [p.lat, p.lng])} 
            pathOptions={{ color: "purple", weight: 3, dashArray: "10, 10", opacity: 0.6 }} 
          />
        )}

        <Marker position={[pos.lat, pos.lng]} icon={courierIcon}>
          <Popup>
            <div className="text-xs font-bold text-[#1a365d]">Courier #{courierId}</div>
            <div className="text-[10px] text-gray-500">Live Location Tracking Active</div>
          </Popup>
        </Marker>
      </MapContainer>
    </div>
  );
}
