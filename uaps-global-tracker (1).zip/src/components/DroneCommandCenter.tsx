import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Send, AlertTriangle, Shield, Navigation, Terminal, 
  ChevronRight, Zap, Loader2, CheckCircle2, XCircle,
  Radio, Map as MapIcon, Activity
} from 'lucide-react';

interface DroneCommand {
  drone_id: string;
  type: string;
  reason?: string;
  payload_base64?: string;
}

interface SafetyAlert {
  event_id: string;
  drone_id: string;
  type: string;
  severity: 'INFO' | 'WARNING' | 'CRITICAL';
  ts: string;
}

export function DroneCommandCenter() {
  const [activeDrones, setActiveDrones] = useState<string[]>([]);
  const [selectedDrone, setSelectedDrone] = useState<string | null>(null);
  const [commandType, setCommandType] = useState('HOLD');
  const [reason, setReason] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [lastResponse, setLastResponse] = useState<any>(null);
  const [safetyAlerts, setSafetyAlerts] = useState<SafetyAlert[]>([]);
  const [logs, setLogs] = useState<{msg: string, type: 'info' | 'warn' | 'error' | 'success', ts: string}[]>([]);

  useEffect(() => {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const ws = new WebSocket(`${protocol}//${window.location.host}`);

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        
        if (data.type === 'telemetry_update' || data.type === 'telemetry_update_grpc') {
          setActiveDrones(prev => {
            if (!prev.includes(data.courierId)) {
              return [...prev, data.courierId];
            }
            return prev;
          });
        }

        if (data.type === 'safety_event' || data.type === 'safety_event_grpc') {
          const alert = data.event;
          setSafetyAlerts(prev => [alert, ...prev].slice(0, 10));
          addLog(`Safety Alert [${alert.severity}]: ${alert.type} from ${data.drone_id}`, alert.severity === 'CRITICAL' ? 'error' : 'warn');
        }

        if (data.type === 'command_ack') {
          addLog(`Command Ack: ${data.command_id} for ${data.drone_id} - ${data.success ? 'SUCCESS' : 'FAILED'}`, data.success ? 'success' : 'error');
        }

        if (data.type === 'route_computed' || data.type === 'route_computed_grpc') {
          addLog(`Route Computed for Delivery ${data.delivery_id}`, 'info');
        }
      } catch (err) {
        console.error("Command Center WS Error:", err);
      }
    };

    return () => ws.close();
  }, []);

  const addLog = (msg: string, type: 'info' | 'warn' | 'error' | 'success' = 'info') => {
    setLogs(prev => [{ msg, type, ts: new Date().toLocaleTimeString() }, ...prev].slice(0, 50));
  };

  const sendCommand = async () => {
    if (!selectedDrone) return;
    setIsSending(true);
    setLastResponse(null);

    try {
      const res = await fetch('/api/drones/command', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          drone_id: selectedDrone,
          type: commandType,
          reason
        })
      });

      const __dataBody = await res.json();
      const data = __dataBody.data || __dataBody;
      setLastResponse(data);
      
      if (res.ok) {
        addLog(`Command ${commandType} sent to ${selectedDrone}`, 'success');
      } else {
        addLog(`Failed to send command: ${data.error || 'Unknown error'}`, 'error');
      }
    } catch (err) {
      addLog(`Network error sending command`, 'error');
    } finally {
      setIsSending(false);
    }
  };

  const computeRoute = async () => {
    if (!selectedDrone) return;
    addLog(`Requesting autonomous route computation for ${selectedDrone}...`, 'info');
    
    try {
      const res = await fetch('/api/drones/route/compute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          delivery_id: `DEL-${Math.floor(Math.random() * 1000)}`,
          start: { lat: 6.5244, lon: 3.3792, alt_m: 0 },
          end: { lat: 6.6, lon: 3.4, alt_m: 0 }
        })
      });
      
      if (res.ok) {
        addLog(`Route computation initiated via gRPC RoutingEngine`, 'success');
      }
    } catch (err) {
      addLog(`Failed to initiate route computation`, 'error');
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Drone Selection & Command Panel */}
      <div className="lg:col-span-2 bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden flex flex-col">
        <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-slate-50/50">
          <div className="flex items-center gap-2">
            <Terminal className="w-4 h-4 text-indigo-600" />
            <h3 className="text-sm font-bold text-[#1a365d] uppercase tracking-widest">Tactical Command Center</h3>
          </div>
          <div className="flex items-center gap-2">
            <Radio className="w-3 h-3 text-emerald-500 animate-pulse" />
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">gRPC Uplink Active</span>
          </div>
        </div>

        <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div>
              <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 block">Select Active Drone</label>
              <div className="grid grid-cols-2 gap-2">
                {activeDrones.length > 0 ? (
                  activeDrones.map(id => (
                    <button
                      key={id}
                      onClick={() => setSelectedDrone(id)}
                      className={`px-3 py-2 rounded-lg border text-xs font-bold transition-all flex items-center gap-2 ${
                        selectedDrone === id 
                          ? 'bg-indigo-600 border-indigo-600 text-white shadow-md' 
                          : 'bg-white border-gray-200 text-gray-600 hover:border-indigo-300'
                      }`}
                    >
                      <Navigation className={`w-3 h-3 ${selectedDrone === id ? 'text-white' : 'text-indigo-500'}`} />
                      {id}
                    </button>
                  ))
                ) : (
                  <div className="col-span-2 py-4 text-center border-2 border-dashed border-gray-100 rounded-xl text-gray-300 text-[10px] font-bold uppercase">
                    No Drones Connected
                  </div>
                )}
              </div>
            </div>

            <div>
              <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 block">Command Type</label>
              <select
                value={commandType}
                onChange={(e) => setCommandType(e.target.value)}
                className="w-full bg-gray-50 border border-gray-200 rounded-lg px-4 py-2 text-sm font-bold text-[#1a365d] focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
              >
                <option value="HOLD">HOLD POSITION</option>
                <option value="RETURN_TO_BASE">RETURN TO BASE</option>
                <option value="EMERGENCY_LAND">EMERGENCY LAND</option>
                <option value="UPDATE_ROUTE">UPDATE ROUTE</option>
                <option value="RESUME">RESUME MISSION</option>
              </select>
            </div>

            <div>
              <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 block">Reason / Context</label>
              <textarea
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="Enter reason for manual override..."
                className="w-full bg-gray-50 border border-gray-200 rounded-lg px-4 py-2 text-sm text-gray-600 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 h-20 resize-none"
              />
            </div>

            <div className="flex gap-3">
              <button
                onClick={sendCommand}
                disabled={!selectedDrone || isSending}
                className="flex-1 bg-indigo-600 text-white py-3 rounded-xl font-bold text-xs uppercase tracking-widest hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {isSending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                Issue Command
              </button>
              <button
                onClick={computeRoute}
                disabled={!selectedDrone}
                className="bg-slate-800 text-white px-4 py-3 rounded-xl font-bold text-xs uppercase tracking-widest hover:bg-slate-900 transition-all shadow-lg shadow-slate-100 disabled:opacity-50 flex items-center justify-center gap-2"
                title="Compute Autonomous Route"
              >
                <MapIcon className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="bg-slate-900 rounded-xl p-4 font-mono text-[10px] flex flex-col h-[340px]">
            <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
              <span className="text-slate-500 uppercase font-bold tracking-widest">Command Console</span>
              <div className="flex gap-1">
                <div className="w-2 h-2 rounded-full bg-red-500/50" />
                <div className="w-2 h-2 rounded-full bg-amber-500/50" />
                <div className="w-2 h-2 rounded-full bg-emerald-500/50" />
              </div>
            </div>
            <div className="flex-1 overflow-y-auto space-y-2 custom-scrollbar">
              {logs.length > 0 ? (
                logs.map((log, i) => (
                  <div key={i} className="flex gap-2">
                    <span className="text-slate-600">[{log.ts}]</span>
                    <span className={
                      log.type === 'error' ? 'text-red-400' :
                      log.type === 'warn' ? 'text-amber-400' :
                      log.type === 'success' ? 'text-emerald-400' :
                      'text-indigo-300'
                    }>
                      {log.msg}
                    </span>
                  </div>
                ))
              ) : (
                <div className="text-slate-700 italic">Waiting for telemetry or commands...</div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Safety Alerts Panel */}
      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden flex flex-col">
        <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-red-50/30">
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-red-600" />
            <h3 className="text-sm font-bold text-[#1a365d] uppercase tracking-widest">Safety Alerts</h3>
          </div>
          <span className="px-2 py-0.5 bg-red-100 text-red-700 text-[10px] font-bold rounded-full">
            {safetyAlerts.filter(a => a.severity === 'CRITICAL').length} CRITICAL
          </span>
        </div>
        <div className="flex-1 overflow-y-auto p-4 space-y-3 max-h-[450px]">
          <AnimatePresence initial={false}>
            {safetyAlerts.length > 0 ? (
              safetyAlerts.map((alert) => (
                <motion.div
                  key={alert.event_id}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className={`p-3 rounded-xl border flex gap-3 ${
                    alert.severity === 'CRITICAL' 
                      ? 'bg-red-50 border-red-100' 
                      : alert.severity === 'WARNING'
                      ? 'bg-amber-50 border-amber-100'
                      : 'bg-blue-50 border-blue-100'
                  }`}
                >
                  <div className={`p-2 rounded-lg h-fit ${
                    alert.severity === 'CRITICAL' ? 'bg-red-100 text-red-600' : 'bg-amber-100 text-amber-600'
                  }`}>
                    <AlertTriangle className="w-4 h-4" />
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between items-start mb-1">
                      <span className="text-[10px] font-black text-[#1a365d] uppercase tracking-widest">{alert.type}</span>
                      <span className="text-[8px] text-gray-400 font-bold">{new Date(alert.ts).toLocaleTimeString()}</span>
                    </div>
                    <p className="text-[10px] text-gray-600 font-bold mb-2">Drone: {alert.drone_id}</p>
                    <div className="flex gap-2">
                      <button className="px-2 py-1 bg-white border border-gray-200 rounded text-[8px] font-bold uppercase tracking-widest hover:bg-gray-50">Investigate</button>
                      {alert.severity === 'CRITICAL' && (
                        <button 
                          onClick={() => {
                            setSelectedDrone(alert.drone_id);
                            setCommandType('EMERGENCY_LAND');
                          }}
                          className="px-2 py-1 bg-red-600 text-white rounded text-[8px] font-bold uppercase tracking-widest hover:bg-red-700"
                        >
                          Emergency Land
                        </button>
                      )}
                    </div>
                  </div>
                </motion.div>
              ))
            ) : (
              <div className="flex flex-col items-center justify-center py-20 opacity-20">
                <Shield className="w-12 h-12 mb-4" />
                <span className="text-xs font-bold uppercase tracking-widest">All Systems Safe</span>
              </div>
            )}
          </AnimatePresence>
        </div>
        <div className="p-4 border-t border-gray-100 bg-gray-50/50">
          <button className="w-full py-2 text-[10px] font-bold text-red-600 uppercase tracking-widest hover:underline">Clear All Alerts</button>
        </div>
      </div>
    </div>
  );
}
