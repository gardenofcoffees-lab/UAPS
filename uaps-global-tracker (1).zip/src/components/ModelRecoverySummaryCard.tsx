import React from 'react';
import { motion } from 'motion/react';
import { 
  ShieldCheck, 
  RotateCcw, 
  TrendingDown, 
  CheckCircle2, 
  Clock, 
  FileText, 
  ArrowRight, 
  BarChart3, 
  Activity,
  Gavel,
  ExternalLink
} from 'lucide-react';

interface ModelRecoverySummaryProps {
  event: any;
}

export function ModelRecoverySummaryCard({ event }: ModelRecoverySummaryProps) {
  const { 
    model_id, 
    from_version, 
    to_version, 
    drift_metrics, 
    thresholds, 
    auto_rollback, 
    rollback_timeline, 
    governance,
    evidence_packet_ref 
  } = event;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-[32px] border-2 border-emerald-500 shadow-2xl overflow-hidden relative"
    >
      {/* Success Header */}
      <div className="p-6 bg-emerald-500 text-white flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-sm font-black uppercase tracking-tight">Incident Resolved: Model Recovery</h3>
            <p className="text-[10px] font-bold text-white/60 uppercase tracking-widest">
              {model_id} • Lifecycle Summary
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 px-4 py-1.5 bg-white/20 rounded-full text-[10px] font-black uppercase tracking-widest">
          <CheckCircle2 className="w-3 h-3" />
          Closed & Audited
        </div>
      </div>

      <div className="p-8 space-y-8">
        {/* Version Shift Summary */}
        <div className="flex items-center justify-between p-6 bg-gray-50 rounded-[32px] border border-gray-100">
          <div className="text-center flex-1">
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Drifted Version</p>
            <span className="text-xl font-black text-rose-500">{from_version}</span>
          </div>
          <div className="flex flex-col items-center gap-1 px-8">
            <div className="px-3 py-1 bg-emerald-100 rounded-full border border-emerald-200">
              <span className="text-[8px] font-black text-emerald-600 uppercase tracking-widest">Auto-Rollback</span>
            </div>
            <ArrowRight className="w-6 h-6 text-gray-300" />
          </div>
          <div className="text-center flex-1">
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Restored Version</p>
            <span className="text-xl font-black text-emerald-600">{to_version}</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Drift Metrics */}
          <div className="space-y-4">
            <h4 className="text-[10px] font-black text-[#1a365d] uppercase tracking-widest flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-amber-500" /> Drift Indicators
            </h4>
            <div className="p-6 bg-gray-50 rounded-3xl border border-gray-100 space-y-4">
              <MetricRow label="Input PSI" value={drift_metrics.input_psi} max={thresholds.input_psi_max} />
              <MetricRow label="Calibration Error" value={drift_metrics.calibration_error} max={thresholds.calibration_error_max} />
              <MetricRow label="Unsafe FN Rate" value={drift_metrics.unsafe_false_negative_rate} max={thresholds.unsafe_fn_rate_max} isPercent />
            </div>
          </div>

          {/* Governance Summary */}
          <div className="space-y-4">
            <h4 className="text-[10px] font-black text-[#1a365d] uppercase tracking-widest flex items-center gap-2">
              <Gavel className="w-4 h-4 text-blue-500" /> Governance Approval
            </h4>
            <div className="p-6 bg-gray-50 rounded-3xl border border-gray-100 space-y-4">
              <div className="flex justify-between items-center mb-2">
                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Event ID</span>
                <span className="text-[10px] font-black text-blue-500">{governance.event_id}</span>
              </div>
              <div className="space-y-3">
                {governance.committee_decisions.map((decision: any, idx: number) => (
                  <div key={idx} className="flex items-center justify-between p-2 bg-white rounded-xl border border-gray-100">
                    <span className="text-[9px] font-bold text-[#1a365d] uppercase">{decision.role.replace('_', ' ')}</span>
                    <div className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                      <span className="text-[9px] font-black text-emerald-600">APPROVED</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Timeline */}
        <div className="space-y-4">
          <h4 className="text-[10px] font-black text-[#1a365d] uppercase tracking-widest flex items-center gap-2">
            <Clock className="w-4 h-4 text-emerald-600" /> Recovery Timeline
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <TimelineStep 
              label="Detection" 
              time={rollback_timeline.drift_detected_at} 
              color="bg-amber-500"
            />
            <TimelineStep 
              label="Initiation" 
              time={rollback_timeline.rollback_initiated_at} 
              color="bg-blue-500"
            />
            <TimelineStep 
              label="Completion" 
              time={rollback_timeline.rollback_completed_at} 
              color="bg-emerald-500"
            />
          </div>
        </div>

        {/* Evidence Link */}
        <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <FileText className="w-5 h-5 text-emerald-600" />
            <div>
              <p className="text-[10px] font-black text-[#1a365d] uppercase tracking-tight">Immutable Evidence Packet</p>
              <p className="text-[9px] font-bold text-emerald-600/60 truncate max-w-[300px]">{evidence_packet_ref}</p>
            </div>
          </div>
          <button className="flex items-center gap-2 px-4 py-2 bg-white border border-emerald-200 text-emerald-600 text-[10px] font-black uppercase tracking-widest rounded-xl hover:bg-emerald-100 transition-colors">
            View Source <ExternalLink className="w-3 h-3" />
          </button>
        </div>
      </div>
    </motion.div>
  );
}

function MetricRow({ label, value, max, isPercent = false }: any) {
  const isBreached = value > max;
  return (
    <div className="flex justify-between items-center">
      <span className="text-[10px] font-bold text-gray-400 uppercase">{label}</span>
      <div className="flex items-center gap-3">
        <span className={`text-[10px] font-black ${isBreached ? 'text-rose-500' : 'text-emerald-600'}`}>
          {isPercent ? `${(value * 100).toFixed(1)}%` : value.toFixed(3)}
        </span>
        <div className="w-20 h-1 bg-gray-200 rounded-full overflow-hidden">
          <div 
            className={`h-full ${isBreached ? 'bg-rose-500' : 'bg-emerald-500'}`}
            style={{ width: `${Math.min((value / max) * 100, 100)}%` }}
          />
        </div>
      </div>
    </div>
  );
}

function TimelineStep({ label, time, color }: any) {
  return (
    <div className="p-4 bg-white border border-gray-100 rounded-2xl space-y-1 shadow-sm">
      <div className="flex items-center gap-2">
        <div className={`w-2 h-2 rounded-full ${color}`} />
        <span className="text-[9px] font-black text-[#1a365d] uppercase tracking-tight">{label}</span>
      </div>
      <p className="text-[10px] font-bold text-gray-500">{new Date(time).toLocaleTimeString()}</p>
    </div>
  );
}
