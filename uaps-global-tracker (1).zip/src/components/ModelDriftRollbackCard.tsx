import React from 'react';
import { motion } from 'motion/react';
import { ShieldCheck, RotateCcw, TrendingDown, AlertCircle, Clock, Server, Fingerprint, ArrowRight, BarChart3, Activity } from 'lucide-react';

interface ModelDriftRollbackProps {
  event: any;
}

export function ModelDriftRollbackCard({ event }: ModelDriftRollbackProps) {
  const { model, drift_event, rollback, impact_analysis, hashes } = event;
  const isSuccess = rollback.status === 'SUCCESS';

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-[#0f172a] rounded-[32px] border border-blue-500/30 shadow-2xl overflow-hidden relative"
    >
      {/* Background Glow */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/10 blur-[100px] -mr-32 -mt-32" />
      
      <div className="p-6 bg-blue-500/10 border-b border-blue-500/20 flex items-center justify-between relative z-10">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-blue-500/20 text-blue-400 rounded-2xl flex items-center justify-center">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-sm font-black text-white uppercase tracking-tight">Evidence Packet: Model Recovery</h3>
            <p className="text-[10px] font-bold text-blue-400/60 uppercase tracking-widest">
              {model.model_id} • {event.packet_id}
            </p>
          </div>
        </div>
        <div className="px-4 py-1.5 bg-emerald-500 text-white rounded-full text-[10px] font-black uppercase tracking-widest">
          Audit Complete
        </div>
      </div>

      <div className="p-8 space-y-8 relative z-10">
        {/* Version Transition */}
        <div className="flex items-center justify-center gap-12 p-8 bg-white/5 rounded-[32px] border border-white/10">
          <div className="text-center">
            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-2">Drifted Version</p>
            <span className="text-2xl font-black text-red-400">{model.from_version}</span>
          </div>
          <div className="flex flex-col items-center gap-2">
            <div className="px-3 py-1 bg-blue-500/20 rounded-full border border-blue-500/30">
              <span className="text-[8px] font-black text-blue-400 uppercase tracking-widest">Rollback Executed</span>
            </div>
            <ArrowRight className="w-8 h-8 text-gray-600" />
          </div>
          <div className="text-center">
            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-2">Restored Version</p>
            <span className="text-2xl font-black text-emerald-400">{model.to_version}</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Impact Analysis */}
          <div className="space-y-4">
            <h4 className="text-[10px] font-black text-white uppercase tracking-widest flex items-center gap-2">
              <Activity className="w-4 h-4 text-rose-400" /> Impact Analysis
            </h4>
            <div className="p-6 bg-white/5 rounded-3xl border border-white/10 space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Time in Drift</p>
                  <p className="text-sm font-black text-white">{impact_analysis.time_in_drift_state.replace('P', '')}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Affected Flights</p>
                  <p className="text-sm font-black text-rose-400">{impact_analysis.estimated_affected_flights.toLocaleString()}</p>
                </div>
              </div>
              <div className="space-y-2">
                <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Affected Services</p>
                <div className="flex flex-wrap gap-2">
                  {impact_analysis.affected_services.map((service: string, idx: number) => (
                    <span key={idx} className="px-2 py-1 bg-white/5 rounded-lg border border-white/10 text-[9px] font-bold text-gray-300 uppercase">
                      {service}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Drift Metrics Summary */}
          <div className="space-y-4">
            <h4 className="text-[10px] font-black text-white uppercase tracking-widest flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-amber-400" /> Drift Indicators
            </h4>
            <div className="p-6 bg-white/5 rounded-3xl border border-white/10 space-y-4">
              <MetricRow label="Input PSI" value={drift_event.metrics.input_psi} max={drift_event.thresholds.input_psi_max} />
              <MetricRow label="Calibration Error" value={drift_event.metrics.calibration_error} max={drift_event.thresholds.calibration_error_max} />
              <MetricRow label="Unsafe FN Rate" value={drift_event.metrics.unsafe_false_negative_rate} max={drift_event.thresholds.unsafe_fn_rate_max} isPercent />
            </div>
          </div>
        </div>

        {/* Timeline */}
        <div className="p-6 bg-white/5 rounded-3xl border border-white/10 space-y-4">
          <h4 className="text-[10px] font-black text-white uppercase tracking-widest flex items-center gap-2">
            <Clock className="w-4 h-4 text-blue-400" /> Execution Timeline
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <TimelineItem label="Drift Detected" time={drift_event.ts} />
            <TimelineItem label="Rollback Initiated" time={rollback.initiated_at} />
            <TimelineItem label="Recovery Complete" time={rollback.completed_at} />
          </div>
        </div>

        {/* Integrity Hashes */}
        <div className="p-4 bg-black/40 rounded-2xl space-y-3 border border-white/5">
          <div className="flex items-center gap-2">
            <Fingerprint className="w-3 h-3 text-blue-400" />
            <span className="text-[8px] font-black text-blue-400 uppercase tracking-widest">Evidence Integrity Hashes (SHA-256)</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <HashItem label="Packet" hash={hashes.packet_hash} />
            <HashItem label="Drift Event" hash={hashes.drift_event_hash} />
            <HashItem label="Rollback Result" hash={hashes.rollback_result_hash} />
          </div>
        </div>

        <div className="p-4 bg-white/5 rounded-2xl border border-white/10 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
            <span className="text-[8px] font-black text-white/40 uppercase tracking-widest">Audit Immutable Record</span>
          </div>
          <p className="text-[8px] font-bold text-white/20 uppercase tracking-widest">
            Generated by {event.created_by} at {new Date(event.created_at).toLocaleString()}
          </p>
        </div>
      </div>
    </motion.div>
  );
}

function MetricRow({ label, value, max, isPercent = false }: any) {
  const isBreached = value > max;
  return (
    <div className="flex justify-between items-center">
      <span className="text-[10px] font-bold text-gray-500 uppercase">{label}</span>
      <div className="flex items-center gap-3">
        <span className={`text-[10px] font-black ${isBreached ? 'text-red-400' : 'text-emerald-400'}`}>
          {isPercent ? `${(value * 100).toFixed(1)}%` : value.toFixed(3)}
        </span>
        <div className="w-24 h-1 bg-white/10 rounded-full overflow-hidden">
          <div 
            className={`h-full ${isBreached ? 'bg-red-500' : 'bg-emerald-500'}`}
            style={{ width: `${Math.min((value / max) * 100, 100)}%` }}
          />
        </div>
      </div>
    </div>
  );
}

function TimelineItem({ label, time }: any) {
  return (
    <div className="space-y-1">
      <p className="text-[8px] font-bold text-gray-500 uppercase tracking-widest">{label}</p>
      <p className="text-[10px] font-black text-white">{new Date(time).toLocaleTimeString()}</p>
    </div>
  );
}

function HashItem({ label, hash }: any) {
  return (
    <div className="space-y-1">
      <p className="text-[7px] font-bold text-gray-600 uppercase tracking-widest">{label}</p>
      <p className="text-[7px] font-mono text-gray-500 truncate">{hash}</p>
    </div>
  );
}
