import React from 'react';
import { motion } from 'motion/react';
import { 
  FileText, 
  User, 
  Database, 
  Activity, 
  ShieldAlert, 
  Gavel, 
  CheckCircle2, 
  AlertTriangle, 
  ArrowRight,
  Info,
  Globe,
  Calendar,
  Zap,
  ExternalLink
} from 'lucide-react';

interface ModelCardProps {
  event: any;
}

export function ModelCard({ event }: ModelCardProps) {
  const {
    model_id,
    overview,
    data,
    performance,
    monitoring,
    risks_mitigations,
    governance,
    ts
  } = event;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-[32px] border border-gray-200 shadow-2xl overflow-hidden"
    >
      {/* Header */}
      <div className="p-8 bg-[#1a365d] text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-10">
          <Database className="w-32 h-32" />
        </div>
        <div className="relative z-10 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <div className="w-16 h-16 bg-white/10 rounded-2xl flex items-center justify-center backdrop-blur-md border border-white/20">
              <FileText className="w-8 h-8 text-blue-300" />
            </div>
            <div>
              <h2 className="text-2xl font-black tracking-tight uppercase">Model Card — {model_id}</h2>
              <div className="flex items-center gap-4 mt-1">
                <span className="text-[10px] font-bold text-blue-300 uppercase tracking-widest flex items-center gap-1">
                  <User className="w-3 h-3" /> {overview.owner}
                </span>
                <span className="text-[10px] font-bold text-blue-300 uppercase tracking-widest flex items-center gap-1">
                  <Activity className="w-3 h-3" /> {overview.type}
                </span>
              </div>
            </div>
          </div>
          <div className="px-4 py-2 bg-rose-500 rounded-full text-[10px] font-black uppercase tracking-widest flex items-center gap-2 shadow-lg">
            <AlertTriangle className="w-3 h-3" />
            Status: {monitoring.drift_status}
          </div>
        </div>
      </div>

      <div className="p-8 space-y-10">
        {/* 1. Overview & Intended Use */}
        <section className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-4">
            <h3 className="text-[10px] font-black text-[#1a365d] uppercase tracking-widest flex items-center gap-2">
              <Info className="w-4 h-4 text-blue-600" /> Intended Use
            </h3>
            <div className="p-6 bg-blue-50 rounded-3xl border border-blue-100">
              <p className="text-xs font-medium text-blue-900 leading-relaxed">{overview.intended_use}</p>
            </div>
          </div>
          <div className="space-y-4">
            <h3 className="text-[10px] font-black text-rose-900 uppercase tracking-widest flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-rose-600" /> Not Intended Use
            </h3>
            <div className="p-6 bg-rose-50 rounded-3xl border border-rose-100">
              <p className="text-xs font-medium text-rose-900 leading-relaxed">{overview.not_intended_use}</p>
            </div>
          </div>
        </section>

        {/* 2. Data & Performance */}
        <section className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-4">
            <h3 className="text-[10px] font-black text-[#1a365d] uppercase tracking-widest flex items-center gap-2">
              <Database className="w-4 h-4 text-emerald-600" /> Training Data
            </h3>
            <div className="p-6 bg-gray-50 rounded-3xl border border-gray-100 space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Period</span>
                <span className="text-[10px] font-black text-slate-900">{data.training_period}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Geography</span>
                <span className="text-[10px] font-black text-slate-900">{data.geography}</span>
              </div>
              <div className="pt-2">
                <p className="text-[9px] font-bold text-gray-400 uppercase tracking-widest mb-2">Key Features</p>
                <div className="flex flex-wrap gap-2">
                  {data.key_features.map((f: string, i: number) => (
                    <span key={i} className="px-2 py-1 bg-white border border-gray-200 rounded-md text-[9px] font-bold text-slate-600">{f}</span>
                  ))}
                </div>
              </div>
            </div>
          </div>
          <div className="space-y-4">
            <h3 className="text-[10px] font-black text-[#1a365d] uppercase tracking-widest flex items-center gap-2">
              <Zap className="w-4 h-4 text-amber-600" /> Validation Performance
            </h3>
            <div className="p-6 bg-gray-50 rounded-3xl border border-gray-100 space-y-4">
              <MetricBox label="ROC AUC" value={performance.roc_auc} color="text-emerald-600" />
              <MetricBox label="ECE" value={performance.ece} color="text-blue-600" />
              <MetricBox label="FN-Unsafe" value={performance.fn_unsafe} color="text-rose-600" />
            </div>
          </div>
        </section>

        {/* 3. Drift & Monitoring */}
        <section className="space-y-4">
          <h3 className="text-[10px] font-black text-[#1a365d] uppercase tracking-widest flex items-center gap-2">
            <Activity className="w-4 h-4 text-rose-600" /> Drift & Monitoring (Live)
          </h3>
          <div className="p-8 bg-rose-50 rounded-[32px] border border-rose-100 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <LiveMetric 
                label="Input PSI" 
                current={monitoring.live_metrics.psi} 
                threshold={monitoring.thresholds.psi_max} 
              />
              <LiveMetric 
                label="Output ECE" 
                current={monitoring.live_metrics.ece} 
                threshold={monitoring.thresholds.ece_max} 
              />
              <LiveMetric 
                label="FN-Unsafe" 
                current={monitoring.live_metrics.fn_unsafe} 
                threshold={monitoring.thresholds.fn_unsafe_max}
                isPercent
              />
            </div>
            <div className="p-4 bg-white/50 rounded-2xl border border-rose-200 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-rose-500 text-white rounded-xl flex items-center justify-center">
                  <ArrowRight className="w-4 h-4" />
                </div>
                <p className="text-xs font-black text-rose-900 uppercase tracking-tight">
                  Action: {monitoring.actions_taken}
                </p>
              </div>
              <span className="text-[9px] font-bold text-rose-400 uppercase tracking-widest">
                Timestamp: {new Date(monitoring.action_ts).toLocaleString()}
              </span>
            </div>
          </div>
        </section>

        {/* 4. Risks & Governance */}
        <section className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-4">
            <h3 className="text-[10px] font-black text-[#1a365d] uppercase tracking-widest flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-amber-600" /> Risks & Mitigations
            </h3>
            <div className="space-y-3">
              {risks_mitigations.map((rm: any, i: number) => (
                <div key={i} className="p-4 bg-white border border-gray-100 rounded-2xl shadow-sm space-y-2">
                  <p className="text-[10px] font-black text-rose-600 uppercase tracking-tight">Risk: {rm.risk}</p>
                  <div className="flex flex-wrap gap-2">
                    {rm.mitigations.map((m: string, j: number) => (
                      <span key={j} className="px-2 py-1 bg-emerald-50 text-emerald-700 text-[9px] font-bold rounded-md flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> {m}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="space-y-4">
            <h3 className="text-[10px] font-black text-[#1a365d] uppercase tracking-widest flex items-center gap-2">
              <Gavel className="w-4 h-4 text-blue-600" /> Governance
            </h3>
            <div className="p-6 bg-blue-50 rounded-3xl border border-blue-100 space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-bold text-blue-400 uppercase tracking-widest">Risk Register ID</span>
                <span className="text-[10px] font-black text-blue-900">{governance.risk_register_id}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-bold text-blue-400 uppercase tracking-widest">Last Review</span>
                <span className="text-[10px] font-black text-blue-900">{governance.last_review}</span>
              </div>
              <div className="pt-2">
                <button className="w-full p-3 bg-white border border-blue-200 rounded-xl text-[10px] font-black text-blue-600 uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-blue-100 transition-colors">
                  <FileText className="w-4 h-4" /> View Evidence Packet <ExternalLink className="w-3 h-3" />
                </button>
              </div>
            </div>
          </div>
        </section>
      </div>
    </motion.div>
  );
}

function MetricBox({ label, value, color }: any) {
  return (
    <div className="flex justify-between items-center">
      <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{label}</span>
      <span className={`text-sm font-black ${color}`}>{value}</span>
    </div>
  );
}

function LiveMetric({ label, current, threshold, isPercent = false }: any) {
  const isBreached = current > threshold;
  return (
    <div className="p-4 bg-white rounded-2xl border border-rose-100 shadow-sm space-y-2">
      <p className="text-[9px] font-bold text-gray-400 uppercase tracking-widest">{label}</p>
      <div className="flex items-baseline gap-2">
        <span className={`text-lg font-black ${isBreached ? 'text-rose-600' : 'text-emerald-600'}`}>
          {isPercent ? `${(current * 100).toFixed(1)}%` : current}
        </span>
        <span className="text-[9px] font-bold text-gray-400 uppercase">/ {isPercent ? `${(threshold * 100).toFixed(1)}%` : threshold}</span>
      </div>
      <div className="w-full h-1 bg-gray-100 rounded-full overflow-hidden">
        <div 
          className={`h-full ${isBreached ? 'bg-rose-500' : 'bg-emerald-500'}`}
          style={{ width: `${Math.min((current / threshold) * 100, 100)}%` }}
        />
      </div>
    </div>
  );
}
