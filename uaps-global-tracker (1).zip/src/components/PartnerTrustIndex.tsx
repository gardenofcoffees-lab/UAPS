import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  TrendingUp, 
  ShieldCheck, 
  Scale, 
  Eye, 
  Activity, 
  Database, 
  ShieldAlert, 
  ChevronUp, 
  ChevronDown,
  AlertTriangle,
  CheckCircle2,
  Clock,
  BarChart3,
  Search,
  FileText,
  Zap,
  Lock,
  UserCheck
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip,
  BarChart,
  Bar,
  Cell,
  PieChart,
  Pie
} from 'recharts';

const trustTrendData = [
  { name: 'Jan', score: 82 },
  { name: 'Feb', score: 85 },
  { name: 'Mar', score: 84 },
  { name: 'Apr', score: 88 },
  { name: 'May', score: 91 },
  { name: 'Jun', score: 94 },
];

const fairnessData = [
  { name: 'FN Deviation', value: 0.02, target: 0.05 },
  { name: 'FP Deviation', value: 0.03, target: 0.05 },
  { name: 'Corridor Parity', value: 0.98, target: 0.95 },
];

const dataQualityData = [
  { name: 'Missing', value: 1.2 },
  { name: 'Schema', value: 0.5 },
  { name: 'Latency', value: 2.1 },
  { name: 'Duplicates', value: 0.8 },
];

const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444'];

export const PartnerTrustIndex = () => {
  const [metrics, setMetrics] = useState<any>(null);
  const [scorecards, setScorecards] = useState<any[]>([]);
  const [selectedPartner, setSelectedPartner] = useState<string | null>(null);
  const [partnerShipments, setPartnerShipments] = useState<any[]>([]);

  useEffect(() => {
    if (!selectedPartner) {
      setPartnerShipments([]);
      return;
    }
    const fetchShipments = async () => {
      try {
        const res = await fetch(`/api/partners/${selectedPartner}/shipments`);
        if (res.ok) {
          const body = await res.json();
          setPartnerShipments(body.data || body);
        }
      } catch (err) {
        console.error("Failed to fetch partner shipments:", err);
      }
    };
    fetchShipments();
  }, [selectedPartner]);

  useEffect(() => {
    const fetchMetrics = async () => {
      try {
        const res = await fetch('/api/governance/metrics');
        if (res.ok) {
          const body = await res.json();
          setMetrics(body.data || body);
        }
      } catch (err) {
        console.error("Failed to fetch governance metrics:", err);
      }
    };

    const fetchScorecards = async () => {
      try {
        const res = await fetch('/api/partners/scorecards');
        if (res.ok) {
          const body = await res.json();
          setScorecards(body.data || body);
        }
      } catch (err) {
        console.error("Failed to fetch partner scorecards:", err);
      }
    };

    fetchMetrics();
    fetchScorecards();
    const interval = setInterval(fetchMetrics, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-slate-50 p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* HEADER */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-indigo-600 rounded-lg text-white">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h1 className="text-3xl font-black text-slate-900 uppercase tracking-tight">Partner Trust Index</h1>
            </div>
            <p className="text-slate-500 font-medium uppercase tracking-widest text-xs">Executive Governance & Ecosystem Integrity Dashboard</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="px-4 py-2 bg-white rounded-xl border border-slate-200 shadow-sm flex items-center gap-3">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-[10px] font-bold text-slate-600 uppercase tracking-widest">Live Integrity Monitoring</span>
            </div>
          </div>
        </div>

        {/* TOP PANEL — TRUST SCORE */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="lg:col-span-2 bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden p-8 flex flex-col md:flex-row items-center gap-12"
          >
            <div className="text-center md:text-left">
              <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-2">Overall Partner Trust Index</div>
              <div className="flex items-baseline gap-4">
                <span className="text-7xl font-black text-slate-900 tracking-tighter">
                  {metrics?.trustScore?.toFixed(1) || '94.2'}
                </span>
                <div className="flex items-center gap-1 text-emerald-600 font-bold text-sm">
                  <TrendingUp className="w-4 h-4" />
                  +3.1%
                </div>
              </div>
              <div className="mt-6 flex items-center gap-3">
                <div className="px-4 py-1.5 bg-indigo-600 text-white text-[10px] font-black uppercase tracking-widest rounded-full shadow-lg shadow-indigo-200">
                  Platinum Tier
                </div>
                <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Top 2% of Ecosystem</div>
              </div>
            </div>
            <div className="flex-1 h-48 w-full min-h-0 min-w-0">
              <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                <AreaChart data={trustTrendData}>
                  <defs>
                    <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.1}/>
                      <stop offset="95%" stopColor="#4f46e5" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 10, fontWeight: 700, fill: '#94a3b8'}} />
                  <YAxis hide domain={[70, 100]} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                    labelStyle={{ fontWeight: 800, color: '#1e293b', marginBottom: '4px' }}
                  />
                  <Area type="monotone" dataKey="score" stroke="#4f46e5" strokeWidth={4} fillOpacity={1} fill="url(#colorScore)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-slate-900 rounded-3xl p-8 text-white relative overflow-hidden flex flex-col justify-between"
          >
            <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/20 blur-3xl rounded-full -mr-16 -mt-16" />
            <div className="relative z-10">
              <div className="text-[10px] font-black text-indigo-300 uppercase tracking-[0.3em] mb-6">Trust Composition</div>
              <div className="space-y-4">
                {[
                  { label: 'Fairness Parity', value: 98, color: 'bg-emerald-500' },
                  { label: 'Transparency', value: 92, color: 'bg-blue-500' },
                  { label: 'Reliability', value: 95, color: 'bg-indigo-500' },
                  { label: 'Security', value: 89, color: 'bg-rose-500' },
                ].map((item) => (
                  <div key={item.label}>
                    <div className="flex justify-between text-[10px] font-bold uppercase tracking-widest mb-1.5">
                      <span className="text-slate-400">{item.label}</span>
                      <span>{item.value}%</span>
                    </div>
                    <div className="h-1.5 w-full bg-white/10 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${item.value}%` }}
                        transition={{ duration: 1, delay: 0.5 }}
                        className={`h-full ${item.color}`} 
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <button className="relative z-10 mt-8 w-full py-3 bg-white/10 hover:bg-white/20 border border-white/10 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all">
              Download Trust Report
            </button>
          </motion.div>
        </div>

        {/* MIDDLE GRID */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          
          {/* FAIRNESS PANEL */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6"
          >
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-emerald-50 text-emerald-600 rounded-lg">
                  <Scale className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-slate-900 uppercase tracking-tight text-sm">Fairness Panel</h3>
              </div>
              <div className="px-2 py-1 bg-emerald-50 text-emerald-600 text-[8px] font-black uppercase tracking-widest rounded border border-emerald-100">
                Compliant
              </div>
            </div>
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                  <div className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1">FN/FP Deviation</div>
                  <div className="text-xl font-black text-slate-900">
                    {metrics?.fairness?.deviation?.toFixed(2) || '0.02'}%
                  </div>
                </div>
                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                  <div className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1">Corridor Parity</div>
                  <div className="text-xl font-black text-slate-900">
                    {metrics?.fairness?.parity?.toFixed(2) || '0.98'}
                  </div>
                </div>
              </div>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Bias Flags</span>
                  <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">0 Detected</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Mitigation Time</span>
                  <span className="text-[10px] font-black text-slate-900 uppercase tracking-widest">1.2h Avg</span>
                </div>
              </div>
            </div>
          </motion.div>

          {/* TRANSPARENCY PANEL */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6"
          >
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
                  <Eye className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-slate-900 uppercase tracking-tight text-sm">Transparency Panel</h3>
              </div>
              <div className="px-2 py-1 bg-blue-50 text-blue-600 text-[8px] font-black uppercase tracking-widest rounded border border-blue-100">
                High
              </div>
            </div>
            <div className="space-y-6">
              <div className="h-32 w-full min-h-0 min-w-0">
                <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                  <BarChart data={[
                    { name: 'Reason Codes', val: 94 },
                    { name: 'Explainability', val: 88 },
                    { name: 'Engagement', val: 76 },
                  ]}>
                    <XAxis dataKey="name" hide />
                    <Tooltip cursor={{fill: 'transparent'}} contentStyle={{ borderRadius: '12px', border: 'none', fontSize: '10px' }} />
                    <Bar dataKey="val" radius={[4, 4, 0, 0]}>
                      {trustTrendData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={['#3b82f6', '#6366f1', '#8b5cf6'][index]} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center">
                  <div className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1">Code Coverage</div>
                  <div className="text-lg font-black text-slate-900">94.2%</div>
                </div>
                <div className="text-center">
                  <div className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1">Usage Depth</div>
                  <div className="text-lg font-black text-slate-900">8.4/10</div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* RELIABILITY PANEL */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6"
          >
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
                  <Activity className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-slate-900 uppercase tracking-tight text-sm">Reliability Panel</h3>
              </div>
              <div className="px-2 py-1 bg-indigo-50 text-indigo-600 text-[8px] font-black uppercase tracking-widest rounded border border-indigo-100">
                Stable
              </div>
            </div>
            <div className="space-y-4">
              {[
                { label: 'SLA Compliance', value: `${metrics?.reliability?.sla || '99.98'}%`, status: 'success' },
                { label: 'Alert Latency', value: `${metrics?.reliability?.latency || '42'}ms`, status: 'success' },
                { label: 'Drift Detection', value: '2.4m', status: 'warning' },
              ].map((item) => (
                <div key={item.label} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-100">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">{item.label}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-black text-slate-900 uppercase tracking-widest">{item.value}</span>
                    <div className={`w-1.5 h-1.5 rounded-full ${item.status === 'success' ? 'bg-emerald-500' : 'bg-amber-500'}`} />
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          {/* DATA QUALITY PANEL */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6"
          >
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-amber-50 text-amber-600 rounded-lg">
                  <Database className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-slate-900 uppercase tracking-tight text-sm">Data Quality Panel</h3>
              </div>
              <div className="px-2 py-1 bg-amber-50 text-amber-600 text-[8px] font-black uppercase tracking-widest rounded border border-amber-100">
                Warning
              </div>
            </div>
            <div className="h-32 w-full mb-4 min-h-0 min-w-0">
              <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                <PieChart>
                  <Pie
                    data={dataQualityData}
                    cx="50%"
                    cy="50%"
                    innerRadius={35}
                    outerRadius={50}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {dataQualityData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-emerald-500" />
                <span className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">Missing: 1.2%</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-blue-500" />
                <span className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">Schema: 0.5%</span>
              </div>
            </div>
          </motion.div>

          {/* SECURITY PANEL */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 lg:col-span-2"
          >
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-rose-50 text-rose-600 rounded-lg">
                  <ShieldAlert className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-slate-900 uppercase tracking-tight text-sm">Security Panel</h3>
              </div>
              <div className="px-2 py-1 bg-rose-50 text-rose-600 text-[8px] font-black uppercase tracking-widest rounded border border-rose-100">
                Critical Monitoring
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-4">
                <div className="p-4 bg-rose-50 rounded-2xl border border-rose-100 relative overflow-hidden">
                  <div className="absolute top-0 right-0 p-2 opacity-10">
                    <ShieldAlert className="w-8 h-8" />
                  </div>
                  <div className="text-[8px] font-black text-rose-400 uppercase tracking-widest mb-1">API Abuse Attempts</div>
                  <div className="text-2xl font-black text-rose-600">
                    {metrics?.security?.abuseAttempts || '12'}
                  </div>
                  <div className="text-[8px] font-bold text-rose-400 uppercase tracking-widest mt-1">Last 24 Hours</div>
                </div>
                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                  <div className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1">Credential Hygiene</div>
                  <div className="text-2xl font-black text-slate-900">98%</div>
                </div>
              </div>
              <div className="md:col-span-2 bg-slate-900 rounded-2xl p-6 text-white">
                <div className="flex items-center justify-between mb-4">
                  <div className="text-[10px] font-black text-indigo-300 uppercase tracking-[0.2em]">Partner Anomaly Score</div>
                  <div className="px-2 py-0.5 bg-emerald-500/20 text-emerald-400 text-[8px] font-black uppercase tracking-widest rounded">Low Risk</div>
                </div>
                <div className="flex items-center gap-6">
                  <div className="text-4xl font-black">14.2</div>
                  <div className="flex-1 space-y-2">
                    <div className="flex justify-between text-[8px] font-bold uppercase tracking-widest text-slate-400">
                      <span>Behavioral Baseline</span>
                      <span>98.2% Match</span>
                    </div>
                    <div className="h-1.5 w-full bg-white/10 rounded-full overflow-hidden">
                      <div className="h-full bg-indigo-500 w-[98.2%]" />
                    </div>
                  </div>
                </div>
                <div className="mt-6 grid grid-cols-2 gap-4">
                  <div className="flex items-center gap-2 text-[8px] font-bold uppercase tracking-widest text-slate-400">
                    <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                    No Lateral Movement
                  </div>
                  <div className="flex items-center gap-2 text-[8px] font-bold uppercase tracking-widest text-slate-400">
                    <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                    Encrypted Payload Parity
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

        </div>

        {/* PARTNER SCORECARDS */}
        {scorecards && scorecards.length > 0 && (
          <div className="space-y-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 bg-slate-200 text-slate-700 rounded-lg">
                <UserCheck className="w-5 h-5" />
              </div>
              <h3 className="text-xl font-black text-slate-900 uppercase tracking-tight">Partner Scorecards</h3>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {scorecards.map((partner, index) => (
                <motion.div 
                  key={partner.partner_id}
                  onClick={() => setSelectedPartner(selectedPartner === partner.partner_id ? null : partner.partner_id)}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 + (index * 0.1) }}
                  className={`bg-white rounded-3xl border ${selectedPartner === partner.partner_id ? 'border-indigo-500 ring-2 ring-indigo-500/20 shadow-md' : 'border-slate-200 shadow-sm'} p-6 transition-all cursor-pointer`}
                >
                  <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white font-black">
                        {partner.partner_id.substring(0, 2)}
                      </div>
                      <div>
                        <h4 className="font-black text-slate-900 text-lg uppercase tracking-tight">{partner.name}</h4>
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">ID: {partner.partner_id}</p>
                      </div>
                    </div>
                    <div className="text-right flex flex-col items-end">
                      <div className="flex items-baseline mb-1">
                        <span className="text-3xl font-black text-slate-900">{partner.overall_score}</span>
                        <span className="text-xs text-slate-400 font-bold ml-1">/100</span>
                      </div>
                      {partner.certification_level && (
                        <span className={`text-[9px] font-black uppercase tracking-widest px-2 py-0.5 rounded-md ${
                          partner.certification_level === 'ELITE' 
                            ? 'bg-amber-100 text-amber-800' 
                            : partner.certification_level === 'ADVANCED'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-slate-100 text-slate-600'
                        }`}>
                          {partner.certification_level}
                        </span>
                      )}
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4 mb-6">
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 shadow-inner">
                      <h5 className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1">Operational</h5>
                      <span className="text-lg font-black text-slate-900">{partner.metrics.operational}</span>
                    </div>
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 shadow-inner">
                      <h5 className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1">Compliance</h5>
                      <span className="text-lg font-black text-slate-900">{partner.metrics.compliance}</span>
                    </div>
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 shadow-inner">
                      <h5 className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1">CX Rating</h5>
                      <span className="text-lg font-black text-slate-900">{partner.metrics.cx}</span>
                    </div>
                  </div>

                  {partner.corridors && partner.corridors.length > 0 && (
                    <div className="mb-4">
                      <h5 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-2">
                        <Activity className="w-3 h-3 text-emerald-500" /> Corridor Performance & Risk
                      </h5>
                      <div className="space-y-3">
                        {partner.corridors.map((c: any, cidx: number) => (
                          <div key={cidx} className="flex justify-between items-center text-sm p-3 bg-slate-50 rounded-lg border border-slate-100">
                            <span className="font-bold text-slate-700">{c.corridor}</span>
                            <div className="flex flex-col items-end gap-1">
                              {c.risk_score && (
                                <div className="flex items-center gap-1.5 text-[9px] uppercase tracking-widest font-bold text-slate-500">
                                  <span>Avg Risk:</span>
                                  <span className={`px-1.5 py-0.5 rounded ${c.risk_score > 0.3 ? 'bg-rose-100 text-rose-700' : 'bg-slate-200 text-slate-700'}`}>
                                    {c.risk_score}
                                  </span>
                                </div>
                              )}
                              <div className="flex items-center gap-3">
                                <div className="h-1.5 w-20 bg-slate-200 rounded-full overflow-hidden">
                                  <div className="h-full bg-emerald-500" style={{ width: `${c.performance}%` }} />
                                </div>
                                <span className="font-black text-emerald-700 text-xs w-6 text-right">{c.performance}</span>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* ACTIVE SHIPMENTS SECTION */}
                  {selectedPartner === partner.partner_id && (
                    <motion.div 
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      className="mt-6 pt-6 border-t border-slate-100"
                    >
                      <h5 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                        <Database className="w-3 h-3 text-indigo-500" /> Recent & Active Shipments
                      </h5>
                      {partnerShipments.length === 0 ? (
                        <div className="text-center p-4 text-xs font-bold text-slate-400">Loading shipments...</div>
                      ) : (
                        <div className="space-y-3">
                          {partnerShipments.map((shipment: any) => (
                            <div key={shipment.id} className="p-4 bg-white border border-slate-200 rounded-xl hover:shadow-md transition-shadow">
                              <div className="flex justify-between items-start mb-2">
                                <div>
                                  <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-0.5">UAPS Tracking ID</div>
                                  <div className="font-mono text-sm font-bold text-slate-900">{shipment.tracking_id}</div>
                                </div>
                                <span className={`px-2 py-1 rounded text-[9px] font-black uppercase tracking-widest ${
                                  shipment.status === 'DELIVERED' ? 'bg-emerald-100 text-emerald-700' :
                                  shipment.status === 'IN_TRANSIT' ? 'bg-indigo-100 text-indigo-700' :
                                  'bg-amber-100 text-amber-700'
                                }`}>
                                  {shipment.status.replace(/_/g, ' ')}
                                </span>
                              </div>
                              <div className="flex items-center gap-2 text-xs font-medium text-slate-500 mb-4">
                                <span className="truncate max-w-[120px]">{shipment.origin}</span>
                                <div className="flex-1 border-t border-dashed border-slate-300 relative">
                                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-slate-300" />
                                </div>
                                <span className="truncate max-w-[120px]">{shipment.destination}</span>
                              </div>
                              <a 
                                href={`/?tracking=${shipment.tracking_id}`}
                                className="block w-full py-2 text-center bg-slate-50 hover:bg-slate-100 text-indigo-600 text-[10px] font-black uppercase tracking-widest rounded-lg transition-colors border border-slate-200"
                              >
                                Track Now
                              </a>
                            </div>
                          ))}
                        </div>
                      )}
                    </motion.div>
                  )}

                </motion.div>
              ))}
            </div>
          </div>
        )}

        {/* FOOTER ACTION */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 p-8 bg-white rounded-3xl border border-slate-200 shadow-sm">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-indigo-50 text-indigo-600 rounded-2xl">
              <Zap className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-bold text-slate-900 uppercase tracking-tight text-sm">Automated Governance Action</h4>
              <p className="text-slate-500 text-[10px] font-medium uppercase tracking-widest">System-wide fairness mitigation is currently active for Corridor: Lagos-Nairobi</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button className="px-6 py-3 bg-slate-900 text-white text-[10px] font-black uppercase tracking-widest rounded-xl hover:bg-slate-800 transition-all shadow-lg shadow-slate-200">
              Trigger Audit
            </button>
            <button className="px-6 py-3 bg-white text-slate-900 border border-slate-200 text-[10px] font-black uppercase tracking-widest rounded-xl hover:bg-slate-50 transition-all">
              View Evidence Store
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
