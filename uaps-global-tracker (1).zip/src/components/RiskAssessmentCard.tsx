import React from 'react';
import { motion } from 'motion/react';
import { 
  AlertTriangle, 
  Shield, 
  Target, 
  Eye, 
  Zap, 
  CheckCircle2, 
  Clock, 
  FileText, 
  BarChart3,
  Activity,
  Layers
} from 'lucide-react';

interface RiskAssessmentProps {
  event: any;
}

export function RiskAssessmentCard({ event }: RiskAssessmentProps) {
  const { 
    risk_id, 
    name,
    category, 
    owner,
    model_id, 
    description, 
    likelihood = { value: 'N/A', drivers: {} }, 
    impact = { value: 'N/A' }, 
    detectability = { value: 'N/A' }, 
    severity, 
    controls = { preventive: [], detective: [], corrective: [] }, 
    mitigation_strength = 'N/A', 
    evidence_refs = [], 
    status = 'ACTIVE',
    updated_at,
    last_reviewed_at,
    next_review_due_at
  } = event;

  // Handle case where controls is just an array
  const preventiveControls = Array.isArray(controls) ? controls : (controls.preventive || []);
  const detectiveControls = Array.isArray(controls) ? [] : (controls.detective || []);
  const correctiveControls = Array.isArray(controls) ? [] : (controls.corrective || []);

  const getSeverityColor = (sev: string) => {
    switch (sev) {
      case 'CRITICAL': return 'text-rose-600 bg-rose-50 border-rose-100';
      case 'HIGH': return 'text-amber-600 bg-amber-50 border-amber-100';
      default: return 'text-blue-600 bg-blue-50 border-blue-100';
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-[32px] border border-gray-100 shadow-xl overflow-hidden"
    >
      {/* Header */}
      <div className="p-6 bg-slate-900 text-white flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center">
            <AlertTriangle className="w-6 h-6 text-amber-400" />
          </div>
          <div>
            <h3 className="text-sm font-black uppercase tracking-tight">{name || `Risk Assessment: ${category.replace('_', ' ')}`}</h3>
            <p className="text-[10px] font-bold text-white/40 uppercase tracking-widest">
              {model_id} • {risk_id} • Owner: {owner || 'N/A'}
            </p>
          </div>
        </div>
        <div className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest flex items-center gap-2 ${
          severity === 'CRITICAL' ? 'bg-rose-500' : 'bg-amber-500'
        }`}>
          {severity} SEVERITY
        </div>
      </div>

      <div className="p-8 space-y-8">
        {/* Description */}
        <div className="p-6 bg-gray-50 rounded-3xl border border-gray-100">
          <p className="text-sm font-medium text-slate-700 italic">"{description}"</p>
        </div>

        {/* Risk Profile Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <RiskFactor 
            icon={<Zap className="w-4 h-4" />} 
            label="Likelihood" 
            value={likelihood.value} 
            color="text-amber-600"
            bg="bg-amber-50"
          />
          <RiskFactor 
            icon={<Target className="w-4 h-4" />} 
            label="Impact" 
            value={impact.value} 
            color="text-rose-600"
            bg="bg-rose-50"
          />
          <RiskFactor 
            icon={<Eye className="w-4 h-4" />} 
            label="Detectability" 
            value={detectability.value} 
            color="text-emerald-600"
            bg="bg-emerald-50"
          />
        </div>

        {/* Likelihood Drivers */}
        <div className="space-y-4">
          <h4 className="text-[10px] font-black text-slate-900 uppercase tracking-widest flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-blue-600" /> Likelihood Drivers
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {Object.entries(likelihood.drivers).map(([key, val]: [string, any]) => (
              <div key={key} className="p-4 bg-white border border-gray-100 rounded-2xl shadow-sm">
                <p className="text-[9px] font-bold text-gray-400 uppercase tracking-widest mb-1">{key.replace('_', ' ')}</p>
                <p className="text-lg font-black text-slate-900">{typeof val === 'number' ? val.toFixed(3) : val}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Controls Matrix */}
        <div className="space-y-4">
          <h4 className="text-[10px] font-black text-slate-900 uppercase tracking-widest flex items-center gap-2">
            <Layers className="w-4 h-4 text-emerald-600" /> Control Framework
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <ControlList title="Preventive" items={preventiveControls} color="text-blue-600" />
            <ControlList title="Detective" items={detectiveControls} color="text-amber-600" />
            <ControlList title="Corrective" items={correctiveControls} color="text-emerald-600" />
          </div>
        </div>

        {/* Mitigation Strength */}
        <div className="p-6 bg-emerald-50 rounded-3xl border border-emerald-100 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-emerald-600 shadow-sm">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <p className="text-[10px] font-bold text-emerald-600/60 uppercase tracking-widest">Mitigation Strength</p>
              <p className="text-sm font-black text-emerald-900 uppercase tracking-tight">{mitigation_strength}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
            <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">{status}</span>
          </div>
        </div>

        {/* Evidence Refs */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-3">
            <h4 className="text-[10px] font-black text-slate-900 uppercase tracking-widest flex items-center gap-2">
              <FileText className="w-4 h-4 text-slate-400" /> Evidence References
            </h4>
            <div className="space-y-2">
              {evidence_refs.map((ref: string, idx: number) => (
                <div key={idx} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl border border-gray-100">
                  <span className="text-[10px] font-bold text-slate-500 truncate max-w-[200px]">{ref}</span>
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-3">
            <h4 className="text-[10px] font-black text-slate-900 uppercase tracking-widest flex items-center gap-2">
              <Clock className="w-4 h-4 text-slate-400" /> Review Cycle
            </h4>
            <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100 space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-[9px] font-bold text-gray-400 uppercase tracking-widest">Last Reviewed</span>
                <span className="text-[10px] font-black text-slate-900">{last_reviewed_at ? new Date(last_reviewed_at).toLocaleDateString() : 'N/A'}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[9px] font-bold text-gray-400 uppercase tracking-widest">Next Review Due</span>
                <span className="text-[10px] font-black text-amber-600">{next_review_due_at ? new Date(next_review_due_at).toLocaleDateString() : 'N/A'}</span>
              </div>
              <div className="flex justify-between items-center pt-2 border-t border-gray-200">
                <span className="text-[9px] font-bold text-gray-400 uppercase tracking-widest">Last Updated</span>
                <span className="text-[10px] font-black text-slate-500">{updated_at ? new Date(updated_at).toLocaleDateString() : 'N/A'}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function RiskFactor({ icon, label, value, color, bg }: any) {
  return (
    <div className={`p-4 ${bg} rounded-2xl border border-gray-100 flex items-center gap-4`}>
      <div className={`w-10 h-10 bg-white rounded-xl flex items-center justify-center ${color} shadow-sm`}>
        {icon}
      </div>
      <div>
        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{label}</p>
        <p className={`text-sm font-black ${color} uppercase tracking-tight`}>{value}</p>
      </div>
    </div>
  );
}

function ControlList({ title, items, color }: any) {
  return (
    <div className="space-y-2">
      <p className={`text-[9px] font-black ${color} uppercase tracking-widest mb-2`}>{title}</p>
      <div className="space-y-1.5">
        {items.map((item: string, idx: number) => (
          <div key={idx} className="flex items-center gap-2">
            <div className={`w-1 h-1 rounded-full ${color.replace('text', 'bg')}`} />
            <span className="text-[10px] font-bold text-slate-600">{item}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
