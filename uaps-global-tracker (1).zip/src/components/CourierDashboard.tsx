import React, { useEffect, useState } from "react";
import { Logo } from "./Logo";
import { CourierMap } from "./CourierMap";
import { RouteOptimizer } from "./RouteOptimizer";
import { Sparkles, Activity, RefreshCw, Package, Truck, CheckCircle, MapPin, Camera, PenTool, DollarSign, Star, Clock, User, Shield, Award } from "lucide-react";
import { motion } from "motion/react";
import { optimizeMultiStopRoute } from "../services/routeService";
import { ProofOfDeliveryModal } from './ProofOfDeliveryModal';

interface Delivery {
  id: string;
  pickupAddress: string;
  dropoffAddress: string;
  senderName?: string;
  senderPhone?: string;
  receiverName?: string;
  receiverPhone?: string;
  status: string;
  dimensions?: string;
  weight?: string;
  handlingInstructions?: string;
}

const COURIER_ID = "courier-123"; // later: from auth

export function CourierDashboard() {
  const [available, setAvailable] = useState<Delivery[]>([]);
  const [mine, setMine] = useState<Delivery[]>([]);
  const [loading, setLoading] = useState(true);
  const [updatingJobId, setUpdatingJobId] = useState<string | null>(null);
  const [showPlanner, setShowPlanner] = useState(false);
  const [pos, setPos] = useState<{ lat: number; lng: number } | null>(null);
  const [optimizedRoute, setOptimizedRoute] = useState<{ lat: number; lng: number }[]>([]);
  const [routeExplanation, setRouteExplanation] = useState<string>("");
  const [isSimulating, setIsSimulating] = useState(false);
  const [simInterval, setSimInterval] = useState<NodeJS.Timeout | null>(null);
  const [isProofModalOpen, setIsProofModalOpen] = useState(false);
  const [selectedJobForProof, setSelectedJobForProof] = useState<string | null>(null);
  const [plannerData, setPlannerData] = useState({
    start: "Lagos, Nigeria",
    end: "Accra, Ghana",
    vehicle: "Motorcycle",
    traffic: "Moderate",
    roadData: {
      blockedRoads: ["Benin City – Ore Road"],
      unpavedSegments: ["Seme Border – Lomé"],
      safeZones: ["Lekki", "Tema"],
      tollRoads: ["Lekki Toll Gate"]
    }
  });
  const [liveLocation, setLiveLocation] = useState<{ lat: number; lng: number } | null>(null);

  useEffect(() => {
    const fetchLiveLocation = async () => {
      try {
        const res = await fetch(`/api/courier/location/${COURIER_ID}`);
        const __dataBody = await res.json();
      const data = __dataBody.data || __dataBody;
        if (data) setLiveLocation(data);
      } catch (error) {
        console.error("Failed to fetch live location:", error);
      }
    };
    fetchLiveLocation();
    const interval = setInterval(fetchLiveLocation, 3000);
    return () => clearInterval(interval);
  }, []);

  const loadJobs = async () => {
    try {
      const res = await fetch(`/api/courier/jobs?courierId=${COURIER_ID}`);
      const __dataBody = await res.json();
      const data = __dataBody.data || __dataBody;
      setAvailable(data.available || []);
      setMine(data.mine || []);
    } catch (error) {
      console.error("Failed to load jobs:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadJobs();
  }, []);

  useEffect(() => {
    const watch = navigator.geolocation.watchPosition(
      async (p) => {
        const newPos = { lat: p.coords.latitude, lng: p.coords.longitude };
        setPos(newPos);
        try {
          await fetch("/api/courier/location", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              courierId: COURIER_ID,
              lat: newPos.lat,
              lng: newPos.lng,
            }),
          });
        } catch (error) {
          console.error("Failed to send location:", error);
        }
      },
      (err) => console.error(err),
      { enableHighAccuracy: true }
    );

    return () => navigator.geolocation.clearWatch(watch);
  }, []);

  const acceptJob = async (id: string) => {
    try {
      await fetch(`/api/courier/jobs/${id}/accept`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ courierId: COURIER_ID }),
      });
      loadJobs();
    } catch (error) {
      console.error("Failed to accept job:", error);
    }
  };

  const updateStatus = async (id: string, status: string, proof?: any) => {
    setUpdatingJobId(id);
    try {
      await fetch(`/api/courier/jobs/${id}/status`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status, proof }),
      });
      await loadJobs();
      setIsProofModalOpen(false);
      setSelectedJobForProof(null);
    } catch (error) {
      console.error("Failed to update status:", error);
    } finally {
      setUpdatingJobId(null);
    }
  };

  const handleDeliveredClick = (id: string) => {
    setSelectedJobForProof(id);
    setIsProofModalOpen(true);
  };

  const optimizeRoute = async (job?: any) => {
    try {
      const start = job ? job.pickupAddress : (pos ? `${pos.lat}, ${pos.lng}` : plannerData.start);
      const end = job ? job.dropoffAddress : plannerData.end;
      const vehicle = job ? "motorbike" : plannerData.vehicle;
      const traffic = job ? "moderate" : plannerData.traffic;
      const roadData = job ? { condition: "Paved with some potholes", weather: "Clear" } : plannerData.roadData;

      const res = await fetch("/api/optimize-route", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          start,
          end,
          courier: { vehicle },
          traffic,
          roadData
        }),
      });

      const __dataBody = await res.json();
      const data = __dataBody.data || __dataBody;
      setOptimizedRoute(data.route);
    } catch (error) {
      console.error("Failed to optimize route:", error);
    }
  };

  const optimizeMultiStop = async () => {
    if (!pos || mine.length === 0) return;

    try {
      // Mocking stops from active jobs for demonstration
      const myStops = mine.map((job, index) => ({
        id: job.id,
        lat: pos.lat + (index + 1) * 0.01, // Mocked offset
        lng: pos.lng + (index + 1) * 0.01, // Mocked offset
        label: `Job #${job.id} Dropoff`,
        priority: (index === 0 ? "high" : "normal") as "high" | "normal"
      }));

      const data = await optimizeMultiStopRoute({
        start: pos,
        stops: myStops,
        vehicle: "bike",
        city: "Nairobi",
      });
      
      setOptimizedRoute(data.route);
      setRouteExplanation(data.summary);
    } catch (error) {
      console.error("Multi-stop optimization failed:", error);
    }
  };

  const startSimulation = (job: Delivery) => {
    if (isSimulating) {
      if (simInterval) clearInterval(simInterval);
      setIsSimulating(false);
      return;
    }

    setIsSimulating(true);
    // Mock destination
    const dest = { lat: -1.286389, lng: 36.817223 };
    let currentPos = pos || { lat: -1.386389, lng: 36.867223 };

    const interval = setInterval(async () => {
      const step = 0.0005;
      const dLat = dest.lat - currentPos.lat;
      const dLng = dest.lng - currentPos.lng;
      const dist = Math.sqrt(dLat * dLat + dLng * dLng);

      if (dist < step) {
        clearInterval(interval);
        setIsSimulating(false);
        updateStatus(job.id, "DELIVERED");
        return;
      }

      currentPos = {
        lat: currentPos.lat + (dLat / dist) * step,
        lng: currentPos.lng + (dLng / dist) * step,
      };

      setPos(currentPos);
      try {
        await fetch("/api/courier/location", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            courierId: COURIER_ID,
            lat: currentPos.lat,
            lng: currentPos.lng,
          }),
        });
      } catch (error) {
        console.error("Failed to send simulated location:", error);
      }
    }, 2000);

    setSimInterval(interval);
  };

  useEffect(() => {
    return () => {
      if (simInterval) clearInterval(simInterval);
    };
  }, [simInterval]);

  const stats = [
    { label: "Today's Earnings", value: "$142.50", icon: DollarSign, color: "text-emerald-600", bg: "bg-emerald-50" },
    { label: "Jobs Completed", value: "12", icon: CheckCircle, color: "text-blue-600", bg: "bg-blue-50" },
    { label: "Rating", value: "4.9", icon: Star, color: "text-amber-500", bg: "bg-amber-50" },
    { label: "On-Time Rate", value: "98%", icon: Clock, color: "text-purple-600", bg: "bg-purple-50" },
  ];

  if (loading) {
    return <div className="p-8 text-center text-gray-500">Loading courier dashboard...</div>;
  }

  return (
    <div className="bg-[#f8fafc] min-h-screen pb-20">
      {/* Dashboard Header */}
      <div className="bg-white border-b border-gray-200 px-8 py-6 sticky top-0 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex items-center gap-6">
            <Logo size="md" />
            <div className="h-10 w-px bg-gray-100 hidden md:block" />
            <div>
              <div className="flex items-center gap-3 mb-1">
                <h2 className="text-xl font-bold text-[#1a365d]">Courier Command</h2>
                <span className="px-2 py-0.5 bg-emerald-100 text-emerald-700 text-[10px] font-bold rounded-full flex items-center gap-1">
                  <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
                  ONLINE
                </span>
              </div>
              <p className="text-xs text-gray-500">Welcome back, Leslie Alexander. You have {mine.length} active jobs.</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right hidden sm:block relative group cursor-help">
              <p className="text-xs font-bold text-[#1a365d]">Leslie Alexander</p>
              <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Elite Partner</p>
              
              {/* Tooltip */}
              <div className="absolute top-full right-0 mt-2 w-48 bg-gray-900 text-white p-3 rounded-lg shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-50 text-left">
                <p className="text-xs font-bold mb-1">Vehicle: Electric Van</p>
                <p className="text-[10px] text-gray-300">License: KCD 123X</p>
                <p className="text-[10px] text-gray-300">Capacity: 1500kg</p>
                <div className="mt-2 pt-2 border-t border-gray-700">
                  <p className="text-[10px] text-emerald-400 font-bold">Status: Active & Insured</p>
                </div>
              </div>
            </div>
            <div className="w-10 h-10 rounded-full bg-gray-100 border-2 border-white shadow-sm overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=facearea&facepad=2&w=100&h=100&q=80" 
                alt="Profile" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <button 
              onClick={loadJobs}
              className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all"
            >
              <RefreshCw className={`w-5 h-5 ${loading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-8 py-8 space-y-8">
        {/* Quick Stats Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm"
            >
              <div className="flex justify-between items-start mb-4">
                <div className={`p-2 rounded-lg ${stat.bg}`}>
                  <stat.icon className={`w-5 h-5 ${stat.color}`} />
                </div>
              </div>
              <p className="text-2xl font-bold text-[#1a365d] mb-1">{stat.value}</p>
              <p className="text-[10px] uppercase tracking-widest text-gray-400 font-bold">{stat.label}</p>
            </motion.div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content Area */}
          <div className="lg:col-span-2 space-y-8">
            {/* Live Location Map */}
            <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
                <h3 className="text-sm font-bold text-[#1a365d] uppercase tracking-widest flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-emerald-500" /> Live Location Tracking
                </h3>
                {liveLocation && (
                  <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                    {liveLocation.lat.toFixed(4)}, {liveLocation.lng.toFixed(4)}
                  </span>
                )}
              </div>
              <div className="h-64 w-full bg-gray-100 relative">
                <CourierMap courierId={COURIER_ID} optimizedPoints={optimizedRoute} />
              </div>
            </div>

            {/* Active Jobs Section */}
            <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
                <h3 className="text-sm font-bold text-[#1a365d] uppercase tracking-widest flex items-center gap-2">
                  <Activity className="w-4 h-4 text-blue-500" /> Current Active Jobs
                </h3>
              </div>
              <div className="p-6">
                {mine.length > 0 ? (
                  <div className="space-y-6">
                    {mine.map((job) => (
                      <div key={job.id} className="bg-gray-50 rounded-xl p-6 border border-gray-100">
                        <div className="flex flex-col md:flex-row justify-between gap-6">
                          <div className="flex-1 space-y-4">
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-bold text-blue-600 bg-blue-50 px-2 py-1 rounded">#{job.id}</span>
                              <span className="text-xs font-bold text-gray-500">{job.weight || '2.5kg'} • {job.dimensions || '30x20x15cm'}</span>
                            </div>
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div className="space-y-1">
                                <p className="text-[10px] uppercase font-bold text-gray-400">Pickup From</p>
                                <p className="text-sm font-bold text-[#1a365d]">{job.senderName || 'Sender'}</p>
                                <p className="text-xs text-gray-500 leading-relaxed">{job.pickupAddress}</p>
                                <p className="text-xs font-bold text-blue-600">{job.senderPhone}</p>
                              </div>
                              <div className="space-y-1">
                                <p className="text-[10px] uppercase font-bold text-gray-400">Deliver To</p>
                                <p className="text-sm font-bold text-[#1a365d]">{job.receiverName || 'Receiver'}</p>
                                <p className="text-xs text-gray-500 leading-relaxed">{job.dropoffAddress}</p>
                                <p className="text-xs font-bold text-blue-600">{job.receiverPhone}</p>
                              </div>
                            </div>

                            {/* Status Progress */}
                            <div className="pt-4 space-y-4">
                              <div className="flex justify-between items-center mb-2">
                                <span className="text-xs font-bold text-gray-600">Delivery Progress</span>
                                <span className="text-xs font-bold text-[#1a365d]">{job.status.replace('_', ' ')}</span>
                              </div>
                              <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                                <motion.div 
                                  className="h-full bg-[#1a365d]"
                                  initial={{ width: 0 }}
                                  animate={{ 
                                    width: job.status === 'PICKED_UP' ? '33%' : 
                                           job.status === 'IN_TRANSIT' ? '66%' : 
                                           job.status === 'DELIVERED' ? '100%' : '10%' 
                                  }}
                                />
                              </div>
                              
                              <div className="flex flex-wrap gap-2 pt-2">
                                {job.status === 'ACCEPTED' && (
                                  <button 
                                    onClick={() => updateStatus(job.id, 'PICKED_UP')}
                                    disabled={updatingJobId === job.id}
                                    className="flex-1 bg-[#1a365d] text-white py-2.5 rounded-lg text-xs font-bold hover:bg-[#2a4a7d] transition-all flex items-center justify-center gap-2"
                                  >
                                    {updatingJobId === job.id ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Package className="w-3 h-3" />}
                                    Mark as Picked Up
                                  </button>
                                )}
                                {job.status === 'PICKED_UP' && (
                                  <button 
                                    onClick={() => updateStatus(job.id, 'IN_TRANSIT')}
                                    disabled={updatingJobId === job.id}
                                    className="flex-1 bg-blue-600 text-white py-2.5 rounded-lg text-xs font-bold hover:bg-blue-700 transition-all flex items-center justify-center gap-2"
                                  >
                                    {updatingJobId === job.id ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Truck className="w-3 h-3" />}
                                    Start Transit
                                  </button>
                                )}
                                {job.status === 'IN_TRANSIT' && (
                                  <button 
                                    onClick={() => handleDeliveredClick(job.id)}
                                    disabled={updatingJobId === job.id}
                                    className="flex-1 bg-emerald-600 text-white py-2.5 rounded-lg text-xs font-bold hover:bg-emerald-700 transition-all flex items-center justify-center gap-2"
                                  >
                                    {updatingJobId === job.id ? <RefreshCw className="w-3 h-3 animate-spin" /> : <CheckCircle className="w-3 h-3" />}
                                    Complete Delivery
                                  </button>
                                )}
                                <button 
                                  onClick={() => startSimulation(job)}
                                  className={`px-4 py-2.5 rounded-lg text-xs font-bold border transition-all flex items-center gap-2 ${isSimulating ? 'bg-red-50 border-red-200 text-red-600' : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'}`}
                                >
                                  <Activity className={`w-3 h-3 ${isSimulating ? 'animate-pulse' : ''}`} />
                                  {isSimulating ? 'Stop Sim' : 'Simulate Move'}
                                </button>
                              </div>
                            </div>
                          </div>

                          <div className="w-full md:w-72 h-48 md:h-auto bg-gray-200 rounded-xl overflow-hidden border border-gray-100 shadow-inner">
                            <CourierMap courierId={COURIER_ID} optimizedPoints={optimizedRoute} />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Truck className="w-8 h-8 text-gray-300" />
                    </div>
                    <p className="text-sm font-bold text-gray-400">No active jobs. Accept one from the list below.</p>
                  </div>
                )}
              </div>
            </div>

            {/* Available Jobs Section */}
            <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center">
                <h3 className="text-sm font-bold text-[#1a365d] uppercase tracking-widest">Available Jobs Near You</h3>
                <span className="px-2 py-1 bg-blue-50 text-blue-600 text-[10px] font-bold rounded-full">{available.length} New Jobs</span>
              </div>
              <div className="divide-y divide-gray-100">
                {available.length > 0 ? (
                  available.map((job) => (
                    <div key={job.id} className="p-6 hover:bg-gray-50 transition-colors group">
                      <div className="flex flex-col md:flex-row justify-between gap-4">
                        <div className="flex-1 space-y-3">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-[#1a365d]">#{job.id}</span>
                            <span className="px-2 py-0.5 bg-gray-100 text-gray-500 text-[10px] font-bold rounded uppercase tracking-tighter">Priority</span>
                          </div>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="flex items-start gap-2">
                              <MapPin className="w-3.5 h-3.5 text-blue-500 mt-0.5" />
                              <div>
                                <p className="text-[10px] uppercase font-bold text-gray-400">Pickup</p>
                                <p className="text-xs text-gray-600">{job.pickupAddress}</p>
                              </div>
                            </div>
                            <div className="flex items-start gap-2">
                              <MapPin className="w-3.5 h-3.5 text-emerald-500 mt-0.5" />
                              <div>
                                <p className="text-[10px] uppercase font-bold text-gray-400">Dropoff</p>
                                <p className="text-xs text-gray-600">{job.dropoffAddress}</p>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="flex flex-col justify-center gap-2">
                          <div className="text-right mb-2">
                            <p className="text-sm font-bold text-[#1a365d]">$24.50</p>
                            <p className="text-[10px] text-gray-400 font-bold">Estimated Pay</p>
                          </div>
                          <button 
                            onClick={() => acceptJob(job.id)}
                            className="bg-[#1a365d] text-white px-6 py-2 rounded-lg text-xs font-bold hover:bg-[#2a4a7d] transition-all shadow-sm"
                          >
                            Accept Job
                          </button>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="p-12 text-center text-gray-400 text-sm font-bold">
                    Searching for new jobs in your area...
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Sidebar Area */}
          <div className="space-y-8">
            {/* Profile Card */}
            <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
              <div className="h-20 bg-[#1a365d] relative">
                <div className="absolute -bottom-6 left-6 w-16 h-16 rounded-xl bg-white p-1 shadow-md">
                  <div className="w-full h-full rounded-lg bg-gray-100 overflow-hidden">
                    <img 
                      src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=facearea&facepad=2&w=100&h=100&q=80" 
                      alt="Profile" 
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                </div>
              </div>
              <div className="pt-10 p-6 space-y-4">
                <div className="relative group cursor-help inline-block">
                  <h4 className="text-base font-bold text-[#1a365d]">Leslie Alexander</h4>
                  <p className="text-xs text-gray-500">ID: COU-88273-LA</p>
                  
                  {/* Tooltip */}
                  <div className="absolute left-0 bottom-full mb-2 w-48 bg-gray-900 text-white p-3 rounded-lg shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-50 text-left">
                    <p className="text-xs font-bold mb-1">Vehicle: Electric Van</p>
                    <p className="text-[10px] text-gray-300">License: KCD 123X</p>
                    <p className="text-[10px] text-gray-300">Capacity: 1500kg</p>
                    <div className="mt-2 pt-2 border-t border-gray-700">
                      <p className="text-[10px] text-emerald-400 font-bold">Status: Active & Insured</p>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex text-amber-400">
                    {[1,2,3,4,5].map(i => <Star key={i} className="w-3 h-3 fill-current" />)}
                  </div>
                  <span className="text-xs font-bold text-gray-600">4.9 (128 reviews)</span>
                </div>
                <div className="space-y-2 pt-2">
                  <div className="flex items-center gap-3 text-xs text-gray-600">
                    <Shield className="w-4 h-4 text-emerald-500" />
                    <span>Verified Partner</span>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-gray-600">
                    <Award className="w-4 h-4 text-blue-500" />
                    <span>Top Rated Courier 2024</span>
                  </div>
                </div>
                <button className="w-full py-2 border border-gray-200 rounded-lg text-xs font-bold text-gray-600 hover:bg-gray-50 transition-all">
                  Edit Profile
                </button>
              </div>
            </div>

            {/* AI Route Planner Card */}
            <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
              <div className="p-6 border-b border-gray-100 bg-gradient-to-br from-blue-50 to-indigo-50">
                <div className="flex items-center gap-2 mb-2">
                  <Sparkles className="w-5 h-5 text-blue-600" />
                  <h3 className="text-sm font-bold text-[#1a365d] uppercase tracking-widest">AI Route Planner</h3>
                </div>
                <p className="text-xs text-gray-500 leading-relaxed">Optimize your multi-stop route using Gemini AI for maximum efficiency.</p>
              </div>
              <div className="p-6 space-y-4">
                <button 
                  onClick={() => setShowPlanner(!showPlanner)}
                  className="w-full bg-white border border-blue-200 text-blue-600 py-3 rounded-xl text-xs font-bold hover:bg-blue-50 transition-all flex items-center justify-center gap-2 shadow-sm"
                >
                  <RefreshCw className={`w-4 h-4 ${showPlanner ? 'rotate-180' : ''} transition-transform`} />
                  {showPlanner ? 'Hide Planner' : 'Open Route Planner'}
                </button>
                
                {showPlanner && (
                  <motion.div 
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="space-y-4 pt-4 border-t border-gray-100"
                  >
                    <RouteOptimizer 
                      start={plannerData.start}
                      end={plannerData.end}
                      vehicle={plannerData.vehicle}
                      traffic={plannerData.traffic}
                      roadData={plannerData.roadData}
                      onRouteOptimized={setOptimizedRoute}
                    />
                    <button 
                      onClick={optimizeMultiStop}
                      className="w-full bg-blue-600 text-white py-3 rounded-xl text-xs font-bold hover:bg-blue-700 transition-all shadow-md"
                    >
                      Optimize All Active Jobs
                    </button>
                  </motion.div>
                )}

                {routeExplanation && (
                  <div className="bg-emerald-50 p-4 rounded-xl border border-emerald-100">
                    <p className="text-[10px] uppercase font-bold text-emerald-700 mb-2">AI Recommendation</p>
                    <p className="text-xs text-emerald-800 leading-relaxed italic">"{routeExplanation}"</p>
                  </div>
                )}
              </div>
            </div>

            {/* Support Card */}
            <div className="bg-gray-900 rounded-2xl p-6 text-white shadow-xl relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-full -mr-16 -mt-16 blur-2xl group-hover:bg-blue-500/20 transition-all" />
              <h4 className="text-sm font-bold mb-2 relative z-10">Need Help?</h4>
              <p className="text-xs text-gray-400 mb-4 relative z-10">Our 24/7 support team is here to assist you with any issues.</p>
              <button className="w-full py-2.5 bg-white text-gray-900 rounded-lg text-xs font-bold hover:bg-gray-100 transition-all relative z-10">
                Contact Support
              </button>
            </div>
          </div>
        </div>
      </div>

      <ProofOfDeliveryModal 
        isOpen={isProofModalOpen}
        onClose={() => {
          setIsProofModalOpen(false);
          setSelectedJobForProof(null);
        }}
        onConfirm={(proof) => {
          if (selectedJobForProof) {
            updateStatus(selectedJobForProof, "DELIVERED", proof);
          }
        }}
        jobId={selectedJobForProof || ''}
      />
    </div>
  );
}
