import React from 'react';
import { motion } from 'motion/react';
import { MapPin, Clock, AlertTriangle, Shield, CloudLightning, Activity, TrendingUp, AlertCircle, CheckCircle2 } from 'lucide-react';
import { FleetMap } from './FleetMap';

export function NetworkIntelligence() {
  return (
    <div className="space-y-8">
      {/* Top Section: Map & Live Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white rounded-3xl border border-gray-200 shadow-sm overflow-hidden flex flex-col">
          <div className="p-6 border-b border-gray-100 flex items-center justify-between">
            <div>
              <h3 className="text-lg font-black text-[#1a365d]">Pan-African Network Map</h3>
              <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mt-1">Live Corridor Risk & Shipments</p>
            </div>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-emerald-500 rounded-full" />
                <span className="text-[10px] font-bold text-gray-500 uppercase">Low Risk</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-amber-500 rounded-full" />
                <span className="text-[10px] font-bold text-gray-500 uppercase">Moderate</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-rose-500 rounded-full" />
                <span className="text-[10px] font-bold text-gray-500 uppercase">High Risk</span>
              </div>
            </div>
          </div>
          <div className="flex-1 min-h-[400px] relative bg-gray-50">
            <FleetMap />
            {/* Overlay for Route Planning */}
            <div className="absolute top-4 left-4 right-4 bg-white/90 backdrop-blur-sm p-4 rounded-2xl border border-gray-200 shadow-lg">
              <div className="flex items-center justify-between mb-3">
                <h4 className="text-xs font-black text-[#1a365d] uppercase tracking-widest flex items-center gap-2">
                  <Activity className="w-4 h-4 text-blue-600" /> Active Route Plan: route-456
                </h4>
                <span className="px-2 py-1 bg-blue-50 text-blue-600 rounded-lg text-[9px] font-black uppercase tracking-widest border border-blue-100">
                  ETA: 2026-04-17 09:00Z
                </span>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <p className="text-[9px] font-bold text-gray-400 uppercase tracking-widest mb-1">Origin</p>
                  <p className="text-sm font-black text-[#1a365d]">Rotterdam</p>
                </div>
                <div>
                  <p className="text-[9px] font-bold text-gray-400 uppercase tracking-widest mb-1">Destination</p>
                  <p className="text-sm font-black text-[#1a365d]">Kigali</p>
                </div>
                <div>
                  <p className="text-[9px] font-bold text-gray-400 uppercase tracking-widest mb-1">Risk Score</p>
                  <p className="text-sm font-black text-amber-600">0.24</p>
                </div>
                <div>
                  <p className="text-[9px] font-bold text-gray-400 uppercase tracking-widest mb-1">Reliability</p>
                  <p className="text-sm font-black text-emerald-600">81%</p>
                </div>
              </div>
              <div className="mt-4 pt-4 border-t border-gray-100">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Legs:</span>
                  <span className="px-2 py-1 bg-gray-100 text-gray-600 rounded-md text-[10px] font-bold">SEA: Rotterdam → Lome (Maersk)</span>
                  <span className="text-gray-300">→</span>
                  <span className="px-2 py-1 bg-gray-100 text-gray-600 rounded-md text-[10px] font-bold">ROAD: Lome → Kigali (Reload Logistics)</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-gray-200 shadow-sm">
            <h3 className="text-sm font-black text-[#1a365d] uppercase tracking-widest mb-4 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-500" /> Active Alerts
            </h3>
            <div className="space-y-4">
              <div className="p-4 bg-rose-50 rounded-2xl border border-rose-100">
                <div className="flex items-center gap-2 mb-2">
                  <Shield className="w-4 h-4 text-rose-600" />
                  <span className="text-xs font-black text-rose-900">Security Alert</span>
                </div>
                <p className="text-sm text-rose-800 font-medium">Elevated risk reported on Northern Corridor. Recommendation: Switch to Central Corridor.</p>
              </div>
              <div className="p-4 bg-amber-50 rounded-2xl border border-amber-100">
                <div className="flex items-center gap-2 mb-2">
                  <CloudLightning className="w-4 h-4 text-amber-600" />
                  <span className="text-xs font-black text-amber-900">Weather Warning</span>
                </div>
                <p className="text-sm text-amber-800 font-medium">Heavy rainfall expected near Rusumo border. Potential delays of 2-4 hours.</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-gray-200 shadow-sm">
            <h3 className="text-sm font-black text-[#1a365d] uppercase tracking-widest mb-4 flex items-center gap-2">
              <MapPin className="w-4 h-4 text-blue-500" /> Corridor Risk Analysis
            </h3>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-xs font-bold mb-1">
                  <span className="text-gray-600">Northern Corridor</span>
                  <span className="text-rose-600">0.41 Risk</span>
                </div>
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full bg-rose-500 w-[41%]" />
                </div>
                <div className="flex gap-2 mt-2">
                  <span className="text-[9px] font-bold text-gray-400 uppercase">Border: 0.22</span>
                  <span className="text-[9px] font-bold text-gray-400 uppercase">Weather: 0.11</span>
                  <span className="text-[9px] font-bold text-gray-400 uppercase">Security: 0.08</span>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-xs font-bold mb-1">
                  <span className="text-gray-600">Central Corridor</span>
                  <span className="text-amber-500">0.28 Risk</span>
                </div>
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full bg-amber-500 w-[28%]" />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-xs font-bold mb-1">
                  <span className="text-gray-600">Lome-Ouaga</span>
                  <span className="text-emerald-500">0.15 Risk</span>
                </div>
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full bg-emerald-500 w-[15%]" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Middle Section: Operational Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-3xl border border-gray-200 shadow-sm">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-amber-50 rounded-xl">
              <Clock className="w-5 h-5 text-amber-600" />
            </div>
            <div>
              <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Border Wait Times</h4>
              <p className="text-2xl font-black text-[#1a365d]">2.4h <span className="text-sm text-gray-400 font-medium">avg</span></p>
            </div>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-bold">
              <span className="text-gray-600">Rusumo</span>
              <span className="text-amber-600">1.8h</span>
            </div>
            <div className="flex justify-between text-xs font-bold">
              <span className="text-gray-600">Malaba</span>
              <span className="text-rose-600">4.2h</span>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-gray-200 shadow-sm">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-blue-50 rounded-xl">
              <Activity className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Port Congestion</h4>
              <p className="text-2xl font-black text-[#1a365d]">82% <span className="text-sm text-gray-400 font-medium">capacity</span></p>
            </div>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-bold">
              <span className="text-gray-600">Mombasa</span>
              <span className="text-rose-600">94%</span>
            </div>
            <div className="flex justify-between text-xs font-bold">
              <span className="text-gray-600">Lome</span>
              <span className="text-emerald-600">65%</span>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-gray-200 shadow-sm">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-indigo-50 rounded-xl">
              <CloudLightning className="w-5 h-5 text-indigo-600" />
            </div>
            <div>
              <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Weather Impact</h4>
              <p className="text-2xl font-black text-[#1a365d]">Low</p>
            </div>
          </div>
          <p className="text-xs text-gray-500 font-medium">No major weather disruptions across primary corridors.</p>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-gray-200 shadow-sm">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-rose-50 rounded-xl">
              <Shield className="w-5 h-5 text-rose-600" />
            </div>
            <div>
              <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Security Index</h4>
              <p className="text-2xl font-black text-[#1a365d]">94/100</p>
            </div>
          </div>
          <p className="text-xs text-gray-500 font-medium">1 active alert on Northern Corridor. All other routes secure.</p>
        </div>
      </div>

      {/* Bottom Section: Partner & Trends */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-3xl border border-gray-200 shadow-sm">
          <h3 className="text-sm font-black text-[#1a365d] uppercase tracking-widest mb-6 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-500" /> Partner Reliability
          </h3>
          <div className="space-y-4">
            {[
              { name: 'AGL Logistics', score: 92, trend: '+2%' },
              { name: 'Reload Logistics', score: 88, trend: '+5%' },
              { name: 'Maersk', score: 95, trend: '0%' },
            ].map((partner) => (
              <div key={partner.name} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl border border-gray-100">
                <span className="text-sm font-bold text-[#1a365d]">{partner.name}</span>
                <div className="flex items-center gap-4">
                  <span className="text-sm font-black text-[#1a365d]">{partner.score}/100</span>
                  <span className={`text-xs font-bold ${partner.trend.startsWith('+') ? 'text-emerald-600' : 'text-gray-500'}`}>{partner.trend}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-gray-200 shadow-sm">
          <h3 className="text-sm font-black text-[#1a365d] uppercase tracking-widest mb-6 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-blue-500" /> Corridor Trends
          </h3>
          <div className="space-y-4">
            <div className="p-4 bg-blue-50 rounded-2xl border border-blue-100">
              <p className="text-xs font-bold text-blue-900 mb-1">Central Corridor Volume</p>
              <p className="text-2xl font-black text-blue-600">+14% <span className="text-sm font-medium text-blue-800">MoM</span></p>
            </div>
            <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-100">
              <p className="text-xs font-bold text-emerald-900 mb-1">Avg Transit Time (Lome-Kigali)</p>
              <p className="text-2xl font-black text-emerald-600">-1.2 <span className="text-sm font-medium text-emerald-800">Days</span></p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-gray-200 shadow-sm">
          <h3 className="text-sm font-black text-[#1a365d] uppercase tracking-widest mb-6 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-500" /> SLA Breaches
          </h3>
          <div className="flex items-center justify-center h-32">
            <div className="text-center">
              <p className="text-4xl font-black text-rose-600 mb-2">2</p>
              <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Active Breaches</p>
            </div>
          </div>
          <div className="mt-4 space-y-2">
            <div className="text-xs font-medium text-gray-600 flex justify-between">
              <span>EXD-928179 (Customs Hold)</span>
              <span className="text-rose-600 font-bold">+24h</span>
            </div>
            <div className="text-xs font-medium text-gray-600 flex justify-between">
              <span>EXD-928182 (Port Delay)</span>
              <span className="text-rose-600 font-bold">+12h</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
