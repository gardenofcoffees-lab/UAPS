import React, { useState, useEffect } from 'react';
import { Package, Truck, CheckCircle, Clock, AlertTriangle, Send, Map as MapIcon } from 'lucide-react';

interface Activity {
  id: string | number;
  type: string;
  packageId: string;
  location: string;
  time: string;
  severity?: string;
}

const initialActivities: Activity[] = [
  { id: 1, type: 'PICKED_UP', packageId: 'UAPS-NG-2024-817263', location: 'Lagos, Nigeria', time: '2 mins ago' },
  { id: 2, type: 'IN_TRANSIT', packageId: 'UAPS-KE-2024-918273', location: 'Nairobi, Kenya', time: '15 mins ago' },
  { id: 3, type: 'DELIVERED', packageId: 'UAPS-ZA-2024-102938', location: 'Johannesburg, SA', time: '45 mins ago' },
  { id: 4, type: 'NEW', packageId: 'UAPS-EG-2024-112233', location: 'Cairo, Egypt', time: '1 hour ago' },
  { id: 5, type: 'PICKED_UP', packageId: 'UAPS-GH-2024-445566', location: 'Accra, Ghana', time: '2 hours ago' },
];

export function RecentActivity() {
  const [activities, setActivities] = useState<Activity[]>(initialActivities);

  useEffect(() => {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const ws = new WebSocket(`${protocol}//${window.location.host}`);

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        let newActivity: Activity | null = null;

        if (data.type === 'safety_event' || data.type === 'safety_event_grpc') {
          newActivity = {
            id: Date.now(),
            type: `SAFETY_${data.event.severity}`,
            packageId: data.drone_id,
            location: data.event.type,
            time: 'Just now',
            severity: data.event.severity
          };
        } else if (data.type === 'command_ack') {
          newActivity = {
            id: Date.now(),
            type: 'COMMAND_ACK',
            packageId: data.drone_id,
            location: data.success ? 'Command Executed' : 'Command Failed',
            time: 'Just now'
          };
        } else if (data.type === 'route_computed') {
          newActivity = {
            id: Date.now(),
            type: 'ROUTE_COMPUTED',
            packageId: data.delivery_id,
            location: 'Autonomous Path Optimized',
            time: 'Just now'
          };
        }

        if (newActivity) {
          setActivities(prev => [newActivity!, ...prev].slice(0, 15));
        }
      } catch (err) {
        console.error("RecentActivity WS Error:", err);
      }
    };

    return () => ws.close();
  }, []);

  const getIcon = (type: string) => {
    if (type.startsWith('SAFETY')) return <AlertTriangle className="w-4 h-4 text-red-500" />;
    switch (type) {
      case 'PICKED_UP': return <Package className="w-4 h-4 text-blue-500" />;
      case 'IN_TRANSIT': return <Truck className="w-4 h-4 text-amber-500" />;
      case 'DELIVERED': return <CheckCircle className="w-4 h-4 text-emerald-500" />;
      case 'COMMAND_ACK': return <Send className="w-4 h-4 text-indigo-500" />;
      case 'ROUTE_COMPUTED': return <MapIcon className="w-4 h-4 text-purple-500" />;
      default: return <Clock className="w-4 h-4 text-gray-500" />;
    }
  };

  return (
    <div className="space-y-4">
      {activities.map((activity) => (
        <div key={activity.id} className={`flex items-start gap-3 p-3 rounded-lg hover:bg-gray-50 transition-colors border border-transparent hover:border-gray-100 ${activity.severity === 'CRITICAL' ? 'bg-red-50/50 border-red-100' : ''}`}>
          <div className="mt-1 p-2 bg-white rounded-lg shadow-sm border border-gray-100">
            {getIcon(activity.type)}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex justify-between items-start">
              <p className="text-xs font-bold text-gray-900 truncate">#{activity.packageId}</p>
              <span className="text-[10px] text-gray-400 font-medium">{activity.time}</span>
            </div>
            <p className="text-[10px] text-gray-500 mt-0.5">
              <span className={`font-bold ${activity.severity === 'CRITICAL' ? 'text-red-600' : 'text-gray-700'}`}>
                {activity.type.replace('_', ' ')}
              </span> in {activity.location}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
}
