import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  ShieldCheck, AlertTriangle, FileText, CheckCircle2, 
  Activity, Lock, Server, XCircle, ArrowRight, Cpu, 
  Download, ExternalLink, RefreshCw, Check
} from 'lucide-react';

interface PartnerCertificationDashboardProps {
  partnerId: string;
  onBack?: () => void;
}

const LIFECYCLE_STAGES = [
  { id: 'Registration', label: 'Registration' },
  { id: 'CredentialIssuance', label: 'Credentials' },
  { id: 'TechnicalIntegration', label: 'Integration' },
  { id: 'SelfTest', label: 'Self-Test' },
  { id: 'Testing', label: 'Certification' },
  { id: 'OperationalReadiness', label: 'Ops Ready' },
  { id: 'Decision', label: 'Decision' },
  { id: 'Production', label: 'Onboarding' }
];

export function PartnerCertificationDashboard({ partnerId, onBack }: PartnerCertificationDashboardProps) {
  const [activeTab, setActiveTab] = useState<'status' | 'tests' | 'evidence' | 'issues' | 'decision'>('status');
  
  // Mock data states
  const [status, setStatus] = useState<any>(null);
  const [testRuns, setTestRuns] = useState<any[]>([]);
  const [evidence, setEvidence] = useState<any[]>([]);
  const [issues, setIssues] = useState<any[]>([]);
  const [decision, setDecision] = useState<any>(null);
  const [evaluationCriteria, setEvaluationCriteria] = useState<any>(null);
  
  const [loading, setLoading] = useState(true);

  // Load the example JSON we saved
  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        // Normally this would fetch from /api/certification/...
        
        setEvaluationCriteria({
          weights: {
            authSecurity: 0.30,
            restApi: 0.25,
            websocket: 0.25,
            operational: 0.20
          },
          thresholds: {
            certified: 0.90,
            conditional: 0.80
          },
          hardBlockCategories: ["authSecurity", "operational"]
        });

        // Mock Status
        setStatus({
          partnerId: "partner_abc",
          tier: "T2",
          status: "InProgress",
          overallScore: 87,
          phase: "Testing",
          createdAt: "2026-04-16T15:00:00Z",
          updatedAt: "2026-04-16T15:30:00Z",
          reviewer: "cert_reviewer_01",
          categories: {
            authSecurity: { score: 100, status: "Pass", hardBlock: false },
            restApi: { score: 92, status: "Pass", hardBlock: false },
            websocket: { score: 78, status: "Conditional", hardBlock: false },
            operational: { score: 100, status: "Pass", hardBlock: false }
          }
        });

        // Mock Test Run
        setTestRuns([
          {
            testRunId: "run_20260416_001",
            partnerId: "partner_abc",
            category: "restApi",
            startedAt: "2026-04-16T13:00:00Z",
            completedAt: "2026-04-16T13:10:00Z",
            results: [
              { testId: "REST-001", description: "GET /fleet/locations returns valid schema", status: "Pass", durationMs: 120, evidenceId: "ev_010" },
              { testId: "REST-004", description: "Filtering by updatedSince", status: "Fail", durationMs: 98, evidenceId: "ev_011", details: { expected: "All timestamps > updatedSince", actual: "2 items older than filter" } }
            ]
          }
        ]);

        // Mock Evidence
        setEvidence([
          {
            evidenceId: "ev_002",
            partnerId: "partner_abc",
            controlId: "CTL-PTC-002",
            type: "jwt_validation",
            status: "Submitted",
            submittedBy: "cert_system",
            submittedAt: "2026-04-16T15:44:00Z",
            metadata: {
              testRunId: "run_20260416_001",
              category: "authSecurity"
            },
            attachments: [
              {
                fileId: "file_124",
                fileName: "jwt_validation_log.txt",
                url: "s3://.../jwt_validation_log.txt"
              }
            ]
          },
          {
            evidenceId: "ev_001",
            partnerId: "partner_abc",
            controlId: "CTL-PTC-002",
            type: "jwt_validation",
            status: "Approved",
            submittedBy: "partner_user_01",
            submittedAt: "2026-04-16T14:00:00Z",
            reviewedBy: "cert_reviewer_01",
            reviewedAt: "2026-04-16T14:30:00Z",
            notes: "Validated against IdP config",
            attachments: [{ fileId: "file_123", fileName: "jwt_validation_log.txt", url: "s3://evidence/partner_abc/jwt_validation_log.txt" }]
          }
        ]);

        // Mock Issues
        setIssues([
          {
            issueId: "ISS-023",
            partnerId: "partner_abc",
            severity: "Critical",
            category: "Auth",
            description: "Partner can access other partnerId",
            status: "Open",
            createdAt: "2026-04-16T12:00:00Z",
            updatedAt: "2026-04-16T12:30:00Z",
            owner: "partner_abc",
            comments: [{ author: "cert_reviewer_01", timestamp: "2026-04-16T12:10:00Z", message: "Cross-partner access detected in test REST-007" }]
          }
        ]);

        // Mock Decision
        setDecision({
          decisionId: "DEC-20260416-001",
          partnerId: "partner_abc",
          status: "Conditional",
          score: 0.87,
          reason: "WebSocket category below threshold",
          issuedAt: "2026-04-16T15:45:00Z",
          validUntil: "2027-04-16T00:00:00Z",
          controls: ["CTL-PTC-002", "CTL-PTC-010", "CTL-PTC-011"],
          evidenceIds: ["ev_001", "ev_010", "ev_011"],
          conditions: ["Fix WebSocket filter handling", "Resolve issue ISS-023"],
          signedBy: "cert_manager_01",
          reportUrl: "s3://certification_reports/partner_abc_20260416.pdf"
        });

      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, [partnerId]);

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'pass':
      case 'approved':
      case 'certified':
        return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      case 'conditional':
      case 'inprogress':
      case 'testing':
      case 'open':
        return 'bg-amber-100 text-amber-700 border-amber-200';
      case 'fail':
      case 'rejected':
      case 'critical':
        return 'bg-red-100 text-red-700 border-red-200';
      default:
        return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <RefreshCw className="w-8 h-8 text-blue-600 animate-spin" />
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden"
    >
      <div className="bg-[#1a365d] p-6 text-white flex justify-between items-start">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <ShieldCheck className="w-6 h-6 text-emerald-400" />
            <h2 className="text-xl font-bold">Partner Certification: {partnerId}</h2>
            <span className={`px-2 py-0.5 text-[10px] font-bold uppercase tracking-widest rounded border ${
              status?.status === 'InProgress' ? 'bg-amber-500/20 text-amber-300 border-amber-500/50' : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50'
            }`}>
              {status?.phase} - {status?.status}
            </span>
          </div>
          <p className="text-sm text-blue-200">Tier: {status?.tier} | Overall Score: {status?.overallScore}</p>
        </div>
        {onBack && (
          <button onClick={onBack} className="text-blue-200 hover:text-white text-sm font-bold">
            &larr; Back to Dashboard
          </button>
        )}
      </div>

      {/* Stepper */}
      <div className="bg-white border-b border-gray-200 p-6 overflow-x-auto">
        <div className="flex items-center min-w-max">
          {LIFECYCLE_STAGES.map((stage, idx) => {
            const currentStageIndex = LIFECYCLE_STAGES.findIndex(s => s.id === status?.phase);
            const isCompleted = idx < currentStageIndex;
            const isCurrent = idx === currentStageIndex;
            const isPending = idx > currentStageIndex;

            return (
              <React.Fragment key={stage.id}>
                {/* Step Node */}
                <div className="flex flex-col items-center group relative w-24">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center border-2 mb-2 transition-colors z-10 bg-white ${
                    isCompleted ? 'bg-emerald-500 border-emerald-500 text-white' : 
                    isCurrent ? 'border-amber-500 text-amber-500 shadow-[0_0_15px_rgba(245,158,11,0.2)]' : 
                    'border-gray-200 text-gray-300'
                  }`}>
                    {isCompleted ? <Check className="w-4 h-4" /> : <span className="text-xs font-bold">{idx + 1}</span>}
                  </div>
                  <span className={`text-[9px] font-bold uppercase tracking-widest text-center transition-colors ${
                    isCompleted ? 'text-emerald-700' :
                    isCurrent ? 'text-amber-600' :
                    'text-gray-400'
                  }`}>
                    {stage.label}
                  </span>
                </div>
                
                {/* Connecting Line */}
                {idx < LIFECYCLE_STAGES.length - 1 && (
                  <div className={`flex-1 h-0.5 mx-2 -mt-6 transition-colors ${
                    isCompleted ? 'bg-emerald-500' : 'bg-gray-200'
                  }`} style={{ minWidth: '40px' }} />
                )}
              </React.Fragment>
            );
          })}
        </div>
      </div>

      <div className="flex border-b border-gray-200 bg-gray-50/50">
        {[
          { id: 'status', label: 'Status & Categories' },
          { id: 'tests', label: 'Test Runs', count: testRuns.length },
          { id: 'evidence', label: 'Evidence', count: evidence.length },
          { id: 'issues', label: 'Issues', count: issues.filter(i => i.status === 'Open').length },
          { id: 'decision', label: 'Decision' }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-6 py-3 text-sm font-bold uppercase tracking-widest border-b-2 transition-colors ${
              activeTab === tab.id
                ? 'border-[#1a365d] text-[#1a365d]'
                : 'border-transparent text-gray-400 hover:text-gray-600'
            }`}
          >
            {tab.label}
            {tab.count !== undefined && tab.count > 0 && (
              <span className={`ml-2 px-2 py-0.5 rounded-full text-[10px] ${
                tab.id === 'issues' ? 'bg-red-100 text-red-600' : 'bg-gray-100 text-gray-600'
              }`}>
                {tab.count}
              </span>
            )}
          </button>
        ))}
      </div>

      <div className="p-6 bg-gray-50/50 min-h-[400px]">
        {/* Status Tab */}
        {activeTab === 'status' && status && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="p-4 bg-white border border-gray-200 rounded-xl">
                <div className="flex items-center gap-2 mb-2 text-gray-500"><Lock className="w-4 h-4"/> <span className="text-[10px] font-bold uppercase">Auth Security</span></div>
                <div className="text-2xl font-black text-[#1a365d]">{status.categories.authSecurity.score}</div>
                <span className={`mt-2 inline-block px-2 py-0.5 text-[10px] font-bold rounded ${getStatusColor(status.categories.authSecurity.status)}`}>{status.categories.authSecurity.status}</span>
              </div>
              <div className="p-4 bg-white border border-gray-200 rounded-xl">
                <div className="flex items-center gap-2 mb-2 text-gray-500"><Server className="w-4 h-4"/> <span className="text-[10px] font-bold uppercase">REST API</span></div>
                <div className="text-2xl font-black text-[#1a365d]">{status.categories.restApi.score}</div>
                <span className={`mt-2 inline-block px-2 py-0.5 text-[10px] font-bold rounded ${getStatusColor(status.categories.restApi.status)}`}>{status.categories.restApi.status}</span>
              </div>
              <div className="p-4 bg-white border border-gray-200 rounded-xl">
                <div className="flex items-center gap-2 mb-2 text-gray-500"><Activity className="w-4 h-4"/> <span className="text-[10px] font-bold uppercase">WebSocket</span></div>
                <div className="text-2xl font-black text-[#1a365d]">{status.categories.websocket.score}</div>
                <span className={`mt-2 inline-block px-2 py-0.5 text-[10px] font-bold rounded ${getStatusColor(status.categories.websocket.status)}`}>{status.categories.websocket.status}</span>
              </div>
              <div className="p-4 bg-white border border-gray-200 rounded-xl">
                <div className="flex items-center gap-2 mb-2 text-gray-500"><Cpu className="w-4 h-4"/> <span className="text-[10px] font-bold uppercase">Operational</span></div>
                <div className="text-2xl font-black text-[#1a365d]">{status.categories.operational.score}</div>
                <span className={`mt-2 inline-block px-2 py-0.5 text-[10px] font-bold rounded ${getStatusColor(status.categories.operational.status)}`}>{status.categories.operational.status}</span>
              </div>
            </div>
          </div>
        )}

        {/* Tests Tab */}
        {activeTab === 'tests' && (
          <div className="space-y-4">
            {testRuns.map(run => (
              <div key={run.testRunId} className="bg-white border border-gray-200 rounded-xl overflow-hidden">
                <div className="bg-gray-50 p-4 border-b border-gray-200 flex justify-between items-center">
                  <div>
                    <h3 className="font-bold text-[#1a365d]">{run.testRunId}</h3>
                    <p className="text-xs text-gray-500">Category: {run.category}</p>
                  </div>
                  <span className="text-xs text-gray-400">{new Date(run.completedAt).toLocaleString()}</span>
                </div>
                <div className="divide-y divide-gray-100">
                  {run.results.map((r: any) => (
                    <div key={r.testId} className="p-4 flex items-start gap-4">
                      {r.status === 'Pass' ? <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" /> : <XCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />}
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <p className="font-bold text-sm text-gray-800">{r.testId}: {r.description}</p>
                          <span className={`px-2 py-0.5 text-[10px] font-bold rounded ${getStatusColor(r.status)}`}>{r.status}</span>
                        </div>
                        <p className="text-xs text-gray-400 mt-1">Duration: {r.durationMs}ms | Evidence: {r.evidenceId}</p>
                        {r.details && (
                          <div className="mt-2 bg-red-50 text-red-800 text-xs p-3 rounded border border-red-100 font-mono">
                            <div>Expected: {r.details.expected}</div>
                            <div>Actual: {r.details.actual}</div>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Evidence Tab */}
        {activeTab === 'evidence' && (
          <div className="space-y-4">
            {evidence.map(ev => (
              <div key={ev.evidenceId} className="bg-white p-4 border border-gray-200 rounded-xl">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-bold text-[#1a365d] flex items-center gap-2"><FileText className="w-4 h-4 text-blue-500"/> {ev.controlId} - {ev.type}</h3>
                  <span className={`px-2 py-0.5 text-[10px] font-bold rounded ${getStatusColor(ev.status)}`}>{ev.status}</span>
                </div>
                
                {ev.notes && <p className="text-sm text-gray-600 mb-3">{ev.notes}</p>}
                
                {ev.metadata && (
                  <div className="bg-gray-50 border border-gray-100 rounded p-3 mb-3 text-xs font-mono text-gray-600">
                    <span className="text-[9px] font-bold uppercase tracking-widest text-gray-400 block mb-1">System Metadata</span>
                    <p>Test Run: {ev.metadata.testRunId}</p>
                    <p>Category: {ev.metadata.category}</p>
                  </div>
                )}
                
                <div className="flex flex-wrap gap-2">
                  {ev.attachments.map((att: any, i: number) => (
                    <a key={att.fileId || i} href="#" className="flex items-center gap-1 text-xs font-bold text-blue-600 bg-blue-50 px-2 py-1 rounded border border-blue-100 hover:bg-blue-100">
                      <Download className="w-3 h-3" /> {att.fileName}
                    </a>
                  ))}
                </div>
                
                <div className="mt-3 flex gap-4 text-[10px] text-gray-400 font-bold uppercase tracking-widest">
                  <span>Source: {ev.submittedBy}</span>
                  <span>Time: {new Date(ev.submittedAt).toLocaleTimeString()}</span>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Issues Tab */}
        {activeTab === 'issues' && (
          <div className="space-y-4">
            {issues.map(issue => (
              <div key={issue.issueId} className="bg-white border border-red-200 rounded-xl overflow-hidden shadow-sm">
                <div className="bg-red-50 p-4 border-b border-red-100 flex justify-between items-start">
                  <div className="flex gap-3">
                    <AlertTriangle className="w-5 h-5 text-red-500 shrink-0" />
                    <div>
                      <h3 className="font-bold text-red-800">{issue.issueId}: {issue.description}</h3>
                      <p className="text-xs text-red-600 mt-1">Category: {issue.category} | Severity: {issue.severity}</p>
                    </div>
                  </div>
                  <span className={`px-2 py-0.5 text-[10px] font-bold rounded ${getStatusColor(issue.status)}`}>{issue.status}</span>
                </div>
                <div className="p-4 bg-white">
                  <h4 className="text-xs font-bold text-gray-500 uppercase mb-2">Comments</h4>
                  <div className="space-y-3">
                    {issue.comments.map((comment: any, i: number) => (
                      <div key={i} className="bg-gray-50 p-3 rounded border border-gray-100 text-sm text-gray-700">
                        <div className="flex justify-between items-center mb-1">
                          <span className="font-bold text-gray-900 text-xs">{comment.author}</span>
                          <span className="text-[10px] text-gray-400">{new Date(comment.timestamp).toLocaleString()}</span>
                        </div>
                        {comment.message}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Decision Tab */}
        {activeTab === 'decision' && decision && (
          <div className="bg-white p-6 border border-amber-200 rounded-xl shadow-sm">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <ShieldCheck className="w-8 h-8 text-amber-600" />
              </div>
              <h2 className="text-2xl font-black text-[#1a365d]">Certification: {decision.status}</h2>
              <p className="text-gray-500 text-sm mt-1">Overall Score: {(decision.score * 100).toFixed(0)}%</p>
              {decision.reason && (
                <p className="text-red-600 font-bold text-sm mt-2">{decision.reason}</p>
              )}
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div className="border border-amber-100 bg-amber-50 rounded-xl p-4">
                <h4 className="text-xs font-bold text-amber-800 uppercase tracking-widest mb-3">Conditions for Full Certification</h4>
                <ul className="space-y-2">
                  {decision.conditions.map((cond: string, i: number) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-amber-900">
                      <ArrowRight className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                      {cond}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="border border-gray-200 bg-gray-50 rounded-xl p-4">
                <h4 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-3">Associated Evidence & Controls</h4>
                <div className="space-y-4">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-widest text-gray-400 block mb-1">Controls Verified</span>
                    <div className="flex flex-wrap gap-2">
                      {decision.controls?.map((c: string) => (
                        <span key={c} className="px-2 py-1 bg-white border border-gray-200 rounded text-xs font-mono text-gray-600">{c}</span>
                      ))}
                    </div>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-widest text-gray-400 block mb-1">Evidence Linked</span>
                    <div className="flex flex-wrap gap-2">
                      {decision.evidenceIds?.map((e: string) => (
                        <span key={e} className="px-2 py-1 bg-white border border-gray-200 rounded text-xs font-mono text-gray-600">{e}</span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-between items-center text-xs text-gray-500 border-t border-gray-100 pt-4">
              <div>Issued At: {new Date(decision.issuedAt).toLocaleString()}</div>
              <div>Valid Until: {new Date(decision.validUntil).toLocaleDateString()}</div>
              <div>Signed by: {decision.signedBy}</div>
              <a href="#" className="flex items-center gap-1 font-bold text-blue-600 hover:underline">
                <ExternalLink className="w-3 h-3" /> View Full Report
              </a>
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}
