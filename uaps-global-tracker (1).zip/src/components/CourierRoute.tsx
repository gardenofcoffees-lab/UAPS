import { Polyline } from "react-leaflet";
import { useEffect, useState } from "react";

export function CourierRoute({ courierId }: { courierId: string }) {
  const [path, setPath] = useState<any[]>([]);

  useEffect(() => {
    const interval = setInterval(async () => {
      try {
        const res = await fetch(`/api/courier/path/${courierId}`);
        const __dataBody = await res.json();
      const data = __dataBody.data || __dataBody;
        setPath(data);
      } catch (error) {
        console.error("Failed to fetch courier path:", error);
      }
    }, 3000);

    return () => clearInterval(interval);
  }, [courierId]);

  if (!path.length) return null;

  return (
    <Polyline
      positions={path.map(p => [p.lat, p.lng])}
      color="#3b82f6"
      weight={4}
      opacity={0.6}
      dashArray="10, 10"
    />
  );
}
