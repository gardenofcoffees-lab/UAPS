import React, { useState } from 'react';
import { motion } from 'motion/react';
import { History, Package, MapPin, QrCode, CheckCircle, ArrowRight } from 'lucide-react';

export function ReturnPortal() {
  const [deliveryId, setDeliveryId] = useState('');
  const [returnState, setReturnState] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const startReturn = async () => {
    if (!deliveryId) return;
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/returns', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ delivery_id: deliveryId })
      });
      if (!res.ok) throw new Error('Failed to start return');
      const __dataBody = await res.json();
      const data = __dataBody.data || __dataBody;
      setReturnState(data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const selectMethod = async (method: string, locationId: string) => {
    if (!returnState?.return_id) return;
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/returns/${returnState.return_id}/method`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ method, location_id: locationId })
      });
      if (!res.ok) throw new Error('Failed to select method');
      const __dataBody = await res.json();
      const data = __dataBody.data || __dataBody;
      setReturnState(data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const simulateDropoff = async () => {
    if (!returnState?.return_id || !returnState?.dropoff) return;
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/returns/${returnState.return_id}/events`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          event_type: 'DROP_OFF_CONFIRMED',
          source: returnState.dropoff.method,
          location_id: returnState.dropoff.location_id,
          timestamp: new Date().toISOString()
        })
      });
      if (!res.ok) throw new Error('Failed to confirm dropoff');
      const __dataBody = await res.json();
      const data = __dataBody.data || __dataBody;
      setReturnState(data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-8 py-20 text-center">
      <div className="bg-white p-12 rounded-3xl shadow-2xl border border-gray-100">
        <div className="w-20 h-20 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-8">
          <History className="w-10 h-10 text-[#1a365d]" />
        </div>
        <h2 className="text-4xl font-bold text-[#1a365d] mb-6">UAPS Return Portal</h2>
        
        {error && (
          <div className="mb-6 p-4 bg-red-50 text-red-700 rounded-lg text-sm">
            {error}
          </div>
        )}

        {returnState && (
          <div className="mb-12 max-w-2xl mx-auto px-4">
            <div className="flex items-center justify-between relative">
              <div className="absolute left-0 top-1/2 -translate-y-1/2 w-full h-1 bg-gray-100 rounded-full -z-10"></div>
              <div 
                className="absolute left-0 top-1/2 -translate-y-1/2 h-1 bg-blue-600 rounded-full -z-10 transition-all duration-500" 
                style={{ width: returnState.status === 'INITIATED' ? '0%' : returnState.status === 'READY_FOR_DROP_OFF' ? '50%' : '100%' }}
              ></div>
              
              <div className={`flex flex-col items-center ${returnState.status === 'INITIATED' || returnState.status === 'READY_FOR_DROP_OFF' || returnState.status === 'RECEIVED' ? 'text-blue-600' : 'text-gray-400'}`}>
                <div className={`w-10 h-10 rounded-full flex items-center justify-center mb-2 transition-colors duration-500 ${returnState.status === 'INITIATED' || returnState.status === 'READY_FOR_DROP_OFF' || returnState.status === 'RECEIVED' ? 'bg-blue-600 text-white shadow-lg shadow-blue-200' : 'bg-gray-100'}`}>
                  <Package className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-bold uppercase tracking-wider">Initiated</span>
              </div>

              <div className={`flex flex-col items-center ${returnState.status === 'READY_FOR_DROP_OFF' || returnState.status === 'RECEIVED' ? 'text-blue-600' : 'text-gray-400'}`}>
                <div className={`w-10 h-10 rounded-full flex items-center justify-center mb-2 transition-colors duration-500 ${returnState.status === 'READY_FOR_DROP_OFF' || returnState.status === 'RECEIVED' ? 'bg-blue-600 text-white shadow-lg shadow-blue-200' : 'bg-gray-100'}`}>
                  <QrCode className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-bold uppercase tracking-wider">Drop-off</span>
              </div>

              <div className={`flex flex-col items-center ${returnState.status === 'RECEIVED' ? 'text-emerald-600' : 'text-gray-400'}`}>
                <div className={`w-10 h-10 rounded-full flex items-center justify-center mb-2 transition-colors duration-500 ${returnState.status === 'RECEIVED' ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-200' : 'bg-gray-100'}`}>
                  <CheckCircle className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-bold uppercase tracking-wider">Received</span>
              </div>
            </div>
          </div>
        )}

        {!returnState && (
          <>
            <p className="text-gray-500 mb-10 max-w-lg mx-auto leading-relaxed">
              Need to return a package? Enter your tracking or order number below to start the return process through our global network.
            </p>
            <div className="max-w-md mx-auto">
              <div className="flex bg-gray-50 rounded-xl overflow-hidden border border-gray-200 p-1 mb-4">
                <input 
                  type="text" 
                  value={deliveryId}
                  onChange={(e) => setDeliveryId(e.target.value)}
                  placeholder="Order or Tracking Number" 
                  className="bg-transparent px-6 py-4 flex-1 focus:outline-none text-sm"
                />
                <button 
                  onClick={startReturn}
                  disabled={loading || !deliveryId}
                  className="bg-[#1a365d] text-white px-8 py-4 rounded-lg font-bold text-xs uppercase tracking-widest hover:bg-blue-900 transition-all disabled:opacity-50"
                >
                  {loading ? 'Processing...' : 'Start Return'}
                </button>
              </div>
              <p className="text-[10px] text-gray-400 uppercase tracking-widest font-bold">
                Returns are subject to UAPS global shipping policies.
              </p>
            </div>
          </>
        )}

        {returnState?.status === 'INITIATED' && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="max-w-2xl mx-auto text-left">
            <h3 className="text-xl font-bold text-[#1a365d] mb-2">Select Return Method</h3>
            <p className="text-sm text-gray-500 mb-6">Return ID: {returnState.return_id}</p>
            
            <div className="grid gap-4">
              {returnState.eligible_methods?.map((method: any) => (
                <div 
                  key={method.id} 
                  className="border border-gray-200 rounded-xl p-6 hover:border-blue-300 hover:bg-blue-50/50 transition-all cursor-pointer flex items-center justify-between group"
                  onClick={() => selectMethod(method.method, method.id)}
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center group-hover:bg-blue-100 transition-colors">
                      {method.method === 'LOCKER' ? <Package className="w-6 h-6 text-gray-600 group-hover:text-blue-600" /> : <MapPin className="w-6 h-6 text-gray-600 group-hover:text-blue-600" />}
                    </div>
                    <div>
                      <div className="font-bold text-gray-900">{method.label}</div>
                      <div className="text-xs text-gray-500 mt-1">Estimated refund in {method.eta_refund_days} days</div>
                    </div>
                  </div>
                  <ArrowRight className="w-5 h-5 text-gray-300 group-hover:text-blue-500 transition-colors" />
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {returnState?.status === 'READY_FOR_DROP_OFF' && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="max-w-md mx-auto">
            <div className="bg-blue-50 border border-blue-100 rounded-2xl p-8 text-center">
              <QrCode className="w-32 h-32 mx-auto text-[#1a365d] mb-6" />
              <h3 className="text-xl font-bold text-[#1a365d] mb-2">Ready for Drop-off</h3>
              <p className="text-sm text-gray-600 mb-6">{returnState.dropoff?.instructions}</p>
              
              <button 
                onClick={simulateDropoff}
                disabled={loading}
                className="w-full bg-white border border-gray-200 text-gray-700 px-6 py-3 rounded-lg font-bold text-sm hover:bg-gray-50 transition-colors"
              >
                {loading ? 'Processing...' : 'Simulate Drop-off Scan'}
              </button>
            </div>
          </motion.div>
        )}

        {returnState?.status === 'RECEIVED' && (
          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="max-w-md mx-auto">
            <div className="bg-emerald-50 border border-emerald-100 rounded-2xl p-8 text-center">
              <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="w-8 h-8 text-emerald-600" />
              </div>
              <h3 className="text-2xl font-bold text-emerald-800 mb-2">Return Received</h3>
              <p className="text-sm text-emerald-600 mb-6">Your package has been successfully dropped off.</p>
              
              <div className="bg-white rounded-lg p-4 text-left border border-emerald-100 mb-6">
                <div className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-2">Digital Proof of Return</div>
                <div className="text-sm font-mono text-gray-700">{returnState.digital_proof_of_return?.id || returnState.return_id}</div>
                <div className="text-xs text-gray-500 mt-1">{new Date(returnState.digital_proof_of_return?.timestamp || returnState.timestamp).toLocaleString()}</div>
              </div>

              <button 
                onClick={() => { setReturnState(null); setDeliveryId(''); }}
                className="text-emerald-700 font-bold text-sm hover:text-emerald-800"
              >
                Start Another Return
              </button>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
