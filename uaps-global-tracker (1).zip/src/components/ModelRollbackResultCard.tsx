import React from 'react';
import { motion } from 'motion/react';
import { CheckCircle2, XCircle, Server, Globe, Clock, Hash, ArrowRight } from 'lucide-react';

interface ModelRollbackResultProps {
  event: any;
}

export function ModelRollbackResultCard({ event }: ModelRollbackResultProps) {
  const isSuccess = event.status === 'SUCCESS';
  const { details } = event;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`bg-white rounded-[32px] border ${isSuccess ? 'border-emerald-100' : 'border-rose-100'} shadow-xl overflow-hidden`}
    >
      <div className={`p-6 ${isSuccess ? 'bg-emerald-50' : 'bg-rose-50'} border-b flex items-center justify-between`}>
        <div className="flex items-center gap-4">
          <div className={`w-12 h-12 ${isSuccess ? 'bg-emerald-100 text-emerald-600' : 'bg-rose-100 text-rose-600'} rounded-2xl flex items-center justify-center`}>
            {isSuccess ? <CheckCircle2 className="w-6 h-6" /> : <XCircle className="w-6 h-6" />}
          </div>
          <div>
            <h3 className="text-sm font-black text-[#1a365d] uppercase tracking-tight">Rollback Result</h3>
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">
              {event.model_id} • {event.result_id}
            </p>
          </div>
        </div>
        <div className={`px-4 py-1.5 ${isSuccess ? 'bg-emerald-500' : 'bg-rose-500'} text-white rounded-full text-[10px] font-black uppercase tracking-widest`}>
          {event.status}
        </div>
      </div>

      <div className="p-8 space-y-8">
        <div className="flex items-center justify-between p-4 bg-gray-50 rounded-2xl border border-gray-100">
          <div className="flex items-center gap-3">
            <Hash className="w-4 h-4 text-gray-400" />
            <div>
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Command Reference</p>
              <p className="text-[10px] font-black text-blue-500">{event.command_id}</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Version Shift</p>
              <div className="flex items-center gap-2">
                <span className="text-xs font-black text-gray-400 line-through">{event.from_version}</span>
                <ArrowRight className="w-3 h-3 text-gray-300" />
                <span className="text-xs font-black text-emerald-600">{event.to_version}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <h4 className="text-[10px] font-black text-[#1a365d] uppercase tracking-widest flex items-center gap-2">
            <Server className="w-4 h-4 text-blue-600" /> Updated Serving Endpoints
          </h4>
          <div className="flex flex-wrap gap-2">
            {details.serving_endpoints_updated.map((endpoint: string, idx: number) => (
              <div key={idx} className="flex items-center gap-2 px-3 py-1.5 bg-white border border-gray-100 rounded-xl shadow-sm">
                <Globe className="w-3 h-3 text-emerald-500" />
                <span className="text-[10px] font-bold text-[#1a365d]">{endpoint}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100 flex items-center gap-3">
            <Clock className="w-4 h-4 text-gray-400" />
            <div>
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Propagation Complete</p>
              <p className="text-[10px] font-black text-[#1a365d]">{new Date(details.propagation_completed_at).toLocaleString()}</p>
            </div>
          </div>
          <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100 flex items-center gap-3">
            <Clock className="w-4 h-4 text-gray-400" />
            <div>
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Result Logged At</p>
              <p className="text-[10px] font-black text-[#1a365d]">{new Date(event.ts).toLocaleString()}</p>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
