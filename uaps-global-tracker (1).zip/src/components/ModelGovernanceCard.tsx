import React from 'react';
import { motion } from 'motion/react';
import { Gavel, ShieldCheck, AlertCircle, Clock, FileText, ArrowRight, CheckCircle2, UserCheck } from 'lucide-react';

interface ModelGovernanceProps {
  event: any;
}

export function ModelGovernanceCard({ event }: ModelGovernanceProps) {
  const isPending = event.status === 'PENDING_REVIEW' && !event.final_status;
  const isApproved = event.final_status === 'APPROVED_ROLLBACK' || event.status === 'APPROVED';
  
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`bg-white rounded-[32px] border ${isPending ? 'border-amber-100 shadow-amber-500/5' : isApproved ? 'border-emerald-100 shadow-emerald-500/5' : 'border-gray-100'} shadow-xl overflow-hidden`}
    >
      <div className={`p-6 ${isPending ? 'bg-amber-50' : isApproved ? 'bg-emerald-50' : 'bg-gray-50'} border-b flex items-center justify-between`}>
        <div className="flex items-center gap-4">
          <div className={`w-12 h-12 ${isPending ? 'bg-amber-100 text-amber-600' : isApproved ? 'bg-emerald-100 text-emerald-600' : 'bg-gray-100 text-gray-600'} rounded-2xl flex items-center justify-center`}>
            <Gavel className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-sm font-black text-[#1a365d] uppercase tracking-tight">Model Governance Review</h3>
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">
              {event.model_id} • {event.governance_event_id}
            </p>
          </div>
        </div>
        <div className={`px-4 py-1.5 ${isPending ? 'bg-amber-500' : isApproved ? 'bg-emerald-500' : 'bg-gray-500'} text-white rounded-full text-[10px] font-black uppercase tracking-widest flex items-center gap-2`}>
          {isPending ? <Clock className="w-3 h-3" /> : <CheckCircle2 className="w-3 h-3" />}
          {event.final_status ? event.final_status.replace('_', ' ') : event.status.replace('_', ' ')}
        </div>
      </div>

      <div className="p-8 space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-6 bg-gray-50 rounded-3xl border border-gray-100 space-y-4">
            <h4 className="text-[10px] font-black text-[#1a365d] uppercase tracking-widest flex items-center gap-2">
              <FileText className="w-4 h-4 text-blue-600" /> Incident Chain
            </h4>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Drift Event</span>
                <span className="text-[10px] font-black text-blue-500">{event.drift_event_id}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Rollback Cmd</span>
                <span className="text-[10px] font-black text-blue-500">{event.rollback_command_id}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Result ID</span>
                <span className="text-[10px] font-black text-blue-500">{event.rollback_result_id}</span>
              </div>
            </div>
          </div>

          <div className="p-6 bg-gray-50 rounded-3xl border border-gray-100 space-y-4">
            <h4 className="text-[10px] font-black text-[#1a365d] uppercase tracking-widest flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600" /> Governance Context
            </h4>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Auto-Rollback</span>
                <span className="text-[10px] font-black text-emerald-600">{event.auto_rollback ? 'YES' : 'NO'}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Action Type</span>
                <span className="text-[10px] font-black text-[#1a365d]">{event.type?.replace('_', ' ')}</span>
              </div>
              <div className="flex items-center gap-2 pt-1">
                <span className="text-[10px] font-black text-red-400">{event.from_version}</span>
                <ArrowRight className="w-3 h-3 text-gray-300" />
                <span className="text-[10px] font-black text-emerald-500">{event.to_version}</span>
              </div>
            </div>
          </div>
        </div>

        {event.decisions && (
          <div className="space-y-4">
            <h4 className="text-[10px] font-black text-[#1a365d] uppercase tracking-widest flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-emerald-600" /> Reviewer Decisions
            </h4>
            <div className="grid grid-cols-1 gap-4">
              {event.decisions.map((decision: any, idx: number) => (
                <div key={idx} className="p-4 bg-white border border-gray-100 rounded-2xl flex items-start gap-4 shadow-sm">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                    decision.decision === 'APPROVE' ? 'bg-emerald-100 text-emerald-600' : 'bg-rose-100 text-rose-600'
                  }`}>
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                  <div className="flex-1 space-y-1">
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] font-black text-[#1a365d] uppercase tracking-tight">{decision.role.replace('_', ' ')}</span>
                      <span className="text-[8px] font-bold text-gray-400 uppercase tracking-widest">{new Date(decision.ts).toLocaleString()}</span>
                    </div>
                    <p className="text-xs text-gray-600 italic">"{decision.comment}"</p>
                    <p className="text-[8px] font-bold text-gray-400 uppercase tracking-widest">Reviewer ID: {decision.user_id}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {isPending && (
          <div className="p-6 bg-amber-50 rounded-3xl border border-amber-100 flex items-center gap-4">
            <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-amber-500 shadow-sm">
              <UserCheck className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <p className="text-xs font-black text-[#1a365d] uppercase tracking-tight">Awaiting Post-hoc Approval</p>
              <p className="text-[10px] font-bold text-amber-600/60 uppercase tracking-widest">Compliance officer review required per safety policy</p>
            </div>
            <button className="px-4 py-2 bg-[#1a365d] text-white text-[10px] font-black uppercase tracking-widest rounded-lg hover:bg-[#2a4a7d] transition-colors shadow-lg">
              Review Evidence
            </button>
          </div>
        )}

        <div className="flex justify-between items-center pt-4 border-t border-gray-100">
          <div className="flex items-center gap-2">
            <Clock className="w-3 h-3 text-gray-400" />
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Logged At: {new Date(event.created_at).toLocaleString()}</span>
          </div>
          <div className="flex items-center gap-2">
            <AlertCircle className="w-3 h-3 text-blue-400" />
            <span className="text-[10px] font-black text-blue-400 uppercase tracking-widest">Governance ID: {event.governance_event_id}</span>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
