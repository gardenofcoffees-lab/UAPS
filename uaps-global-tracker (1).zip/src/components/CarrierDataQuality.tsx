import React from 'react';
import { Activity, CheckCircle, AlertTriangle, TrendingUp, Award, ListChecks, Clock, Shield } from 'lucide-react';

interface DataQualityMetrics {
  carrier_id: string;
  data_quality_score: number;
  completeness: number;
  accuracy: number;
  timeliness: number;
  consistency: number;
  grade: string;
  recommendations: string[];
}

const mockData: DataQualityMetrics = {
  carrier_id: "Reload Logistics",
  data_quality_score: 0.91,
  completeness: 0.94,
  accuracy: 0.89,
  timeliness: 0.92,
  consistency: 0.88,
  grade: "A",
  recommendations: [
    "Improve border timestamp accuracy",
    "Reduce duplicate IN_TRANSIT events"
  ]
};

export function CarrierDataQuality({ data = mockData }: { data?: DataQualityMetrics }) {
  const getGradeColor = (grade: string) => {
    switch (grade) {
      case 'A': return 'text-emerald-600 bg-emerald-50 border-emerald-200';
      case 'B': return 'text-blue-600 bg-blue-50 border-blue-200';
      case 'C': return 'text-amber-600 bg-amber-50 border-amber-200';
      default: return 'text-red-600 bg-red-50 border-red-200';
    }
  };

  const toPercent = (val: number) => `${(val * 100).toFixed(0)}%`;

  return (
    <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-purple-50 rounded-lg">
            <Activity className="w-5 h-5 text-purple-600" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-[#1a365d] uppercase tracking-widest">Carrier Data Quality</h3>
            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-tighter">Real-time integration metrics for {data.carrier_id}</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className={`px-3 py-1 rounded-lg border font-black text-sm flex items-center gap-2 ${getGradeColor(data.grade)}`}>
            <Award className="w-4 h-4" />
            Grade {data.grade}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'Overall Score', value: toPercent(data.data_quality_score), icon: Activity, color: 'text-purple-600' },
            { label: 'Completeness', value: toPercent(data.completeness), icon: ListChecks, color: 'text-blue-600' },
            { label: 'Accuracy', value: toPercent(data.accuracy), icon: CheckCircle, color: 'text-emerald-600' },
            { label: 'Timeliness', value: toPercent(data.timeliness), icon: Clock, color: 'text-amber-600' },
            { label: 'Consistency', value: toPercent(data.consistency), icon: Shield, color: 'text-indigo-600' },
          ].map((stat, i) => (
            <div key={i} className="p-4 rounded-xl bg-gray-50 border border-gray-100 flex flex-col justify-between">
              <div className="flex justify-between items-start mb-2">
                <div className="text-[9px] font-black text-gray-400 uppercase tracking-widest">{stat.label}</div>
                <stat.icon className={`w-4 h-4 ${stat.color}`} />
              </div>
              <div className="text-xl font-black text-[#1a365d]">{stat.value}</div>
            </div>
          ))}
        </div>

        <div className="bg-orange-50/50 rounded-xl border border-orange-100 p-4">
          <h4 className="text-[10px] font-black text-orange-800 uppercase tracking-widest mb-3 flex items-center gap-2">
            <AlertTriangle className="w-3 h-3" /> Actionable Recommendations
          </h4>
          <ul className="space-y-2">
            {data.recommendations.map((rec, idx) => (
              <li key={idx} className="flex items-start gap-2 text-xs font-medium text-orange-900">
                <div className="w-1.5 h-1.5 rounded-full bg-orange-400 mt-1.5 shrink-0" />
                {rec}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
