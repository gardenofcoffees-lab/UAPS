import React from 'react';
import { motion } from 'motion/react';
import { AlertTriangle, Shield, Zap, Bird, ArrowUp, CheckCircle2, Clock, ShieldCheck, ExternalLink, Database, FileText, Cloud, Wind, Fingerprint } from 'lucide-react';

interface SafetyEventProps {
  event: any; // Using any to handle both wrapped and unwrapped structures during transition
}

export function SafetyEventCard({ event: rawEvent }: SafetyEventProps) {
  // Data Normalization Logic
  const isIncidentReport = rawEvent.type === 'SAFETY';
  const isEvidencePacket = rawEvent.type === 'SAFETY_INCIDENT';
  
  let event, metadata, context, hashes;

  if (isIncidentReport) {
    event = {
      event_id: rawEvent.incident_id,
      drone_id: rawEvent.drone_id,
      delivery_id: rawEvent.delivery_id,
      flight_id: rawEvent.flight_id,
      ts: rawEvent.timestamp,
      severity: rawEvent.severity,
      category: rawEvent.category,
      inputs: {
        object_type: rawEvent.incident_details.object_type,
        distance_m: rawEvent.incident_details.distance_m,
        collision_probability: rawEvent.incident_details.collision_probability,
      },
      action_taken: {
        mode: rawEvent.incident_details.action_mode,
        delta_alt_m: rawEvent.incident_details.delta_alt_m,
        delta_heading_deg: rawEvent.incident_details.delta_heading_deg,
      },
      result: {
        outcome: rawEvent.incident_details.outcome,
      }
    };
    metadata = {
      validated_signature: rawEvent.integrity.signature_valid,
    };
    context = rawEvent.flight_context;
    hashes = rawEvent.integrity;
  } else if (isEvidencePacket) {
    event = rawEvent.incident;
    metadata = rawEvent.ingest_metadata;
    context = rawEvent.context;
    hashes = rawEvent.hashes;
  } else {
    event = rawEvent.safety_event || rawEvent;
    metadata = rawEvent.ingest_metadata;
    context = null;
    hashes = null;
  }

  const isWarning = event.severity === 'WARNING';
  const isCritical = event.severity === 'CRITICAL';

  const actionMode = typeof event.action_taken === 'string' ? event.action_taken : event.action_taken.mode;
  const outcome = typeof event.result === 'string' ? event.result : event.result.outcome;
  const notes = typeof event.result === 'object' ? event.result.notes : null;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-[32px] border border-gray-100 shadow-xl overflow-hidden group hover:border-blue-200 transition-all"
    >
      <div className={`p-6 flex items-center justify-between ${
        isWarning ? 'bg-amber-50' : isCritical ? 'bg-red-50' : 'bg-blue-50'
      }`}>
        <div className="flex items-center gap-4">
          <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${
            isWarning ? 'bg-amber-100 text-amber-600' : isCritical ? 'bg-red-100 text-red-600' : 'bg-blue-100 text-blue-600'
          }`}>
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-sm font-black text-[#1a365d] uppercase tracking-tight">{event.category.replace('_', ' ')}</h3>
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">ID: {event.event_id} {event.flight_id && `• FLIGHT: ${event.flight_id}`}</p>
          </div>
        </div>
        <div className="flex flex-col items-end gap-2">
          <div className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest ${
            isWarning ? 'bg-amber-200 text-amber-800' : isCritical ? 'bg-red-200 text-red-800' : 'bg-blue-200 text-blue-800'
          }`}>
            {event.severity}
          </div>
          {metadata?.validated_signature && (
            <div className="flex items-center gap-1 text-[8px] font-black text-emerald-600 uppercase tracking-widest">
              <ShieldCheck className="w-3 h-3" /> Signed & Verified
            </div>
          )}
        </div>
      </div>

      <div className="p-8 space-y-8">
        <div className="grid grid-cols-2 gap-8">
          <div className="space-y-2">
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Drone Asset</p>
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4 text-blue-500" />
              <span className="text-sm font-black text-[#1a365d]">{event.drone_id}</span>
            </div>
            {metadata?.drone_cert_id && (
              <p className="text-[8px] font-bold text-gray-400 uppercase tracking-widest">Cert: {metadata.drone_cert_id}</p>
            )}
          </div>
          <div className="space-y-2">
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Timestamp</p>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-gray-400" />
              <span className="text-sm font-bold text-gray-600">{new Date(event.ts).toLocaleTimeString()}</span>
            </div>
          </div>
        </div>

        <div className="p-6 bg-gray-50 rounded-3xl border border-gray-100 space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Bird className="w-5 h-5 text-blue-600" />
              <span className="text-xs font-black text-[#1a365d] uppercase tracking-tight">Detection: {event.inputs.object_type}</span>
            </div>
            <span className="text-xs font-bold text-blue-600">{event.inputs.distance_m}m Distance</span>
          </div>
          
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Collision Probability</span>
              <span className="text-[10px] font-black text-[#1a365d]">{(event.inputs.collision_probability * 100).toFixed(0)}%</span>
            </div>
            <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${event.inputs.collision_probability * 100}%` }}
                className={`h-full ${isWarning ? 'bg-amber-500' : isCritical ? 'bg-red-500' : 'bg-blue-500'}`}
              />
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between pt-4 border-t border-gray-50">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-emerald-50 rounded-lg flex items-center justify-center text-emerald-600">
                <ArrowUp className="w-4 h-4" />
              </div>
              <div>
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Action Taken</p>
                <p className="text-xs font-black text-[#1a365d] uppercase tracking-tight">{actionMode.replace('_', ' ')}</p>
              </div>
            </div>
            <div className="flex items-center gap-2 text-emerald-600">
              <CheckCircle2 className="w-4 h-4" />
              <span className="text-[10px] font-black uppercase tracking-widest">{outcome}</span>
            </div>
          </div>
          
          {typeof event.action_taken === 'object' && (
            <div className="flex gap-4 pl-11">
              {event.action_taken.delta_alt_m && (
                <div className="px-3 py-1 bg-emerald-50 rounded-full text-[10px] font-bold text-emerald-700">
                  ALT: +{event.action_taken.delta_alt_m}m
                </div>
              )}
              {event.action_taken.delta_heading_deg && (
                <div className="px-3 py-1 bg-emerald-50 rounded-full text-[10px] font-bold text-emerald-700">
                  HDG: {event.action_taken.delta_heading_deg}°
                </div>
              )}
            </div>
          )}

          {notes && (
            <div className="pl-11">
              <p className="text-[10px] font-bold text-gray-400 italic">"{notes}"</p>
            </div>
          )}
        </div>

        {context && (
          <div className="pt-8 border-t border-gray-100 space-y-8">
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Database className="w-4 h-4 text-blue-600" />
                <h4 className="text-[10px] font-black text-[#1a365d] uppercase tracking-widest">Evidence Context References</h4>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {(context.pre_event_telemetry || context.pre_event_telemetry_ref) && (
                  <div className="p-3 bg-gray-50 rounded-xl border border-gray-100 flex items-center justify-between group/ref cursor-pointer hover:bg-blue-50 transition-colors">
                    <div className="flex items-center gap-3">
                      <FileText className="w-4 h-4 text-gray-400" />
                      <span className="text-[9px] font-bold text-gray-600 uppercase tracking-tight">Pre-Event Telemetry</span>
                    </div>
                    <ExternalLink className="w-3 h-3 text-gray-300 group-hover/ref:text-blue-500" />
                  </div>
                )}
                {(context.post_event_telemetry || context.post_event_telemetry_ref) && (
                  <div className="p-3 bg-gray-50 rounded-xl border border-gray-100 flex items-center justify-between group/ref cursor-pointer hover:bg-blue-50 transition-colors">
                    <div className="flex items-center gap-3">
                      <FileText className="w-4 h-4 text-gray-400" />
                      <span className="text-[9px] font-bold text-gray-600 uppercase tracking-tight">Post-Event Telemetry</span>
                    </div>
                    <ExternalLink className="w-3 h-3 text-gray-300 group-hover/ref:text-blue-500" />
                  </div>
                )}
                {(context.weather_snapshot || context.weather_ref) && (
                  <div className="p-3 bg-gray-50 rounded-xl border border-gray-100 flex items-center justify-between group/ref cursor-pointer hover:bg-blue-50 transition-colors">
                    <div className="flex items-center gap-3">
                      <Wind className="w-4 h-4 text-gray-400" />
                      <span className="text-[9px] font-bold text-gray-600 uppercase tracking-tight">Weather Conditions</span>
                    </div>
                    <ExternalLink className="w-3 h-3 text-gray-300 group-hover/ref:text-blue-500" />
                  </div>
                )}
                {(context.routing_decision || context.routing_decision_ref) && (
                  <div className="p-3 bg-gray-50 rounded-xl border border-gray-100 flex items-center justify-between group/ref cursor-pointer hover:bg-blue-50 transition-colors">
                    <div className="flex items-center gap-3">
                      <Cloud className="w-4 h-4 text-gray-400" />
                      <span className="text-[9px] font-bold text-gray-600 uppercase tracking-tight">Routing Decision</span>
                    </div>
                    <ExternalLink className="w-3 h-3 text-gray-300 group-hover/ref:text-blue-500" />
                  </div>
                )}
              </div>
            </div>

            {hashes && (
              <div className="p-4 bg-slate-900 rounded-2xl space-y-3">
                <div className="flex items-center gap-2">
                  <Fingerprint className="w-3 h-3 text-blue-400" />
                  <span className="text-[8px] font-black text-blue-400 uppercase tracking-widest">Audit Hashes (SHA-256)</span>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[7px] font-bold text-slate-500 uppercase">Packet</span>
                    <span className="text-[7px] font-mono text-slate-400 truncate ml-4">{hashes.packet_hash}</span>
                  </div>
                  {(hashes.telemetry_hash || hashes.hash_chain_root) && (
                    <div className="flex items-center justify-between">
                      <span className="text-[7px] font-bold text-slate-500 uppercase">{hashes.telemetry_hash ? 'Telemetry' : 'Chain Root'}</span>
                      <span className="text-[7px] font-mono text-slate-400 truncate ml-4">{hashes.telemetry_hash || hashes.hash_chain_root}</span>
                    </div>
                  )}
                  {hashes.safety_event_hash && (
                    <div className="flex items-center justify-between">
                      <span className="text-[7px] font-bold text-slate-500 uppercase">Incident</span>
                      <span className="text-[7px] font-mono text-slate-400 truncate ml-4">{hashes.safety_event_hash}</span>
                    </div>
                  )}
                </div>
              </div>
            )}
            
            <div className="flex items-center justify-between text-[8px] font-bold text-gray-400 uppercase tracking-widest">
              <span>Created By: {rawEvent.created_by || 'Evidence Service'}</span>
              <span>Packet ID: {rawEvent.packet_id || rawEvent.incident_id}</span>
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}
