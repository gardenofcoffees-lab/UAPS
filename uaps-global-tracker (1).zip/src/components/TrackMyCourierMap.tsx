import { MapContainer, TileLayer, Marker, Polyline, Popup } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";
import { useEffect, useState } from "react";

const courierIcon = L.icon({
  iconUrl: "https://cdn-icons-png.flaticon.com/512/684/684908.png",
  iconSize: [32, 32],
});

export function TrackMyCourierMap({ trackingId }: { trackingId: string }) {
  const [courierLocation, setCourierLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [path, setPath] = useState<{ lat: number; lng: number }[]>([]);
  const [eta, setEta] = useState<number | null>(null);
  const [status, setStatus] = useState("IN_TRANSIT");

  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const ws = new WebSocket(`${protocol}//${window.location.host}`);

    ws.onopen = () => {
      ws.send(JSON.stringify({ type: "subscribe", trackingId }));
    };

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);

        if (data.type === "tracking_update") {
          if (data.courierLocation) setCourierLocation(data.courierLocation);
          if (data.path) setPath(data.path);
          if (data.etaMinutes !== undefined) setEta(data.etaMinutes);
          if (data.status) setStatus(data.status);
        }
      } catch (err) {
        console.error("WebSocket message error:", err);
      }
    };

    return () => ws.close();
  }, [trackingId]);

  if (!courierLocation) return (
    <div className="w-full h-[500px] flex items-center justify-center bg-gray-900 rounded-3xl border border-gray-800">
      <div className="text-center">
        <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
        <p className="text-gray-400 font-bold uppercase tracking-widest text-xs">Waiting for courier location...</p>
      </div>
    </div>
  );

  return (
    <div className="w-full h-[500px] rounded-3xl overflow-hidden border border-gray-800 shadow-2xl relative z-0">
      <MapContainer
        center={[courierLocation.lat, courierLocation.lng]}
        zoom={14}
        style={{ height: "100%", width: "100%", background: "#0f172a" }}
      >
        <TileLayer 
          url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
        />

        <Polyline
          positions={path.map((p) => [p.lat, p.lng])}
          color="#3b82f6"
          weight={4}
          opacity={0.6}
          dashArray="10, 10"
        />

        <Marker position={[courierLocation.lat, courierLocation.lng]} icon={courierIcon}>
          <Popup>
            <div className="p-2">
              <p className="font-bold text-blue-600 mb-1">UAPS Courier</p>
              <p className="text-xs text-gray-600">ETA: <span className="font-bold text-gray-900">{eta ? `${eta} min` : "Calculating..."}</span></p>
              <p className="text-xs text-gray-600">Status: <span className="font-bold text-gray-900 uppercase tracking-tighter">{status}</span></p>
            </div>
          </Popup>
        </Marker>
      </MapContainer>
      
      {/* Overlay Info */}
      <div className="absolute top-4 right-4 z-[1000] bg-white/90 backdrop-blur shadow-xl rounded-2xl p-4 border border-blue-100">
        <p className="text-[10px] font-bold uppercase tracking-widest text-blue-600/60 leading-none mb-1">Live Tracking</p>
        <p className="text-xl font-black text-blue-900 leading-none">{status === 'FAILED_SECURITY_EVENT' ? 'ABORTED' : (eta ? `${eta} mins` : "Calculating...")}</p>
        <p className={`text-[9px] mt-1 uppercase font-bold ${status === 'FAILED_SECURITY_EVENT' ? 'text-red-600' : 'text-blue-400'}`}>{status.replace('_', ' ')}</p>
      </div>
    </div>
  );
}
