import React from 'react';
import { motion } from 'motion/react';
import { RotateCcw, ShieldCheck, AlertCircle, Cpu, ArrowRight, Clock, FileCheck } from 'lucide-react';

interface ModelRollbackProps {
  event: any;
}

export function ModelRollbackCard({ event }: ModelRollbackProps) {
  const { policy } = event;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-[32px] border border-emerald-100 shadow-xl overflow-hidden"
    >
      <div className="p-6 bg-emerald-50 border-b border-emerald-100 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-2xl flex items-center justify-center">
            <RotateCcw className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-sm font-black text-[#1a365d] uppercase tracking-tight">Model Rollback Executed</h3>
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">
              {event.model_id} • {event.command_id}
            </p>
          </div>
        </div>
        <div className="px-4 py-1.5 bg-emerald-500 text-white rounded-full text-[10px] font-black uppercase tracking-widest">
          Action Completed
        </div>
      </div>

      <div className="p-8 space-y-8">
        <div className="flex items-center justify-center gap-8 p-6 bg-gray-50 rounded-[32px] border border-gray-100">
          <div className="text-center">
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">From Version</p>
            <span className="text-lg font-black text-red-500">{event.from_version}</span>
          </div>
          <ArrowRight className="w-6 h-6 text-gray-300" />
          <div className="text-center">
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">To Version</p>
            <span className="text-lg font-black text-emerald-600">{event.to_version}</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-6 bg-white border border-gray-100 rounded-3xl space-y-4">
            <h4 className="text-[10px] font-black text-[#1a365d] uppercase tracking-widest flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-amber-500" /> Rollback Reason
            </h4>
            <p className="text-xs font-bold text-[#1a365d] uppercase tracking-tight bg-amber-50 p-3 rounded-xl border border-amber-100">
              {event.reason.replace('_', ' ')}
            </p>
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">
              Triggered by: <span className="text-blue-500">{event.trigger_event_id}</span>
            </p>
          </div>

          <div className="p-6 bg-white border border-gray-100 rounded-3xl space-y-4">
            <h4 className="text-[10px] font-black text-[#1a365d] uppercase tracking-widest flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-500" /> Safety Policy
            </h4>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold text-gray-400">Auto-Rollback</span>
                <span className={`text-[10px] font-black uppercase px-2 py-1 rounded ${
                  policy.auto_rollback_allowed ? 'bg-emerald-100 text-emerald-700' : 'bg-gray-100 text-gray-500'
                }`}>
                  {policy.auto_rollback_allowed ? 'ALLOWED' : 'MANUAL'}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold text-gray-400">Post-hoc Approval</span>
                <span className={`text-[10px] font-black uppercase px-2 py-1 rounded ${
                  policy.requires_posthoc_approval ? 'bg-amber-100 text-amber-700' : 'bg-emerald-100 text-emerald-700'
                }`}>
                  {policy.requires_posthoc_approval ? 'REQUIRED' : 'NOT REQUIRED'}
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Clock className="w-4 h-4 text-gray-400" />
            <div>
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Execution Time</p>
              <p className="text-[10px] font-black text-[#1a365d]">{new Date(event.ts).toLocaleString()}</p>
            </div>
          </div>
          <div className="flex items-center gap-2 text-emerald-600">
            <FileCheck className="w-4 h-4" />
            <span className="text-[10px] font-black uppercase tracking-widest">Policy Compliant</span>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
