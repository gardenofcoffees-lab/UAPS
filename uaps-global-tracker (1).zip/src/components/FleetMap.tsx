import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

const courierIcon = L.icon({
  iconUrl: 'https://cdn-icons-png.flaticon.com/512/684/684908.png',
  iconSize: [24, 24],
});

const droneIcon = L.icon({
  iconUrl: 'https://cdn-icons-png.flaticon.com/512/3565/3565431.png',
  iconSize: [32, 32],
});

export function FleetMap() {
  const [locations, setLocations] = useState<Record<string, { lat: number; lng: number; timestamp: number; type?: 'courier' | 'drone' }>>({});

  useEffect(() => {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const ws = new WebSocket(`${protocol}//${window.location.host}`);

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type === 'location_update' || data.type === 'telemetry_update' || data.type === 'telemetry_update_grpc') {
          setLocations(prev => ({
            ...prev,
            [data.courierId]: {
              lat: data.location.lat,
              lng: data.location.lng,
              timestamp: Date.now(),
              type: (data.type === 'telemetry_update' || data.type === 'telemetry_update_grpc') ? 'drone' : 'courier'
            }
          }));
        }
      } catch (err) {
        console.error("FleetMap WS Error:", err);
      }
    };

    const fetchLocations = async () => {
      try {
        const res = await fetch('/api/couriers/locations', {
          headers: {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer uaps_partner_secret_123" // Using the default token from server.ts
          }
        });
        
        if (!res.ok) {
          const text = await res.text();
          throw new Error(`Server responded with ${res.status}: ${text.substring(0, 100)}`);
        }

        const contentType = res.headers.get("content-type");
        if (!contentType || !contentType.includes("application/json")) {
          const text = await res.text();
          throw new Error(`Expected JSON but received ${contentType}. Body: ${text.substring(0, 100)}`);
        }

        const __dataBody = await res.json();
      const data = __dataBody.data || __dataBody;
        setLocations(data);
      } catch (err) {
        console.error("Failed to fetch fleet locations:", err);
      }
    };

    fetchLocations();
    const interval = setInterval(fetchLocations, 30000); // Update every 30s as fallback
    return () => {
      clearInterval(interval);
      ws.close();
    };
  }, []);

  return (
    <div className="h-full w-full rounded-xl overflow-hidden border border-gray-200 shadow-inner bg-gray-900">
      <MapContainer 
        center={[9.0820, 8.6753]} // Center of Africa roughly
        zoom={3} 
        style={{ height: '100%', width: '100%' }}
      >
        <TileLayer
          url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
        />
        {Object.entries(locations).map(([id, loc]) => (
          <Marker key={id} position={[loc.lat, loc.lng]} icon={loc.type === 'drone' ? droneIcon : courierIcon}>
            <Popup>
              <div className="text-xs">
                <p className="font-bold text-blue-600">{loc.type === 'drone' ? 'Drone' : 'Courier'}: {id}</p>
                <p className="text-gray-500">Last update: {new Date(loc.timestamp).toLocaleTimeString()}</p>
              </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  );
}
