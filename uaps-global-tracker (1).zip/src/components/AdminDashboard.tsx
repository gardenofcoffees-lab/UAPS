import React, { useState, useMemo, useEffect } from 'react';
import { Logo } from './Logo';
import { motion } from 'motion/react';
import { 
  DollarSign, Activity, TrendingUp, Package, Clock, Settings, Download, 
  ChevronUp, ChevronDown, LayoutDashboard, Shield, Cpu, Globe, Server,
  AlertTriangle, CheckCircle2, Zap, ShieldCheck, Truck, MapPin, Navigation, Info, Users, Star
} from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, 
  LineChart, Line, PieChart, Pie, Cell, ComposedChart
} from 'recharts';
import { FleetMap } from './FleetMap';
import { RecentActivity } from './RecentActivity';
import { DroneTelemetryMonitor } from './DroneTelemetryMonitor';
import { DroneCommandCenter } from './DroneCommandCenter';
import { CarrierDataQuality } from './CarrierDataQuality';
import { NetworkIntelligence } from './NetworkIntelligence';
import { PartnerCertificationDashboard } from './PartnerCertificationDashboard';
import { PartnerDeveloperPortal } from './PartnerDeveloperPortal';

interface AdminDashboardProps {
  userRole?: 'admin' | 'partner';
  recentOrders: any[];
  handleExportCSV: () => void;
  getStatusStyles: (status: string) => string;
  getPriorityStyles: (priority: string) => string;
  getCarrierLogo: (carrier: string) => string | null;
}

export function AdminDashboard({ 
  userRole = 'admin',
  recentOrders, 
  handleExportCSV, 
  getStatusStyles, 
  getPriorityStyles, 
  getCarrierLogo 
}: AdminDashboardProps) {
  const [sortConfig, setSortConfig] = useState<{ key: string; direction: 'asc' | 'desc' } | null>(null);
  const [selectedOrder, setSelectedOrder] = useState<any | null>(null);
  const [activeTab, setActiveTab] = useState<'overview' | 'applications' | 'network' | 'developer'>('overview');
  const [applications, setApplications] = useState<any[]>([]);
  const [selectedPartnerApp, setSelectedPartnerApp] = useState<string | null>(null);

  useEffect(() => {
    if (activeTab === 'applications') {
      fetch('/api/partner-applications')
        .then(res => res.json())
        .then(data => setApplications(data))
        .catch(err => console.error(err));
    }
  }, [activeTab]);

  const handleUpdateApplicationStatus = async (id: string, status: string) => {
    try {
      const res = await fetch(`/api/partner-applications/${id}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
      if (res.ok) {
        setApplications(prev => prev.map(app => app.id === id ? { ...app, status } : app));
      }
    } catch (err) {
      console.error(err);
    }
  };

  const sortedOrders = useMemo(() => {
    let sortableItems = [...recentOrders];
    if (sortConfig !== null) {
      sortableItems.sort((a, b) => {
        const aValue = a[sortConfig.key as keyof typeof a];
        const bValue = b[sortConfig.key as keyof typeof b];
        if (aValue < bValue) return sortConfig.direction === 'asc' ? -1 : 1;
        if (aValue > bValue) return sortConfig.direction === 'asc' ? 1 : -1;
        return 0;
      });
    }
    return sortableItems;
  }, [recentOrders, sortConfig]);

  const handleSort = (key: string) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const getSortIcon = (key: string) => {
    if (!sortConfig || sortConfig.key !== key) {
      return <div className="w-3 h-3 opacity-20"><ChevronUp className="w-full h-full" /></div>;
    }
    return sortConfig.direction === 'asc' ? 
      <ChevronUp className="w-3 h-3 text-blue-600" /> : 
      <ChevronDown className="w-3 h-3 text-blue-600" />;
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="bg-[#f8fafc] min-h-screen pb-20"
    >
      {/* Dashboard Header */}
      <div className="bg-white border-b border-gray-200 px-8 py-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex items-center gap-6">
            <Logo size="md" />
            <div className="h-10 w-px bg-gray-100 hidden md:block" />
            <div>
              <div className="flex items-center gap-2 mb-1">
                <h2 className="text-xl font-bold text-[#1a365d]">
                  {userRole === 'partner' ? 'Partner Dashboard' : 'Logistics Command Center'}
                </h2>
                <span className="px-2 py-0.5 bg-emerald-100 text-emerald-700 text-[10px] font-bold rounded-full flex items-center gap-1">
                  <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
                  SYSTEM LIVE
                </span>
              </div>
              <p className="text-xs text-gray-500">Real-time performance indicators and fleet status</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex bg-gray-100 rounded-lg p-1 border border-gray-200">
              <button className="px-4 py-1.5 text-xs font-bold bg-white shadow-sm rounded-md text-[#1a365d]">Last Month</button>
              <button className="px-4 py-1.5 text-xs font-bold text-gray-500 hover:text-[#1a365d]">Last Quarter</button>
            </div>
            <button 
              onClick={handleExportCSV}
              className="flex items-center gap-2 bg-white border border-gray-200 px-4 py-2 rounded-lg text-xs font-bold text-gray-600 hover:bg-gray-50 transition-all"
            >
              <Download className="w-3.5 h-3.5" /> Export Report
            </button>
          </div>
        </div>
        
        {/* Tabs */}
        <div className="max-w-7xl mx-auto mt-6 flex gap-6 border-b border-gray-200">
          <button 
            onClick={() => { setActiveTab('overview'); setSelectedPartnerApp(null); }}
            className={`pb-3 text-sm font-bold uppercase tracking-widest transition-colors ${activeTab === 'overview' ? 'text-[#1a365d] border-b-2 border-[#1a365d]' : 'text-gray-400 hover:text-gray-600'}`}
          >
            Overview
          </button>
          <button 
            onClick={() => { setActiveTab('network'); setSelectedPartnerApp(null); }}
            className={`pb-3 text-sm font-bold uppercase tracking-widest transition-colors ${activeTab === 'network' ? 'text-[#1a365d] border-b-2 border-[#1a365d]' : 'text-gray-400 hover:text-gray-600'}`}
          >
            Network Intelligence
          </button>
          {userRole === 'admin' && (
            <button 
              onClick={() => { setActiveTab('applications'); setSelectedPartnerApp(null); }}
              className={`pb-3 text-sm font-bold uppercase tracking-widest transition-colors flex items-center gap-2 ${activeTab === 'applications' ? 'text-[#1a365d] border-b-2 border-[#1a365d]' : 'text-gray-400 hover:text-gray-600'}`}
            >
              Partner Applications
              {applications.filter(a => a.status === 'pending').length > 0 && (
                <span className="bg-red-500 text-white text-[10px] px-2 py-0.5 rounded-full">
                  {applications.filter(a => a.status === 'pending').length}
                </span>
              )}
            </button>
          )}
          {userRole === 'partner' && (
            <button 
              onClick={() => { setActiveTab('developer'); setSelectedPartnerApp(null); }}
              className={`pb-3 text-sm font-bold uppercase tracking-widest transition-colors flex items-center gap-2 ${activeTab === 'developer' ? 'text-[#1a365d] border-b-2 border-[#1a365d]' : 'text-gray-400 hover:text-gray-600'}`}
            >
              Developer Portal
            </button>
          )}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-8 py-8 space-y-8">
        {activeTab === 'overview' && (
          <>
            {userRole === 'admin' && (
              <>
                {/* Drone Command & Control */}
                <DroneCommandCenter />

                {/* Drone Telemetry Monitor */}
                <DroneTelemetryMonitor />

                {/* System Health Row */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  {[
                    { label: "API Latency", value: "24ms", icon: Zap, color: "text-amber-500" },
                    { label: "Server Load", value: "12%", icon: Server, color: "text-blue-500" },
                    { label: "Security Status", value: "Encrypted", icon: Shield, color: "text-emerald-500" },
                    { label: "Active Nodes", value: "14 Hubs", icon: Globe, color: "text-purple-500" }
                  ].map((item, i) => (
                    <div key={i} className="bg-white px-4 py-3 rounded-xl border border-gray-100 shadow-sm flex items-center gap-3">
                      <div className={`p-2 rounded-lg bg-gray-50`}>
                        <item.icon className={`w-4 h-4 ${item.color}`} />
                      </div>
                      <div>
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest leading-none mb-1">{item.label}</p>
                        <p className="text-sm font-bold text-[#1a365d] leading-none">{item.value}</p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Governance & Compliance Quick View */}
                <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-indigo-50 rounded-lg">
                        <ShieldCheck className="w-5 h-5 text-indigo-600" />
                      </div>
                      <div>
                        <h3 className="text-sm font-bold text-[#1a365d] uppercase tracking-widest">Model Governance & Compliance</h3>
                        <p className="text-[10px] text-gray-400 font-bold uppercase tracking-tighter">Real-time oversight of AI/ML systems</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-emerald-500 rounded-full" />
                        <span className="text-[10px] font-bold text-gray-500 uppercase">All Systems Compliant</span>
                      </div>
                      <button className="px-4 py-1.5 bg-indigo-600 text-white text-[10px] font-bold uppercase tracking-widest rounded-lg hover:bg-indigo-700 transition-colors">
                        View Full Audit
                      </button>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
                    {[
                      { label: 'Fairness Parity', value: '98.2%', status: 'Optimal' },
                      { label: 'Drift Index', value: '0.12', status: 'Stable' },
                      { label: 'Bias Flags', value: '0', status: 'Clear' },
                      { label: 'Model Integrity', value: 'Verified', status: 'Secure' },
                      { label: 'Audit Trail', value: 'Automated', status: 'Active' },
                      { label: 'Risk Exposure', value: 'Low', status: 'Within Appetite' }
                    ].map((stat, i) => (
                      <div key={i} className="p-3 rounded-xl bg-gray-50 border border-gray-100">
                        <div className="text-[9px] font-black text-gray-400 uppercase tracking-widest mb-1">{stat.label}</div>
                        <div className="text-sm font-black text-[#1a365d] mb-1">{stat.value}</div>
                        <div className="text-[8px] font-bold text-emerald-600 uppercase tracking-tighter">{stat.status}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Carrier Data Quality Metrics */}
                <CarrierDataQuality />

                {/* Top Metrics Row */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
                  {[
                    { label: "Revenue", value: "$1,594,280", trend: "+12.5%", icon: DollarSign, color: "text-blue-600", bg: "bg-blue-50" },
                    { label: "Costs", value: "$494,227", trend: "-2.4%", icon: Activity, color: "text-orange-600", bg: "bg-orange-50" },
                    { label: "Profit", value: "$1,100,053", trend: "+14.2%", icon: TrendingUp, color: "text-green-600", bg: "bg-green-50" },
                    { label: "Shipments", value: "1,042", trend: "+8.1%", icon: Package, color: "text-purple-600", bg: "bg-purple-50" },
                    { label: "Avg Delivery Time", value: "6.7h", trend: "-10%", icon: Clock, color: "text-indigo-600", bg: "bg-indigo-50" }
                  ].map((metric, i) => (
                    <div key={i} className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
                      <div className="flex justify-between items-start mb-4">
                        <div className={`p-2 rounded-lg ${metric.bg}`}>
                          <metric.icon className={`w-5 h-5 ${metric.color}`} />
                        </div>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${metric.trend.startsWith('-') ? 'bg-red-50 text-red-600' : 'bg-green-50 text-green-600'}`}>
                          {metric.trend}
                        </span>
                      </div>
                      <p className="text-2xl font-bold text-[#1a365d] mb-1">{metric.value}</p>
                      <p className="text-[10px] uppercase tracking-widest text-gray-400 font-bold">{metric.label}</p>
                    </div>
                  ))}
                </div>
              </>
            )}

            {/* Fleet Map & Activity Row */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden flex flex-col">
            <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center">
              <h3 className="text-sm font-bold text-[#1a365d] uppercase tracking-widest">Live Fleet Distribution</h3>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 bg-blue-500 rounded-full animate-pulse" />
                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">60 Active Couriers</span>
              </div>
            </div>
            <div className="flex-1 min-h-[400px]">
              <FleetMap />
            </div>
          </div>
          <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden flex flex-col">
            <div className="px-6 py-4 border-b border-gray-100">
              <h3 className="text-sm font-bold text-[#1a365d] uppercase tracking-widest">Recent Activity</h3>
            </div>
            <div className="p-4 flex-1 overflow-y-auto max-h-[400px]">
              <RecentActivity />
            </div>
            <div className="p-4 border-t border-gray-100 bg-gray-50/50">
              <button className="w-full py-2 text-[10px] font-bold text-blue-600 uppercase tracking-widest hover:underline">View All Logs</button>
            </div>
          </div>
        </div>

        {/* Fleet & Efficiency Row */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Fleet Status */}
          <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm lg:col-span-1">
            <div className="flex justify-between items-center mb-8">
              <h3 className="text-sm font-bold text-[#1a365d] uppercase tracking-widest">Fleet Status</h3>
              <Settings className="w-4 h-4 text-gray-400" />
            </div>
            <div className="flex flex-col items-center mb-8">
              <div className="relative w-32 h-32">
                <svg className="w-full h-full" viewBox="0 0 100 100">
                  <circle cx="50" cy="50" r="45" fill="none" stroke="#f1f5f9" strokeWidth="8" />
                  <circle cx="50" cy="50" r="45" fill="none" stroke="#1a365d" strokeWidth="8" strokeDasharray="282.7" strokeDashoffset="14.1" strokeLinecap="round" />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-2xl font-bold text-[#1a365d]">95%</span>
                  <span className="text-[7px] uppercase font-bold text-gray-400">Efficiency</span>
                </div>
              </div>
            </div>
            <div className="space-y-3 mb-6">
              {[
                { label: "Total Fleet", value: 63, color: "bg-gray-400" },
                { label: "On the Move", value: 60, color: "bg-[#1a365d]" },
                { label: "In Maintenance", value: 3, color: "bg-orange-400" }
              ].map((item, i) => (
                <div key={i} className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <div className={`w-1.5 h-1.5 rounded-full ${item.color}`} />
                    <span className="text-[10px] text-gray-600">{item.label}</span>
                  </div>
                  <span className="text-[10px] font-bold text-[#1a365d]">{item.value}</span>
                </div>
              ))}
            </div>
            <div className="grid grid-cols-2 gap-2 pt-4 border-t border-gray-100">
              <div className="h-16 rounded-lg overflow-hidden relative group">
                <img src="https://images.unsplash.com/photo-1544016768-982d1554f0b9?auto=format&fit=crop&q=80&w=100" alt="Plane" className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all" referrerPolicy="no-referrer" />
                <div className="absolute top-1 right-1 w-3 h-3 opacity-50">
                  <img src="/logo.png" alt="" className="w-full h-full object-contain brightness-200" referrerPolicy="no-referrer" />
                </div>
                <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                  <span className="text-[8px] text-white font-bold">AIR</span>
                </div>
              </div>
              <div className="h-16 rounded-lg overflow-hidden relative group">
                <img src="https://images.unsplash.com/photo-1519003722824-194d4455a60c?auto=format&fit=crop&q=80&w=100" alt="Truck" className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all" referrerPolicy="no-referrer" />
                <div className="absolute top-1 right-1 w-3 h-3 opacity-50">
                  <img src="/logo.png" alt="" className="w-8 h-8 object-contain brightness-200" referrerPolicy="no-referrer" />
                </div>
                <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                  <span className="text-[8px] text-white font-bold">GROUND</span>
                </div>
              </div>
            </div>
          </div>

          {/* Loading Metrics */}
          <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm lg:col-span-1">
            <h3 className="text-sm font-bold text-[#1a365d] uppercase tracking-widest mb-8">Loading Metrics</h3>
            <div className="space-y-8">
              <div className="flex flex-col items-center">
                <div className="relative w-24 h-12 overflow-hidden">
                  <svg className="w-24 h-24" viewBox="0 0 100 100">
                    <path d="M 10 50 A 40 40 0 0 1 90 50" fill="none" stroke="#f1f5f9" strokeWidth="10" strokeLinecap="round" />
                    <path d="M 10 50 A 40 40 0 0 1 70 20" fill="none" stroke="#1a365d" strokeWidth="10" strokeLinecap="round" />
                  </svg>
                  <div className="absolute bottom-0 left-0 right-0 text-center">
                    <span className="text-sm font-bold text-[#1a365d]">25 min</span>
                  </div>
                </div>
                <span className="text-[8px] uppercase font-bold text-gray-400 mt-2">Avg Loading Time</span>
              </div>
              <div className="flex flex-col items-center">
                <div className="w-16 h-16 bg-amber-500 rounded-lg flex items-center justify-center relative shadow-lg">
                  <div className="absolute -top-2 w-6 h-4 border-2 border-amber-600 rounded-t-full" />
                  <span className="text-white font-bold text-xs">10 tons</span>
                </div>
                <span className="text-[8px] uppercase font-bold text-gray-400 mt-4">Avg Loading Weight</span>
              </div>
            </div>
          </div>

          {/* Logistics Efficiency */}
          <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm lg:col-span-1">
            <div className="flex justify-between items-center mb-8">
              <h3 className="text-sm font-bold text-[#1a365d] uppercase tracking-widest">Efficiency Status</h3>
              <Activity className="w-4 h-4 text-gray-400" />
            </div>
            <div className="flex flex-col items-center mb-8">
              <div className="relative w-32 h-32">
                <svg className="w-full h-full" viewBox="0 0 100 100">
                  <circle cx="50" cy="50" r="45" fill="none" stroke="#f1f5f9" strokeWidth="8" />
                  <circle cx="50" cy="50" r="45" fill="none" stroke="#c5a059" strokeWidth="8" strokeDasharray="282.7" strokeDashoffset="14.1" strokeLinecap="round" />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center px-4 text-center">
                  <span className="text-2xl font-bold text-[#1a365d]">95%</span>
                  <span className="text-[7px] uppercase font-bold text-gray-400">Within Time</span>
                </div>
              </div>
            </div>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-[10px] text-gray-600">Within Time Limit</span>
                <span className="text-[10px] font-bold text-[#1a365d]">502</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[10px] text-gray-600">Out of Time Limit</span>
                <span className="text-[10px] font-bold text-[#1a365d]">6</span>
              </div>
            </div>
          </div>

          {/* Deliveries by Gateway */}
          <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm lg:col-span-1">
            <h3 className="text-sm font-bold text-[#1a365d] uppercase tracking-widest mb-6">Deliveries by Gateway</h3>
            <div className="h-48 min-h-0 min-w-0">
              <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                <PieChart>
                  <Pie
                    data={[
                      { name: 'Ethiopia', value: 34 },
                      { name: 'Kenya', value: 18 },
                      { name: 'Nigeria', value: 20 },
                      { name: 'Ghana', value: 24 }
                    ]}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    <Cell fill="#1a365d" />
                    <Cell fill="#c5a059" />
                    <Cell fill="#4ade80" />
                    <Cell fill="#fbbf24" />
                  </Pie>
                  <Tooltip />
                  <Legend verticalAlign="bottom" height={36} iconType="circle" />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Charts Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Profit by Country */}
          <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
            <h3 className="text-sm font-bold text-[#1a365d] uppercase tracking-widest mb-6">Profit by Country</h3>
            <div className="h-80 min-h-0 min-w-0">
              <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                <LineChart
                  data={[
                    { month: 'Aug-20', Austria: 100, France: 120, Germany: 150, Switzerland: 130 },
                    { month: 'Sep-20', Austria: 150, France: 110, Germany: 140, Switzerland: 160 },
                    { month: 'Oct-20', Austria: 120, France: 130, Germany: 160, Switzerland: 140 },
                    { month: 'Nov-20', Austria: 140, France: 150, Germany: 130, Switzerland: 150 },
                    { month: 'Dec-20', Austria: 130, France: 140, Germany: 170, Switzerland: 120 },
                  ]}
                >
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#94a3b8' }} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#94a3b8' }} />
                  <Tooltip contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }} />
                  <Legend iconType="circle" />
                  <Line type="monotone" dataKey="Austria" stroke="#1a365d" strokeWidth={2} dot={false} />
                  <Line type="monotone" dataKey="France" stroke="#c5a059" strokeWidth={2} dot={false} />
                  <Line type="monotone" dataKey="Germany" stroke="#1e293b" strokeWidth={2} dot={false} />
                  <Line type="monotone" dataKey="Switzerland" stroke="#64748b" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Avg Delivery Time & Route */}
          <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
            <h3 className="text-sm font-bold text-[#1a365d] uppercase tracking-widest mb-6">Avg Delivery Time & Route</h3>
            <div className="h-80 min-h-0 min-w-0">
              <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                <ComposedChart
                  data={[
                    { month: 'Aug-20', route: 400, time: 6.7 },
                    { month: 'Sep-20', route: 550, time: 7.2 },
                    { month: 'Oct-20', route: 420, time: 6.5 },
                    { month: 'Nov-20', route: 480, time: 6.8 },
                    { month: 'Dec-20', route: 600, time: 7.5 },
                  ]}
                >
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#94a3b8' }} />
                  <YAxis yAxisId="left" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#94a3b8' }} />
                  <YAxis yAxisId="right" orientation="right" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#94a3b8' }} />
                  <Tooltip />
                  <Legend />
                  <Bar yAxisId="left" dataKey="route" fill="#1a365d" radius={[4, 4, 0, 0]} barSize={40} />
                  <Line yAxisId="right" type="monotone" dataKey="time" stroke="#c5a059" strokeWidth={3} />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Recent Orders Table */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
          <div className="px-8 py-6 border-b border-gray-100 flex justify-between items-center">
            <h3 className="text-sm font-bold text-[#1a365d] uppercase tracking-widest">Recent Delivery Orders</h3>
            <div className="flex gap-2 items-center">
              <button 
                onClick={handleExportCSV}
                className="flex items-center gap-2 bg-white border border-gray-200 text-[#1a365d] px-3 py-1.5 rounded text-[10px] font-bold uppercase tracking-widest hover:bg-gray-50 transition-colors mr-2"
              >
                <Download className="w-3 h-3" /> Export CSV
              </button>
              <button className="px-3 py-1 text-[10px] font-bold bg-blue-50 text-blue-600 rounded">All Delivery</button>
              <button className="px-3 py-1 text-[10px] font-bold text-gray-500 hover:bg-gray-50 rounded">In Progress</button>
              <button className="px-3 py-1 text-[10px] font-bold text-gray-500 hover:bg-gray-50 rounded">Successful</button>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-gray-50 text-[10px] uppercase tracking-widest text-gray-400 font-bold">
                  <th className="px-8 py-4 cursor-pointer hover:bg-gray-100 transition-colors group" onClick={() => handleSort('id')}>
                    <div className="flex items-center gap-2">Shipment ID {getSortIcon('id')}</div>
                  </th>
                  <th className="px-8 py-4 cursor-pointer hover:bg-gray-100 transition-colors group" onClick={() => handleSort('courier')}>
                    <div className="flex items-center gap-2">Courier {getSortIcon('courier')}</div>
                  </th>
                  <th className="px-8 py-4 cursor-pointer hover:bg-gray-100 transition-colors group" onClick={() => handleSort('dest')}>
                    <div className="flex items-center gap-2">Destination {getSortIcon('dest')}</div>
                  </th>
                  <th className="px-8 py-4 cursor-pointer hover:bg-gray-100 transition-colors group" onClick={() => handleSort('status')}>
                    <div className="flex items-center gap-2">Status {getSortIcon('status')}</div>
                  </th>
                  <th className="px-8 py-4 cursor-pointer hover:bg-gray-100 transition-colors group" onClick={() => handleSort('priority')}>
                    <div className="flex items-center gap-2">Priority {getSortIcon('priority')}</div>
                  </th>
                  <th className="px-8 py-4 cursor-pointer hover:bg-gray-100 transition-colors group" onClick={() => handleSort('date')}>
                    <div className="flex items-center gap-2">Expected Ends {getSortIcon('date')}</div>
                  </th>
                  <th className="px-8 py-4">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {sortedOrders.map((order, i) => (
                  <tr key={i} className="hover:bg-gray-50 transition-colors cursor-pointer" onClick={() => setSelectedOrder(order)}>
                    <td className="px-8 py-4">
                      <div className="flex flex-col">
                        <span className="text-xs font-bold text-[#1a365d]">{order.id}</span>
                        {order.partnerTrackingIds && order.partnerTrackingIds.length > 0 && (
                          <span className="text-[9px] text-gray-400 font-mono">{order.partnerTrackingIds[0]}</span>
                        )}
                      </div>
                    </td>
                    <td className="px-8 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-gray-50 rounded-lg border border-gray-100 flex items-center justify-center p-1.5 overflow-hidden">
                          {getCarrierLogo(order.carrier) ? (
                            <img src={getCarrierLogo(order.carrier)!} alt={order.carrier} className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                          ) : (
                            <div className="w-full h-full bg-gray-200 rounded" />
                          )}
                        </div>
                        <div className="flex flex-col">
                          <span className="text-xs font-bold text-[#1a365d]">{order.courier}</span>
                          <span className="text-[10px] text-gray-400 uppercase tracking-tighter">{order.carrier}</span>
                        </div>
                      </div>
                    </td>
                    <td className="px-8 py-4 text-xs text-gray-500">{order.dest}</td>
                    <td className="px-8 py-4">
                      <span className={`px-2 py-1 rounded-full text-[10px] font-bold ${getStatusStyles(order.status)}`}>
                        {order.status}
                      </span>
                    </td>
                    <td className="px-8 py-4">
                      <span className={`px-2 py-1 rounded-full text-[10px] font-bold ${getPriorityStyles(order.priority)}`}>
                        {order.priority}
                      </span>
                    </td>
                    <td className="px-8 py-4 text-xs text-gray-500">{order.date}</td>
                    <td className="px-8 py-4">
                      <button className="text-[#1a365d] hover:underline text-xs font-bold">Details</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
        </>
        )}
        
        {activeTab === 'network' && (
          <NetworkIntelligence />
        )}

        {activeTab === 'applications' && (
          selectedPartnerApp ? (
            <PartnerCertificationDashboard partnerId={selectedPartnerApp} onBack={() => setSelectedPartnerApp(null)} />
          ) : (
            <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center">
                <h3 className="text-sm font-bold text-[#1a365d] uppercase tracking-widest">Partner Applications</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-gray-50 border-b border-gray-100">
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Company</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Operating Countries</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Contact</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Date Submitted</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Status</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="text-sm">
                    {applications.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="px-6 py-8 text-center text-gray-500">No applications found.</td>
                      </tr>
                    ) : (
                      applications.map((app) => (
                        <tr key={app.id} className="border-b border-gray-50 hover:bg-gray-50/50 transition-colors">
                          <td className="px-6 py-4 font-bold text-[#1a365d]">{app.companyName}</td>
                          <td className="px-6 py-4 text-gray-600">{app.operatingCountries}</td>
                          <td className="px-6 py-4 text-gray-600">{app.contactEmail}</td>
                          <td className="px-6 py-4 text-gray-500">{new Date(app.submittedAt).toLocaleDateString()}</td>
                          <td className="px-6 py-4">
                            <span className={`px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest ${
                              app.status === 'approved' ? 'bg-emerald-100 text-emerald-700' :
                              app.status === 'rejected' ? 'bg-red-100 text-red-700' :
                              'bg-amber-100 text-amber-700'
                            }`}>
                              {app.status}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-right">
                            <div className="flex items-center justify-end gap-2">
                              <button 
                                onClick={() => setSelectedPartnerApp(app.id)}
                                className="px-3 py-1 bg-indigo-50 text-indigo-600 hover:bg-indigo-100 rounded text-xs font-bold transition-colors"
                              >
                                View Certification
                              </button>
                              {app.status === 'pending' && (
                                <>
                                  <button 
                                    onClick={() => handleUpdateApplicationStatus(app.id, 'approved')}
                                    className="px-3 py-1 bg-emerald-50 text-emerald-600 hover:bg-emerald-100 rounded text-xs font-bold transition-colors"
                                  >
                                    Approve
                                  </button>
                                  <button 
                                    onClick={() => handleUpdateApplicationStatus(app.id, 'rejected')}
                                    className="px-3 py-1 bg-red-50 text-red-600 hover:bg-red-100 rounded text-xs font-bold transition-colors"
                                  >
                                    Reject
                                  </button>
                                </>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )
        )}

        {activeTab === 'developer' && (
          <PartnerDeveloperPortal partnerId="partner_abc" />
        )}
      </div>

      {/* Order Details Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-[40px] shadow-2xl w-full max-w-2xl overflow-hidden border border-gray-100"
          >
            <div className="p-8 border-b border-gray-50 flex justify-between items-center bg-gray-50/50">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-[#1a365d] rounded-2xl flex items-center justify-center text-white">
                  <Package className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xl font-black text-[#1a365d]">{selectedOrder.id}</h3>
                  <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Shipment Details</p>
                </div>
              </div>
              <button 
                onClick={() => setSelectedOrder(null)}
                className="p-2 hover:bg-gray-200 rounded-xl transition-colors text-gray-400"
              >
                <ChevronDown className="w-6 h-6" />
              </button>
            </div>

            <div className="p-8 space-y-8 max-h-[70vh] overflow-y-auto">
              <div className="grid grid-cols-2 gap-8">
                <div className="space-y-4">
                  <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Route Info</h4>
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 bg-blue-50 rounded-lg flex items-center justify-center text-blue-600 mt-0.5">
                        <Globe className="w-3 h-3" />
                      </div>
                      <div>
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Carrier</p>
                        <p className="text-xs font-black text-[#1a365d]">{selectedOrder.carrier} - {selectedOrder.courier}</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 bg-emerald-50 rounded-lg flex items-center justify-center text-emerald-600 mt-0.5">
                        <Activity className="w-3 h-3" />
                      </div>
                      <div>
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Destination</p>
                        <p className="text-xs font-black text-[#1a365d]">{selectedOrder.dest}</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Status & Priority</h4>
                  <div className="flex flex-wrap gap-2">
                    <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${getStatusStyles(selectedOrder.status)}`}>
                      {selectedOrder.status}
                    </span>
                    <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${getPriorityStyles(selectedOrder.priority)}`}>
                      {selectedOrder.priority}
                    </span>
                  </div>
                  <p className="text-[10px] font-bold text-gray-400">Expected: {selectedOrder.date}</p>
                </div>
              </div>

              {selectedOrder.shipment_options && (
                <div className="pt-8 border-t border-gray-100 space-y-6">
                  <h4 className="text-sm font-black text-[#1a365d] uppercase tracking-widest flex items-center gap-2">
                    <Settings className="w-4 h-4 text-blue-600" /> Advanced Options
                  </h4>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                    <div>
                      <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Delivery Mode</p>
                      <p className="text-xs font-black text-[#1a365d]">{selectedOrder.shipment_options.delivery_mode || 'AIR_DRONE'}</p>
                    </div>
                    <div>
                      <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Speed</p>
                      <p className="text-xs font-black text-[#1a365d]">{selectedOrder.shipment_options.speed}</p>
                    </div>
                    <div>
                      <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Dropoff Mode</p>
                      <p className="text-xs font-black text-[#1a365d]">{selectedOrder.shipment_options.dropoff_mode}</p>
                    </div>
                    <div>
                      <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">SLA Tier</p>
                      <p className="text-xs font-black text-[#1a365d]">{selectedOrder.shipment_options.sla_tier}</p>
                    </div>
                    {selectedOrder.shipment_options.delivery_window && (
                      <div className="col-span-2">
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Delivery Window</p>
                        <p className="text-xs font-black text-[#1a365d]">
                          {new Date(selectedOrder.shipment_options.delivery_window.start).toLocaleString()} - {new Date(selectedOrder.shipment_options.delivery_window.end).toLocaleString()}
                        </p>
                      </div>
                    )}
                    <div>
                      <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Privacy</p>
                      <p className="text-xs font-black text-[#1a365d]">{selectedOrder.shipment_options.privacy_mode}</p>
                    </div>
                  </div>
                  {selectedOrder.shipment_options.handling && selectedOrder.shipment_options.handling.length > 0 && (
                    <div>
                      <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Special Handling</p>
                      <div className="flex flex-wrap gap-2">
                        {selectedOrder.shipment_options.handling.map((h: string) => (
                          <span key={h} className="px-2 py-1 bg-blue-50 text-blue-600 rounded-lg text-[9px] font-black uppercase tracking-widest border border-blue-100">
                            {h}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {selectedOrder.routing_constraints && (
                <div className="pt-8 border-t border-gray-100 space-y-6">
                  <h4 className="text-sm font-black text-[#1a365d] uppercase tracking-widest flex items-center gap-2">
                    <Truck className="w-4 h-4 text-blue-600" /> Routing Constraints
                  </h4>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                    {selectedOrder.routing_constraints.fragile_handling && (
                      <div className="p-4 bg-gray-50 rounded-2xl">
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Fragile Handling</p>
                        <p className="text-xs font-black text-[#1a365d]">{selectedOrder.routing_constraints.fragile_handling}</p>
                      </div>
                    )}
                    {selectedOrder.routing_constraints.delivery_window && (
                      <div className="p-4 bg-gray-50 rounded-2xl">
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Window</p>
                        <p className="text-xs font-black text-[#1a365d]">{selectedOrder.routing_constraints.delivery_window}</p>
                      </div>
                    )}
                    {selectedOrder.routing_constraints.max_transit_days && (
                      <div className="p-4 bg-gray-50 rounded-2xl">
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Max Transit Days</p>
                        <p className="text-xs font-black text-[#1a365d]">{selectedOrder.routing_constraints.max_transit_days}</p>
                      </div>
                    )}
                    {selectedOrder.routing_constraints.avoid_countries && (
                      <div className="p-4 bg-gray-50 rounded-2xl">
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Avoid Countries</p>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {selectedOrder.routing_constraints.avoid_countries.map((c: string) => (
                            <span key={c} className="px-2 py-0.5 bg-rose-50 text-rose-600 rounded text-[9px] font-bold uppercase tracking-widest border border-rose-100">
                              {c}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                    {selectedOrder.routing_constraints.preferred_modes && (
                      <div className="p-4 bg-gray-50 rounded-2xl">
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Preferred Modes</p>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {selectedOrder.routing_constraints.preferred_modes.map((m: string) => (
                            <span key={m} className="px-2 py-0.5 bg-blue-50 text-blue-600 rounded text-[9px] font-bold uppercase tracking-widest border border-blue-100">
                              {m}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {selectedOrder.routing_decision && (
                <div className="pt-8 border-t border-gray-100 space-y-6">
                  <h4 className="text-sm font-black text-[#1a365d] uppercase tracking-widest flex items-center gap-2">
                    <Globe className="w-4 h-4 text-emerald-600" /> Routing Decision
                  </h4>
                  <div className="p-6 bg-emerald-50 rounded-3xl border border-emerald-100">
                    <div className="grid grid-cols-2 gap-6">
                      <div>
                        <p className="text-[10px] font-bold text-emerald-600/60 uppercase tracking-widest mb-1">Strategy</p>
                        <p className="text-xs font-black text-emerald-900">{selectedOrder.routing_decision.strategy}</p>
                      </div>
                      <div>
                        <p className="text-[10px] font-bold text-emerald-600/60 uppercase tracking-widest mb-1">Confidence</p>
                        <p className="text-xs font-black text-emerald-900">{(selectedOrder.routing_decision.confidence * 100).toFixed(1)}%</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Cross-Border Intelligence Section */}
              {selectedOrder.cross_border_intelligence && (
                <div className="pt-8 border-t border-gray-100 space-y-6">
                  <h4 className="text-sm font-black text-[#1a365d] uppercase tracking-widest flex items-center gap-2">
                    <Shield className="w-4 h-4 text-purple-600" /> Cross-Border Intelligence
                  </h4>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Document Requirements */}
                    <div className="p-6 bg-white border border-gray-200 rounded-3xl shadow-sm">
                      <div className="flex items-center justify-between mb-4">
                        <h5 className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Required Documents</h5>
                        <span className="px-2 py-1 bg-amber-50 text-amber-600 rounded-lg text-[9px] font-black uppercase tracking-widest border border-amber-100">
                          {selectedOrder.cross_border_intelligence.status}
                        </span>
                      </div>
                      <div className="space-y-2">
                        {selectedOrder.cross_border_intelligence.required_documents.map((doc: string) => (
                          <div key={doc} className="flex items-center gap-2">
                            <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                            <span className="text-xs font-bold text-gray-600">{doc.replace(/_/g, ' ')}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Carrier Recommendation */}
                    {selectedOrder.cross_border_intelligence.carrier_recommendation && (
                      <div className="p-6 bg-blue-50 border border-blue-100 rounded-3xl shadow-sm">
                        <div className="flex items-center justify-between mb-4">
                          <h5 className="text-[10px] font-black text-blue-600/60 uppercase tracking-widest">Carrier Recommendation</h5>
                          {selectedOrder.cross_border_intelligence.carrier_recommendation.recommended && (
                            <span className="px-2 py-1 bg-emerald-100 text-emerald-700 rounded-lg text-[9px] font-black uppercase tracking-widest border border-emerald-200 flex items-center gap-1">
                              <CheckCircle2 className="w-3 h-3" /> Recommended
                            </span>
                          )}
                        </div>
                        <div className="space-y-3">
                          <div>
                            <p className="text-[10px] font-bold text-blue-600/60 uppercase tracking-widest mb-1">Carrier</p>
                            <p className="text-sm font-black text-blue-900">{selectedOrder.cross_border_intelligence.carrier_recommendation.carrier}</p>
                          </div>
                          <div className="grid grid-cols-3 gap-4">
                            <div>
                              <p className="text-[10px] font-bold text-blue-600/60 uppercase tracking-widest mb-1">Corridor</p>
                              <p className="text-xs font-bold text-blue-800">{selectedOrder.cross_border_intelligence.carrier_recommendation.corridor}</p>
                            </div>
                            <div>
                              <p className="text-[10px] font-bold text-blue-600/60 uppercase tracking-widest mb-1">Delay Prob.</p>
                              <p className="text-xs font-bold text-emerald-600">{(selectedOrder.cross_border_intelligence.carrier_recommendation.delay_probability * 100).toFixed(0)}%</p>
                            </div>
                            {selectedOrder.cross_border_intelligence.carrier_recommendation.reliability_score && (
                              <div>
                                <p className="text-[10px] font-bold text-blue-600/60 uppercase tracking-widest mb-1">Reliability</p>
                                <p className="text-xs font-bold text-blue-900">{(selectedOrder.cross_border_intelligence.carrier_recommendation.reliability_score * 100).toFixed(0)}%</p>
                              </div>
                            )}
                          </div>
                          <div>
                            <p className="text-[10px] font-bold text-blue-600/60 uppercase tracking-widest mb-1">Key Drivers</p>
                            <div className="flex flex-wrap gap-2">
                              {selectedOrder.cross_border_intelligence.carrier_recommendation.drivers.map((driver: string) => (
                                <span key={driver} className="px-2 py-1 bg-white text-blue-600 rounded-lg text-[9px] font-black uppercase tracking-widest border border-blue-100">
                                  {driver}
                                </span>
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Corridor Risk Analysis */}
                  {selectedOrder.cross_border_intelligence.corridor_risk && (
                    <div className="p-6 bg-rose-50 border border-rose-100 rounded-3xl shadow-sm">
                      <div className="flex items-center justify-between mb-4">
                        <h5 className="text-[10px] font-black text-rose-600/60 uppercase tracking-widest">Corridor Risk Analysis</h5>
                        <span className="px-2 py-1 bg-white text-rose-600 rounded-lg text-[9px] font-black uppercase tracking-widest border border-rose-100">
                          {selectedOrder.cross_border_intelligence.corridor_risk.corridor}
                        </span>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div>
                          <p className="text-[10px] font-bold text-rose-600/60 uppercase tracking-widest mb-1">Overall Risk Score</p>
                          <p className="text-2xl font-black text-rose-600">{selectedOrder.cross_border_intelligence.corridor_risk.risk_score}</p>
                        </div>
                        <div className="md:col-span-2">
                          <p className="text-[10px] font-bold text-rose-600/60 uppercase tracking-widest mb-2">Risk Factors</p>
                          <div className="space-y-2">
                            {Object.entries(selectedOrder.cross_border_intelligence.corridor_risk.factors).map(([factor, value]: [string, any]) => (
                              <div key={factor}>
                                <div className="flex justify-between text-[10px] font-bold text-rose-800 mb-1">
                                  <span className="capitalize">{factor.replace('_', ' ')}</span>
                                  <span>{value}</span>
                                </div>
                                <div className="h-1.5 bg-rose-100 rounded-full overflow-hidden">
                                  <div className="h-full bg-rose-500" style={{ width: `${value * 100}%` }} />
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                      <div className="mt-4 pt-4 border-t border-rose-100/50">
                        <p className="text-[10px] font-bold text-rose-600/60 uppercase tracking-widest mb-1">AI Recommendation</p>
                        <p className="text-sm font-black text-rose-900">{selectedOrder.cross_border_intelligence.corridor_risk.recommendation}</p>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Live Transit & Route Progress */}
              {selectedOrder.live_transit && (
                <div className="pt-8 border-t border-gray-100 space-y-6">
                  <h4 className="text-sm font-black text-[#1a365d] uppercase tracking-widest flex items-center gap-2">
                    <Activity className="w-4 h-4 text-emerald-600" /> Live Transit & Route Progress
                  </h4>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Current Leg Info */}
                    <div className="p-6 bg-emerald-50 border border-emerald-100 rounded-3xl shadow-sm">
                      <div className="flex items-center justify-between mb-4">
                        <h5 className="text-[10px] font-black text-emerald-600/60 uppercase tracking-widest">
                          {selectedOrder.live_transit.route_id ? `Route: ${selectedOrder.live_transit.route_id}` : `Current Leg: ${selectedOrder.live_transit.current_leg_id}`}
                        </h5>
                        <span className="px-2 py-1 bg-white text-emerald-600 rounded-lg text-[9px] font-black uppercase tracking-widest border border-emerald-100">
                          {selectedOrder.live_transit.status}
                        </span>
                      </div>
                      <div className="grid grid-cols-2 gap-4 mb-4">
                        <div>
                          <p className="text-[10px] font-bold text-emerald-600/60 uppercase tracking-widest mb-1">Mode</p>
                          <p className="text-xs font-black text-emerald-900">{selectedOrder.live_transit.mode}</p>
                        </div>
                        <div>
                          <p className="text-[10px] font-bold text-emerald-600/60 uppercase tracking-widest mb-1">Partner</p>
                          <p className="text-xs font-black text-emerald-900">{selectedOrder.live_transit.partner}</p>
                        </div>
                        <div>
                          <p className="text-[10px] font-bold text-emerald-600/60 uppercase tracking-widest mb-1">ETA</p>
                          <p className="text-xs font-black text-emerald-900">{new Date(selectedOrder.live_transit.eta).toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-[10px] font-bold text-emerald-600/60 uppercase tracking-widest mb-1">Risk Score</p>
                          <p className="text-xs font-black text-emerald-900">{selectedOrder.live_transit.risk_score}</p>
                        </div>
                      </div>
                      {selectedOrder.live_transit.reliability_score && (
                        <div className="pt-4 border-t border-emerald-200/50">
                          <p className="text-[10px] font-bold text-emerald-600/60 uppercase tracking-widest mb-1">Reliability Score</p>
                          <p className="text-sm font-black text-emerald-900">{(selectedOrder.live_transit.reliability_score * 100).toFixed(0)}%</p>
                        </div>
                      )}
                    </div>

                    {/* Route Legs */}
                    {selectedOrder.live_transit.route_legs && (
                      <div className="p-6 bg-white border border-gray-200 rounded-3xl shadow-sm">
                        <h5 className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-4">Route Legs</h5>
                        <div className="space-y-4 relative before:absolute before:inset-0 before:ml-2 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-transparent before:via-gray-200 before:to-transparent">
                          {selectedOrder.live_transit.route_legs.map((leg: any) => (
                            <div key={leg.leg_id} className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                              <div className={`flex items-center justify-center w-5 h-5 rounded-full border-2 border-white shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 ${leg.status === 'COMPLETED' ? 'bg-emerald-500' : 'bg-blue-500'}`}>
                                {leg.status === 'COMPLETED' ? <CheckCircle2 className="w-3 h-3 text-white" /> : <div className="w-2 h-2 bg-white rounded-full animate-pulse" />}
                              </div>
                              <div className={`w-[calc(100%-2.5rem)] md:w-[calc(50%-1.5rem)] p-3 rounded-xl border ${leg.status === 'COMPLETED' ? 'bg-gray-50 border-gray-100' : 'bg-blue-50 border-blue-100'}`}>
                                <div className="flex items-center justify-between mb-1">
                                  <span className={`text-[9px] font-black uppercase tracking-widest ${leg.status === 'COMPLETED' ? 'text-emerald-600' : 'text-blue-600'}`}>{leg.status}</span>
                                  <span className={`text-[9px] font-bold ${leg.status === 'COMPLETED' ? 'text-gray-400' : 'text-blue-400'}`}>{leg.mode}</span>
                                </div>
                                <p className={`text-xs font-bold ${leg.status === 'COMPLETED' ? 'text-[#1a365d]' : 'text-blue-900'}`}>{leg.from} → {leg.to}</p>
                                {leg.partner && (
                                  <p className={`text-[10px] font-bold mt-1 ${leg.status === 'COMPLETED' ? 'text-gray-500' : 'text-blue-700'}`}>Partner: {leg.partner}</p>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Border Events */}
                  {selectedOrder.live_transit.border_events && selectedOrder.live_transit.border_events.map((event: any, idx: number) => (
                    <div key={idx} className="p-6 bg-amber-50 border border-amber-100 rounded-3xl shadow-sm mb-4">
                      <div className="flex items-center justify-between mb-4">
                        <h5 className="text-[10px] font-black text-amber-600/60 uppercase tracking-widest">Recent Border Events</h5>
                        <span className="px-2 py-1 bg-white text-amber-600 rounded-lg text-[9px] font-black uppercase tracking-widest border border-amber-100">
                          {event.location}
                        </span>
                      </div>
                      <div className="flex items-start gap-4">
                        <div className="w-8 h-8 bg-amber-100 rounded-full flex items-center justify-center shrink-0 mt-1">
                          <AlertTriangle className="w-4 h-4 text-amber-600" />
                        </div>
                        <div>
                          <p className="text-sm font-black text-amber-900">{event.type}</p>
                          <p className="text-xs text-amber-800 mt-1">Source: {event.source} • {new Date(event.timestamp).toLocaleString()}</p>
                          <div className="mt-2 p-3 bg-white rounded-xl border border-amber-100 inline-block">
                            <p className="text-[10px] font-bold text-amber-600/60 uppercase tracking-widest mb-1">Wait Time</p>
                            <p className="text-sm font-black text-amber-900">{event.wait_time_hours} Hours</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}

                  {/* Handover Events */}
                  {selectedOrder.live_transit.handover_events && selectedOrder.live_transit.handover_events.map((event: any, idx: number) => (
                    <div key={idx} className="p-6 bg-blue-50 border border-blue-100 rounded-3xl shadow-sm">
                      <div className="flex items-center justify-between mb-4">
                        <h5 className="text-[10px] font-black text-blue-600/60 uppercase tracking-widest">Handover Event</h5>
                        <span className="px-2 py-1 bg-white text-blue-600 rounded-lg text-[9px] font-black uppercase tracking-widest border border-blue-100">
                          {event.location}
                        </span>
                      </div>
                      <div className="flex items-start gap-4">
                        <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center shrink-0 mt-1">
                          <Activity className="w-4 h-4 text-blue-600" />
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-black text-blue-900">Transfer from {event.from_carrier} to {event.to_partner}</p>
                          <p className="text-xs text-blue-800 mt-1">{new Date(event.timestamp).toLocaleString()} • Status: {event.status}</p>
                          <div className="mt-3 grid grid-cols-2 gap-3">
                            <div className="p-3 bg-white rounded-xl border border-blue-100">
                              <p className="text-[10px] font-bold text-blue-600/60 uppercase tracking-widest mb-1">Next Leg Mode</p>
                              <p className="text-sm font-black text-blue-900">{event.next_leg_mode}</p>
                            </div>
                            <div className="p-3 bg-white rounded-xl border border-blue-100">
                              <p className="text-[10px] font-bold text-blue-600/60 uppercase tracking-widest mb-1">Assigned Partner</p>
                              <p className="text-sm font-black text-blue-900">{event.assigned_partner}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Partner Performance */}
              {selectedOrder.partner_performance && (
                <div className="pt-8 border-t border-gray-100 space-y-6">
                  <h4 className="text-sm font-black text-[#1a365d] uppercase tracking-widest flex items-center gap-2">
                    <Star className="w-4 h-4 text-amber-500" /> Partner Performance
                  </h4>
                  <div className="p-6 bg-white border border-gray-200 rounded-3xl shadow-sm">
                    <div className="flex items-center justify-between mb-6">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-[#1a365d] rounded-xl flex items-center justify-center text-white font-black">
                          {selectedOrder.partner_performance.partner_id}
                        </div>
                        <div>
                          <h5 className="text-sm font-black text-[#1a365d]">{selectedOrder.partner_performance.name}</h5>
                          <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Partner ID: {selectedOrder.partner_performance.partner_id}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="px-3 py-1 bg-amber-50 text-amber-600 rounded-full text-[10px] font-black uppercase tracking-widest border border-amber-100">
                          {selectedOrder.partner_performance.certification_level} CERTIFIED
                        </span>
                        <p className="text-2xl font-black text-[#1a365d] mt-1">{selectedOrder.partner_performance.overall_score}<span className="text-sm text-gray-400">/100</span></p>
                      </div>
                    </div>

                    {selectedOrder.partner_performance.drivers && (
                      <div className="mb-6">
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Key Performance Drivers</p>
                        <div className="flex flex-wrap gap-2">
                          {selectedOrder.partner_performance.drivers.map((driver: string, idx: number) => (
                            <span key={idx} className="px-2 py-1 bg-blue-50 text-blue-600 rounded-lg text-[9px] font-black uppercase tracking-widest border border-blue-100">
                              {driver}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                      <div className="p-4 bg-gray-50 rounded-2xl">
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Operational</p>
                        <p className="text-lg font-black text-[#1a365d]">{selectedOrder.partner_performance.metrics.operational}</p>
                      </div>
                      <div className="p-4 bg-gray-50 rounded-2xl">
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Compliance</p>
                        <p className="text-lg font-black text-emerald-600">{selectedOrder.partner_performance.metrics.compliance}</p>
                      </div>
                      <div className="p-4 bg-gray-50 rounded-2xl">
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">CX</p>
                        <p className="text-lg font-black text-[#1a365d]">{selectedOrder.partner_performance.metrics.cx}</p>
                      </div>
                      <div className="p-4 bg-gray-50 rounded-2xl">
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Resilience</p>
                        <p className="text-lg font-black text-blue-600">{selectedOrder.partner_performance.metrics.resilience}</p>
                      </div>
                    </div>
                    
                    {selectedOrder.partner_performance.metrics.otd && (
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                        <div className="p-4 bg-indigo-50 rounded-2xl">
                          <p className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest mb-1">On-Time Delivery</p>
                          <p className="text-lg font-black text-indigo-900">{(selectedOrder.partner_performance.metrics.otd * 100).toFixed(0)}%</p>
                        </div>
                        <div className="p-4 bg-indigo-50 rounded-2xl">
                          <p className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest mb-1">Border Dwell Avg</p>
                          <p className="text-lg font-black text-indigo-900">{selectedOrder.partner_performance.metrics.border_dwell_avg}h</p>
                        </div>
                        <div className="p-4 bg-indigo-50 rounded-2xl">
                          <p className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest mb-1">Port Dwell Avg</p>
                          <p className="text-lg font-black text-indigo-900">{selectedOrder.partner_performance.metrics.port_dwell_avg}h</p>
                        </div>
                        <div className="p-4 bg-indigo-50 rounded-2xl">
                          <p className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest mb-1">Exception Rate</p>
                          <p className="text-lg font-black text-indigo-900">{(selectedOrder.partner_performance.metrics.exception_rate * 100).toFixed(1)}%</p>
                        </div>
                      </div>
                    )}

                    {selectedOrder.partner_performance.corridors && (
                      <div className="mt-6 pt-6 border-t border-gray-100">
                        <h6 className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-4">Corridor Performance</h6>
                        <div className="space-y-3">
                          {selectedOrder.partner_performance.corridors.map((c: any, idx: number) => (
                            <div key={idx} className="p-4 bg-gray-50 rounded-2xl border border-gray-100 flex items-center justify-between">
                              <div>
                                <p className="text-xs font-black text-[#1a365d]">{c.corridor}</p>
                              </div>
                              <div className="flex gap-6">
                                <div>
                                  <p className="text-[9px] font-bold text-gray-400 uppercase tracking-widest mb-1">Score</p>
                                  <p className="text-sm font-black text-[#1a365d]">{c.score}</p>
                                </div>
                                <div>
                                  <p className="text-[9px] font-bold text-gray-400 uppercase tracking-widest mb-1">Risk-Adj Reliability</p>
                                  <p className="text-sm font-black text-[#1a365d]">{(c.risk_adjusted_reliability * 100).toFixed(0)}%</p>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {selectedOrder.partner_performance.integration_status && (
                      <div className="mt-6 pt-6 border-t border-gray-100">
                        <h6 className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-4">Integration Status</h6>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                          <div>
                            <p className="text-[9px] font-bold text-gray-400 uppercase tracking-widest mb-1">Status</p>
                            <p className="text-xs font-black text-[#1a365d]">{selectedOrder.partner_performance.integration_status}</p>
                          </div>
                          <div>
                            <p className="text-[9px] font-bold text-gray-400 uppercase tracking-widest mb-1">Event Coverage</p>
                            <p className="text-xs font-black text-[#1a365d]">{(selectedOrder.partner_performance.event_coverage * 100).toFixed(0)}%</p>
                          </div>
                          <div>
                            <p className="text-[9px] font-bold text-gray-400 uppercase tracking-widest mb-1">Latency p95</p>
                            <p className="text-xs font-black text-[#1a365d]">{selectedOrder.partner_performance.latency_p95}ms</p>
                          </div>
                          <div>
                            <p className="text-[9px] font-bold text-gray-400 uppercase tracking-widest mb-1">Schema Compliance</p>
                            <p className="text-xs font-black text-[#1a365d]">{(selectedOrder.partner_performance.schema_compliance * 100).toFixed(0)}%</p>
                          </div>
                        </div>
                      </div>
                    )}

                    {selectedOrder.partner_performance.customer_experience && (
                      <div className="mt-6 pt-6 border-t border-gray-100">
                        <h6 className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-4">Customer Experience</h6>
                        <div className="grid grid-cols-3 gap-4">
                          <div className="p-3 bg-purple-50 rounded-xl border border-purple-100">
                            <p className="text-[9px] font-bold text-purple-600/60 uppercase tracking-widest mb-1">Sentiment Score</p>
                            <p className="text-sm font-black text-purple-900">{selectedOrder.partner_performance.customer_experience.sentiment_score}</p>
                          </div>
                          <div className="p-3 bg-purple-50 rounded-xl border border-purple-100">
                            <p className="text-[9px] font-bold text-purple-600/60 uppercase tracking-widest mb-1">Damage Rate</p>
                            <p className="text-sm font-black text-purple-900">{(selectedOrder.partner_performance.customer_experience.damage_rate * 100).toFixed(2)}%</p>
                          </div>
                          <div className="p-3 bg-purple-50 rounded-xl border border-purple-100">
                            <p className="text-[9px] font-bold text-purple-600/60 uppercase tracking-widest mb-1">Complaint Rate</p>
                            <p className="text-sm font-black text-purple-900">{(selectedOrder.partner_performance.customer_experience.complaint_rate * 100).toFixed(2)}%</p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {selectedOrder.routing_weights && (
                <div className="pt-8 border-t border-gray-100 space-y-6">
                  <h4 className="text-sm font-black text-[#1a365d] uppercase tracking-widest flex items-center gap-2">
                    <Zap className="w-4 h-4 text-amber-500" /> Optimization Weights
                  </h4>
                  <div className="grid grid-cols-5 gap-4">
                    <div className="p-3 bg-blue-50 rounded-xl border border-blue-100">
                      <p className="text-[9px] font-bold text-blue-600/60 uppercase tracking-widest mb-1">Time</p>
                      <p className="text-xs font-black text-blue-900">{selectedOrder.routing_weights.w_t}</p>
                    </div>
                    <div className="p-3 bg-rose-50 rounded-xl border border-rose-100">
                      <p className="text-[9px] font-bold text-rose-600/60 uppercase tracking-widest mb-1">Risk</p>
                      <p className="text-xs font-black text-rose-900">{selectedOrder.routing_weights.w_r}</p>
                    </div>
                    <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-100">
                      <p className="text-[9px] font-bold text-emerald-600/60 uppercase tracking-widest mb-1">Battery</p>
                      <p className="text-xs font-black text-emerald-900">{selectedOrder.routing_weights.w_b}</p>
                    </div>
                    <div className="p-3 bg-amber-50 rounded-xl border border-amber-100">
                      <p className="text-[9px] font-bold text-amber-600/60 uppercase tracking-widest mb-1">Weather</p>
                      <p className="text-xs font-black text-amber-900">{selectedOrder.routing_weights.w_w}</p>
                    </div>
                    <div className="p-3 bg-purple-50 rounded-xl border border-purple-100">
                      <p className="text-[9px] font-bold text-purple-600/60 uppercase tracking-widest mb-1">Safety</p>
                      <p className="text-xs font-black text-purple-900">{selectedOrder.routing_weights.w_s}</p>
                    </div>
                  </div>
                </div>
              )}

              {selectedOrder.mode_execution && (
                <div className="pt-8 border-t border-gray-100 space-y-6">
                  <h4 className="text-sm font-black text-[#1a365d] uppercase tracking-widest flex items-center gap-2">
                    <Activity className="w-4 h-4 text-blue-600" /> Execution Mode
                  </h4>
                  <div className="p-4 bg-blue-50 rounded-2xl border border-blue-100">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-[10px] font-bold text-blue-600/60 uppercase tracking-widest mb-1">Actual Mode</p>
                        <p className="text-xs font-black text-blue-900">{selectedOrder.mode_execution.actual_mode}</p>
                      </div>
                      <div>
                        <p className="text-[10px] font-bold text-blue-600/60 uppercase tracking-widest mb-1">Handoff</p>
                        <p className="text-xs font-black text-blue-900">{selectedOrder.mode_execution.handoff_point || 'Direct'}</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {selectedOrder.route_summary && (
                <div className="pt-8 border-t border-gray-100 space-y-6">
                  <h4 className="text-sm font-black text-[#1a365d] uppercase tracking-widest flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-emerald-600" /> Route Summary
                  </h4>
                  <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-100">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-[10px] font-bold text-emerald-600/60 uppercase tracking-widest mb-1">Distance</p>
                        <p className="text-xs font-black text-emerald-900">{(selectedOrder.route_summary.distance_m / 1000).toFixed(2)} km</p>
                      </div>
                      <div>
                        <p className="text-[10px] font-bold text-emerald-600/60 uppercase tracking-widest mb-1">ETA</p>
                        <p className="text-xs font-black text-emerald-900">{new Date(selectedOrder.route_summary.eta).toLocaleTimeString()}</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {selectedOrder.mode_rationale && (
                <div className="pt-8 border-t border-gray-100 space-y-6">
                  <h4 className="text-sm font-black text-[#1a365d] uppercase tracking-widest flex items-center gap-2">
                    <Info className="w-4 h-4 text-blue-600" /> Mode Rationale
                  </h4>
                  <div className="p-4 bg-blue-50 rounded-2xl border border-blue-100">
                    <p className="text-[10px] font-bold text-blue-600/60 uppercase tracking-widest mb-1">Reason</p>
                    <p className="text-xs font-medium text-blue-900 italic">"{selectedOrder.mode_rationale.reason}"</p>
                  </div>
                </div>
              )}

              {selectedOrder.handoff_details && (
                <div className="pt-8 border-t border-gray-100 space-y-6">
                  <h4 className="text-sm font-black text-[#1a365d] uppercase tracking-widest flex items-center gap-2">
                    <Navigation className="w-4 h-4 text-purple-600" /> Handoff Details
                  </h4>
                  <div className="p-4 bg-purple-50 rounded-2xl border border-purple-100">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-[10px] font-bold text-purple-600/60 uppercase tracking-widest mb-1">Location</p>
                        <p className="text-xs font-black text-purple-900">{selectedOrder.handoff_details.location.lat.toFixed(4)}, {selectedOrder.handoff_details.location.lon.toFixed(4)}</p>
                      </div>
                      <div>
                        <p className="text-[10px] font-bold text-purple-600/60 uppercase tracking-widest mb-1">Time</p>
                        <p className="text-xs font-black text-purple-900">{new Date(selectedOrder.handoff_details.timestamp).toLocaleTimeString()}</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {selectedOrder.ground_robot_route && (
                <div className="pt-8 border-t border-gray-100 space-y-6">
                  <h4 className="text-sm font-black text-[#1a365d] uppercase tracking-widest flex items-center gap-2">
                    <Truck className="w-4 h-4 text-blue-600" /> Ground Robot Route
                  </h4>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-3 bg-gray-50 rounded-xl border border-gray-100">
                        <p className="text-[9px] font-bold text-gray-400 uppercase tracking-widest mb-1">Robot ID</p>
                        <p className="text-xs font-black text-[#1a365d]">{selectedOrder.ground_robot_route.robot_id}</p>
                      </div>
                      <div className="p-3 bg-gray-50 rounded-xl border border-gray-100">
                        <p className="text-[9px] font-bold text-gray-400 uppercase tracking-widest mb-1">Route ID</p>
                        <p className="text-xs font-black text-[#1a365d]">{selectedOrder.ground_robot_route.route_id}</p>
                      </div>
                    </div>
                    <div className="p-4 bg-blue-50/30 rounded-2xl border border-blue-100/50">
                      <p className="text-[10px] font-black text-blue-600 uppercase tracking-widest mb-3">Waypoints ({selectedOrder.ground_robot_route.waypoints.length})</p>
                      <div className="space-y-2">
                        {selectedOrder.ground_robot_route.waypoints.map((wp: any) => (
                          <div key={wp.seq} className="flex items-center gap-3 p-2 bg-white rounded-lg border border-blue-100/50">
                            <div className="w-5 h-5 bg-blue-600 text-white rounded flex items-center justify-center text-[9px] font-black">
                              {wp.seq}
                            </div>
                            <div className="flex-1">
                              <p className="text-[9px] font-black text-[#1a365d] uppercase tracking-widest">{wp.type}</p>
                              <p className="text-[8px] font-bold text-gray-400">{wp.lat.toFixed(5)}, {wp.lon.toFixed(5)}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="p-8 bg-gray-50/50 border-t border-gray-100 flex justify-end gap-4">
              <button 
                onClick={() => setSelectedOrder(null)}
                className="px-8 py-3 rounded-2xl text-xs font-black uppercase tracking-widest text-gray-400 hover:bg-gray-100 transition-all"
              >
                Close
              </button>
              <button className="px-8 py-3 bg-[#1a365d] text-white rounded-2xl text-xs font-black uppercase tracking-widest hover:bg-blue-900 transition-all shadow-lg shadow-blue-900/20">
                Manage Order
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </motion.div>
  );
}
