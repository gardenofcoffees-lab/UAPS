const steps = ["PICKED_UP", "IN_TRANSIT", "DELIVERED"];

export function DeliveryTimeline({ history }: { history: { status: string; timestamp: number }[] }) {
  const isFailed = history.some(h => h.status === 'FAILED_SECURITY_EVENT');
  const currentSteps = isFailed ? ["PICKED_UP", "IN_TRANSIT", "FAILED_SECURITY_EVENT"] : steps;

  return (
    <div className="flex items-center gap-4">
      {currentSteps.map((step, i) => {
        const done = history.some(h => h.status === step);
        const isStepFailed = step === 'FAILED_SECURITY_EVENT';
        
        return (
          <div key={i} className="flex items-center">
            <div
              className={`w-4 h-4 rounded-full ${
                done ? (isStepFailed ? "bg-red-600" : "bg-green-600") : "bg-gray-300"
              } transition-colors duration-500`}
            />
            {i < currentSteps.length - 1 && (
              <div className={`w-12 h-1 ${done ? "bg-green-600" : "bg-gray-300"} transition-colors duration-500`} />
            )}
          </div>
        );
      })}
    </div>
  );
}
