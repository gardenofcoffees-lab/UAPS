import { useState, useRef, useEffect } from 'react';
import { MessageSquare, X, Send, Bot, User, Loader2, Minimize2, Package, Globe, Shield, Truck, Search } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI, FunctionDeclaration, Type } from "@google/genai";

type Message = {
  role: 'user' | 'assistant' | 'system';
  content: string;
};

const trackPackageTool: FunctionDeclaration = {
  name: "trackPackage",
  description: "Get real-time tracking information for a UAPS shipment using its tracking ID (e.g., UAPS-KE-2026-12345678).",
  parameters: {
    type: Type.OBJECT,
    properties: {
      trackingId: {
        type: Type.STRING,
        description: "The unique tracking number of the shipment.",
      },
    },
    required: ["trackingId"],
  },
};

const getShippingRatesTool: FunctionDeclaration = {
  name: "getShippingRates",
  description: "Estimate shipping rates between two African cities.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      origin: { type: Type.STRING, description: "Origin city and country" },
      destination: { type: Type.STRING, description: "Destination city and country" },
      weight: { type: Type.NUMBER, description: "Weight in kg" },
      dimensions: { type: Type.STRING, description: "Dimensions (e.g., 30x30x30 cm)" },
    },
    required: ["origin", "destination", "weight"],
  },
};

export function AssistantChat() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', content: 'Hello! I am your UAPS Logistics Assistant. I can help you track packages, check shipping rates, or understand customs regulations across Africa. How can I assist you today?' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const quickActions = [
    { label: 'Track Package', icon: Search, prompt: 'I want to track my package' },
    { label: 'Shipping Rates', icon: Truck, prompt: 'Shipping Rates' },
    { label: 'Customs Info', icon: Shield, prompt: 'What are the customs rules for Ghana?' },
  ];

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSendMessage = async (overrideInput?: string) => {
    const messageText = overrideInput || input.trim();
    if (!messageText || isLoading) return;

    if (!overrideInput) setInput('');
    setMessages(prev => [...prev, { role: 'user', content: messageText }]);

    // Direct response for Shipping Rates quick action
    if (messageText === 'Shipping Rates') {
      setIsLoading(true);
      setTimeout(() => {
        setMessages(prev => [...prev, { 
          role: 'assistant', 
          content: "I'd be happy to help you with a shipping quote! To provide an accurate rate, could you please tell me:\n\n1. **Route**: From where to where? (City and Country)\n2. **Weight**: Approximate weight in kilograms (kg)\n3. **Dimensions**: The size of your shipment (Length x Width x Height in cm)" 
        }]);
        setIsLoading(false);
      }, 600);
      return;
    }

    setIsLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      
      const systemInstruction = `You are the UAPS (Universal African Postal Service) Intelligence Assistant. 
      UAPS is the premier pan-African logistics network connecting all 54 African nations.
      
      Key Information:
      - Tracking ID Format: UAPS-CC-YYYY-NNNNNNNN (where CC is country code, YYYY is year).
      - We handle customs clearance, last-mile delivery, and global freight.
      - Our mission is "Delivering Africa Together".
      
      Capabilities:
      - You can track packages using the trackPackage tool.
      - You can estimate rates using getShippingRates tool.
      - You provide expert advice on African intra-continental trade (AfCFTA).
      
      Tone: Professional, efficient, reliable, and proudly African. Keep responses concise but helpful.`;

      let currentContents = [
        ...messages.map(m => ({ 
          role: m.role === 'user' ? 'user' : 'model', 
          parts: [{ text: m.content }] 
        })),
        { role: 'user', parts: [{ text: messageText }] }
      ];

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: currentContents,
        config: {
          systemInstruction,
          tools: [{ functionDeclarations: [trackPackageTool, getShippingRatesTool] }],
          temperature: 0.7,
        },
      });

      // Handle Function Calls
      if (response.functionCalls) {
        const toolResults = [];
        
        for (const call of response.functionCalls) {
          if (call.name === "trackPackage") {
            try {
              const res = await fetch(`/api/track/${call.args.trackingId}`);
              const __dataBody = await res.json();
      const data = __dataBody.data || __dataBody;
              toolResults.push({
                callId: call.id,
                response: { name: "trackPackage", content: data }
              });
            } catch (e) {
              toolResults.push({
                callId: call.id,
                response: { name: "trackPackage", content: { error: "Could not find shipment." } }
              });
            }
          } else if (call.name === "getShippingRates") {
            // Mock rate calculation
            const weight = call.args.weight as number;
            const baseRate = weight * 15.5;
            // Add a small premium if dimensions are provided (mock logic)
            const dimensionPremium = call.args.dimensions ? 5.0 : 0;
            const totalRate = baseRate + dimensionPremium;

            toolResults.push({
              callId: call.id,
              response: { 
                name: "getShippingRates", 
                content: { 
                  estimatedRate: `$${totalRate.toFixed(2)}`,
                  currency: "USD",
                  service: "UAPS Standard",
                  deliveryTime: "3-5 business days",
                  details: `Based on ${weight}kg ${call.args.dimensions ? `(${call.args.dimensions})` : ''}`
                } 
              }
            });
          }
        }

        // Send tool results back to model
        const finalResponse = await ai.models.generateContent({
          model: "gemini-3-flash-preview",
          contents: [
            ...currentContents,
            { role: 'model', parts: response.candidates[0].content.parts },
            { 
              role: 'user', 
              parts: toolResults.map(tr => ({
                functionResponse: {
                  name: tr.response.name,
                  response: tr.response.content
                }
              }))
            }
          ],
          config: { systemInstruction }
        });

        setMessages(prev => [...prev, { role: 'assistant', content: finalResponse.text || "I've processed your request." }]);
      } else {
        const reply = response.text || "I'm sorry, I couldn't generate a response. Please try again.";
        setMessages(prev => [...prev, { role: 'assistant', content: reply }]);
      }
    } catch (error) {
      console.error("Assistant Error:", error);
      setMessages(prev => [...prev, { role: 'assistant', content: "Sorry, I encountered an error. Please try again later." }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-[9999]">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="bg-white border border-gray-200 rounded-2xl shadow-2xl w-[350px] sm:w-[400px] h-[500px] flex flex-col overflow-hidden mb-4"
          >
            {/* Header */}
            <div className="bg-[#1a365d] p-4 flex items-center justify-between text-white">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-white/10 rounded-full flex items-center justify-center">
                  <Bot className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold uppercase tracking-wider">UAPS Assistant</h3>
                  <div className="flex items-center gap-1.5">
                    <div className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse" />
                    <span className="text-[10px] opacity-70 uppercase font-mono">Online</span>
                  </div>
                </div>
              </div>
              <button 
                onClick={() => setIsOpen(false)}
                className="p-1 hover:bg-white/10 rounded-lg transition-colors"
              >
                <Minimize2 className="w-4 h-4" />
              </button>
            </div>

            {/* Messages */}
            <div 
              ref={scrollRef}
              className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50 scroll-smooth"
            >
              {messages.map((m, i) => (
                <div 
                  key={i}
                  className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`flex gap-2 max-w-[85%] ${m.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 mt-1 ${m.role === 'user' ? 'bg-[#1a365d] text-white' : 'bg-white border border-gray-200 text-[#1a365d]'}`}>
                      {m.role === 'user' ? <User className="w-3.5 h-3.5" /> : <Bot className="w-3.5 h-3.5" />}
                    </div>
                    <div className={`p-3 rounded-2xl text-sm leading-relaxed shadow-sm ${
                      m.role === 'user' 
                        ? 'bg-[#1a365d] text-white rounded-tr-none' 
                        : 'bg-white border border-gray-100 text-gray-700 rounded-tl-none'
                    }`}>
                      {m.content}
                    </div>
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="flex gap-2 max-w-[85%]">
                    <div className="w-6 h-6 rounded-full bg-white border border-gray-200 text-[#1a365d] flex items-center justify-center flex-shrink-0 mt-1">
                      <Bot className="w-3.5 h-3.5" />
                    </div>
                    <div className="bg-white border border-gray-100 p-3 rounded-2xl rounded-tl-none shadow-sm flex items-center gap-2">
                      <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
                      <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Processing...</span>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Quick Actions */}
            {!isLoading && messages.length < 4 && (
              <div className="px-4 py-2 bg-gray-50 flex gap-2 overflow-x-auto no-scrollbar border-t border-gray-100">
                {quickActions.map((action, i) => (
                  <button
                    key={i}
                    onClick={() => handleSendMessage(action.prompt)}
                    className="flex-shrink-0 flex items-center gap-2 px-3 py-1.5 bg-white border border-gray-200 rounded-full text-[10px] font-bold text-[#1a365d] hover:border-[#1a365d] hover:bg-blue-50 transition-all whitespace-nowrap"
                  >
                    <action.icon className="w-3 h-3" />
                    {action.label}
                  </button>
                ))}
              </div>
            )}

            {/* Input */}
            <div className="p-4 bg-white border-t border-gray-100">
              <div className="flex gap-2">
                <input 
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                  placeholder="Ask me anything..."
                  className="flex-1 bg-gray-50 border border-gray-200 rounded-xl px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#1a365d]/20 transition-all"
                />
                <button 
                  onClick={() => handleSendMessage()}
                  disabled={isLoading || !input.trim()}
                  className="w-10 h-10 bg-[#1a365d] text-white rounded-xl flex items-center justify-center hover:bg-[#2c5282] disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-lg shadow-[#1a365d]/20"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
              <p className="text-[9px] text-center text-gray-400 mt-3 uppercase tracking-widest">
                Powered by UAPS Intelligence
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsOpen(!isOpen)}
        className={`w-14 h-14 rounded-full flex items-center justify-center shadow-2xl transition-all ${
          isOpen ? 'bg-white text-[#1a365d] border border-gray-200' : 'bg-[#1a365d] text-white'
        }`}
      >
        {isOpen ? <X className="w-6 h-6" /> : <MessageSquare className="w-6 h-6" />}
      </motion.button>
    </div>
  );
}
