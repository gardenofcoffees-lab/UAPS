import React, { useState } from 'react';
import { Logo } from './Logo';
import { motion } from 'motion/react';
import { LogIn, Shield, Lock, Mail, ChevronRight, Server, Activity, Database } from 'lucide-react';

interface AdminLoginProps {
  onLogin: (success: boolean) => void;
}

export function AdminLogin({ onLogin }: AdminLoginProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    // Simulated authentication
    setTimeout(() => {
      if (email === 'admin@uaps.africa' && password === 'admin2024') {
        onLogin(true);
      } else {
        setError('Invalid credentials. Please use admin@uaps.africa / admin2024 for demo access.');
        setIsLoading(false);
      }
    }, 1500);
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center p-6 bg-gray-50">
      <div className="max-w-5xl w-full grid grid-cols-1 lg:grid-cols-2 bg-white rounded-[40px] shadow-2xl overflow-hidden border border-gray-100">
        {/* Left Side: Branding & Info */}
        <div className="bg-[#1a365d] p-12 text-white relative overflow-hidden hidden lg:flex flex-col justify-between">
          <div className="absolute top-0 right-0 w-full h-full opacity-10 pointer-events-none">
            <svg viewBox="0 0 800 800" className="w-full h-full">
              <pattern id="grid-login-admin" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" strokeWidth="0.5" />
              </pattern>
              <rect width="100%" height="100%" fill="url(#grid-login-admin)" />
            </svg>
          </div>

          <div className="relative z-10">
            <div className="mb-12">
              <Logo variant="light" size="md" />
              <p className="text-[8px] font-bold uppercase tracking-[0.3em] text-emerald-400 mt-2 ml-1">Admin Portal</p>
            </div>

            <h2 className="text-4xl font-bold mb-6 leading-tight">
              Command & Control <br />
              <span className="text-emerald-400">Center</span>
            </h2>
            <p className="text-blue-100/60 text-sm leading-relaxed mb-12 max-w-sm">
              Access the central nervous system of the United Africa Postal Service. Monitor fleet telemetry, manage partner applications, and oversee global logistics operations.
            </p>

            <div className="space-y-6">
              {[
                { icon: Shield, title: "System Governance", desc: "Full administrative control and audit logs." },
                { icon: Activity, title: "Real-time Telemetry", desc: "Live tracking of air and ground assets." },
                { icon: Database, title: "Partner Management", desc: "Review and approve partner applications." }
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center">
                    <item.icon className="w-5 h-5 text-emerald-400" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold">{item.title}</h4>
                    <p className="text-[10px] text-blue-100/40">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="relative z-10 pt-12 border-t border-white/10">
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">
              © 2024 United Africa Postal Service. All rights reserved.
            </p>
          </div>
        </div>

        {/* Right Side: Login Form */}
        <div className="p-12 lg:p-20 flex flex-col justify-center">
          <div className="mb-10">
            <h3 className="text-2xl font-bold text-[#1a365d] mb-2">Admin Login</h3>
            <p className="text-gray-500 text-sm">Enter your credentials to access the command center.</p>
          </div>

          {error && (
            <motion.div 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-red-50 border-l-4 border-red-500 p-4 mb-8 flex items-center gap-3"
            >
              <Shield className="w-5 h-5 text-red-500" />
              <p className="text-red-700 text-xs font-medium">{error}</p>
            </motion.div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest ml-1">Admin Email</label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-300" />
                <input 
                  type="email" 
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="admin@uaps.africa"
                  className="w-full bg-gray-50 border border-gray-200 rounded-2xl pl-12 pr-6 py-4 text-sm focus:outline-none focus:ring-2 focus:ring-[#1a365d] transition-all"
                />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center ml-1">
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Password</label>
                <button type="button" className="text-[10px] font-bold text-emerald-600 uppercase tracking-widest hover:underline">Forgot Password?</button>
              </div>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-300" />
                <input 
                  type="password" 
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-gray-50 border border-gray-200 rounded-2xl pl-12 pr-6 py-4 text-sm focus:outline-none focus:ring-2 focus:ring-[#1a365d] transition-all"
                />
              </div>
            </div>

            <div className="flex items-center gap-2 ml-1">
              <input type="checkbox" id="remember-admin" className="rounded border-gray-300 text-[#1a365d] focus:ring-[#1a365d]" />
              <label htmlFor="remember-admin" className="text-[10px] font-bold text-gray-500 uppercase tracking-widest cursor-pointer">Remember this device</label>
            </div>

            <button 
              type="submit" 
              disabled={isLoading}
              className="w-full bg-[#1a365d] text-white py-4 rounded-2xl font-bold text-sm uppercase tracking-widest hover:bg-blue-900 transition-all shadow-xl shadow-blue-900/20 flex items-center justify-center gap-2 group"
            >
              {isLoading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  Access Command Center <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
