import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  FileText, 
  Globe, 
  Shield, 
  AlertCircle, 
  CheckCircle2, 
  Plus, 
  Trash2, 
  ArrowRight, 
  Info,
  Scale,
  DollarSign,
  Package,
  MapPin,
  Sparkles,
  Loader2
} from 'lucide-react';

interface CustomsItem {
  id: string;
  description: string;
  quantity: number;
  value: number;
  weight: number;
  hsCode: string;
  origin: string;
}

interface CustomsClearanceFormProps {
  shipmentId?: string;
  onComplete?: (data: any) => void;
  onCancel?: () => void;
}

export function CustomsClearanceForm({ shipmentId, onComplete, onCancel }: CustomsClearanceFormProps) {
  const [items, setItems] = useState<CustomsItem[]>([
    { id: '1', description: '', quantity: 1, value: 0, weight: 0, hsCode: '', origin: '' }
  ]);
  const [declaration, setDeclaration] = useState({
    reason: 'Sale',
    terms: 'DDP', // Delivered Duty Paid
    currency: 'USD',
    notes: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [generatingId, setGeneratingId] = useState<string | null>(null);
  const [aiError, setAiError] = useState<string | null>(null);

  const addItem = () => {
    setItems([...items, { 
      id: Math.random().toString(36).substr(2, 9), 
      description: '', 
      quantity: 1, 
      value: 0, 
      weight: 0, 
      hsCode: '', 
      origin: '' 
    }]);
  };

  const removeItem = (id: string) => {
    if (items.length > 1) {
      setItems(items.filter(item => item.id !== id));
    }
  };

  const updateItem = (id: string, field: keyof CustomsItem, value: any) => {
    setItems(items.map(item => item.id === id ? { ...item, [field]: value } : item));
  };

  const generateHSCode = async (id: string, description: string) => {
    if (!description.trim()) return;
    
    setGeneratingId(id);
    setAiError(null);
    try {
      const response = await fetch('/api/ai/hs-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ description })
      });
      
      const __dataBody = await response.json();
      const data = __dataBody.data || __dataBody;
      if (response.ok && data.hsCode) {
        updateItem(id, 'hsCode', data.hsCode);
      } else {
        setAiError(data.error || "Failed to generate HS Code");
      }
    } catch (error) {
      console.error("Failed to generate HS Code:", error);
      setAiError("Connection error. Please try again.");
    } finally {
      setGeneratingId(null);
    }
  };

  const totalValue = items.reduce((sum, item) => sum + (item.value * item.quantity), 0);
  const totalWeight = items.reduce((sum, item) => sum + (item.weight * item.quantity), 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
      if (onComplete) {
        onComplete({ items, declaration, totalValue, totalWeight });
      }
    }, 2000);
  };

  if (isSuccess) {
    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white p-12 rounded-[40px] shadow-2xl border border-emerald-100 text-center max-w-2xl mx-auto"
      >
        <div className="w-20 h-20 bg-emerald-50 rounded-3xl flex items-center justify-center text-emerald-500 mx-auto mb-8">
          <CheckCircle2 className="w-10 h-10" />
        </div>
        <h2 className="text-3xl font-black text-[#1a365d] mb-4 uppercase tracking-tight">Declaration Submitted</h2>
        <p className="text-gray-500 mb-8 leading-relaxed">
          Your customs clearance documentation has been successfully processed and attached to shipment <span className="font-bold text-blue-600">{shipmentId || 'UAPS-NEW'}</span>. 
          The regulatory authorities have been notified.
        </p>
        <button 
          onClick={onCancel}
          className="px-8 py-4 bg-[#1a365d] text-white rounded-2xl text-xs font-black uppercase tracking-widest hover:bg-blue-900 transition-all shadow-lg"
        >
          Return to Dashboard
        </button>
      </motion.div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto">
      <div className="bg-white rounded-[40px] shadow-2xl border border-gray-100 overflow-hidden">
        {/* Header */}
        <div className="bg-[#1a365d] p-10 text-white relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/10 rounded-full -mr-32 -mt-32 blur-3xl" />
          <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <div className="p-2 bg-white/10 rounded-lg">
                  <Globe className="w-5 h-5 text-blue-400" />
                </div>
                <span className="text-[10px] font-black uppercase tracking-[0.3em] text-blue-400">International Trade</span>
              </div>
              <h1 className="text-3xl font-black uppercase tracking-tight">Customs Declaration</h1>
              <p className="text-blue-100/60 text-sm mt-2">Regulatory compliance for cross-border drone logistics</p>
            </div>
            <div className="bg-white/5 backdrop-blur-md border border-white/10 p-4 rounded-2xl">
              <p className="text-[10px] font-bold text-blue-200 uppercase tracking-widest mb-1">Shipment ID</p>
              <p className="text-lg font-black font-mono">{shipmentId || 'NEW-SHIPMENT'}</p>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-10 space-y-12">
          {aiError && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-6 py-4 rounded-3xl text-sm flex items-center gap-4 animate-in fade-in slide-in-from-top-4">
              <div className="w-10 h-10 bg-red-100 rounded-xl flex items-center justify-center text-red-600 flex-shrink-0">
                <Info className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <p className="font-black uppercase tracking-tight text-xs mb-0.5">AI Service Error</p>
                <p className="font-medium opacity-80">{aiError}</p>
              </div>
              <button 
                onClick={() => setAiError(null)}
                className="p-2 hover:bg-red-100 rounded-lg transition-colors text-red-400 hover:text-red-600"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Items Section */}
          <section>
            <div className="flex justify-between items-center mb-8">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center text-blue-600">
                  <Package className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-[#1a365d] uppercase tracking-tight">Declared Items</h3>
                  <p className="text-xs text-gray-400 font-bold uppercase tracking-widest">List all contents of the package</p>
                </div>
              </div>
              <button 
                type="button"
                onClick={addItem}
                className="flex items-center gap-2 px-4 py-2 bg-blue-50 text-blue-600 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-blue-100 transition-all"
              >
                <Plus className="w-3 h-3" /> Add Item
              </button>
            </div>

            <div className="space-y-4">
              <AnimatePresence initial={false}>
                {items.map((item, index) => (
                  <motion.div 
                    key={item.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="p-6 bg-gray-50 rounded-3xl border border-gray-100 relative group"
                  >
                    <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
                      <div className="md:col-span-4">
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 block">Description</label>
                        <input 
                          required
                          type="text"
                          value={item.description}
                          onChange={(e) => updateItem(item.id, 'description', e.target.value)}
                          placeholder="e.g. Medical Supplies, Electronics"
                          className="w-full bg-white border border-gray-200 rounded-xl px-4 py-3 text-sm font-bold text-[#1a365d] focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                        />
                      </div>
                      <div className="md:col-span-2">
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 flex items-center justify-between">
                          HS Code
                          <button
                            type="button"
                            onClick={() => generateHSCode(item.id, item.description)}
                            disabled={!item.description || generatingId === item.id}
                            className="text-blue-600 hover:text-blue-700 disabled:opacity-30 flex items-center gap-1 transition-all"
                            title="Generate HS Code with AI"
                          >
                            {generatingId === item.id ? (
                              <Loader2 className="w-3 h-3 animate-spin" />
                            ) : (
                              <Sparkles className="w-3 h-3" />
                            )}
                            <span className="text-[8px] font-black uppercase">AI Suggest</span>
                          </button>
                        </label>
                        <input 
                          type="text"
                          value={item.hsCode}
                          onChange={(e) => updateItem(item.id, 'hsCode', e.target.value)}
                          placeholder="8471.30"
                          className="w-full bg-white border border-gray-200 rounded-xl px-4 py-3 text-sm font-bold text-[#1a365d] focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                        />
                      </div>
                      <div className="md:col-span-1">
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 block">Qty</label>
                        <input 
                          required
                          type="number"
                          min="1"
                          value={item.quantity}
                          onChange={(e) => updateItem(item.id, 'quantity', parseInt(e.target.value))}
                          className="w-full bg-white border border-gray-200 rounded-xl px-4 py-3 text-sm font-bold text-[#1a365d] focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                        />
                      </div>
                      <div className="md:col-span-2">
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 block">Value (USD)</label>
                        <div className="relative">
                          <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-300" />
                          <input 
                            required
                            type="number"
                            min="0"
                            step="0.01"
                            value={item.value}
                            onChange={(e) => updateItem(item.id, 'value', parseFloat(e.target.value))}
                            className="w-full bg-white border border-gray-200 rounded-xl pl-9 pr-4 py-3 text-sm font-bold text-[#1a365d] focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                          />
                        </div>
                      </div>
                      <div className="md:col-span-2">
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 block">Weight (kg)</label>
                        <div className="relative">
                          <Scale className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-300" />
                          <input 
                            required
                            type="number"
                            min="0"
                            step="0.1"
                            value={item.weight}
                            onChange={(e) => updateItem(item.id, 'weight', parseFloat(e.target.value))}
                            className="w-full bg-white border border-gray-200 rounded-xl pl-9 pr-4 py-3 text-sm font-bold text-[#1a365d] focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                          />
                        </div>
                      </div>
                      <div className="md:col-span-1 flex items-end justify-center pb-2">
                        <button 
                          type="button"
                          onClick={() => removeItem(item.id)}
                          className="p-2 text-gray-300 hover:text-red-500 transition-colors"
                          title="Remove Item"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </section>

          {/* Declaration Details */}
          <section className="grid grid-cols-1 md:grid-cols-2 gap-12 pt-8 border-t border-gray-100">
            <div className="space-y-8">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-emerald-50 rounded-xl flex items-center justify-center text-emerald-600">
                  <Shield className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-[#1a365d] uppercase tracking-tight">Trade Terms</h3>
                  <p className="text-xs text-gray-400 font-bold uppercase tracking-widest">Legal and financial details</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 block">Reason for Export</label>
                  <select 
                    value={declaration.reason}
                    onChange={(e) => setDeclaration({ ...declaration, reason: e.target.value })}
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm font-bold text-[#1a365d] outline-none appearance-none"
                  >
                    <option>Sale</option>
                    <option>Gift</option>
                    <option>Sample</option>
                    <option>Repair</option>
                    <option>Return</option>
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 block">Incoterms</label>
                  <select 
                    value={declaration.terms}
                    onChange={(e) => setDeclaration({ ...declaration, terms: e.target.value })}
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm font-bold text-[#1a365d] outline-none appearance-none"
                  >
                    <option value="DDP">DDP (Duty Paid)</option>
                    <option value="DAP">DAP (Duty Unpaid)</option>
                    <option value="FOB">FOB (Free on Board)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 block">Additional Notes</label>
                <textarea 
                  value={declaration.notes}
                  onChange={(e) => setDeclaration({ ...declaration, notes: e.target.value })}
                  placeholder="Any special handling or regulatory notes..."
                  className="w-full bg-gray-50 border border-gray-200 rounded-2xl px-4 py-4 text-sm font-bold text-[#1a365d] outline-none h-32 resize-none"
                />
              </div>
            </div>

            <div className="space-y-8">
              <div className="bg-[#1a365d] p-8 rounded-[40px] text-white shadow-xl relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-blue-400/10 rounded-full -mr-16 -mt-16" />
                <h3 className="text-sm font-black uppercase tracking-widest mb-8 flex items-center gap-2">
                  <FileText className="w-4 h-4 text-blue-400" /> Summary
                </h3>
                
                <div className="space-y-6">
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-bold text-blue-200/60 uppercase tracking-widest">Total Value</span>
                    <span className="text-2xl font-black">${totalValue.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-bold text-blue-200/60 uppercase tracking-widest">Total Weight</span>
                    <span className="text-xl font-black">{totalWeight.toFixed(2)} kg</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-bold text-blue-200/60 uppercase tracking-widest">Items Count</span>
                    <span className="text-xl font-black">{items.length}</span>
                  </div>
                  
                  <div className="pt-6 border-t border-white/10">
                    <div className="flex items-start gap-3 p-4 bg-white/5 rounded-2xl border border-white/10">
                      <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                      <p className="text-[10px] text-blue-100/60 leading-relaxed font-medium">
                        By submitting, you certify that the information provided is accurate and complete. False declarations may result in regulatory penalties.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex gap-4">
                <button 
                  type="button"
                  onClick={onCancel}
                  className="flex-1 py-4 border border-gray-200 rounded-2xl text-xs font-black uppercase tracking-widest text-gray-400 hover:bg-gray-50 transition-all"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  disabled={isSubmitting}
                  className="flex-[2] py-4 bg-blue-600 text-white rounded-2xl text-xs font-black uppercase tracking-widest hover:bg-blue-700 transition-all shadow-lg flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      Submit Declaration <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            </div>
          </section>
        </form>
      </div>
    </div>
  );
}
