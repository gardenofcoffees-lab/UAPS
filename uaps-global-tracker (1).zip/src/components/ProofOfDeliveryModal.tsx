import React, { useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Camera, PenTool, X, CheckCircle2, Upload } from 'lucide-react';

interface ProofOfDeliveryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (proof: { signature?: string; photo?: string }) => void;
  jobId: string;
}

export const ProofOfDeliveryModal: React.FC<ProofOfDeliveryModalProps> = ({ isOpen, onClose, onConfirm, jobId }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [photo, setPhoto] = useState<string | null>(null);
  const [mode, setMode] = useState<'signature' | 'photo'>('signature');

  const startDrawing = (e: React.MouseEvent | React.TouchEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = ('touches' in e) ? e.touches[0].clientX - rect.left : (e as React.MouseEvent).clientX - rect.left;
    const y = ('touches' in e) ? e.touches[0].clientY - rect.top : (e as React.MouseEvent).clientY - rect.top;

    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';
    ctx.strokeStyle = '#1a365d';
    setIsDrawing(true);
  };

  const draw = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = ('touches' in e) ? e.touches[0].clientX - rect.left : (e as React.MouseEvent).clientX - rect.left;
    const y = ('touches' in e) ? e.touches[0].clientY - rect.top : (e as React.MouseEvent).clientY - rect.top;

    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearSignature = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhoto(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleConfirm = () => {
    const signature = canvasRef.current?.toDataURL();
    // Check if signature is empty (all pixels transparent)
    const canvas = canvasRef.current;
    let hasSignature = false;
    if (canvas) {
      const ctx = canvas.getContext('2d');
      const data = ctx?.getImageData(0, 0, canvas.width, canvas.height).data;
      if (data) {
        for (let i = 3; i < data.length; i += 4) {
          if (data[i] > 0) {
            hasSignature = true;
            break;
          }
        }
      }
    }

    onConfirm({ 
      signature: hasSignature ? signature : undefined, 
      photo: photo || undefined 
    });
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="bg-white rounded-[32px] shadow-2xl w-full max-w-lg overflow-hidden border border-gray-100"
          >
            <div className="p-8 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
              <div>
                <h3 className="text-xl font-bold text-[#1a365d]">Proof of Delivery</h3>
                <p className="text-xs text-gray-500 font-medium uppercase tracking-widest mt-1">Job #{jobId}</p>
              </div>
              <button onClick={onClose} className="p-2 hover:bg-gray-200 rounded-full transition-colors">
                <X className="w-5 h-5 text-gray-400" />
              </button>
            </div>

            <div className="p-8">
              <div className="flex gap-4 mb-8">
                <button
                  onClick={() => setMode('signature')}
                  className={`flex-1 py-3 rounded-2xl text-sm font-bold flex items-center justify-center gap-2 transition-all ${
                    mode === 'signature' ? 'bg-[#1a365d] text-white shadow-lg shadow-blue-900/20' : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
                  }`}
                >
                  <PenTool className="w-4 h-4" /> Signature
                </button>
                <button
                  onClick={() => setMode('photo')}
                  className={`flex-1 py-3 rounded-2xl text-sm font-bold flex items-center justify-center gap-2 transition-all ${
                    mode === 'photo' ? 'bg-[#1a365d] text-white shadow-lg shadow-blue-900/20' : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
                  }`}
                >
                  <Camera className="w-4 h-4" /> Photo Proof
                </button>
              </div>

              {mode === 'signature' ? (
                <div className="space-y-4">
                  <div className="border-2 border-dashed border-gray-200 rounded-2xl bg-gray-50 overflow-hidden relative">
                    <canvas
                      ref={canvasRef}
                      width={400}
                      height={200}
                      className="w-full h-[200px] cursor-crosshair touch-none"
                      onMouseDown={startDrawing}
                      onMouseMove={draw}
                      onMouseUp={stopDrawing}
                      onMouseLeave={stopDrawing}
                      onTouchStart={startDrawing}
                      onTouchMove={draw}
                      onTouchEnd={stopDrawing}
                    />
                    <button
                      onClick={clearSignature}
                      className="absolute bottom-4 right-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest hover:text-red-500 transition-colors"
                    >
                      Clear
                    </button>
                  </div>
                  <p className="text-center text-[10px] text-gray-400 font-bold uppercase tracking-widest">Customer Signature Required</p>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="border-2 border-dashed border-gray-200 rounded-2xl bg-gray-50 h-[200px] flex flex-col items-center justify-center relative overflow-hidden">
                    {photo ? (
                      <>
                        <img src={photo} alt="Proof" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                        <button
                          onClick={() => setPhoto(null)}
                          className="absolute top-4 right-4 p-2 bg-black/50 text-white rounded-full hover:bg-black/70 transition-colors"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </>
                    ) : (
                      <label className="cursor-pointer flex flex-col items-center gap-3">
                        <div className="w-12 h-12 bg-white rounded-full shadow-sm flex items-center justify-center">
                          <Upload className="w-6 h-6 text-blue-500" />
                        </div>
                        <span className="text-sm font-bold text-[#1a365d]">Upload or Take Photo</span>
                        <input type="file" accept="image/*" capture="environment" className="hidden" onChange={handlePhotoUpload} />
                      </label>
                    )}
                  </div>
                  <p className="text-center text-[10px] text-gray-400 font-bold uppercase tracking-widest">Photo of Package at Destination</p>
                </div>
              )}
            </div>

            <div className="p-8 bg-gray-50/50 border-t border-gray-100 flex gap-4">
              <button
                onClick={onClose}
                className="flex-1 py-4 rounded-2xl text-sm font-bold text-gray-500 hover:bg-gray-100 transition-all"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirm}
                className="flex-1 py-4 rounded-2xl text-sm font-bold bg-emerald-600 text-white hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-600/20 flex items-center justify-center gap-2"
              >
                <CheckCircle2 className="w-5 h-5" /> Complete Delivery
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
