import { Polyline } from "react-leaflet";

interface Point {
  lat: number;
  lng: number;
}

interface OptimizedRouteProps {
  points: Point[];
}

export function OptimizedRoute({ points }: OptimizedRouteProps) {
  return (
    <Polyline
      positions={points.map((p) => [p.lat, p.lng])}
      pathOptions={{ color: "blue", weight: 4 }}
    />
  );
}
