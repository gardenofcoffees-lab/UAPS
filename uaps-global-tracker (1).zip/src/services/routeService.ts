import { GoogleGenAI, Type } from "@google/genai";
import { Stop, OptimizeRequest } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export interface RouteOptimizationParams {
  start: string;
  end: string;
  vehicle: string;
  traffic: string;
  roadData: any;
}

export async function optimizeRoute(params: RouteOptimizationParams) {
  const prompt = `
You are an expert African logistics route optimizer.
Given:
- Start: ${params.start}
- End: ${params.end}
- Courier vehicle: ${params.vehicle}
- Traffic: ${params.traffic}
- Road conditions: ${JSON.stringify(params.roadData)}

Return the following in a clear, professional format:
1. Best route (list of waypoints)
2. Estimated time
3. Estimated fuel cost
4. Hazards to avoid
5. Explanation of why this route is optimal
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });

    return response.text;
  } catch (error) {
    console.error("Route optimization failed:", error);
    throw new Error("Failed to optimize route. Please try again.");
  }
}

export async function getOptimizedRoutePoints(params: RouteOptimizationParams) {
  const prompt = `
You are a geospatial routing engine. Given the following logistics parameters, generate a list of GPS coordinates (lat, lng) that represent the optimized path between the start and end points, taking into account the road conditions and vehicle type.

Parameters:
- Start: ${params.start}
- End: ${params.end}
- Vehicle: ${params.vehicle}
- Traffic: ${params.traffic}
- Road Data: ${JSON.stringify(params.roadData)}

Return ONLY a JSON object with a "route" property containing an array of {lat, lng} objects.
Example: {"route": [{"lat": 6.45, "lng": 3.39}, {"lat": 6.5, "lng": 3.4}]}
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            route: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  lat: { type: Type.NUMBER },
                  lng: { type: Type.NUMBER }
                },
                required: ["lat", "lng"]
              }
            }
          },
          required: ["route"]
        }
      }
    });

    const data = JSON.parse(response.text || "{}");
    return data.route || [];
  } catch (error) {
    console.error("Failed to get route points:", error);
    return [];
  }
}

export async function optimizeMultiStopRoute(request: OptimizeRequest) {
  const prompt = `
You are an expert logistics route optimizer.
Optimize the following multi-stop route:
- Start Location: ${JSON.stringify(request.start)}
- Stops to visit: ${JSON.stringify(request.stops)}
- Vehicle: ${request.vehicle}
- City: ${request.city}

Please:
1. Reorder the stops for maximum efficiency (shortest distance/time).
2. Respect stop priorities (high priority stops should generally be visited earlier).
3. Provide a detailed turn-by-turn summary.
4. Return the optimized stop order and the full path coordinates.

Return ONLY a JSON object with:
- "optimizedStops": array of Stop objects in the new order.
- "route": array of {lat, lng} coordinates for the full path.
- "summary": string explaining the optimization.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            optimizedStops: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  lat: { type: Type.NUMBER },
                  lng: { type: Type.NUMBER },
                  label: { type: Type.STRING },
                  priority: { type: Type.STRING, enum: ["high", "normal"] }
                },
                required: ["id", "lat", "lng", "label"]
              }
            },
            route: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  lat: { type: Type.NUMBER },
                  lng: { type: Type.NUMBER }
                },
                required: ["lat", "lng"]
              }
            },
            summary: { type: Type.STRING }
          },
          required: ["optimizedStops", "route", "summary"]
        }
      }
    });

    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("Multi-stop optimization failed:", error);
    throw new Error("Failed to optimize multi-stop route.");
  }
}
