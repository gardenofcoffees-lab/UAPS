import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export interface EtaParams {
  start: { lat: number; lng: number };
  end: { lat: number; lng: number };
  city: string;
  vehicle: string;
  timeOfDay: string;
}

export async function computeEta(params: EtaParams) {
  const distanceKm = haversineKm(params.start, params.end);

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `You are an African urban logistics ETA estimator.
City: ${params.city}
Vehicle: ${params.vehicle}
Time of day: ${params.timeOfDay}
Distance: ${distanceKm.toFixed(1)} km

Estimate:
- ETA in minutes
- Short explanation (traffic, road quality, etc.)

Return JSON: { "etaMinutes": number, "reason": string }`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            etaMinutes: { type: Type.NUMBER },
            reason: { type: Type.STRING }
          },
          required: ["etaMinutes", "reason"]
        }
      }
    });

    const data = JSON.parse(response.text || "{}");
    return data as { etaMinutes: number; reason: string };
  } catch (error) {
    console.error("ETA calculation failed:", error);
    return { etaMinutes: Math.round(distanceKm * 5), reason: "Estimated based on distance" };
  }
}

function haversineKm(p1: { lat: number; lng: number }, p2: { lat: number; lng: number }) {
  const R = 6371;
  const dLat = (p2.lat - p1.lat) * Math.PI / 180;
  const dLng = (p2.lng - p1.lng) * Math.PI / 180;
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(p1.lat * Math.PI / 180) * Math.cos(p2.lat * Math.PI / 180) *
    Math.sin(dLng / 2) * Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}
