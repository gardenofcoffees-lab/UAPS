export type Stop = {
  id: string;
  lat: number;
  lng: number;
  label: string;
  priority?: "high" | "normal";
};

export type OptimizeRequest = {
  start: { lat: number; lng: number };
  stops: Stop[];
  vehicle: "bike" | "car" | "van";
  city: string;
};

export interface Courier {
  id: string;
  name: string;
  vehicle: string;
  photoUrl?: string;
  idDocumentUrl?: string;
  verified: boolean;
}

export interface Delivery {
  id: string;
  pickupAddress: string;
  dropoffAddress: string;
  status: string;
  courierId?: string;
  batchId?: string;
}

export interface Batch {
  id: string;
  courierId: string;
  deliveryIds: string[];
}

export interface Partner {
  PartnerID: string;
  CorridorID: string;
  Region: string;
  RiskTier: 'Platinum' | 'Gold' | 'Silver' | 'Bronze';
  Metadata?: Record<string, any>;
}

export interface FairnessMetrics {
  FNFPDeviation: number;
  CorridorParity: number;
  BiasFlags: number;
  DriftAdjustedFairness: number;
  MitigationTimeliness: number;
}

export interface TransparencyMetrics {
  ReasonCodeCoverage: number;
  ExplainabilityUsage: number;
  ReportEngagement: number;
  PortalUsage: number;
}

export interface DataQualityMetrics {
  MissingData: number;
  SchemaErrors: number;
  Timeliness: number;
  DuplicateRate: number;
}

export interface ReliabilityMetrics {
  SLACompliance: number;
  AlertLatency: number;
  DriftDetectionLatency: number;
}

export interface SecurityMetrics {
  APIAbuseAttempts: number;
  CredentialHygiene: number;
  PartnerAnomalyScore: number;
}

export interface UserProfile {
  uid: string;
  email: string;
  role: 'admin' | 'partner' | 'viewer';
  partnerId?: string;
}

export interface DroneOrder {
  partner_id: string;
  external_order_id: string;
  pickup: {
    lat: number;
    lon: number;
    address: string;
  };
  dropoff: {
    lat: number;
    lon: number;
    address: string;
    landing_zone_type: string;
  };
  package: {
    weight_kg: number;
    dimensions_cm: { l: number; w: number; h: number };
    declared_contents: string;
    sensitivity: 'low' | 'medium' | 'high';
  };
  sla: {
    tier: 'STANDARD' | 'PRIORITY' | 'EXPRESS';
    latest_delivery_time: string;
  };
  metadata: {
    customer_id: string;
  };
}
