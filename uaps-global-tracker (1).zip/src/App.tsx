import { useState, useEffect, FormEvent, useMemo } from 'react';
import { Search, Package, MapPin, Clock, CheckCircle2, AlertCircle, Settings, Truck, ChevronRight, History, Flag, Database, Shield, Globe, BarChart3, Map as MapIcon, Layers, Cpu, Server, X, Menu, LogIn, HelpCircle, Users, Network, Landmark, TrendingUp, DollarSign, Activity, PieChart as PieChartIcon, LayoutDashboard, Filter, Download, Calendar, Loader2, ChevronUp, ChevronDown, Mail, Phone, FileText, Plus, LogOut, MessageSquare, Bot, User, Send, Minimize2, ShieldCheck } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { MapContainer, TileLayer, Marker, Popup, Polyline, LayersControl } from 'react-leaflet';
import L from 'leaflet';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, 
  LineChart, Line, PieChart, Pie, Cell, AreaChart, Area, ComposedChart
} from 'recharts';
import { Logo } from './components/Logo';
import { AssistantChat } from './components/AssistantChat';
import { CourierDashboard } from './components/CourierDashboard';
import { TrackPackageMap } from './components/TrackPackageMap';
import { TrackMyCourierMap } from './components/TrackMyCourierMap';
import { DeliveryTimeline } from './components/DeliveryTimeline';
import { CustomerPortal } from './components/CustomerPortal';
import { AdminDashboard } from './components/AdminDashboard';
import { ArchitectureView } from './components/ArchitectureView';
import { PartnerTrustIndex } from './components/PartnerTrustIndex';
import { PartnerLogin } from './components/PartnerLogin';
import { AdminLogin } from './components/AdminLogin';
import { ReturnPortal } from './components/ReturnPortal';
import { ContactSalesModal } from './components/ContactSalesModal';

interface TrackingEvent {
  timestamp: string;
  location: {
    address: {
      addressLocality: string;
    };
  };
  description: string;
  icon?: any;
}

interface Shipment {
  id: string;
  partnerTrackingIds?: string[];
  service?: string;
  origin?: string;
  sender?: {
    name: string;
    phone: string;
  };
  receiver?: {
    name: string;
    phone: string;
  };
  destination?: {
    address: {
      addressLocality: string;
      streetAddress?: string;
    };
    location?: { lat: number; lng: number };
  };
  status: {
    timestamp: string;
    location: {
      address: {
        addressLocality: string;
      };
    };
    statusCode: string;
    status: string;
    description: string;
    eta?: string;
  };
  events: TrackingEvent[];
  courier?: {
    id: string;
    name: string;
    phone: string;
    email: string;
    location?: { lat: number; lng: number; timestamp: string };
    vehicle?: string;
  };
  proofOfDelivery?: {
    signature?: string;
    photo?: string;
    timestamp: string;
  };
  estimatedDeliveryTime?: string;
  actualDeliveryTime?: string;
  courierContact?: {
    name: string;
    phone: string;
    email?: string;
  };
}

type DeliveryStatus =
  | "NEW"
  | "ACCEPTED"
  | "PICKED_UP"
  | "IN_TRANSIT"
  | "DELIVERED";

interface Delivery {
  id: string;
  pickupAddress: string;
  dropoffAddress: string;
  status: DeliveryStatus;
  courierId?: string;
}

// Fix Leaflet icon issue
// @ts-ignore
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

const CITY_COORDINATES: Record<string, [number, number]> = {
  "Lagos, Nigeria": [6.5244, 3.3792],
  "Nairobi, Kenya": [-1.2921, 36.8219],
  "Johannesburg, South Africa": [-26.2041, 28.0473],
  "Cairo, Egypt": [30.0444, 31.2357],
  "Casablanca, Morocco": [33.5731, -7.5898],
  "Accra, Ghana": [5.6037, -0.1870],
  "Addis Ababa, Ethiopia": [8.9806, 38.7578],
  "Dakar, Senegal": [14.7167, -17.4677],
  "Luanda, Angola": [-8.8390, 13.2894],
  "Dar es Salaam, Tanzania": [-6.7924, 39.2083],
  "Chicago, IL": [41.8781, -87.6298],
  "Washington, DC": [38.9072, -77.0369],
  "New York, NY": [40.7128, -74.0060],
  "London, UK": [51.5074, -0.1278],
  "Paris, France": [48.8566, 2.3522],
  "Dubai, UAE": [25.2048, 55.2708],
  "Singapore": [1.3521, 103.8198],
  "Tokyo, Japan": [35.6762, 139.6503],
  "Sydney, Australia": [-33.8688, 151.2093],
  "Cape Town, South Africa": [-33.9249, 18.4241],
  "Abidjan, Ivory Coast": [5.3600, -4.0083],
  "Kinshasa, DR Congo": [-4.4419, 15.2663],
  "Kigali, Rwanda": [-1.9441, 30.0619],
  "Kampala, Uganda": [0.3476, 32.5825],
  "Lusaka, Zambia": [-15.3875, 28.3228],
  "Harare, Zimbabwe": [-17.8252, 31.0522],
  "Windhoek, Namibia": [-22.5609, 17.0658],
  "Gaborone, Botswana": [-24.6282, 25.9231],
  "Maputo, Mozambique": [-25.9692, 32.5732],
  "Antananarivo, Madagascar": [-18.8792, 47.5079],
  "Port Louis, Mauritius": [-20.1609, 57.5012],
  "Victoria, Seychelles": [-4.6191, 55.4513],
  "Praia, Cape Verde": [14.9177, -23.5092],
  "Banjul, Gambia": [13.4549, -16.5790],
  "Freetown, Sierra Leone": [8.4844, -13.2344],
  "Monrovia, Liberia": [6.3156, -10.8074],
  "Conakry, Guinea": [9.5092, -13.7122],
  "Bamako, Mali": [12.6392, -8.0029],
  "Niamey, Niger": [13.5116, 2.1254],
  "Ouagadougou, Burkina Faso": [12.3714, -1.5197],
  "N'Djamena, Chad": [12.1348, 15.0557],
  "Bangui, Central African Republic": [4.3947, 18.5582],
  "Yaounde, Cameroon": [3.8480, 11.5021],
  "Libreville, Gabon": [0.4162, 9.4673],
  "Brazzaville, Congo": [-4.2634, 15.2832],
  "Malabo, Equatorial Guinea": [3.7504, 8.7832],
  "Sao Tome, Sao Tome and Principe": [0.3302, 6.7333],
  "Djibouti, Djibouti": [11.5883, 43.1450],
  "Asmara, Eritrea": [15.3229, 38.9251],
  "Mogadishu, Somalia": [2.0469, 45.3182],
  "Juba, South Sudan": [4.8517, 31.5822],
  "Khartoum, Sudan": [15.5007, 32.5599],
  "Tripoli, Libya": [32.8872, 13.1913],
  "Tunis, Tunisia": [36.8065, 10.1815],
  "Algiers, Algeria": [36.7538, 3.0588],
  "Nouakchott, Mauritania": [18.0735, -15.9582],
};

const InteractiveMap = ({ shipment }: { shipment: Shipment }) => {
  const eventsWithCoords = useMemo(() => {
    return shipment.events
      .map(event => ({
        ...event,
        coords: CITY_COORDINATES[event.location.address.addressLocality] || null
      }))
      .filter(event => event.coords !== null) as (TrackingEvent & { coords: [number, number] })[];
  }, [shipment]);

  if (eventsWithCoords.length === 0) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-gray-900 text-white/50 italic text-sm">
        No geographic data available for this shipment
      </div>
    );
  }

  const center = eventsWithCoords[0].coords;
  const polylinePositions = eventsWithCoords.map(e => e.coords);

  return (
    <MapContainer 
      center={center} 
      zoom={4} 
      style={{ height: '100%', width: '100%', background: '#0f172a' }}
      zoomControl={true}
    >
      <TileLayer
        url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
      />
      <Polyline 
        positions={polylinePositions} 
        color="#c5a059" 
        weight={3} 
        dashArray="10, 10" 
        opacity={0.6}
      />
      {eventsWithCoords.map((event, idx) => (
        <Marker key={idx} position={event.coords}>
          <Popup>
            <div className="p-1">
              <p className="font-bold text-[#1a365d] text-sm">{event.description}</p>
              <p className="text-xs text-gray-500">{event.location.address.addressLocality}</p>
              <p className="text-[10px] text-gray-400 mt-1">{new Date(event.timestamp).toLocaleString()}</p>
            </div>
          </Popup>
        </Marker>
      ))}
    </MapContainer>
  );
};

export default function App() {
  const getStatusStyles = (status: string) => {
    switch (status.toLowerCase()) {
      case 'successful':
      case 'delivered':
        return 'bg-emerald-100 text-emerald-700 border border-emerald-200';
      case 'in progress':
      case 'in transit':
        return 'bg-blue-100 text-blue-700 border border-blue-200';
      case 'on hold':
      case 'pending':
        return 'bg-amber-100 text-amber-700 border border-amber-200';
      case 'cancelled':
      case 'failed':
        return 'bg-rose-100 text-rose-700 border border-rose-200';
      default:
        return 'bg-gray-100 text-gray-700 border border-gray-200';
    }
  };

  const getPriorityStyles = (priority: string) => {
    switch (priority.toLowerCase()) {
      case 'high':
        return 'bg-red-100 text-red-700 border border-red-200';
      case 'medium':
        return 'bg-amber-100 text-amber-700 border border-amber-200';
      case 'low':
        return 'bg-emerald-100 text-emerald-700 border border-emerald-200';
      default:
        return 'bg-gray-100 text-gray-700 border border-gray-200';
    }
  };

  const getCarrierLogo = (carrier: string) => {
    switch (carrier.toLowerCase()) {
      case 'dhl':
        return 'https://upload.wikimedia.org/wikipedia/commons/b/b9/DHL_Logo.svg';
      case 'fedex':
        return 'https://upload.wikimedia.org/wikipedia/commons/9/9d/FedEx_Express_logo.svg';
      case 'ups':
        return 'https://upload.wikimedia.org/wikipedia/commons/1/1b/UPS_Logo_primary.svg';
      case 'usps':
        return 'https://upload.wikimedia.org/wikipedia/commons/8/82/USPS_logo.svg';
      default:
        return null;
    }
  };

  const [trackingNumber, setTrackingNumber] = useState('');
  const [shipment, setShipment] = useState<Shipment | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<string[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [showArchitecture, setShowArchitecture] = useState(false);
  const [view, setView] = useState<'home' | 'tracking' | 'dashboard' | 'returns' | 'settings' | 'courier' | 'customer' | 'architecture' | 'trust' | 'partner_login' | 'admin_login'>('home');
  const [dhlApiKey, setDhlApiKey] = useState('');
  const [fedexApiKey, setFedexApiKey] = useState('');
  const [upsApiKey, setUpsApiKey] = useState('');
  const [uspsApiKey, setUspsApiKey] = useState('');
  const [sortConfig, setSortConfig] = useState<{ key: string; direction: 'asc' | 'desc' } | null>(null);
  const [selectedOrder, setSelectedOrder] = useState<any | null>(null);
  const [isTrackingValid, setIsTrackingValid] = useState(true);
  const [trackingData, setTrackingData] = useState<any>(null);
  const [isPartnerAuthenticated, setIsPartnerAuthenticated] = useState(false);
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [showContactSales, setShowContactSales] = useState(false);

  useEffect(() => {
    if (view === 'tracking' && shipment?.id) {
      setTrackingData(null); // Reset on new tracking
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const ws = new WebSocket(`${protocol}//${window.location.host}`);
      
      ws.onopen = () => {
        ws.send(JSON.stringify({ type: 'subscribe', trackingId: shipment.id }));
      };
      
      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          setTrackingData((prev: any) => ({ ...prev, ...data }));
          
          if (data.type === 'status_update') {
            setShipment(prev => prev ? { ...prev, status: data.status } : null);
            // Refresh history
            fetch(`/api/track/${shipment.id}/history`)
              .then(res => res.json())
              .then(historyData => {
                if (Array.isArray(historyData)) {
                  setHistory(historyData.map((h: any) => `${new Date(h.timestamp).toLocaleString()}: ${h.status}`));
                }
              });
          }

          if (data.type === 'location_update') {
            setShipment(prev => {
              if (prev && prev.courier && prev.courier.id === data.courierId) {
                return {
                  ...prev,
                  courier: {
                    ...prev.courier,
                    location: data.location
                  }
                };
              }
              return prev;
            });
          }
        } catch (err) {
          console.error("WS Client Error:", err);
        }
      };
      
      return () => ws.close();
    }
  }, [view, shipment?.id]);

  const [shipmentNotes, setShipmentNotes] = useState<Record<string, { id: string, text: string, timestamp: string }[]>>(() => {
    const saved = localStorage.getItem('uaps_shipment_notes');
    return saved ? JSON.parse(saved) : {};
  });
  const [newNoteText, setNewNoteText] = useState("");

  const handleAddNote = (shipmentId: string) => {
    if (!newNoteText.trim()) return;
    const newNote = {
      id: Date.now().toString(),
      text: newNoteText.trim(),
      timestamp: new Date().toISOString()
    };
    const updatedNotes = {
      ...shipmentNotes,
      [shipmentId]: [...(shipmentNotes[shipmentId] || []), newNote]
    };
    setShipmentNotes(updatedNotes);
    localStorage.setItem('uaps_shipment_notes', JSON.stringify(updatedNotes));
    setNewNoteText("");
  };

  const validateTracking = (num: string) => {
    if (!num) return true;
    const uapsFormat = /^UAPS-[A-Z]{2}-\d{4}-\d{8}$/;
    const standardFormat = /^UA\d{9}[A-Z]{2}$/;
    const internalFormat = /^del-\d{3}$/;
    const referenceFormat = /^[A-Z0-9]+-[A-Z0-9]+-\d+$/;
    const genericRef = /^[A-Z0-9]{8,20}$/;
    return uapsFormat.test(num) || standardFormat.test(num) || internalFormat.test(num) || referenceFormat.test(num) || genericRef.test(num);
  };

  const recentOrders = useMemo(() => [
    { 
      id: "shp-123", 
      partnerTrackingIds: ["RELOAD-123"],
      courier: "Leslie Alexander", 
      courierPhone: "+251 911 234 567",
      courierEmail: "leslie.a@uaps.et",
      carrier: "Reload Logistics", 
      dest: "Kigali", 
      status: "In Progress", 
      date: "17 Apr 2026",
      origin: "Rotterdam",
      weight: "2.5 kg",
      dimensions: "30x20x15 cm",
      priority: "High",
      type: "Express",
      events: [
        { timestamp: "2026-04-11T10:20:00Z", location: { address: { addressLocality: "Rusumo" } }, description: "BORDER_CROSSING - Wait Time: 1.8 Hours" }
      ],
      routing_constraints: {
        max_transit_days: 14,
        avoid_countries: ["Burundi"],
        preferred_modes: ["SEA", "ROAD"]
      },
      coordinates: [
        [51.9225, 4.47917],
        [6.13748, 1.21227],
        [-1.94407, 30.0619]
      ],
      cross_border_intelligence: {
        required_documents: ["COMESA_CARNET", "EAC_DECLARATION", "HS_CODE_CERTIFICATION"],
        status: "READY_FOR_SUBMISSION",
        carrier_recommendation: {
          carrier: "Reload Logistics",
          corridor: "Central Corridor",
          delay_probability: 0.18,
          reliability_score: 0.82,
          recommended: true,
          drivers: ["low border dwell", "high partner reliability"]
        },
        corridor_risk: {
          corridor: "Northern Corridor",
          risk_score: 0.41,
          factors: {
            border_delay: 0.22,
            weather: 0.11,
            security: 0.08
          },
          recommendation: "Switch to Central Corridor"
        }
      },
      live_transit: {
        current_leg_id: "leg-004",
        status: "IN_TRANSIT",
        mode: "ROAD",
        partner: "Reload Logistics",
        eta: "2026-04-17T09:00:00Z",
        risk_score: 0.24,
        reliability_score: 0.81,
        route_id: "route-456",
        route_legs: [
          { leg_id: "leg-001", mode: "SEA", from: "Rotterdam", to: "Lome", status: "COMPLETED", partner: "Maersk" },
          { leg_id: "leg-002", mode: "ROAD", from: "Lome", to: "Kigali", status: "IN_TRANSIT", partner: "Reload Logistics" }
        ],
        border_events: [
          {
            type: "BORDER_CROSSING",
            source: "Reload Logistics",
            location: "Rusumo",
            timestamp: "2026-04-11T10:20:00Z",
            wait_time_hours: 1.8
          }
        ],
        handover_events: [
          {
            handover_id: "hnd-778",
            from_carrier: "Maersk",
            to_partner: "AGL",
            location: "Lome Terminal 2",
            timestamp: "2026-04-15T11:12:00Z",
            status: "RECEIVED",
            next_leg_mode: "ROAD",
            assigned_partner: "Reload Logistics"
          }
        ]
      },
      partner_performance: {
        partner_id: "AGL",
        name: "AGL Logistics",
        overall_score: 92,
        certification_level: "ELITE",
        drivers: ["high OTD", "strong compliance", "low exception rate"],
        metrics: {
          operational: 88,
          compliance: 95,
          cx: 90,
          resilience: 94,
          otd: 0.94,
          border_dwell_avg: 2.1,
          port_dwell_avg: 36,
          exception_rate: 0.02
        },
        corridors: [
          {
            corridor: "Northern Corridor",
            score: 89,
            risk_adjusted_reliability: 0.78
          }
        ],
        integration_stage: "PILOT_READY",
        event_coverage: 0.97,
        latency_p95: 41,
        schema_compliance: 1.0,
        recommended_certification: "ADVANCED",
        customer_experience: {
          sentiment_score: 0.74,
          damage_rate: 0.009,
          complaint_rate: 0.004
        }
      }
    },
    { 
      id: "EXD-928177", 
      partnerTrackingIds: ["DHL-KE-9981"],
      courier: "Leslie Alexander", 
      courierPhone: "+251 911 234 567",
      courierEmail: "leslie.a@uaps.et",
      carrier: "DHL", 
      dest: "Centreville Storage, US", 
      status: "In Progress", 
      date: "03 Mar 2024",
      origin: "London, UK",
      weight: "2.5 kg",
      dimensions: "30x20x15 cm",
      priority: "High",
      type: "Express",
      events: [
        { timestamp: "2024-03-03T14:30:00Z", location: { address: { addressLocality: "Centreville, US" } }, description: "Arrived at Sort Facility Centreville" },
        { timestamp: "2024-03-03T09:15:00Z", location: { address: { addressLocality: "New York, US" } }, description: "Departed from Sort Facility New York" },
        { timestamp: "2024-03-02T22:00:00Z", location: { address: { addressLocality: "London, UK" } }, description: "Processed at London Hub" }
      ],
      coordinates: [
        [51.5074, -0.1278],
        [40.7128, -74.0060],
        [38.8404, -77.4289]
      ]
    },
    { 
      id: "EXD-928178", 
      partnerTrackingIds: ["FEDEX-NG-1122"],
      courier: "Guy Hawkins", 
      courierPhone: "+251 912 345 678",
      courierEmail: "guy.h@uaps.et",
      carrier: "FedEx", 
      dest: "Sudley Storage, US", 
      status: "Successful", 
      date: "01 Mar 2024",
      origin: "Paris, FR",
      weight: "1.2 kg",
      dimensions: "20x15x10 cm",
      priority: "Medium",
      type: "Standard",
      events: [
        { timestamp: "2024-03-01T16:45:00Z", location: { address: { addressLocality: "Sudley, US" } }, description: "Delivered - Signed by G. Hawkins" },
        { timestamp: "2024-03-01T10:00:00Z", location: { address: { addressLocality: "Sudley, US" } }, description: "Out for Delivery" },
        { timestamp: "2024-02-29T14:30:00Z", location: { address: { addressLocality: "Paris, FR" } }, description: "Picked up" }
      ],
      coordinates: [
        [48.8566, 2.3522],
        [38.8462, -77.5005]
      ]
    },
    { 
      id: "EXD-928179", 
      courier: "Jane Cooper", 
      courierPhone: "+251 913 456 789",
      courierEmail: "jane.c@uaps.et",
      carrier: "UPS", 
      dest: "Manassas Park, US", 
      status: "On Hold", 
      date: "05 Mar 2024",
      origin: "Berlin, DE",
      weight: "5.0 kg",
      dimensions: "40x40x40 cm",
      priority: "Low",
      type: "Freight",
      events: [
        { timestamp: "2024-03-05T08:00:00Z", location: { address: { addressLocality: "Manassas Park, US" } }, description: "Held at Customs - Documentation Required" },
        { timestamp: "2024-03-04T12:00:00Z", location: { address: { addressLocality: "Frankfurt, DE" } }, description: "Departed from Facility" }
      ],
      coordinates: [
        [52.5200, 13.4050],
        [50.1109, 8.6821],
        [38.7843, -77.4647]
      ]
    },
    { 
      id: "EXD-928180", 
      courier: "Robert Fox", 
      courierPhone: "+251 914 567 890",
      courierEmail: "robert.f@uaps.et",
      carrier: "USPS", 
      dest: "Gainesville, US", 
      status: "In Progress", 
      date: "04 Mar 2024",
      origin: "Tokyo, JP",
      weight: "0.8 kg",
      dimensions: "15x10x5 cm",
      priority: "High",
      type: "Express",
      events: [
        { timestamp: "2024-03-04T11:30:00Z", location: { address: { addressLocality: "Gainesville, US" } }, description: "Arrived at Local Post Office" },
        { timestamp: "2024-03-02T19:00:00Z", location: { address: { addressLocality: "Tokyo, JP" } }, description: "International Dispatch" }
      ],
      coordinates: [
        [35.6762, 139.6503],
        [38.7993, -77.6136]
      ]
    },
  ], []);

  const sortedOrders = useMemo(() => {
    let sortableItems = [...recentOrders];
    if (sortConfig !== null) {
      sortableItems.sort((a, b) => {
        const aValue = a[sortConfig.key as keyof typeof a];
        const bValue = b[sortConfig.key as keyof typeof b];
        if (aValue < bValue) {
          return sortConfig.direction === 'asc' ? -1 : 1;
        }
        if (aValue > bValue) {
          return sortConfig.direction === 'asc' ? 1 : -1;
        }
        return 0;
      });
    }
    return sortableItems;
  }, [recentOrders, sortConfig]);

  const handleSort = (key: string) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const getSortIcon = (key: string) => {
    if (!sortConfig || sortConfig.key !== key) {
      return <div className="w-3 h-3 opacity-20"><ChevronUp className="w-full h-full" /></div>;
    }
    return sortConfig.direction === 'asc' ? 
      <ChevronUp className="w-3 h-3 text-blue-600" /> : 
      <ChevronDown className="w-3 h-3 text-blue-600" />;
  };
  const [viewMode, setViewMode] = useState<'timeline' | 'map'>('map');

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const urlDhlKey = params.get('dhl_key');
    if (urlDhlKey) {
      setDhlApiKey(urlDhlKey);
      localStorage.setItem('uaps_dhl_api_key', urlDhlKey);
    }

    const urlFedexKey = params.get('fedex_key');
    if (urlFedexKey) {
      setFedexApiKey(urlFedexKey);
      localStorage.setItem('uaps_fedex_api_key', urlFedexKey);
    }

    const urlUpsKey = params.get('ups_key');
    if (urlUpsKey) {
      setUpsApiKey(urlUpsKey);
      localStorage.setItem('uaps_ups_api_key', urlUpsKey);
    }

    const urlUspsKey = params.get('usps_key');
    if (urlUspsKey) {
      setUspsApiKey(urlUspsKey);
      localStorage.setItem('uaps_usps_api_key', urlUspsKey);
    }

    const saved = localStorage.getItem('uaps_history');
    if (saved) setHistory(JSON.parse(saved));
    
    const savedKey = localStorage.getItem('uaps_dhl_api_key');
    if (savedKey) setDhlApiKey(savedKey);

    const savedFedexKey = localStorage.getItem('uaps_fedex_api_key');
    if (savedFedexKey) setFedexApiKey(savedFedexKey);

    const savedUpsKey = localStorage.getItem('uaps_ups_api_key');
    if (savedUpsKey) setUpsApiKey(savedUpsKey);

    const savedUspsKey = localStorage.getItem('uaps_usps_api_key');
    if (savedUspsKey) setUspsApiKey(savedUspsKey);
  }, []);

  const saveToHistory = (num: string) => {
    const newHistory = [num, ...history.filter(h => h !== num)].slice(0, 5);
    setHistory(newHistory);
    localStorage.setItem('uaps_history', JSON.stringify(newHistory));
  };

  const handleExportCSV = () => {
    const headers = ['Order ID', 'Courier', 'Courier Phone', 'Courier Email', 'Status', 'Date', 'Destination', 'Weight', 'Dimensions', 'Type', 'Priority'];
    const csvData = recentOrders.map(order => [
      order.id,
      order.courier,
      order.courierPhone,
      order.courierEmail,
      order.status,
      order.date,
      `"${order.dest}"`, // Wrap in quotes to handle commas in destination
      order.weight,
      order.dimensions,
      order.type,
      order.priority
    ]);

    const csvContent = [
      headers.join(','),
      ...csvData.map(row => row.join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `uaps_orders_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleTrack = async (e?: FormEvent, num?: string) => {
    if (e) e.preventDefault();
    const targetNum = num || trackingNumber;
    if (!targetNum) return;

    if (!validateTracking(targetNum)) {
      setError('Invalid tracking number format. Use UAPS-CC-YYYY-NNNNNNNN, UA123456789XX, or internal ID (e.g., del-001).');
      setIsTrackingValid(false);
      setView('tracking');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await fetch(`/api/track/${targetNum}`, {
        headers: {
          'x-dhl-api-key': localStorage.getItem('uaps_dhl_api_key') || '',
          'x-fedex-api-key': localStorage.getItem('uaps_fedex_api_key') || '',
          'x-ups-api-key': localStorage.getItem('uaps_ups_api_key') || '',
          'x-usps-api-key': localStorage.getItem('uaps_usps_api_key') || ''
        }
      });
      const __dataBody = await response.json();
      const data = __dataBody.data || __dataBody;

      if (!response.ok) {
        throw new Error(data.error || data.detail || 'Failed to track shipment');
      }

      if (data.shipments && data.shipments.length > 0) {
        setShipment(data.shipments[0]);
        saveToHistory(targetNum);
        setView('tracking');
      } else {
        throw new Error('No shipment found with this tracking number.');
      }
    } catch (err: any) {
      setError(err.message);
      setView('tracking');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#f4f7f9] text-[#333] font-sans">
      {/* Top Header */}
      <header className="bg-[#1a365d] text-white px-4 md:px-8 py-3 flex flex-col md:flex-row justify-between items-center gap-4 sticky top-0 z-50 shadow-lg">
        <div className="flex items-center gap-4 w-full md:w-auto">
          <button onClick={() => setView('home')} className="flex items-center gap-3 hover:opacity-80 transition-opacity">
            <Logo variant="light" size="md" />
            <div className="hidden lg:block text-left border-l border-white/20 pl-4">
              <p className="text-[7px] font-bold uppercase tracking-[0.3em] text-[#c5a059]">United Africa</p>
              <p className="text-[7px] font-bold uppercase tracking-[0.3em] text-[#c5a059]">Postal Service</p>
            </div>
          </button>
        </div>

        <div className="flex items-center gap-4 w-full md:w-auto">
          <div className="relative group">
            {/* Recent Searches Tags */}
            {history.length > 0 && (
              <div className="absolute bottom-full left-0 right-0 mb-2 flex flex-wrap gap-2 items-center">
                <span className="text-[8px] font-bold text-white/40 uppercase tracking-widest">Recent:</span>
                <div className="flex flex-wrap gap-1.5 flex-1">
                  {history.map((num, i) => (
                    <button
                      key={i}
                      onClick={() => {
                        setTrackingNumber(num);
                        handleTrack(undefined, num);
                      }}
                      className="text-[9px] font-mono bg-white/5 hover:bg-white/20 px-2 py-0.5 rounded border border-white/10 transition-all text-white/80 hover:text-white"
                    >
                      {num}
                    </button>
                  ))}
                </div>
                <button 
                  onClick={() => {
                    setHistory([]);
                    localStorage.removeItem('uaps_history');
                  }}
                  className="text-[8px] text-red-400 hover:text-red-300 font-bold uppercase tracking-widest ml-2"
                >
                  Clear
                </button>
              </div>
            )}

            <div className={`flex bg-white/10 backdrop-blur-md rounded-lg overflow-hidden border ${!isTrackingValid && trackingNumber ? 'border-red-500 bg-red-500/10' : 'border-white/20'} shadow-sm focus-within:border-white/40 transition-all`}>
              <input
                type="text"
                value={trackingNumber}
                onChange={(e) => {
                  const val = e.target.value.toUpperCase();
                  setTrackingNumber(val);
                  setIsTrackingValid(validateTracking(val));
                }}
                onKeyDown={(e) => e.key === 'Enter' && handleTrack()}
                placeholder="Tracking # or Reference ID..."
                className="bg-transparent border-none px-4 py-2 text-sm text-white placeholder:text-white/50 focus:outline-none w-48 md:w-64"
                disabled={loading}
              />
              <button 
                onClick={() => handleTrack()} 
                disabled={loading || (!isTrackingValid && trackingNumber.length > 0)}
                className={`bg-white/10 px-4 py-2 hover:bg-white/20 transition-colors border-l border-white/10 flex items-center justify-center min-w-[48px] ${(!isTrackingValid && trackingNumber.length > 0) ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                {loading ? (
                  <Loader2 className="w-4 h-4 text-white animate-spin" />
                ) : (
                  <Search className="w-4 h-4 text-white" />
                )}
              </button>
            </div>
            
            {!isTrackingValid && trackingNumber && (
              <div className="absolute top-full left-0 mt-1 bg-red-500 text-white text-[8px] font-bold uppercase tracking-widest px-2 py-1 rounded shadow-lg pointer-events-none whitespace-nowrap z-[60]">
                Invalid Format: UAPS-CC-YYYY-NNNNNNNN, UA123456789XX, or Reference ID
              </div>
            )}
          </div>
          <div className="relative group hidden md:block">
            <button 
              onClick={() => {
                if (isAdminAuthenticated) {
                  setView('dashboard');
                } else {
                  setView('admin_login');
                }
              }}
              className={`bg-[#1a365d] text-white px-6 py-2 rounded-lg text-xs font-bold uppercase tracking-widest hover:bg-blue-900 transition-all shadow-lg mr-2 ${view === 'dashboard' || view === 'admin_login' ? 'ring-2 ring-white ring-offset-2 ring-offset-[#1a365d]' : ''}`}
            >
              {isAdminAuthenticated ? 'Admin Dashboard' : 'Admin Portal'}
            </button>
            {isAdminAuthenticated && (
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-xl border border-gray-100 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-50 overflow-hidden">
                <div className="p-2">
                  <button 
                    onClick={() => setView('dashboard')}
                    className="w-full text-left px-4 py-3 text-sm font-bold text-[#1a365d] hover:bg-gray-50 rounded-lg transition-colors flex items-center gap-2"
                  >
                    <LayoutDashboard className="w-4 h-4" /> Dashboard
                  </button>
                  <button 
                    onClick={() => {
                      setIsAdminAuthenticated(false);
                      setView('home');
                    }}
                    className="w-full text-left px-4 py-3 text-sm font-bold text-red-600 hover:bg-red-50 rounded-lg transition-colors flex items-center gap-2"
                  >
                    <LogIn className="w-4 h-4" /> Sign Out
                  </button>
                </div>
              </div>
            )}
          </div>
          <div className="relative group hidden md:block">
            <button 
              onClick={() => {
                if (isPartnerAuthenticated) {
                  setView('dashboard');
                } else {
                  setView('partner_login');
                }
              }}
              className={`bg-[#c5a059] text-white px-6 py-2 rounded-lg text-xs font-bold uppercase tracking-widest hover:bg-[#b08e4d] transition-all shadow-lg ${view === 'dashboard' || view === 'partner_login' ? 'ring-2 ring-white ring-offset-2 ring-offset-[#1a365d]' : ''}`}
            >
              {isPartnerAuthenticated ? 'Admin Panel' : 'Partner Login'}
            </button>
            {isPartnerAuthenticated && (
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-xl border border-gray-100 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-50 overflow-hidden">
                <div className="p-2">
                  <button 
                    onClick={() => setView('dashboard')}
                    className="w-full text-left px-4 py-3 text-sm font-bold text-[#1a365d] hover:bg-gray-50 rounded-lg transition-colors flex items-center gap-2"
                  >
                    <LayoutDashboard className="w-4 h-4" /> Dashboard
                  </button>
                  <button 
                    onClick={() => setView('settings')}
                    className="w-full text-left px-4 py-3 text-sm font-bold text-[#1a365d] hover:bg-gray-50 rounded-lg transition-colors flex items-center gap-2"
                  >
                    <Settings className="w-4 h-4" /> Settings
                  </button>
                  <div className="h-px bg-gray-100 my-1" />
                  <button 
                    onClick={() => {
                      setIsPartnerAuthenticated(false);
                      setView('home');
                    }}
                    className="w-full text-left px-4 py-3 text-sm font-bold text-red-600 hover:bg-red-50 rounded-lg transition-colors flex items-center gap-2"
                  >
                    <LogOut className="w-4 h-4" /> Logout
                  </button>
                </div>
              </div>
            )}
          </div>
          
          {/* Mobile Menu Toggle */}
          <div className="relative md:hidden">
            <button 
              onClick={() => {
                const menu = document.getElementById('mobile-menu');
                if (menu) menu.classList.toggle('hidden');
              }}
              className="text-white hover:opacity-80 p-2"
            >
              <Menu className="w-6 h-6" />
            </button>
            
            {/* Mobile Dropdown */}
            <div id="mobile-menu" className="hidden absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-2xl border border-gray-100 z-50 overflow-hidden">
              <div className="p-2">
                <button 
                  onClick={() => {
                    setView('home');
                    document.getElementById('mobile-menu')?.classList.add('hidden');
                  }}
                  className="w-full text-left px-4 py-3 text-sm font-bold text-[#1a365d] hover:bg-gray-50 rounded-lg transition-colors"
                >
                  Home
                </button>
                <button 
                  onClick={() => {
                    setView('tracking');
                    document.getElementById('mobile-menu')?.classList.add('hidden');
                  }}
                  className="w-full text-left px-4 py-3 text-sm font-bold text-[#1a365d] hover:bg-gray-50 rounded-lg transition-colors"
                >
                  Tracking
                </button>
                <button 
                  onClick={() => {
                    setView('returns');
                    document.getElementById('mobile-menu')?.classList.add('hidden');
                  }}
                  className="w-full text-left px-4 py-3 text-sm font-bold text-[#1a365d] hover:bg-gray-50 rounded-lg transition-colors"
                >
                  Return Portal
                </button>
                <div className="h-px bg-gray-100 my-1" />
                <button 
                  onClick={() => {
                    if (isAdminAuthenticated) {
                      setView('dashboard');
                    } else {
                      setView('admin_login');
                    }
                    document.getElementById('mobile-menu')?.classList.add('hidden');
                  }}
                  className="w-full text-left px-4 py-3 text-sm font-bold text-[#1a365d] hover:bg-gray-50 rounded-lg transition-colors flex items-center gap-2"
                >
                  <Shield className="w-4 h-4" /> {isAdminAuthenticated ? 'Admin Dashboard' : 'Admin Portal'}
                </button>
                {isAdminAuthenticated && (
                  <button 
                    onClick={() => {
                      setIsAdminAuthenticated(false);
                      setView('home');
                      document.getElementById('mobile-menu')?.classList.add('hidden');
                    }}
                    className="w-full text-left px-4 py-3 text-sm font-bold text-red-600 hover:bg-red-50 rounded-lg transition-colors flex items-center gap-2"
                  >
                    <LogIn className="w-4 h-4" /> Sign Out
                  </button>
                )}
                <button 
                  onClick={() => {
                    if (isPartnerAuthenticated) {
                      setView('dashboard');
                    } else {
                      setView('partner_login');
                    }
                    document.getElementById('mobile-menu')?.classList.add('hidden');
                  }}
                  className="w-full text-left px-4 py-3 text-sm font-bold text-[#c5a059] hover:bg-gray-50 rounded-lg transition-colors flex items-center gap-2"
                >
                  <LogIn className="w-4 h-4" /> {isPartnerAuthenticated ? 'Admin Panel' : 'Partner Login'}
                </button>
                {isPartnerAuthenticated && (
                  <button 
                    onClick={() => {
                      setIsPartnerAuthenticated(false);
                      setView('home');
                      document.getElementById('mobile-menu')?.classList.add('hidden');
                    }}
                    className="w-full text-left px-4 py-3 text-sm font-bold text-red-600 hover:bg-red-50 rounded-lg transition-colors flex items-center gap-2 mt-1"
                  >
                    <LogOut className="w-4 h-4" /> Logout
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Navigation */}
      <nav className="bg-white border-b border-gray-200 px-4 md:px-8 py-2 flex justify-center items-center text-xs font-bold uppercase tracking-widest text-gray-600 overflow-x-auto whitespace-nowrap">
        <div className="flex gap-8">
          <button 
            onClick={() => {
              setView('home');
              setTimeout(() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' }), 100);
            }} 
            className={`hover:text-[#1a365d] transition-colors ${view === 'home' ? 'text-[#1a365d]' : ''}`}
          >
            About
          </button>
          <button 
            onClick={() => {
              setView('home');
              setTimeout(() => document.getElementById('services')?.scrollIntoView({ behavior: 'smooth' }), 100);
            }} 
            className="flex items-center gap-1 hover:text-[#1a365d] transition-colors"
          >
            Services <ChevronRight className="w-3 h-3 rotate-90" />
          </button>
          <button 
            onClick={() => {
              setView('home');
              setTimeout(() => document.getElementById('network')?.scrollIntoView({ behavior: 'smooth' }), 100);
            }} 
            className="flex items-center gap-1 hover:text-[#1a365d] transition-colors"
          >
            Network <ChevronRight className="w-3 h-3 rotate-90" />
          </button>
          <button 
            onClick={() => {
              setView('home');
              setTimeout(() => document.getElementById('corridors')?.scrollIntoView({ behavior: 'smooth' }), 100);
            }} 
            className="flex items-center gap-1 hover:text-[#1a365d] transition-colors"
          >
            Corridors <ChevronRight className="w-3 h-3 rotate-90" />
          </button>
          <button 
            onClick={() => setView('architecture')}
            className={`flex items-center gap-1 hover:text-[#1a365d] transition-colors ${view === 'architecture' ? 'text-[#1a365d]' : ''}`}
          >
            Security <ShieldCheck className="w-3 h-3" />
          </button>
          <button 
            onClick={() => setView('returns')}
            className={`flex items-center gap-1 hover:text-[#1a365d] transition-colors ${view === 'returns' ? 'text-[#1a365d]' : ''}`}
          >
            Return Portal <ChevronRight className="w-3 h-3 rotate-90" />
          </button>
          <button 
            onClick={() => setView('dashboard')}
            className={`flex items-center gap-1 hover:text-[#1a365d] transition-colors ${view === 'dashboard' ? 'text-[#1a365d]' : ''}`}
          >
            Dashboard <LayoutDashboard className="w-3 h-3" />
          </button>
          <button 
            onClick={() => setView('trust')}
            className={`flex items-center gap-1 hover:text-[#1a365d] transition-colors ${view === 'trust' ? 'text-[#1a365d]' : ''}`}
          >
            Trust Index <ShieldCheck className="w-3 h-3" />
          </button>
          <button 
            onClick={() => setView('courier')}
            className={`flex items-center gap-1 hover:text-[#1a365d] transition-colors ${view === 'courier' ? 'text-[#1a365d]' : ''}`}
          >
            Courier Portal <Truck className="w-3 h-3" />
          </button>
          <button 
            onClick={() => setView('customer')}
            className={`flex items-center gap-1 hover:text-[#1a365d] transition-colors ${view === 'customer' ? 'text-[#1a365d]' : ''}`}
          >
            Customer Portal <User className="w-3 h-3" />
          </button>
          <button className="hover:text-[#1a365d] transition-colors">Contact</button>
          <button 
            onClick={() => setView('settings')}
            className={`hover:text-[#1a365d] transition-colors ${view === 'settings' ? 'text-[#1a365d] border-b-2 border-[#1a365d] pb-1' : ''}`}
          >
            Settings
          </button>
        </div>
      </nav>

      <AnimatePresence mode="wait">
        {view === 'trust' ? (
          <motion.div
            key="trust"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <PartnerTrustIndex />
          </motion.div>
        ) : view === 'architecture' ? (
          <motion.div
            key="architecture"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <ArchitectureView />
          </motion.div>
        ) : view === 'home' ? (
          <motion.div
            key="home"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            {/* Hero Section */}
            <section className="relative min-h-[700px] bg-[#1a365d] overflow-hidden flex items-center">
              {/* Background Image with Overlay */}
              <div className="absolute inset-0 z-0">
                <img 
                  src="https://images.unsplash.com/photo-1544016768-982d1554f0b9?auto=format&fit=crop&q=80&w=2000" 
                  alt="UAPS Cargo Plane" 
                  className="w-full h-full object-cover opacity-30"
                  referrerPolicy="no-referrer"
                />
                {/* Perspective Logo Overlay on Plane */}
                <div className="absolute top-[35%] left-[45%] w-[15%] h-[10%] opacity-20 pointer-events-none" style={{ transform: 'perspective(1000px) rotateY(-30deg) rotateX(5deg) skewY(-5deg)' }}>
                  <img src="/logo.png" alt="" className="w-full h-full object-contain grayscale brightness-200" referrerPolicy="no-referrer" />
                </div>
                <div className="absolute inset-0 bg-gradient-to-r from-[#1a365d] via-[#1a365d]/80 to-transparent" />
              </div>

              {/* Animated Background Pattern */}
              <div className="absolute inset-0 opacity-10 pointer-events-none z-1">
                <svg viewBox="0 0 800 400" className="w-full h-full object-cover">
                  <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                    <path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" strokeWidth="0.5" />
                  </pattern>
                  <rect width="100%" height="100%" fill="url(#grid)" />
                </svg>
              </div>
              
              <div className="max-w-6xl mx-auto px-8 relative z-10 w-full">
                <div className="max-w-3xl">
                  <motion.div
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.6 }}
                  >
                    <span className="inline-block bg-[#c5a059] text-white text-[10px] font-bold uppercase tracking-[0.3em] px-3 py-1 mb-6 rounded-sm">
                      Official Postal Authority
                    </span>
                    <h2 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-[1.1] tracking-tight">
                      The Gateway to <br />
                      <span className="text-[#c5a059]">African Logistics</span>
                    </h2>
                    <p className="text-xl text-blue-100/80 mb-10 leading-relaxed max-w-xl">
                      UAPS provides government-aligned postal and logistics infrastructure, bridging the gap between global carriers and local delivery networks across Africa.
                    </p>
                    <div className="flex flex-col sm:flex-row gap-4">
                      <button 
                        onClick={() => {
                          const input = document.querySelector('input');
                          if (input) input.focus();
                        }}
                        className="bg-[#c5a059] text-white px-10 py-4 rounded font-bold text-sm uppercase tracking-widest hover:bg-[#b08e4d] transition-all shadow-xl hover:-translate-y-1 active:translate-y-0"
                      >
                        Track a Shipment
                      </button>
                      <button 
                        onClick={() => setView('partner_login')}
                        className="bg-white/10 backdrop-blur-md border border-white/20 text-white px-10 py-4 rounded font-bold text-sm uppercase tracking-widest hover:bg-white/20 transition-all flex items-center justify-center gap-2 group"
                      >
                        Partner With UAPS <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                      </button>
                    </div>
                  </motion.div>
                </div>
              </div>

              {/* Decorative Elements */}
              <div className="absolute right-[-10%] bottom-[-10%] w-[600px] h-[600px] bg-blue-500/10 rounded-full blur-[120px] pointer-events-none" />
              <div className="absolute left-[10%] top-[-10%] w-[300px] h-[300px] bg-[#c5a059]/10 rounded-full blur-[80px] pointer-events-none" />
            </section>

            {/* Stats Bar */}
            <section className="bg-white border-b border-gray-200 py-8">
              <div className="max-w-6xl mx-auto px-8">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
                  {[
                    { label: "Countries Covered", value: "54" },
                    { label: "Partner Carriers", value: "120+" },
                    { label: "Annual Shipments", value: "15M+" },
                    { label: "Regional Hubs", value: "12" }
                  ].map((stat, i) => (
                    <div key={i} className="text-center md:text-left">
                      <p className="text-3xl font-bold text-[#1a365d] mb-1">{stat.value}</p>
                      <p className="text-[10px] uppercase tracking-widest text-gray-400 font-bold">{stat.label}</p>
                    </div>
                  ))}
                </div>
              </div>
            </section>

            {/* Who We Serve */}
            <section id="about" className="py-24 bg-white relative overflow-hidden">
              <div className="max-w-6xl mx-auto px-8 relative z-10">
                <div className="text-center mb-16">
                  <h3 className="text-xs font-bold text-[#c5a059] uppercase tracking-[0.4em] mb-4">Our Ecosystem</h3>
                  <h2 className="text-4xl font-bold text-[#1a365d]">Who We Serve</h2>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                  {[
                    { title: "Diaspora Communities", desc: "Reliable shipping solutions for families sending goods back home to Africa.", icon: Users, color: "bg-blue-50" },
                    { title: "Government Partners", desc: "Official mail handling and secure logistics for national and regional authorities.", icon: Landmark, color: "bg-amber-50" },
                    { title: "Global Carriers", desc: "Strategic last-mile partnership for UPS, FedEx, DHL, and other global leaders.", icon: Globe, color: "bg-green-50" },
                    { title: "E-commerce Giants", desc: "Scalable fulfillment and delivery for the continent's booming digital economy.", icon: Truck, color: "bg-purple-50" }
                  ].map((item, i) => (
                    <motion.div 
                      key={i} 
                      whileHover={{ y: -10 }}
                      className="bg-white p-10 rounded-2xl border border-gray-100 shadow-sm hover:shadow-xl transition-all group"
                    >
                      <div className={`w-14 h-14 ${item.color} rounded-xl flex items-center justify-center mb-8 group-hover:scale-110 transition-transform`}>
                        <item.icon className="w-7 h-7 text-[#1a365d]" />
                      </div>
                      <h4 className="font-bold text-lg text-[#1a365d] mb-4">{item.title}</h4>
                      <p className="text-sm text-gray-500 leading-relaxed">{item.desc}</p>
                    </motion.div>
                  ))}
                </div>
              </div>
            </section>

            {/* Fleet & Infrastructure - Mockup Showcase */}
            <section id="infrastructure" className="py-24 bg-[#1a365d] overflow-hidden relative">
              <div className="max-w-7xl mx-auto px-8 relative z-10">
                <div className="text-center mb-16">
                  <h3 className="text-xs font-bold text-[#c5a059] uppercase tracking-[0.4em] mb-4">Physical Assets</h3>
                  <h2 className="text-4xl font-bold text-white">Unified Infrastructure</h2>
                  <p className="text-blue-100/50 mt-4 max-w-2xl mx-auto">
                    Standardized branding and operational protocols across our entire fleet ensure the UAPS promise of "Delivering Africa Together" is met with every shipment.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* Large Hero Mockup - Cargo Plane */}
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    className="md:col-span-2 relative h-[400px] rounded-3xl overflow-hidden shadow-2xl group"
                  >
                    <img 
                      src="https://images.unsplash.com/photo-1544016768-982d1554f0b9?auto=format&fit=crop&q=80&w=1600" 
                      alt="UAPS Cargo Plane on Ground" 
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000"
                      referrerPolicy="no-referrer"
                    />
                    {/* Branded Tail Logo */}
                    <div className="absolute top-[20%] right-[15%] w-[8%] h-[12%] opacity-60 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" style={{ transform: 'perspective(500px) rotateY(45deg) skewY(-10deg)' }}>
                      <img src="/logo.png" alt="" className="w-full h-full object-contain brightness-200" referrerPolicy="no-referrer" />
                    </div>
                    {/* Branded Fuselage Text */}
                    <div className="absolute top-[45%] left-[30%] opacity-40 group-hover:opacity-80 transition-opacity duration-500 pointer-events-none" style={{ transform: 'perspective(500px) rotateY(-20deg) skewY(-2deg)' }}>
                      <span className="text-white font-black text-4xl tracking-tighter">UNITED AFRICA</span>
                    </div>
                    
                    <div className="absolute inset-0 bg-gradient-to-t from-[#1a365d] via-transparent to-transparent opacity-80" />
                    <div className="absolute bottom-0 left-0 p-8">
                      <div className="flex items-center gap-3 mb-4">
                        <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center p-2 shadow-lg">
                          <img src="/logo.png" alt="UAPS" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                        </div>
                        <div>
                          <p className="text-[#c5a059] text-[10px] font-bold uppercase tracking-widest">Heavy Lift Fleet</p>
                          <h4 className="text-white font-bold text-xl">United Africa Postal Service Air Cargo</h4>
                        </div>
                      </div>
                      <p className="text-blue-100/70 text-sm max-w-md">
                        Our dedicated air fleet connects major global hubs directly to African gateways, bypassing traditional bottlenecks.
                      </p>
                    </div>
                  </motion.div>

                  {/* AKE Container Mockup */}
                  <motion.div 
                    initial={{ opacity: 0, x: 20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.2 }}
                    className="relative h-[400px] rounded-3xl overflow-hidden shadow-xl group bg-white"
                  >
                    <img 
                      src="https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&q=80&w=800" 
                      alt="UAPS AKE Container" 
                      className="w-full h-full object-cover opacity-90 group-hover:scale-110 transition-transform duration-1000"
                      referrerPolicy="no-referrer"
                    />
                    {/* Branded Container Side */}
                    <div className="absolute top-[40%] left-[20%] w-[40%] h-[30%] opacity-80 pointer-events-none" style={{ transform: 'perspective(500px) rotateY(20deg) rotateX(5deg)' }}>
                      <div className="flex items-center gap-2 mb-2">
                        <img src="/logo.png" alt="" className="w-8 h-8 object-contain" referrerPolicy="no-referrer" />
                        <span className="text-[#1a365d] font-black text-xl tracking-tighter">UAPS</span>
                      </div>
                      <div className="h-1 bg-[#c5a059] w-full" />
                    </div>
                    
                    <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-[#1a365d]/90" />
                    <div className="absolute top-6 right-6 bg-white/90 backdrop-blur-md px-4 py-2 rounded-full shadow-lg border border-gray-200">
                      <span className="text-[10px] font-bold text-[#1a365d] uppercase tracking-widest">ID: AKE U-0001 UA</span>
                    </div>
                    <div className="absolute bottom-0 left-0 p-8">
                      <h4 className="text-white font-bold text-lg mb-2">Standardized ULDs</h4>
                      <p className="text-blue-100/70 text-xs">
                        Branded Unit Load Devices (ULDs) optimized for inter-carrier compatibility and automated sorting.
                      </p>
                    </div>
                  </motion.div>

                  {/* Logistics Truck Mockup */}
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.3 }}
                    className="relative h-[300px] rounded-3xl overflow-hidden shadow-xl group"
                  >
                    <img 
                      src="https://images.unsplash.com/photo-1519003722824-194d4455a60c?auto=format&fit=crop&q=80&w=800" 
                      alt="UAPS Logistics Truck" 
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000"
                      referrerPolicy="no-referrer"
                    />
                    {/* Branded Truck Side */}
                    <div className="absolute top-[30%] left-[15%] w-[30%] h-[20%] opacity-70 pointer-events-none" style={{ transform: 'perspective(500px) rotateY(-15deg) skewY(-2deg)' }}>
                      <div className="flex items-center gap-2 mb-1">
                        <img src="/logo.png" alt="" className="w-6 h-6 object-contain brightness-200" referrerPolicy="no-referrer" />
                        <span className="text-white font-black text-lg tracking-tighter">UAPS</span>
                      </div>
                      <div className="h-0.5 bg-[#c5a059] w-full" />
                    </div>
                    
                    <div className="absolute inset-0 bg-gradient-to-t from-[#1a365d] to-transparent opacity-60" />
                    <div className="absolute bottom-0 left-0 p-6">
                      <h4 className="text-white font-bold">Regional Ground Fleet</h4>
                      <p className="text-blue-100/70 text-xs mt-1">Last-mile delivery across 54 countries.</p>
                    </div>
                  </motion.div>

                  {/* In-Flight Mockup */}
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.4 }}
                    className="relative h-[300px] rounded-3xl overflow-hidden shadow-xl group"
                  >
                    <img 
                      src="https://images.unsplash.com/photo-1569154941061-e231b4725ef1?auto=format&fit=crop&q=80&w=800" 
                      alt="UAPS Plane in Flight" 
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#1a365d] to-transparent opacity-60" />
                    <div className="absolute bottom-0 left-0 p-6">
                      <h4 className="text-white font-bold">Strategic Air Corridors</h4>
                      <p className="text-blue-100/70 text-xs mt-1">Connecting Africa to the World.</p>
                    </div>
                  </motion.div>

                  {/* Ground Handling Mockup */}
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.5 }}
                    className="relative h-[300px] rounded-3xl overflow-hidden shadow-xl group"
                  >
                    <img 
                      src="https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&q=80&w=800" 
                      alt="UAPS Ground Handling" 
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#1a365d] to-transparent opacity-60" />
                    <div className="absolute bottom-0 left-0 p-6">
                      <h4 className="text-white font-bold">Hub Operations</h4>
                      <p className="text-blue-100/70 text-xs mt-1">Automated sorting and secure handling.</p>
                    </div>
                  </motion.div>
                </div>
              </div>
              
              {/* Decorative Background Text */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-[15vw] font-black text-white/[0.03] whitespace-nowrap pointer-events-none select-none">
                UAPS ASSETS
              </div>
            </section>

            {/* How UAPS Works */}
            <section id="how-it-works" className="py-24 bg-[#f8fafc] border-y border-gray-200">
              <div className="max-w-6xl mx-auto px-8">
                <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
                  <div className="max-w-xl">
                    <h3 className="text-xs font-bold text-[#c5a059] uppercase tracking-[0.4em] mb-4">The Process</h3>
                    <h2 className="text-4xl font-bold text-[#1a365d]">Seamless Connectivity</h2>
                  </div>
                  <p className="text-sm text-gray-500 max-w-xs">
                    Our integrated network ensures your packages move efficiently from global origin to local destination.
                  </p>
                </div>

                <div className="relative">
                  {/* Connecting Line */}
                  <div className="absolute top-[24px] left-0 w-full h-0.5 bg-gray-200 hidden lg:block" />
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
                    {[
                      { step: "01", title: "Global Pickup", desc: "Packages are collected by international partners at origin.", icon: Package },
                      { step: "02", title: "UAPS Gateway", desc: "Consolidation and sorting at our strategic regional hubs.", icon: Layers },
                      { step: "03", title: "Customs Clearance", desc: "Fast-track processing through government-aligned channels.", icon: Shield },
                      { step: "04", title: "Last-Mile Delivery", desc: "Final delivery via local postal and courier networks.", icon: Truck }
                    ].map((item, i) => (
                      <div key={i} className="relative z-10 flex flex-col items-center lg:items-start text-center lg:text-left">
                        <div className="w-12 h-12 bg-[#1a365d] text-white rounded-full flex items-center justify-center font-bold text-sm mb-6 shadow-lg border-4 border-white">
                          <item.icon className="w-5 h-5" />
                        </div>
                        <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm w-full">
                          <span className="text-[10px] font-bold text-[#c5a059] uppercase tracking-widest mb-2 block">Step {item.step}</span>
                          <h4 className="font-bold text-[#1a365d] mb-3">{item.title}</h4>
                          <p className="text-xs text-gray-500 leading-relaxed">{item.desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </section>

            {/* Global Carrier Integration Map */}
            <section id="network" className="py-24 bg-[#1a365d] text-white overflow-hidden relative">
              {/* Background World Map Image */}
              <div className="absolute inset-0 opacity-20 pointer-events-none">
                <img 
                  src="https://images.unsplash.com/photo-1589519160732-57fc498494f8?auto=format&fit=crop&q=80&w=2000" 
                  alt="World Map Background" 
                  className="w-full h-full object-cover grayscale invert"
                  referrerPolicy="no-referrer"
                />
              </div>

              <div className="max-w-7xl mx-auto px-8 relative z-10">
                <div className="flex flex-col lg:flex-row justify-between items-center mb-16 gap-12">
                  <div className="lg:w-1/2">
                    <div className="flex items-center gap-4 mb-6">
                      <div className="w-16 h-16 bg-white rounded-xl flex items-center justify-center p-2 shadow-xl">
                        <img src="/logo.png" alt="UAPS" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                      </div>
                      <div>
                        <h2 className="text-3xl font-bold tracking-tight">Global Carrier Integration Map</h2>
                        <p className="text-[#c5a059] text-xs font-bold uppercase tracking-widest">Delivering Africa Together</p>
                      </div>
                    </div>
                    <p className="text-blue-100/70 mb-8 leading-relaxed">
                      Our network is built on deep integration with global logistics leaders. By standardizing data exchange and physical handling protocols, we enable seamless cross-border trade.
                    </p>
                    <div className="flex gap-6">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-0.5 bg-green-400 border-t-2 border-dashed border-green-400" />
                        <span className="text-[10px] font-bold uppercase tracking-widest text-gray-300">Intercontinental Air Routes</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-0.5 bg-amber-400 border-t-2 border-dashed border-amber-400" />
                        <span className="text-[10px] font-bold uppercase tracking-widest text-gray-300">Regional Cargo Feeder Routes</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="lg:w-1/3 relative">
                    <div className="absolute -inset-4 bg-[#c5a059]/20 blur-2xl rounded-full" />
                    <div className="relative bg-white/5 backdrop-blur-md border border-white/10 p-2 rounded-2xl shadow-2xl overflow-hidden">
                      <div className="relative">
                        <img 
                          src="https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&q=80&w=600" 
                          alt="UAPS Cargo Container" 
                          className="w-full h-48 object-cover rounded-xl mb-4"
                          referrerPolicy="no-referrer"
                        />
                        {/* Container Branding Overlay */}
                        <div className="absolute top-[30%] left-[20%] w-[30%] h-[20%] opacity-60 pointer-events-none" style={{ transform: 'perspective(500px) rotateY(20deg) rotateX(5deg)' }}>
                          <div className="flex items-center gap-1 mb-1">
                            <img src="/logo.png" alt="" className="w-4 h-4 object-contain" referrerPolicy="no-referrer" />
                            <span className="text-[#1a365d] font-black text-xs tracking-tighter">UAPS</span>
                          </div>
                          <div className="h-0.5 bg-[#c5a059] w-full" />
                        </div>
                      </div>
                      <div className="p-4">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-[10px] font-bold text-[#c5a059] uppercase tracking-widest">Asset ID: AKE U-0001 UA</span>
                          <div className="flex gap-1">
                            <div className="w-1 h-1 bg-green-400 rounded-full" />
                            <div className="w-1 h-1 bg-green-400 rounded-full" />
                            <div className="w-1 h-1 bg-green-400 rounded-full" />
                          </div>
                        </div>
                        <h4 className="text-white font-bold text-sm">Standardized Cargo Units</h4>
                        <p className="text-blue-100/50 text-[10px] leading-tight mt-1">
                          Our ULD containers are tracked in real-time across the entire global carrier network.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* The Map Visualization */}
                <div className="relative aspect-[21/9] bg-blue-900/40 rounded-[40px] border border-white/10 backdrop-blur-md shadow-2xl overflow-hidden">
                  {/* Hub Callouts */}
                  
                  {/* USA HUBS */}
                  <motion.div 
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    className="absolute left-[5%] top-[15%] z-20"
                  >
                    <div className="bg-[#1a365d]/90 backdrop-blur-md border border-white/20 p-4 rounded-xl shadow-2xl min-w-[140px]">
                      <h4 className="text-xs font-black text-white mb-3 border-b border-white/10 pb-2 flex items-center justify-between">
                        USA HUBS <Globe className="w-3 h-3 text-blue-400" />
                      </h4>
                      <ul className="space-y-1.5">
                        {['New York', 'Atlanta', 'Chicago'].map(city => (
                          <li key={city} className="text-[10px] font-bold text-blue-100 flex items-center gap-2">
                            <div className="w-1 h-1 bg-blue-400 rounded-full" /> {city}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </motion.div>

                  {/* EU HUBS */}
                  <motion.div 
                    initial={{ opacity: 0, y: -20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    className="absolute left-[38%] top-[10%] z-20"
                  >
                    <div className="bg-[#1a365d]/90 backdrop-blur-md border border-white/20 p-4 rounded-xl shadow-2xl min-w-[140px]">
                      <h4 className="text-xs font-black text-white mb-3 border-b border-white/10 pb-2 flex items-center justify-between">
                        EU HUBS <Globe className="w-3 h-3 text-blue-400" />
                      </h4>
                      <ul className="space-y-1.5">
                        {['London', 'Frankfurt', 'Paris'].map(city => (
                          <li key={city} className="text-[10px] font-bold text-blue-100 flex items-center gap-2">
                            <div className="w-1 h-1 bg-blue-400 rounded-full" /> {city}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </motion.div>

                  {/* GCC HUBS */}
                  <motion.div 
                    initial={{ opacity: 0, x: 20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    className="absolute right-[25%] top-[20%] z-20"
                  >
                    <div className="bg-[#1a365d]/90 backdrop-blur-md border border-white/20 p-4 rounded-xl shadow-2xl min-w-[140px]">
                      <h4 className="text-xs font-black text-white mb-3 border-b border-white/10 pb-2 flex items-center justify-between">
                        GCC HUBS <Globe className="w-3 h-3 text-blue-400" />
                      </h4>
                      <ul className="space-y-1.5">
                        {['Dubai', 'Doha', 'Riyadh'].map(city => (
                          <li key={city} className="text-[10px] font-bold text-blue-100 flex items-center gap-2">
                            <div className="w-1 h-1 bg-blue-400 rounded-full" /> {city}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </motion.div>

                  {/* ASIA HUBS */}
                  <motion.div 
                    initial={{ opacity: 0, x: 20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    className="absolute right-[5%] top-[10%] z-20"
                  >
                    <div className="bg-[#1a365d]/90 backdrop-blur-md border border-white/20 p-4 rounded-xl shadow-2xl min-w-[140px]">
                      <h4 className="text-xs font-black text-white mb-3 border-b border-white/10 pb-2 flex items-center justify-between">
                        ASIA HUBS <Globe className="w-3 h-3 text-blue-400" />
                      </h4>
                      <ul className="space-y-1.5">
                        {['Hong Kong', 'Singapore', 'Shanghai'].map(city => (
                          <li key={city} className="text-[10px] font-bold text-blue-100 flex items-center gap-2">
                            <div className="w-1 h-1 bg-blue-400 rounded-full" /> {city}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </motion.div>

                  {/* UNITED AFRICA POSTAL SERVICE Branding Box */}
                  <motion.div 
                    initial={{ opacity: 0, x: 20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    className="absolute right-[5%] top-[35%] z-20"
                  >
                    <div className="bg-white border border-gray-200 p-4 rounded-xl shadow-2xl min-w-[180px]">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="w-8 h-8 bg-blue-900 rounded flex items-center justify-center p-1">
                          <img src="/logo.png" alt="UAPS" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                        </div>
                        <div className="text-[10px] font-black leading-tight text-blue-900">
                          UNITED AFRICA<br />POSTAL SERVICE
                        </div>
                      </div>
                      <div className="h-0.5 bg-blue-900 w-full mb-2" />
                      <p className="text-[8px] font-bold text-gray-400 uppercase tracking-widest">Global Logistics Network</p>
                    </div>
                  </motion.div>

                  {/* AFRICA GATEWAYS (UAPS HUB) - Centered on Africa */}
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.8 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    className="absolute left-[45%] top-[45%] z-30"
                  >
                    <div className="bg-white p-5 rounded-2xl shadow-[0_0_50px_rgba(197,160,89,0.4)] border-2 border-[#c5a059] min-w-[220px]">
                      <div className="flex items-center gap-3 mb-4">
                        <div className="w-10 h-10 bg-[#1a365d] rounded-lg flex items-center justify-center p-1.5">
                          <img src="/logo.png" alt="UAPS" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                        </div>
                        <div>
                          <h4 className="text-xs font-bold text-gray-400 uppercase tracking-widest leading-none mb-1">Africa Gateways</h4>
                          <h4 className="text-sm font-black text-[#1a365d] uppercase tracking-tighter">UAPS HUB</h4>
                        </div>
                      </div>
                      <div className="space-y-2 border-t border-gray-100 pt-3">
                        <div className="flex items-center gap-2 text-[10px] font-bold text-gray-600">
                          <CheckCircle2 className="w-3.5 h-3.5 text-green-500" /> Customs Clearance
                        </div>
                        <div className="flex items-center gap-2 text-[10px] font-bold text-gray-600">
                          <CheckCircle2 className="w-3.5 h-3.5 text-green-500" /> Distribution Centers
                        </div>
                      </div>
                    </div>
                  </motion.div>

                  {/* Route Lines (SVG) */}
                  <svg viewBox="0 0 1000 400" className="absolute inset-0 w-full h-full pointer-events-none">
                    <defs>
                      <marker id="arrowhead-green" markerWidth="10" markerHeight="7" refX="0" refY="3.5" orient="auto">
                        <polygon points="0 0, 10 3.5, 0 7" fill="#4ade80" />
                      </marker>
                      <marker id="arrowhead-amber" markerWidth="10" markerHeight="7" refX="0" refY="3.5" orient="auto">
                        <polygon points="0 0, 10 3.5, 0 7" fill="#fbbf24" />
                      </marker>
                    </defs>
                    
                    {/* USA to EU */}
                    <motion.path 
                      d="M100,100 Q250,50 400,80" 
                      fill="none" stroke="#4ade80" strokeWidth="3" strokeDasharray="8,4" 
                      initial={{ pathLength: 0 }} whileInView={{ pathLength: 1 }} transition={{ duration: 2 }}
                    />
                    {/* USA to Africa */}
                    <motion.path 
                      d="M100,150 Q250,250 450,200" 
                      fill="none" stroke="#4ade80" strokeWidth="3" strokeDasharray="8,4" 
                      initial={{ pathLength: 0 }} whileInView={{ pathLength: 1 }} transition={{ duration: 2, delay: 0.5 }}
                    />
                    {/* EU to Africa */}
                    <motion.path 
                      d="M450,100 Q480,150 480,180" 
                      fill="none" stroke="#4ade80" strokeWidth="3" strokeDasharray="8,4" 
                      initial={{ pathLength: 0 }} whileInView={{ pathLength: 1 }} transition={{ duration: 2, delay: 1 }}
                    />
                    {/* GCC to Africa */}
                    <motion.path 
                      d="M750,150 Q600,180 500,200" 
                      fill="none" stroke="#fbbf24" strokeWidth="3" strokeDasharray="8,4" 
                      initial={{ pathLength: 0 }} whileInView={{ pathLength: 1 }} transition={{ duration: 2, delay: 1.5 }}
                    />
                    {/* Asia to Africa */}
                    <motion.path 
                      d="M900,100 Q700,150 500,200" 
                      fill="none" stroke="#4ade80" strokeWidth="3" strokeDasharray="8,4" 
                      initial={{ pathLength: 0 }} whileInView={{ pathLength: 1 }} transition={{ duration: 2, delay: 1.8 }}
                    />
                    {/* Africa to Regional (South) */}
                    <motion.path 
                      d="M480,250 Q500,350 600,380" 
                      fill="none" stroke="#fbbf24" strokeWidth="3" strokeDasharray="8,4" 
                      initial={{ pathLength: 0 }} whileInView={{ pathLength: 1 }} transition={{ duration: 2, delay: 2 }}
                    />
                    {/* Africa to Regional (East) */}
                    <motion.path 
                      d="M520,220 Q700,250 850,280" 
                      fill="none" stroke="#fbbf24" strokeWidth="3" strokeDasharray="8,4" 
                      initial={{ pathLength: 0 }} whileInView={{ pathLength: 1 }} transition={{ duration: 2, delay: 2.2 }}
                    />
                  </svg>

                  {/* Partner Logos Overlay */}
                  <div className="absolute left-[12%] top-[40%] flex flex-col gap-3">
                    <div className="bg-white p-2 rounded shadow-lg w-14 h-8 flex items-center justify-center">
                      <span className="text-[10px] font-black text-[#351c15]">UPS</span>
                    </div>
                    <div className="bg-white p-2 rounded shadow-lg w-14 h-8 flex items-center justify-center">
                      <span className="text-[10px] font-black text-[#4d148c]">FedEx</span>
                    </div>
                  </div>
                  <div className="absolute left-[42%] top-[25%]">
                    <div className="bg-[#ffcc00] p-2 rounded shadow-lg w-14 h-8 flex items-center justify-center">
                      <span className="text-[10px] font-black text-[#d40511]">DHL</span>
                    </div>
                  </div>
                </div>

                {/* Handoff Points Legend */}
                <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8">
                  <div className="bg-white/5 border border-white/10 p-6 rounded-2xl flex items-center gap-6">
                    <div className="w-16 h-16 bg-blue-500/20 rounded-xl flex items-center justify-center">
                      <Globe className="w-8 h-8 text-blue-400" />
                    </div>
                    <div>
                      <h5 className="font-bold text-sm mb-1">Airport Hubs</h5>
                      <p className="text-[10px] text-gray-400 uppercase tracking-widest font-bold">Strategic Handoff Points</p>
                    </div>
                  </div>
                  <div className="bg-white/5 border border-white/10 p-6 rounded-2xl flex items-center gap-6">
                    <div className="w-16 h-16 bg-amber-500/20 rounded-xl flex items-center justify-center">
                      <Database className="w-8 h-8 text-amber-400" />
                    </div>
                    <div>
                      <h5 className="font-bold text-sm mb-1">Logistics Centers</h5>
                      <p className="text-[10px] text-gray-400 uppercase tracking-widest font-bold">Consolidation & Sorting</p>
                    </div>
                  </div>
                  <div className="bg-white/5 border border-white/10 p-6 rounded-2xl flex items-center gap-6">
                    <div className="w-16 h-16 bg-green-500/20 rounded-xl flex items-center justify-center">
                      <Truck className="w-8 h-8 text-green-400" />
                    </div>
                    <div>
                      <h5 className="font-bold text-sm mb-1">Final Mile Delivery</h5>
                      <p className="text-[10px] text-gray-400 uppercase tracking-widest font-bold">Local Network Integration</p>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* Pilot Shipping Corridors – Phase I */}
            <section id="corridors" className="py-24 bg-white">
              <div className="max-w-7xl mx-auto px-8">
                <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
                  <div className="max-w-2xl">
                    <h3 className="text-xs font-bold text-[#c5a059] uppercase tracking-[0.4em] mb-4">Strategic Rollout</h3>
                    <h2 className="text-5xl font-black text-[#1a365d] tracking-tighter leading-none">Pilot Shipping Corridors <br /><span className="text-[#c5a059]">Phase I</span></h2>
                  </div>
                  <div className="bg-gray-50 p-6 rounded-2xl border border-gray-100 max-w-sm">
                    <p className="text-xs text-gray-500 leading-relaxed font-medium">
                      Clear, credible rollout logic designed for ministers, regulators, and investors to drive Africa's logistics transformation.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  {[
                    {
                      id: "usa",
                      flag: "🇺🇸",
                      title: "USA ↔ Africa",
                      hubs: ["New York", "Washington DC", "Atlanta", "Chicago"],
                      gateways: ["Addis Ababa", "Nairobi", "Lagos", "Accra"],
                      focus: "Diaspora parcels, documents, e-commerce",
                      color: "blue"
                    },
                    {
                      id: "eu",
                      flag: "🇪🇺",
                      title: "EU ↔ Africa",
                      hubs: ["London", "Paris", "Frankfurt", "Rome"],
                      gateways: ["Dakar", "Abidjan", "Tunis", "Cairo"],
                      focus: "Trade flows, SMEs, government mail",
                      color: "indigo"
                    },
                    {
                      id: "gcc",
                      flag: "🇬🇨",
                      title: "GCC ↔ Africa",
                      hubs: ["Dubai", "Doha", "Riyadh"],
                      gateways: ["Addis Ababa", "Khartoum", "Mogadishu"],
                      focus: "Express cargo, labor-linked mail, remittance-related services",
                      color: "amber"
                    }
                  ].map((corridor, idx) => (
                    <motion.div
                      key={corridor.id}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.1 }}
                      className="group bg-white rounded-[32px] border border-gray-100 shadow-xl hover:shadow-2xl transition-all duration-500 overflow-hidden flex flex-col"
                    >
                      <div className={`h-2 w-full ${
                        corridor.color === 'blue' ? 'bg-blue-600' : 
                        corridor.color === 'indigo' ? 'bg-indigo-600' : 'bg-[#c5a059]'
                      }`} />
                      <div className="p-10 flex-1 flex flex-col">
                        <div className="flex items-center justify-between mb-8">
                          <span className="text-4xl">{corridor.flag}</span>
                          <div className="w-16 h-10 bg-gray-50 rounded-lg overflow-hidden border border-gray-100 flex items-center justify-center relative">
                            <img 
                              src={
                                corridor.id === 'usa' ? "https://images.unsplash.com/photo-1544016768-982d1554f0b9?auto=format&fit=crop&q=80&w=100" :
                                corridor.id === 'eu' ? "https://images.unsplash.com/photo-1519003722824-194d4455a60c?auto=format&fit=crop&q=80&w=100" :
                                "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&q=80&w=100"
                              }
                              alt="Asset Mockup"
                              className="w-full h-full object-cover opacity-50 grayscale group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-500"
                              referrerPolicy="no-referrer"
                            />
                            {/* Tiny Branded Overlay for Corridor Assets */}
                            <div className="absolute inset-0 bg-[#1a365d]/10 group-hover:bg-transparent transition-colors" />
                            <div className="absolute top-1 right-1 w-2 h-2 opacity-0 group-hover:opacity-100 transition-opacity">
                              <img src="/logo.png" alt="" className="w-full h-full object-contain brightness-200" referrerPolicy="no-referrer" />
                            </div>
                          </div>
                        </div>
                        
                        <h4 className="text-2xl font-black text-[#1a365d] mb-8">{corridor.title}</h4>
                        
                        <div className="space-y-8 flex-1">
                          <div>
                            <h5 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-4">Strategic Hubs</h5>
                            <div className="flex flex-wrap gap-2">
                              {corridor.hubs.map(hub => (
                                <span key={hub} className="px-3 py-1.5 bg-gray-50 text-[#1a365d] text-[10px] font-bold rounded-lg border border-gray-100">
                                  {hub}
                                </span>
                              ))}
                            </div>
                          </div>
                          
                          <div>
                            <h5 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-4">Africa Gateways</h5>
                            <div className="flex flex-wrap gap-2">
                              {corridor.gateways.map(gateway => (
                                <span key={gateway} className="px-3 py-1.5 bg-blue-50 text-blue-700 text-[10px] font-bold rounded-lg border border-blue-100">
                                  {gateway}
                                </span>
                              ))}
                            </div>
                          </div>
                        </div>

                        <div className="mt-10 pt-8 border-t border-gray-100">
                          <h5 className="text-[10px] font-bold text-[#c5a059] uppercase tracking-widest mb-3">Strategic Focus</h5>
                          <p className="text-sm text-gray-600 font-medium leading-relaxed">
                            {corridor.focus}
                          </p>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </section>

            {/* Our Services */}
            <section id="services" className="py-24 bg-gray-900 text-white overflow-hidden relative">
              <div className="absolute top-0 right-0 w-1/2 h-full bg-[#c5a059]/5 skew-x-12 translate-x-1/4" />
              <div className="max-w-6xl mx-auto px-8 relative z-10">
                <div className="mb-16">
                  <h3 className="text-xs font-bold text-[#c5a059] uppercase tracking-[0.4em] mb-4">What We Offer</h3>
                  <h2 className="text-4xl font-bold">Our Services</h2>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {[
                    { 
                      title: "Global Priority Express", 
                      desc: "Fastest delivery for urgent documents and parcels from anywhere in the world to Africa.",
                      features: ["2-5 Business Days", "End-to-End Tracking", "Priority Customs"]
                    },
                    { 
                      title: "Diaspora Direct", 
                      desc: "Specialized service for families sending personal effects and gifts to relatives in Africa.",
                      features: ["Consolidated Shipping", "Door-to-Door Delivery", "Affordable Rates"]
                    },
                    { 
                      title: "Government Logistics", 
                      desc: "Secure handling of official mail, diplomatic pouches, and sensitive government cargo.",
                      features: ["Highest Security", "Diplomatic Immunity Support", "Dedicated Account Mgmt"]
                    }
                  ].map((service, i) => (
                    <div key={i} className="bg-white/5 backdrop-blur-sm border border-white/10 p-8 rounded-2xl hover:bg-white/10 transition-all">
                      <h4 className="text-xl font-bold mb-4 text-[#c5a059]">{service.title}</h4>
                      <p className="text-sm text-gray-400 mb-8 leading-relaxed">{service.desc}</p>
                      <ul className="space-y-3">
                        {service.features.map((f, j) => (
                          <li key={j} className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-gray-300">
                            <CheckCircle2 className="w-4 h-4 text-[#c5a059]" /> {f}
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </div>
            </section>

            {/* News & Updates */}
            <section id="news" className="py-24 bg-white">
              <div className="max-w-6xl mx-auto px-8">
                <div className="flex justify-between items-end mb-16">
                  <div>
                    <h3 className="text-xs font-bold text-[#c5a059] uppercase tracking-[0.4em] mb-4">Stay Informed</h3>
                    <h2 className="text-4xl font-bold text-[#1a365d]">News & Updates</h2>
                  </div>
                  <button className="text-sm font-bold text-[#1a365d] flex items-center gap-2 hover:gap-3 transition-all">
                    View All News <ChevronRight className="w-4 h-4" />
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {[
                    {
                      date: "March 20, 2024",
                      title: "UAPS Expands Network to West Africa Hubs",
                      desc: "New strategic partnerships in Lagos and Accra to reduce delivery times by 30%."
                    },
                    {
                      date: "March 15, 2024",
                      title: "Digital Customs Integration Goes Live",
                      desc: "Our new automated clearance system is now operational across 15 major African ports."
                    },
                    {
                      date: "March 10, 2024",
                      title: "UAPS Partners with Global E-commerce Leaders",
                      desc: "Strengthening the last-mile delivery infrastructure for international digital trade."
                    }
                  ].map((news, i) => (
                    <div key={i} className="group cursor-pointer">
                      <div className="aspect-video bg-gray-100 rounded-xl mb-6 overflow-hidden relative">
                         <div className="absolute inset-0 bg-gradient-to-br from-[#1a365d]/20 to-transparent" />
                         <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-[#1a365d]/40 backdrop-blur-sm">
                            <span className="text-white font-bold text-xs uppercase tracking-widest">Read More</span>
                         </div>
                      </div>
                      <p className="text-[10px] font-bold text-[#c5a059] uppercase tracking-widest mb-2">{news.date}</p>
                      <h4 className="font-bold text-[#1a365d] mb-3 group-hover:text-[#c5a059] transition-colors">{news.title}</h4>
                      <p className="text-sm text-gray-500 leading-relaxed">{news.desc}</p>
                    </div>
                  ))}
                </div>
              </div>
            </section>

            {/* CTA Section */}
            <section className="py-20 bg-[#c5a059]">
              <div className="max-w-4xl mx-auto px-8 text-center">
                <h2 className="text-4xl font-bold text-white mb-8">Ready to transform your African logistics?</h2>
                <p className="text-white/80 mb-10 text-lg">
                  Join the UAPS network and gain access to the most comprehensive postal and logistics infrastructure on the continent.
                </p>
                <div className="flex flex-col sm:flex-row justify-center gap-4">
                  <button 
                    onClick={() => setView('partner_login')}
                    className="bg-[#1a365d] text-white px-10 py-4 rounded font-bold text-sm uppercase tracking-widest hover:bg-blue-900 transition-all shadow-xl"
                  >
                    Become a Partner
                  </button>
                  <button 
                    onClick={() => setShowContactSales(true)}
                    className="bg-white text-[#1a365d] px-10 py-4 rounded font-bold text-sm uppercase tracking-widest hover:bg-gray-100 transition-all shadow-xl"
                  >
                    Contact Sales
                  </button>
                </div>
              </div>
            </section>

            <ContactSalesModal 
              isOpen={showContactSales} 
              onClose={() => setShowContactSales(false)} 
            />

            {/* Trusted Partnerships / Newsletter */}
            <section className="py-12 bg-gray-100 border-y border-gray-200">
              <div className="max-w-6xl mx-auto px-8 flex flex-col md:flex-row justify-between items-center gap-8">
                <h3 className="text-xl font-bold text-[#1a365d] uppercase tracking-widest">Trusted Partnerships</h3>
                <div className="flex w-full md:w-auto bg-white rounded overflow-hidden shadow-sm border border-gray-300">
                  <input 
                    type="email" 
                    placeholder="Enter your email address" 
                    className="px-6 py-3 text-sm focus:outline-none flex-1 md:w-80"
                  />
                  <button className="bg-[#666] text-white px-8 py-3 font-bold uppercase tracking-widest hover:bg-gray-700 transition-colors">
                    Submit
                  </button>
                </div>
              </div>
            </section>
          </motion.div>
        ) : view === 'returns' ? (
          <motion.div
            key="returns"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            <ReturnPortal />
          </motion.div>
        ) : view === 'admin_login' ? (
          <motion.div
            key="admin_login"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            <AdminLogin onLogin={(success) => {
              if (success) {
                setIsAdminAuthenticated(true);
                setView('dashboard');
              }
            }} />
          </motion.div>
        ) : view === 'partner_login' ? (
          <motion.div
            key="partner_login"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <PartnerLogin onLogin={(success) => {
              if (success) {
                setIsPartnerAuthenticated(true);
                setView('dashboard');
              }
            }} />
          </motion.div>
        ) : view === 'dashboard' ? (
          (isPartnerAuthenticated || isAdminAuthenticated) ? (
            <AdminDashboard 
              userRole={isAdminAuthenticated ? 'admin' : 'partner'}
              recentOrders={recentOrders}
              handleExportCSV={handleExportCSV}
              getStatusStyles={getStatusStyles}
              getPriorityStyles={getPriorityStyles}
              getCarrierLogo={getCarrierLogo}
            />
          ) : (
            <motion.div
              key="redirect"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              onAnimationComplete={() => setView('partner_login')}
              className="min-h-[60vh] flex items-center justify-center"
            >
              <div className="flex flex-col items-center gap-4">
                <Loader2 className="w-8 h-8 text-[#1a365d] animate-spin" />
                <p className="text-sm font-bold text-[#1a365d] uppercase tracking-widest">Redirecting to Secure Login...</p>
              </div>
            </motion.div>
          )
        ) : view === 'courier' ? (
          <motion.div
            key="courier"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="w-full"
          >
            <CourierDashboard />
          </motion.div>
        ) : view === 'customer' ? (
          <CustomerPortal onTrack={(id) => {
            setTrackingNumber(id);
            handleTrack(undefined, id);
          }} />
        ) : view === 'tracking' ? (
          <motion.div
            key="tracking"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="max-w-6xl mx-auto p-4 md:p-8"
          >
            <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-6 gap-4">
              <div>
                <button 
                  onClick={() => setView('home')}
                  className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-2 flex items-center gap-1 hover:text-[#1a365d]"
                >
                  <ChevronRight className="w-3 h-3 rotate-180" /> Back to Home
                </button>
                <div className="flex items-center gap-3">
                  <h2 className="text-3xl font-bold text-[#1a365d]">Package Tracking</h2>
                  {trackingData && (
                    <span className="flex items-center gap-1 bg-emerald-100 text-emerald-700 px-2 py-1 rounded text-[10px] font-bold uppercase tracking-widest animate-pulse">
                      <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
                      Live
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-4 mt-1">
                  <p className="text-lg font-mono text-gray-500">{shipment?.id}</p>
                  <button
                    onClick={() => {
                      const link = `${window.location.origin}/track/${shipment?.id}`;
                      navigator.clipboard.writeText(link);
                    }}
                    className="flex items-center gap-2 bg-blue-600/10 text-blue-600 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest hover:bg-blue-600/20 transition-all"
                  >
                    <Globe className="w-3 h-3" /> Copy Link
                  </button>
                  <button
                    onClick={async () => {
                      // Simulated subscription
                      try {
                        const res = await fetch('/api/subscribe', {
                          method: 'POST',
                          headers: { 'Content-Type': 'application/json' },
                          body: JSON.stringify({
                            trackingId: shipment?.id,
                            subscription: { endpoint: 'simulated-endpoint' }
                          })
                        });
                        if (res.ok) alert('Subscribed to notifications!');
                      } catch (err) {
                        console.error(err);
                      }
                    }}
                    className="flex items-center gap-2 bg-emerald-600/10 text-emerald-600 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest hover:bg-emerald-600/20 transition-all"
                  >
                    <Activity className="w-3 h-3" /> Notify Me
                  </button>
                </div>
              </div>
              <div className="flex bg-white border border-gray-200 rounded p-1 shadow-sm">
                <button 
                  onClick={() => setViewMode('timeline')}
                  className={`px-4 py-1.5 text-xs font-bold rounded transition-all ${viewMode === 'timeline' ? 'bg-[#1a365d] text-white' : 'text-gray-500 hover:bg-gray-100'}`}
                >
                  Timeline
                </button>
                <button 
                  onClick={() => setViewMode('map')}
                  className={`px-4 py-1.5 text-xs font-bold rounded transition-all ${viewMode === 'map' ? 'bg-[#1a365d] text-white' : 'text-gray-500 hover:bg-gray-100'}`}
                >
                  Map
                </button>
              </div>
            </div>

            {error && (
              <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-8 flex items-center gap-3">
                <AlertCircle className="text-red-500 w-5 h-5" />
                <p className="text-red-700 text-sm">{error}</p>
              </div>
            )}

            {shipment && (
              <div className="space-y-8">
                {/* Top Status Bar & Map Card */}
                <div className="bg-white border border-gray-100 rounded-[32px] shadow-2xl overflow-hidden flex flex-col lg:flex-row">
                  {/* Estimated Delivery Card */}
                  <div className="w-full lg:w-1/3 bg-gray-50 p-12 flex flex-col items-center justify-center text-center border-r border-gray-100">
                    <h3 className="text-sm font-bold text-[#1a365d] uppercase tracking-[0.2em] mb-4">Estimated delivery</h3>
                    <div className="flex flex-col items-center">
                      <span className="text-8xl font-black text-[#1a365d] leading-none">
                        {new Date(shipment.events[0].timestamp).getDate()}
                      </span>
                      <span className="text-xl font-bold text-[#1a365d] mt-2">
                        {new Date(shipment.events[0].timestamp).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
                      </span>
                    </div>
                  </div>

                  {/* Map Visualization */}
                  <div className="w-full lg:w-2/3 bg-[#0f172a] relative overflow-hidden min-h-[400px] z-0">
                    {shipment.courier?.id ? (
                      <TrackMyCourierMap trackingId={shipment.id} />
                    ) : (
                      <InteractiveMap shipment={shipment} />
                    )}
                    {/* Map Controls Overlay (Optional, since Leaflet has its own) */}
                    <div className="absolute bottom-6 right-6 flex gap-2 z-[1000]">
                      <button className="bg-white/10 backdrop-blur-md border border-white/20 p-2 rounded-xl text-white hover:bg-white/20 transition-all"><MapIcon className="w-4 h-4" /></button>
                      <button className="bg-white/10 backdrop-blur-md border border-white/20 p-2 rounded-xl text-white hover:bg-white/20 transition-all"><Settings className="w-4 h-4" /></button>
                    </div>
                  </div>
                </div>

                {/* Horizontal Progress Bar */}
                <div className="bg-white p-12 rounded-[32px] shadow-xl border border-gray-100">
                  <div className="relative px-4">
                    {/* Background Line */}
                    <div className="absolute top-1/2 left-0 w-full h-1.5 bg-gray-100 -translate-y-1/2 rounded-full" />
                    {/* Active Line */}
                    <motion.div 
                      className="absolute top-1/2 left-0 h-1.5 bg-[#1a365d] -translate-y-1/2 rounded-full"
                      initial={{ width: "0%" }}
                      animate={{ 
                        width: shipment.status.status === 'DELIVERED' ? "100%" :
                               shipment.status.status === 'IN_TRANSIT' ? "75%" :
                               shipment.status.status === 'PICKED_UP' ? "50%" :
                               shipment.status.status === 'ACCEPTED' ? "25%" : "5%"
                      }}
                      transition={{ duration: 1.5, ease: "easeOut" }}
                    />
                    
                    <div className="relative flex justify-between items-center">
                      {[
                        { label: "Ordered", key: "NEW" },
                        { label: "Accepted", key: "ACCEPTED" },
                        { label: "Picked Up", key: "PICKED_UP", icon: Package },
                        { label: "In Transit", key: "IN_TRANSIT", icon: Truck },
                        { label: "Delivered", key: "DELIVERED", icon: CheckCircle2 }
                      ].map((step, i) => {
                        const statusOrder = ["NEW", "ACCEPTED", "PICKED_UP", "IN_TRANSIT", "DELIVERED"];
                        const currentIdx = statusOrder.indexOf(shipment.status.status);
                        const state = i < currentIdx ? 'completed' : i === currentIdx ? 'active' : 'pending';
                        
                        return (
                          <div key={i} className="flex flex-col items-center group">
                            <div className={`w-10 h-10 rounded-full flex items-center justify-center border-4 border-white shadow-xl transition-all relative z-10 ${
                              state === 'completed' ? 'bg-[#1a365d]' : 
                              state === 'active' ? 'bg-[#c5a059] scale-125' : 
                              'bg-gray-200'
                            }`}>
                              {state === 'completed' ? (
                                <CheckCircle2 className="w-5 h-5 text-white" />
                              ) : step.icon ? (
                                <step.icon className={`w-5 h-5 text-white ${state === 'active' ? 'animate-pulse' : ''}`} />
                              ) : (
                                <div className="w-2 h-2 bg-white rounded-full" />
                              )}
                            </div>
                            <span className={`mt-6 text-[10px] font-bold uppercase tracking-widest transition-colors ${
                              state === 'pending' ? 'text-gray-400' : 'text-[#1a365d]'
                            }`}>
                              {step.label}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>

                {/* Details Grid */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* Last Update Card */}
                  <div className="bg-white p-10 rounded-[32px] shadow-xl border border-gray-100">
                    <div className="text-center mb-8">
                      <h3 className="text-3xl font-black text-[#1a365d] mb-2">{shipment.status.status.replace('_', ' ')}</h3>
                      <p className="text-gray-500 font-medium">{shipment.status.description}</p>
                      {shipment.status.eta && (
                        <div className="mt-4 inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-2xl shadow-lg shadow-blue-600/20">
                          <Clock className="w-4 h-4" />
                          <span className="text-xs font-black uppercase tracking-widest">ETA: {shipment.status.eta}</span>
                        </div>
                      )}
                    </div>
                    <div className="bg-gray-50 p-8 rounded-2xl flex items-start gap-6">
                      <div className="w-14 h-14 bg-white rounded-2xl shadow-sm flex items-center justify-center flex-shrink-0">
                        <History className="w-7 h-7 text-gray-400" />
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-[#1a365d] mb-2">Last update</h4>
                        <p className="text-sm text-gray-500 leading-relaxed mb-6">
                          {shipment.status.description} <br />
                          <span className="text-[#1a365d] font-bold">{shipment.status.location.address.addressLocality}</span>, {new Date(shipment.status.timestamp).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}, {new Date(shipment.status.timestamp).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
                        </p>
                        <div className="pt-6 border-t border-gray-100">
                          <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-4">Delivery Progress</h4>
                          <DeliveryTimeline history={(shipment as any).statusHistory || []} />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Shipment Details Card */}
                  <div className="bg-white rounded-[32px] shadow-xl border border-gray-100 overflow-hidden">
                    <div className="bg-gray-50 px-10 py-6 border-b border-gray-100 flex justify-between items-center">
                      <h3 className="text-sm font-bold text-[#1a365d] uppercase tracking-widest">Details</h3>
                      <ChevronRight className="w-5 h-5 text-gray-400 rotate-90" />
                    </div>
                    <div className="p-10 grid grid-cols-2 gap-y-10">
                      <div>
                        <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Tracking Number</h4>
                        <p className="text-sm font-bold text-blue-600 underline cursor-pointer">{shipment.id}</p>
                        <p className="text-[10px] font-bold text-gray-400 uppercase mt-1">UAPS</p>
                        
                        {shipment.partnerTrackingIds && shipment.partnerTrackingIds.length > 0 && (
                          <div className="mt-4">
                            <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Partner IDs</h4>
                            <div className="flex flex-wrap gap-2">
                              {shipment.partnerTrackingIds.map(id => (
                                <span key={id} className="text-[10px] font-mono bg-gray-100 px-2 py-1 rounded text-gray-600">
                                  {id}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                      <div>
                        <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Name</h4>
                        <p className="text-sm font-bold text-[#1a365d]">{shipment.receiver?.name || 'Aaron Abraha'}</p>
                      </div>
                      {shipment.service && (
                        <div>
                          <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Service Type</h4>
                          <p className="text-sm font-bold text-[#1a365d]">{shipment.service}</p>
                        </div>
                      )}
                      {shipment.destination?.address?.addressLocality && (
                        <div>
                          <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Destination</h4>
                          <p className="text-sm font-bold text-[#1a365d]">{shipment.destination.address.addressLocality}</p>
                        </div>
                      )}
                      <div>
                        <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Order Number</h4>
                        <p className="text-sm font-bold text-blue-600 underline cursor-pointer">#{shipment.id.split('-').pop()}</p>
                      </div>
                      <div>
                        <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Address</h4>
                        <p className="text-sm font-bold text-[#1a365d] leading-relaxed">
                          {shipment.destination?.address?.streetAddress || (
                            <>
                              199-131 E 22nd St <br />
                              Nairobi, 00100
                            </>
                          )}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Courier Information Card */}
                  {shipment.courier && (
                    <div className="bg-white p-10 rounded-[32px] shadow-xl border border-gray-100 lg:col-span-2">
                      <h3 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-6">Courier Information</h3>
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                        <div className="flex items-center gap-4">
                          <div className="w-16 h-16 bg-gray-50 rounded-2xl flex items-center justify-center p-3 border border-gray-100">
                            <img 
                              src="/logo.png" 
                              alt="UAPS" 
                              className="w-full h-full object-contain"
                              referrerPolicy="no-referrer"
                            />
                          </div>
                          <div>
                            <p className="text-xl font-black text-[#1a365d]">{shipment.courier.name}</p>
                            <p className="text-xs text-gray-400 font-bold uppercase tracking-widest">Official UAPS Logistics Partner</p>
                          </div>
                        </div>
                        <div className="flex flex-wrap gap-4">
                          <a 
                            href={`tel:${shipment.courier.phone}`}
                            className="flex items-center gap-3 bg-gray-50 px-6 py-3 rounded-2xl border border-gray-100 text-sm font-bold text-[#1a365d] hover:bg-gray-100 transition-all shadow-sm"
                          >
                            <Phone className="w-4 h-4 text-blue-500" />
                            {shipment.courier.phone}
                          </a>
                          <a 
                            href={`mailto:${shipment.courier.email}`}
                            className="flex items-center gap-3 bg-gray-50 px-6 py-3 rounded-2xl border border-gray-100 text-sm font-bold text-[#1a365d] hover:bg-gray-100 transition-all shadow-sm"
                          >
                            <Mail className="w-4 h-4 text-blue-500" />
                            {shipment.courier.email}
                          </a>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                  {/* Proof of Delivery Card */}
                  {shipment.status.status === 'DELIVERED' && (shipment as any).proofOfDelivery && (
                    <div className="bg-white p-10 rounded-[32px] shadow-xl border border-gray-100 lg:col-span-2">
                      <h3 className="text-sm font-bold text-[#1a365d] uppercase tracking-widest mb-8 flex items-center gap-2">
                        <ShieldCheck className="w-5 h-5 text-emerald-500" /> Proof of Delivery
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                        {(shipment as any).proofOfDelivery.signature && (
                          <div>
                            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-4">Customer Signature</p>
                            <div className="bg-gray-50 rounded-2xl p-6 border border-gray-100 flex items-center justify-center">
                              <img 
                                src={(shipment as any).proofOfDelivery.signature} 
                                alt="Signature" 
                                className="max-h-32 object-contain"
                                referrerPolicy="no-referrer"
                              />
                            </div>
                          </div>
                        )}
                        {(shipment as any).proofOfDelivery.photo && (
                          <div>
                            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-4">Delivery Photo</p>
                            <div className="bg-gray-50 rounded-2xl overflow-hidden border border-gray-100">
                              <img 
                                src={(shipment as any).proofOfDelivery.photo} 
                                alt="Delivery Proof" 
                                className="w-full h-48 object-cover"
                                referrerPolicy="no-referrer"
                              />
                            </div>
                          </div>
                        )}
                      </div>
                      <p className="mt-8 text-[10px] text-gray-400 font-bold uppercase tracking-widest text-center">
                        Delivered on {new Date((shipment as any).proofOfDelivery.timestamp).toLocaleString()}
                      </p>
                    </div>
                  )}

                {/* Detailed Timeline (Optional Toggle) */}
                <div className="bg-white p-10 rounded-[32px] shadow-xl border border-gray-100">
                  <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-8">Full Activity Log</h3>
                  <div className="space-y-8 relative">
                    <div className="absolute left-[11px] top-2 bottom-2 w-[2px] bg-gray-100" />
                    {shipment.events.map((event, i) => (
                      <div key={i} className="relative flex gap-6 items-start">
                        <div className={`relative z-10 w-6 h-6 rounded-full flex items-center justify-center border-4 border-white shadow-md ${
                          i === shipment.events.length - 1 ? 'bg-blue-500' : 'bg-gray-200'
                        }`}>
                          <div className="w-1.5 h-1.5 bg-white rounded-full" />
                        </div>
                        <div className="flex-1">
                          <div className="flex justify-between items-baseline mb-1">
                            <span className="text-[10px] font-bold text-gray-400">
                              {new Date(event.timestamp).toLocaleDateString('en-GB', { day: '2-digit', month: 'short' })}
                            </span>
                            <span className="text-[10px] font-bold text-gray-400 uppercase">{event.location.address.addressLocality}</span>
                          </div>
                          <p className="text-sm text-[#1a365d] font-medium">{event.description}</p>
                          {(event as any).partnerInfo && (
                            <div className="mt-1 flex items-center gap-2">
                              <span className="text-[9px] font-black bg-blue-50 text-blue-600 px-2 py-0.5 rounded uppercase tracking-tighter border border-blue-100">
                                Partner: {(event as any).partnerInfo.partnerId}
                              </span>
                              {(event as any).partnerInfo.localTrackingId && (
                                <span className="text-[9px] font-bold text-gray-400">
                                  Ref: {(event as any).partnerInfo.localTrackingId}
                                </span>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Shipment Notes Section */}
                <div className="bg-gray-50 p-10 rounded-[32px] shadow-xl border border-gray-100">
                  <h3 className="text-sm font-bold text-[#1a365d] uppercase tracking-widest mb-6 flex items-center gap-2">
                    <FileText className="w-4 h-4" /> Shipment Notes
                  </h3>
                  <div className="space-y-4 mb-6 max-h-40 overflow-y-auto">
                    {(shipmentNotes[shipment.id] || []).length === 0 ? (
                      <p className="text-sm text-gray-400 italic">No notes added yet.</p>
                    ) : (
                      (shipmentNotes[shipment.id] || []).map(note => (
                        <div key={note.id} className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm">
                          <p className="text-sm text-[#1a365d] mb-2">{note.text}</p>
                          <p className="text-[10px] font-bold text-gray-400 uppercase">
                            {new Date(note.timestamp).toLocaleString()}
                          </p>
                        </div>
                      ))
                    )}
                  </div>
                  <div className="flex gap-3">
                    <input
                      type="text"
                      value={newNoteText}
                      onChange={(e) => setNewNoteText(e.target.value)}
                      placeholder="Add a note..."
                      className="flex-1 px-4 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                      onKeyDown={(e) => e.key === 'Enter' && handleAddNote(shipment.id)}
                    />
                    <button
                      onClick={() => handleAddNote(shipment.id)}
                      disabled={!newNoteText.trim()}
                      className="bg-[#1a365d] text-white px-6 py-3 rounded-xl text-sm font-bold uppercase tracking-widest hover:bg-blue-900 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                    >
                      <Plus className="w-4 h-4" /> Add
                    </button>
                  </div>
                </div>
              </div>
            )}
          </motion.div>
        ) : view === 'settings' ? (
          <motion.div
            key="settings"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="max-w-4xl mx-auto p-8 py-20"
          >
            <div className="bg-white rounded-[32px] shadow-2xl border border-gray-100 overflow-hidden">
              <div className="bg-[#1a365d] p-12 text-white">
                <h2 className="text-3xl font-bold mb-2">UAPS Plugin Settings</h2>
                <p className="text-blue-100/60 text-sm">Configure your UAPS integration and API keys securely.</p>
              </div>
              <div className="p-12 space-y-10">
                <div>
                  <h3 className="text-sm font-bold text-[#1a365d] uppercase tracking-widest mb-6 flex items-center gap-2">
                    <Shield className="w-4 h-4" /> Security & API Keys
                  </h3>
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">DHL API Key</label>
                      <div className="relative">
                        <input 
                          type="password"
                          value={dhlApiKey}
                          onChange={(e) => setDhlApiKey(e.target.value)}
                          placeholder="Enter your DHL API Key..."
                          className="w-full bg-gray-50 border border-gray-200 rounded-xl px-6 py-4 text-sm focus:outline-none focus:ring-2 focus:ring-[#1a365d] transition-all"
                        />
                        <div className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-300">
                          <Settings className="w-5 h-5" />
                        </div>
                      </div>
                      <p className="text-[10px] text-gray-400 mt-2 italic">
                        This key is used to authenticate requests to the DHL Tracking API.
                      </p>
                    </div>

                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">FedEx API Key</label>
                      <div className="relative">
                        <input 
                          type="password"
                          value={fedexApiKey}
                          onChange={(e) => setFedexApiKey(e.target.value)}
                          placeholder="Enter your FedEx API Key..."
                          className="w-full bg-gray-50 border border-gray-200 rounded-xl px-6 py-4 text-sm focus:outline-none focus:ring-2 focus:ring-[#1a365d] transition-all"
                        />
                        <div className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-300">
                          <Settings className="w-5 h-5" />
                        </div>
                      </div>
                      <p className="text-[10px] text-gray-400 mt-2 italic">
                        This key is used to authenticate requests to the FedEx Tracking API.
                      </p>
                    </div>

                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">UPS API Key</label>
                      <div className="relative">
                        <input 
                          type="password"
                          value={upsApiKey}
                          onChange={(e) => setUpsApiKey(e.target.value)}
                          placeholder="Enter your UPS API Key..."
                          className="w-full bg-gray-50 border border-gray-200 rounded-xl px-6 py-4 text-sm focus:outline-none focus:ring-2 focus:ring-[#1a365d] transition-all"
                        />
                        <div className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-300">
                          <Settings className="w-5 h-5" />
                        </div>
                      </div>
                      <p className="text-[10px] text-gray-400 mt-2 italic">
                        This key is used to authenticate requests to the UPS Tracking API.
                      </p>
                    </div>

                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">USPS API Key</label>
                      <div className="relative">
                        <input 
                          type="password"
                          value={uspsApiKey}
                          onChange={(e) => setUspsApiKey(e.target.value)}
                          placeholder="Enter your USPS API Key..."
                          className="w-full bg-gray-50 border border-gray-200 rounded-xl px-6 py-4 text-sm focus:outline-none focus:ring-2 focus:ring-[#1a365d] transition-all"
                        />
                        <div className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-300">
                          <Settings className="w-5 h-5" />
                        </div>
                      </div>
                      <p className="text-[10px] text-gray-400 mt-2 italic">
                        This key is used to authenticate requests to the USPS Tracking API.
                      </p>
                    </div>
                    
                    <p className="text-[10px] text-gray-400 mt-2 italic">
                      These keys are stored in your browser's local storage for this session. 
                      For WordPress users, keys are securely managed via the UAPS Tracking Plugin.
                    </p>
                  </div>
                </div>

                <div className="pt-8 border-t border-gray-100 flex justify-end gap-4">
                  <button 
                    onClick={() => setView('home')}
                    className="px-8 py-3 rounded-xl text-xs font-bold uppercase tracking-widest text-gray-500 hover:bg-gray-50 transition-all"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={() => {
                      localStorage.setItem('uaps_dhl_api_key', dhlApiKey);
                      localStorage.setItem('uaps_fedex_api_key', fedexApiKey);
                      localStorage.setItem('uaps_ups_api_key', upsApiKey);
                      localStorage.setItem('uaps_usps_api_key', uspsApiKey);
                      setView('home');
                    }}
                    className="bg-[#1a365d] text-white px-10 py-3 rounded-xl text-xs font-bold uppercase tracking-widest hover:bg-blue-900 transition-all shadow-lg"
                  >
                    Save Settings
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        ) : null}
      </AnimatePresence>
      <footer className="bg-[#1a365d] text-white py-20 border-t border-white/10">
        <div className="max-w-7xl mx-auto px-8 grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="md:col-span-2">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center p-2">
                <img src="/logo.png" alt="UAPS" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
              </div>
              <div>
                <h4 className="text-xl font-black tracking-tighter leading-none">UAPS</h4>
                <p className="text-[6px] font-bold uppercase tracking-[0.3em] text-[#c5a059]">United Africa Postal Service</p>
              </div>
            </div>
            <p className="text-xs text-blue-100/60 leading-relaxed mb-8 max-w-md">
              The official postal and logistics authority for the African continent, connecting 54 nations to the global trade network through state-of-the-art infrastructure and digital integration.
            </p>
            <div className="flex gap-4">
              <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center hover:bg-white/20 transition-colors cursor-pointer group">
                <Globe className="w-5 h-5 text-white group-hover:scale-110 transition-transform" />
              </div>
              <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center hover:bg-white/20 transition-colors cursor-pointer group">
                <Shield className="w-5 h-5 text-white group-hover:scale-110 transition-transform" />
              </div>
              <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center hover:bg-white/20 transition-colors cursor-pointer group">
                <Activity className="w-5 h-5 text-white group-hover:scale-110 transition-transform" />
              </div>
            </div>
          </div>
          
          <div>
            <h5 className="text-[10px] font-bold text-[#c5a059] uppercase tracking-widest mb-6">Quick Links</h5>
            <ul className="space-y-4 text-xs font-medium text-blue-100/60">
              <li 
                onClick={() => { setView('tracking'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                className="hover:text-white transition-colors cursor-pointer flex items-center gap-2"
              >
                <ChevronRight className="w-3 h-3 text-[#c5a059]" /> Tracking Portal
              </li>
              <li 
                onClick={() => { setView('admin_login'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                className="hover:text-white transition-colors cursor-pointer flex items-center gap-2"
              >
                <ChevronRight className="w-3 h-3 text-[#c5a059]" /> Admin Portal
              </li>
              <li 
                onClick={() => { setView('partner_login'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                className="hover:text-white transition-colors cursor-pointer flex items-center gap-2"
              >
                <ChevronRight className="w-3 h-3 text-[#c5a059]" /> Partner Dashboard
              </li>
              <li 
                onClick={() => { setView('returns'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                className="hover:text-white transition-colors cursor-pointer flex items-center gap-2"
              >
                <ChevronRight className="w-3 h-3 text-[#c5a059]" /> Return Services
              </li>
              <li 
                onClick={() => { setView('home'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                className="hover:text-white transition-colors cursor-pointer flex items-center gap-2"
              >
                <ChevronRight className="w-3 h-3 text-[#c5a059]" /> Global Network
              </li>
              <li 
                onClick={() => {
                  setView('home');
                  setTimeout(() => document.getElementById('how-it-works')?.scrollIntoView({ behavior: 'smooth' }), 100);
                }}
                className="hover:text-white transition-colors cursor-pointer flex items-center gap-2"
              >
                <ChevronRight className="w-3 h-3 text-[#c5a059]" /> How it Works
              </li>
              <li 
                onClick={() => {
                  setView('home');
                  setTimeout(() => document.getElementById('news')?.scrollIntoView({ behavior: 'smooth' }), 100);
                }}
                className="hover:text-white transition-colors cursor-pointer flex items-center gap-2"
              >
                <ChevronRight className="w-3 h-3 text-[#c5a059]" /> News
              </li>
            </ul>
          </div>

          <div>
            <h5 className="text-[10px] font-bold text-[#c5a059] uppercase tracking-widest mb-6">Global HQ</h5>
            <p className="text-xs text-blue-100/60 leading-relaxed mb-6">
              African Union Plaza, Level 12<br />
              Roosevelt St, Addis Ababa<br />
              Federal Democratic Republic of Ethiopia
            </p>
            <div className="space-y-2">
              <p className="text-xs text-blue-100/60 font-bold">contact@uaps.africa</p>
              <p className="text-xs text-blue-100/60 font-bold">+251 11 551 7700</p>
            </div>
          </div>
        </div>
        
        <div className="max-w-7xl mx-auto px-8 mt-20 pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-[10px] text-blue-100/40 font-mono uppercase tracking-widest">
            © 2024 United Africa Postal Service. All Rights Reserved.
          </p>
          <div className="flex gap-8 text-[10px] text-blue-100/40 font-mono uppercase tracking-widest">
            <span className="hover:text-white cursor-pointer transition-colors">Privacy Policy</span>
            <span className="hover:text-white cursor-pointer transition-colors">Terms of Service</span>
            <span className="hover:text-white cursor-pointer transition-colors">Compliance</span>
          </div>
        </div>
      </footer>


      {/* Shipment Detail Modal */}
      <AnimatePresence>
        {selectedOrder && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedOrder(null)}
              className="absolute inset-0 bg-[#1a365d]/40 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-5xl bg-white rounded-[32px] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
            >
              <div className="bg-[#1a365d] p-8 text-white flex justify-between items-center">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <h2 className="text-2xl font-bold">Shipment Details</h2>
                    <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest ${getStatusStyles(selectedOrder.status)}`}>
                      {selectedOrder.status}
                    </span>
                  </div>
                  <p className="text-blue-100/60 text-sm font-mono">{selectedOrder.id}</p>
                </div>
                <button 
                  onClick={() => setSelectedOrder(null)}
                  className="w-10 h-10 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center transition-all"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-8">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <div className="space-y-8">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-gray-50 p-6 rounded-2xl border border-gray-100 col-span-2">
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-3">Courier Information</p>
                        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                          <div className="flex items-center gap-3">
                            <div className="w-12 h-12 bg-white rounded-xl border border-gray-100 flex items-center justify-center p-2 shadow-sm">
                              <img 
                                src={getCarrierLogo(selectedOrder.carrier)!} 
                                alt={selectedOrder.carrier} 
                                className="w-full h-full object-contain"
                                referrerPolicy="no-referrer"
                              />
                            </div>
                            <div>
                              <p className="text-base font-bold text-[#1a365d]">{selectedOrder.courier}</p>
                              <p className="text-[10px] text-gray-400 uppercase font-bold tracking-wider">{selectedOrder.carrier} Logistics Partner</p>
                            </div>
                          </div>
                          <div className="flex flex-wrap gap-3">
                            <a 
                              href={`tel:${selectedOrder.courierPhone}`}
                              className="flex items-center gap-2 bg-white px-4 py-2 rounded-xl border border-gray-100 text-xs font-bold text-[#1a365d] hover:bg-gray-50 transition-colors shadow-sm"
                            >
                              <Phone className="w-3.5 h-3.5 text-blue-500" />
                              {selectedOrder.courierPhone}
                            </a>
                            <a 
                              href={`mailto:${selectedOrder.courierEmail}`}
                              className="flex items-center gap-2 bg-white px-4 py-2 rounded-xl border border-gray-100 text-xs font-bold text-[#1a365d] hover:bg-gray-50 transition-colors shadow-sm"
                            >
                              <Mail className="w-3.5 h-3.5 text-blue-500" />
                              {selectedOrder.courierEmail}
                            </a>
                          </div>
                        </div>
                      </div>
                      <div className="bg-gray-50 p-6 rounded-2xl border border-gray-100">
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Expected Delivery</p>
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-white rounded-xl border border-gray-100 flex items-center justify-center">
                            <Calendar className="w-5 h-5 text-blue-500" />
                          </div>
                          <p className="text-sm font-bold text-[#1a365d]">{selectedOrder.date}</p>
                        </div>
                      </div>
                    </div>

                    <div className="bg-gray-50 p-8 rounded-3xl border border-gray-100">
                      <h3 className="text-sm font-bold text-[#1a365d] uppercase tracking-widest mb-6 flex items-center gap-2">
                        <History className="w-4 h-4" /> Tracking History
                      </h3>
                      <div className="space-y-6 relative before:absolute before:left-[11px] before:top-2 before:bottom-2 before:w-0.5 before:bg-gray-200">
                        {selectedOrder.events.map((event: any, i: number) => (
                          <div key={i} className="flex gap-6 relative">
                            <div className={`w-6 h-6 rounded-full border-4 border-white shadow-sm flex items-center justify-center z-10 ${
                              i === 0 ? 'bg-blue-500' : 'bg-gray-300'
                            }`}>
                              <div className="w-1.5 h-1.5 bg-white rounded-full" />
                            </div>
                            <div className="flex-1">
                              <div className="flex justify-between items-baseline mb-1">
                                <span className="text-[10px] font-bold text-gray-400">
                                  {new Date(event.timestamp).toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}
                                </span>
                                <span className="text-[10px] font-bold text-gray-400 uppercase">{event.location.address.addressLocality}</span>
                              </div>
                              <p className="text-sm text-[#1a365d] font-medium">{event.description}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-gray-50 p-6 rounded-2xl border border-gray-100">
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Weight</p>
                        <p className="text-sm font-bold text-[#1a365d]">{selectedOrder.weight}</p>
                      </div>
                      <div className="bg-gray-50 p-6 rounded-2xl border border-gray-100">
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Dimensions</p>
                        <p className="text-sm font-bold text-[#1a365d]">{selectedOrder.dimensions}</p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-6">
                    <div className="bg-gray-50 rounded-3xl border border-gray-100 overflow-hidden h-full min-h-[400px]">
                      <MapContainer 
                        center={selectedOrder.coordinates[selectedOrder.coordinates.length - 1]} 
                        zoom={4} 
                        style={{ height: '100%', width: '100%' }}
                        scrollWheelZoom={false}
                      >
                        <LayersControl position="topright">
                          <LayersControl.BaseLayer checked name="Standard View">
                            <TileLayer
                              url="https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png"
                              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
                            />
                          </LayersControl.BaseLayer>
                          <LayersControl.BaseLayer name="Satellite View">
                            <TileLayer
                              url="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
                              attribution='&copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community'
                            />
                          </LayersControl.BaseLayer>
                        </LayersControl>
                        {selectedOrder.coordinates.map((coord: [number, number], i: number) => (
                          <Marker key={i} position={coord}>
                            <Popup>
                              <div className="text-xs font-bold text-[#1a365d]">
                                {i === 0 ? 'Origin' : i === selectedOrder.coordinates.length - 1 ? 'Current Location' : 'Transit Point'}
                              </div>
                            </Popup>
                          </Marker>
                        ))}
                        <Polyline 
                          positions={selectedOrder.coordinates} 
                          color="#1a365d" 
                          weight={4} 
                          dashArray="10, 10"
                          opacity={0.7}
                        />
                      </MapContainer>
                    </div>
                  </div>
                </div>

                {/* Shipment Notes Section */}
                <div className="mt-8 bg-gray-50 p-8 rounded-3xl border border-gray-100">
                  <h3 className="text-sm font-bold text-[#1a365d] uppercase tracking-widest mb-6 flex items-center gap-2">
                    <FileText className="w-4 h-4" /> Shipment Notes
                  </h3>
                  <div className="space-y-4 mb-6 max-h-40 overflow-y-auto">
                    {(shipmentNotes[selectedOrder.id] || []).length === 0 ? (
                      <p className="text-sm text-gray-400 italic">No notes added yet.</p>
                    ) : (
                      (shipmentNotes[selectedOrder.id] || []).map(note => (
                        <div key={note.id} className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm">
                          <p className="text-sm text-[#1a365d] mb-2">{note.text}</p>
                          <p className="text-[10px] font-bold text-gray-400 uppercase">
                            {new Date(note.timestamp).toLocaleString()}
                          </p>
                        </div>
                      ))
                    )}
                  </div>
                  <div className="flex gap-3">
                    <input
                      type="text"
                      value={newNoteText}
                      onChange={(e) => setNewNoteText(e.target.value)}
                      placeholder="Add a note..."
                      className="flex-1 px-4 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                      onKeyDown={(e) => e.key === 'Enter' && handleAddNote(selectedOrder.id)}
                    />
                    <button
                      onClick={() => handleAddNote(selectedOrder.id)}
                      disabled={!newNoteText.trim()}
                      className="bg-[#1a365d] text-white px-6 py-3 rounded-xl text-sm font-bold uppercase tracking-widest hover:bg-blue-900 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                    >
                      <Plus className="w-4 h-4" /> Add
                    </button>
                  </div>
                </div>
              </div>

              <div className="p-8 bg-gray-50 border-t border-gray-100 flex justify-end">
                <button 
                  onClick={() => setSelectedOrder(null)}
                  className="bg-[#1a365d] text-white px-10 py-3 rounded-xl text-xs font-bold uppercase tracking-widest hover:bg-blue-900 transition-all shadow-lg"
                >
                  Close Details
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Floating Architecture Button (Keeping from previous version) */}
      <button
        onClick={() => setShowArchitecture(true)}
        className="fixed bottom-6 right-6 bg-[#1a365d] text-white p-4 rounded-full shadow-2xl hover:scale-110 transition-transform z-40 border border-white/20"
        title="System Architecture"
      >
        <Settings className="w-6 h-6" />
      </button>

      {/* Architecture Modal (Keeping from previous version) */}
      <AnimatePresence>
        {showArchitecture && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] flex items-center justify-center p-4 md:p-8 bg-[#1a365d]/90 backdrop-blur-sm"
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="bg-[#f4f7f9] w-full max-w-6xl h-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden rounded-xl border border-white/20"
            >
              <div className="bg-[#1a365d] text-white p-6 flex justify-between items-center border-b border-white/10">
                <div className="flex items-center gap-4">
                  <div className="bg-white/10 p-2 rounded">
                    <Cpu className="w-6 h-6" />
                  </div>
                  <div>
                    <h2 className="text-xl font-bold uppercase tracking-tighter">UAPS Reference Architecture</h2>
                    <p className="text-[10px] font-mono opacity-50 uppercase tracking-widest">Enterprise Logistics Blueprint v2.5</p>
                  </div>
                </div>
                <button 
                  onClick={() => setShowArchitecture(false)}
                  className="p-2 hover:bg-white/10 rounded-full transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-8 space-y-12">
                {/* Reference Architecture Flow */}
                <div className="bg-white border border-gray-200 p-8 rounded-xl shadow-sm">
                  <h3 className="font-serif italic text-xl mb-12 border-b border-gray-100 pb-4 text-center uppercase tracking-widest text-[#1a365d]">Integrated System Architecture</h3>
                  
                  <div className="flex flex-col items-center space-y-8">
                    {/* External Partners */}
                    <div className="w-full">
                      <div className="text-[10px] uppercase font-mono text-center mb-4 opacity-50 tracking-[0.3em]">External Partners & APIs</div>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="bg-gray-50 border border-gray-200 p-4 text-center rounded">
                          <div className="text-[10px] font-bold uppercase mb-1">USA / Global Carriers</div>
                          <div className="text-[9px] opacity-60 uppercase">UPS, FedEx, DHL, USPS</div>
                        </div>
                        <div className="bg-gray-50 border border-gray-200 p-4 text-center rounded">
                          <div className="text-[10px] font-bold uppercase mb-1">Customs Systems</div>
                          <div className="text-[9px] opacity-60 uppercase">ASYCUDA / WCO</div>
                        </div>
                        <div className="bg-gray-50 border border-gray-200 p-4 text-center rounded">
                          <div className="text-[10px] font-bold uppercase mb-1">Regional Postal APIs</div>
                          <div className="text-[9px] opacity-60 uppercase">GCC / Regional Hubs</div>
                        </div>
                      </div>
                    </div>

                    <ChevronRight className="w-6 h-6 rotate-90 opacity-20" />

                    {/* Integration Layer */}
                    <div className="w-full bg-[#1a365d] text-white p-4 text-center rounded shadow-lg">
                      <div className="text-xs font-bold uppercase tracking-[0.2em]">Integration Layer</div>
                      <div className="text-[10px] opacity-50 uppercase mt-1">API Gateway & Middleware (MuleSoft / Boomi)</div>
                    </div>

                    <ChevronRight className="w-6 h-6 rotate-90 opacity-20" />

                    {/* Core Systems */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full">
                      <div className="bg-white border border-gray-200 p-4 rounded shadow-sm">
                        <div className="text-[10px] font-bold uppercase border-b border-gray-100 pb-2 mb-3 text-[#1a365d]">Logistics Mgmt (TMS)</div>
                        <ul className="text-[9px] uppercase space-y-2 opacity-70">
                          <li>• Route Optimization</li>
                          <li>• Hub & SLA Management</li>
                          <li>• Capacity Planning</li>
                        </ul>
                      </div>
                      <div className="bg-white border border-gray-200 p-4 rounded shadow-sm">
                        <div className="text-[10px] font-bold uppercase border-b border-gray-100 pb-2 mb-3 text-[#1a365d]">Postal Operations (IPS)</div>
                        <ul className="text-[9px] uppercase space-y-2 opacity-70">
                          <li>• Mail & Parcel Processing</li>
                          <li>• Terminal Dues Settlement</li>
                          <li>• UPU Compliance</li>
                        </ul>
                      </div>
                      <div className="bg-white border border-gray-200 p-4 rounded shadow-sm">
                        <div className="text-[10px] font-bold uppercase border-b border-gray-100 pb-2 mb-3 text-[#1a365d]">Customs & Compliance</div>
                        <ul className="text-[9px] uppercase space-y-2 opacity-70">
                          <li>• Pre-Arrival Data</li>
                          <li>• Risk Assessment</li>
                          <li>• Clearance Processing</li>
                        </ul>
                      </div>
                    </div>

                    <ChevronRight className="w-6 h-6 rotate-90 opacity-20" />

                    {/* Visibility Engine */}
                    <div className="w-full max-w-md bg-[#2c5282] text-white p-3 text-center rounded">
                      <div className="text-[10px] font-bold uppercase tracking-widest">Tracking & Visibility Engine</div>
                    </div>

                    <ChevronRight className="w-6 h-6 rotate-90 opacity-20" />

                    {/* Portals */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full max-w-2xl">
                      <div className="bg-white border border-gray-200 p-4 rounded shadow-sm">
                        <div className="text-[10px] font-bold uppercase border-b border-gray-100 pb-2 mb-3 text-center text-[#1a365d]">Customer Portal</div>
                        <ul className="text-[9px] uppercase space-y-2 opacity-70 text-center">
                          <li>Shipment Tracking</li>
                          <li>Rate Calculator</li>
                          <li>Customer Support</li>
                        </ul>
                      </div>
                      <div className="bg-white border border-gray-200 p-4 rounded shadow-sm">
                        <div className="text-[10px] font-bold uppercase border-b border-gray-100 pb-2 mb-3 text-center text-[#1a365d]">Financial & ERP System</div>
                        <ul className="text-[9px] uppercase space-y-2 opacity-70 text-center">
                          <li>Billing & Settlement</li>
                          <li>Financial Reporting</li>
                          <li>Audit & Analytics</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Detailed Stack Components */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[
                    {
                      title: "1. Core Logistics (TMS)",
                      icon: Truck,
                      options: ["Oracle Transportation Mgmt (OTM)", "SAP TM"],
                      why: "Handles route planning, hub-to-hub handoffs, and global capacity management."
                    },
                    {
                      title: "2. Postal Operations (IPS)",
                      icon: Globe,
                      options: ["UPU-Compatible IPS Software", "Solystic / Beumer / SITA"],
                      why: "Ensures postal interoperability, terminal dues, and government mail compliance."
                    },
                    {
                      title: "3. Customs & Compliance",
                      icon: Shield,
                      options: ["ASYCUDA (WCO Data Model)", "Customs Integration Layer"],
                      why: "Prevents clearance bottlenecks with pre-arrival data and risk scoring."
                    },
                    {
                      title: "4. Integration Layer",
                      icon: Layers,
                      options: ["MuleSoft", "Boomi"],
                      why: "API Gateway for clean separation between carriers and UAPS core systems."
                    },
                    {
                      title: "5. Financials & Audit",
                      icon: BarChart3,
                      options: ["Oracle Financials", "SAP S/4HANA"],
                      why: "Covers interline settlements, government reporting, and PPP transparency."
                    },
                    {
                      title: "6. Tracking & Portal",
                      icon: Search,
                      options: ["React / Next.js (Frontend)", "Node.js / Spring Boot (Backend)"],
                      why: "Normalizes tracking across all carriers to build trust for diaspora and governments."
                    }
                  ].map((block, i) => (
                    <div key={i} className="bg-white border border-gray-200 p-6 rounded-xl shadow-sm flex flex-col">
                      <div className="flex items-center gap-3 mb-4">
                        <div className="bg-[#1a365d] text-white p-2 rounded">
                          <block.icon className="w-4 h-4" />
                        </div>
                        <h4 className="font-bold uppercase text-xs tracking-widest text-[#1a365d]">{block.title}</h4>
                      </div>
                      <div className="space-y-3 flex-1">
                        <div className="space-y-1">
                          <span className="text-[9px] uppercase opacity-50 font-mono">Primary Options</span>
                          <ul className="space-y-1">
                            {block.options.map((opt, j) => (
                              <li key={j} className="text-xs font-bold uppercase flex items-center gap-2">
                                <div className="w-1 h-1 bg-[#1a365d]" /> {opt}
                              </li>
                            ))}
                          </ul>
                        </div>
                        <div className="pt-3 border-t border-gray-100">
                          <span className="text-[9px] uppercase opacity-50 font-mono">Strategic Value</span>
                          <p className="text-[11px] leading-tight mt-1 italic text-gray-600">{block.why}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Practical Deployment Roadmap */}
                <div className="bg-white border border-gray-200 p-8 rounded-xl shadow-sm">
                  <h3 className="font-serif italic text-xl mb-8 border-b border-gray-100 pb-4 text-[#1a365d]">Practical Deployment Roadmap</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {[
                      {
                        phase: "Phase 1: Pilot Corridors",
                        items: [
                          "WordPress + Custom tracking portal",
                          "Manual/CSV imports + limited APIs",
                          "Lightweight TMS implementation"
                        ],
                        status: "Current / Immediate"
                      },
                      {
                        phase: "Phase 2: Scale",
                        items: [
                          "Full TMS + IPS integration",
                          "Carrier API live connections",
                          "Customs pre-clearance automation"
                        ],
                        status: "6-12 Months"
                      },
                      {
                        phase: "Phase 3: Maturity",
                        items: [
                          "Full ERP & Financial integration",
                          "Advanced analytics & SLA enforcement",
                          "Government & Partner dashboards"
                        ],
                        status: "18+ Months"
                      }
                    ].map((p, i) => (
                      <div key={i} className="space-y-4">
                        <div className="flex justify-between items-start">
                          <h4 className="font-bold uppercase text-xs tracking-widest max-w-[150px] text-[#1a365d]">{p.phase}</h4>
                          <span className="text-[9px] font-mono bg-[#1a365d] text-white px-2 py-0.5 rounded">{p.status}</span>
                        </div>
                        <ul className="space-y-2">
                          {p.items.map((item, j) => (
                            <li key={j} className="text-xs flex items-start gap-2 text-gray-600">
                              <CheckCircle2 className="w-3 h-3 mt-0.5 text-green-600" />
                              <span>{item}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Final Recommendation */}
                <div className="bg-[#1a365d] text-white p-8 rounded-xl shadow-xl">
                  <h3 className="font-serif italic text-2xl mb-6">Final Recommendation</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-4">
                      <p className="text-sm font-medium leading-relaxed opacity-90">
                        If UAPS had to choose today, this is the definitive stack for a serious pan-African postal authority—credible to governments, acceptable to carriers, and trusted by the public.
                      </p>
                      <div className="bg-white/10 p-4 border-l-4 border-white/30 rounded">
                        <p className="text-xs italic opacity-70">
                          "This architecture ensures UAPS remains government- and carrier-compatible while avoiding startup fragility."
                        </p>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 gap-3">
                      {[
                        { label: "Enterprise Backbone", value: "SAP or Oracle" },
                        { label: "Postal Interoperability", value: "UPU-compatible IPS" },
                        { label: "Tracking & Trust", value: "Custom-built Portal" },
                        { label: "Integration Layer", value: "MuleSoft / Boomi" },
                        { label: "Customs Compliance", value: "ASYCUDA" },
                        { label: "Public Interface", value: "WordPress + React Tracking" }
                      ].map((rec, i) => (
                        <div key={i} className="flex justify-between items-center border-b border-white/10 pb-2">
                          <span className="text-[10px] uppercase font-mono opacity-50">{rec.label}</span>
                          <span className="text-xs font-bold uppercase tracking-tighter">{rec.value}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Governance & Security */}
                <div className="bg-[#2c5282] text-white p-8 rounded-xl">
                  <div className="flex items-center gap-4 mb-8">
                    <Shield className="w-8 h-8" />
                    <div>
                      <h3 className="text-xl font-bold uppercase tracking-tighter">Governance, Risk & Security</h3>
                      <p className="text-xs font-mono opacity-50 uppercase">Government-Grade Protection Standards</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                    <div className="space-y-4">
                      <h4 className="text-xs font-bold uppercase tracking-widest border-b border-white/20 pb-2">Identity & Access</h4>
                      <ul className="space-y-2 text-xs opacity-80">
                        <li className="flex items-center gap-2"><ChevronRight className="w-3 h-3" /> Role-based access (Public / Ops / Government)</li>
                        <li className="flex items-center gap-2"><ChevronRight className="w-3 h-3" /> Multi-factor authentication (MFA)</li>
                        <li className="flex items-center gap-2"><ChevronRight className="w-3 h-3" /> Zero-trust network architecture</li>
                      </ul>
                    </div>
                    <div className="space-y-4">
                      <h4 className="text-xs font-bold uppercase tracking-widest border-b border-white/20 pb-2">Security & Audit</h4>
                      <ul className="space-y-2 text-xs opacity-80">
                        <li className="flex items-center gap-2"><ChevronRight className="w-3 h-3" /> ISO 27001-aligned event logging</li>
                        <li className="flex items-center gap-2"><ChevronRight className="w-3 h-3" /> Government-grade data retention policies</li>
                        <li className="flex items-center gap-2"><ChevronRight className="w-3 h-3" /> Real-time incident reporting dashboards</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-[#1a365d] text-white/40 text-[10px] font-mono uppercase tracking-[0.2em] text-center border-t border-white/10">
                UAPS Technical Specification v2.5 // Confidential & Proprietary
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
      <AssistantChat />
    </div>
  );
}
