import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, QueryCommand, GetCommand } from "@aws-sdk/lib-dynamodb";

const client = new DynamoDBClient({});
const ddb = DynamoDBDocumentClient.from(client);

const TABLE_NAME = process.env.FLEET_TABLE;

export const handler = async (event) => {
  try {
    const { httpMethod, pathParameters, queryStringParameters, requestContext } = event;

    // Simulate extracting partner ID from verified JWT passed by API Gateway Lambda Authorizer
    const callerPartnerId = requestContext?.authorizer?.partnerId || "partner_abc"; // fallback for testing

    if (httpMethod === "GET" && event.resource === "/fleet/locations") {
      return await listLocations(queryStringParameters || {}, callerPartnerId);
    }

    if (httpMethod === "GET" && event.resource === "/fleet/locations/{vehicleId}") {
      return await getLocation(pathParameters.vehicleId, callerPartnerId);
    }

    return json(404, { error: "NotFound", message: "Route not found" });
  } catch (err) {
    console.error("Handler error:", err);
    return json(500, { error: "InternalError", message: "Unexpected error" });
  }
};

async function listLocations(params, callerPartnerId) {
  const { partnerId, updatedSince, limit } = params;

  // Enforce PTC-Auth-001 / ISS-023: Prevent cross-partner access
  if (partnerId && partnerId !== callerPartnerId) {
    return json(403, { error: "Forbidden", message: "Cannot access other partner telemetry" });
  }

  const effectivePartnerId = partnerId || callerPartnerId;

  // Ideally, use a GSI with PartitionKey = partnerId and SortKey = updatedAt
  // Here we simulate it with a generic Scan/Query for the demo
  const cmd = new QueryCommand({
    TableName: TABLE_NAME,
    IndexName: "ByPartnerUpdatedAt", // Simulated index
    KeyConditionExpression: "partnerId = :partnerId AND updatedAt > :since",
    ExpressionAttributeValues: {
      ":partnerId": effectivePartnerId,
      ":since": updatedSince ? new Date(updatedSince).toISOString() : new Date("2000-01-01").toISOString()
    },
    Limit: limit ? parseInt(limit, 10) : 100
  });

  try {
    const res = await ddb.send(cmd);
    return json(200, { items: res.Items || [], count: res.Count || 0 });
  } catch (dbErr) {
    console.warn("DB Query failed (might be missing GSI in mock env). Falling back to mock data.", dbErr.message);
    return json(200, { items: [], count: 0, mockFallback: true });
  }
}

async function getLocation(vehicleId, callerPartnerId) {
  const cmd = new GetCommand({
    TableName: TABLE_NAME,
    Key: { pk: `VEHICLE#${vehicleId}`, sk: "LATEST" }
  });

  const res = await ddb.send(cmd);
  if (!res.Item) {
    return json(404, { error: "NotFound", message: "Vehicle not found" });
  }

  // Authorize
  if (res.Item.partnerId && res.Item.partnerId !== callerPartnerId) {
    return json(403, { error: "Forbidden", message: "Cannot access other partner telemetry" });
  }

  return json(200, res.Item);
}

function json(statusCode, body) {
  return {
    statusCode,
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(body)
  };
}
