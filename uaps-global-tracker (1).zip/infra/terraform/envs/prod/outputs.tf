output "k8s_cluster_endpoint" {
  value = module.k8s_cluster.cluster_endpoint
}

output "rds_endpoint" {
  value = module.rds.db_instance_endpoint
}

output "s3_bucket_name" {
  value = module.s3_evidence.bucket_name
}
