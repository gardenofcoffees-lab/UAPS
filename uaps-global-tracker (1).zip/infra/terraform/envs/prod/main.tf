# Production Environment Main Configuration

terraform {
  required_version = ">= 1.0.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 4.0"
    }
  }
}

provider "aws" {
  region = var.region
}

module "network" {
  source = "../../modules/network"
  env    = "prod"
}

module "iam" {
  source = "../../modules/iam"
  env    = "prod"
}

module "k8s_cluster" {
  source     = "../../modules/k8s-cluster"
  env        = "prod"
  vpc_id     = module.network.vpc_id
  subnet_ids = module.network.private_subnets
}

module "rds" {
  source     = "../../modules/rds"
  env        = "prod"
  vpc_id     = module.network.vpc_id
  subnet_ids = module.network.database_subnets
}

module "s3_evidence" {
  source = "../../modules/s3-evidence"
  env    = "prod"
}

module "kafka" {
  source     = "../../modules/mska-or-kafka"
  env        = "prod"
  vpc_id     = module.network.vpc_id
  subnet_ids = module.network.private_subnets
}
