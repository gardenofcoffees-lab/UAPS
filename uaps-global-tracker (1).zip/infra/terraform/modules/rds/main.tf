# RDS Module
variable "env" { type = string }
variable "vpc_id" { type = string }
variable "subnet_ids" { type = list(string) }
output "db_instance_endpoint" { value = "placeholder-rds-endpoint" }
