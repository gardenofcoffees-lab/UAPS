# K8s Cluster Module
variable "env" { type = string }
variable "vpc_id" { type = string }
variable "subnet_ids" { type = list(string) }
output "cluster_endpoint" { value = "https://placeholder-eks-endpoint" }
