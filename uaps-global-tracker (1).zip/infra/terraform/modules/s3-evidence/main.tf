# S3 Evidence Module
variable "env" { type = string }
output "bucket_name" { value = "uaps-evidence-${var.env}" }
