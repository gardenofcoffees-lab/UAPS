# Network Module
resource "aws_vpc" "main" {
  cidr_block = "10.0.0.0/16"
  tags = {
    Name = "uaps-vpc-${var.env}"
  }
}

variable "env" { type = string }
output "vpc_id" { value = aws_vpc.main.id }
output "private_subnets" { value = [] } # Placeholder
output "database_subnets" { value = [] } # Placeholder
