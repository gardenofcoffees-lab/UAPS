provider "aws" {
  region = "us-east-1"
}

resource "aws_iam_role" "lambda_role" {
  name = "fleet-lambda-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17",
    Statement = [{
      Action    = "sts:AssumeRole",
      Effect    = "Allow",
      Principal = { Service = "lambda.amazonaws.com" }
    }]
  })
}

resource "aws_iam_role_policy_attachment" "lambda_basic" {
  role       = aws_iam_role.lambda_role.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
}

resource "aws_lambda_function" "fleet_api" {
  function_name = "fleet-locations-api"
  role          = aws_iam_role.lambda_role.arn
  handler       = "index.handler"
  runtime       = "nodejs20.x"
  filename      = "build/fleet-api.zip"

  environment {
    variables = {
      FLEET_TABLE = "fleet_locations"
    }
  }
}

resource "aws_apigateway_rest_api" "fleet" {
  name        = "fleet-api"
  description = "Fleet locations API"
}

resource "aws_apigateway_resource" "fleet_locations" {
  rest_api_id = aws_apigateway_rest_api.fleet.id
  parent_id   = aws_apigateway_rest_api.fleet.root_resource_id
  path_part   = "fleet"
}

resource "aws_apigateway_resource" "fleet_locations_sub" {
  rest_api_id = aws_apigateway_rest_api.fleet.id
  parent_id   = aws_apigateway_resource.fleet_locations.id
  path_part   = "locations"
}

resource "aws_apigateway_method" "get_locations" {
  rest_api_id   = aws_apigateway_rest_api.fleet.id
  resource_id   = aws_apigateway_resource.fleet_locations_sub.id
  http_method   = "GET"
  authorization = "NONE"
}

resource "aws_apigateway_integration" "get_locations_integration" {
  rest_api_id             = aws_apigateway_rest_api.fleet.id
  resource_id             = aws_apigateway_resource.fleet_locations_sub.id
  http_method             = aws_apigateway_method.get_locations.http_method
  integration_http_method = "POST"
  type                    = "AWS_PROXY"
  uri                     = aws_lambda_function.fleet_api.invoke_arn
}

resource "aws_lambda_permission" "apigw_invoke" {
  statement_id  = "AllowAPIGatewayInvoke"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.fleet_api.function_name
  principal     = "apigateway.amazonaws.com"
  source_arn    = "${aws_apigateway_rest_api.fleet.execution_arn}/*/*"
}

resource "aws_apigateway_deployment" "fleet_deploy" {
  rest_api_id = aws_apigateway_rest_api.fleet.id
  stage_name  = "prod"

  depends_on = [
    aws_apigateway_integration.get_locations_integration
  ]
}
