# WebSocket Live Tracking Protocol

The live-tracking WebSocket API utilizes a structured JSON protocol over WebSocket for real-time location updates. Subscriptions support spatial bounding boxes, mode filters, and partner tenancy rules.

## Client -> Server Messages

### 1. Subscribe Request
Requests continuous location updates for a combination of vehicles, modes, or regions.
```json
{
  "type": "subscribe",
  "subscriptionId": "sub-001",
  "filters": {
    "partnerId": "partner_abc",
    "modes": ["truck", "moto"],
    "vehicleIds": ["veh_123", "veh_456"],
    "bbox": {
      "minLat": -2.0,
      "minLng": 36.0,
      "maxLat": 0.0,
      "maxLng": 38.0
    }
  }
}
```

### 2. Unsubscribe Request
Terminates an existing active subscription.
```json
{
  "type": "unsubscribe",
  "subscriptionId": "sub-001"
}
```

### 3. Ping
Keep-alive heartbeat initiated by the client.
```json
{
  "type": "ping",
  "timestamp": "2026-04-16T15:00:00Z"
}
```

## Server -> Client Messages

### 1. Subscribe Acknowledgment
Confirmed subscription stream setup.
```json
{
  "type": "subscribed",
  "subscriptionId": "sub-001"
}
```

### 2. Unsubscribe Acknowledgment
Confirmed teardown of the requested subscription.
```json
{
  "type": "unsubscribed",
  "subscriptionId": "sub-001"
}
```

### 3. Location Update (Stream)
Near-real-time push of vehicle telemetry adhering to the subscription filters.
```json
{
  "type": "locationUpdate",
  "subscriptionId": "sub-001",
  "items": [
    {
      "id": "veh_123",
      "partnerId": "partner_abc",
      "mode": "truck",
      "lat": -1.2921,
      "lng": 36.8219,
      "heading": 90,
      "speedKph": 42,
      "updatedAt": "2026-04-16T15:01:00Z"
    }
  ]
}
```

### 4. Subscription/System Error
Delivered asynchronously if a subscription fails constraint checks (e.g. scoping bounds out of user's permissions, unsupported values).
```json
{
  "type": "error",
  "subscriptionId": "sub-001",
  "error": "Forbidden",
  "message": "You are not allowed to subscribe to partner_xyz",
  "correlationId": "c9f9b4b0-9c3a-4a1e-8f3a-2b8f0c1d1234"
}
```

### 5. Pong
Server response to client keep-alive heartbeats.
```json
{
  "type": "pong",
  "timestamp": "2026-04-16T15:00:01Z"
}
```
