# Partner Integration Lifecycle

**Partner → Portal → Integration → Certification → Go‑Live**

1. **Registration**
   - Partner submits legal + business details

2. **Credential Issuance**
   - JWT + API key issued after identity verification

3. **Technical Integration**
   - Partner implements REST + WebSocket
   - Access to sandbox + mock server

4. **Self‑Test Harness**
   - Partner runs automated tests
   - Uploads evidence

5. **Certification Testing**
   - Platform runs full suite
   - Issues logged + remediated

6. **Operational Readiness**
   - NOC contacts
   - IR plan
   - SLA acceptance

7. **Certification Decision**
   - Certified / Conditional / Failed

8. **Production Onboarding**
   - API keys promoted
   - Monitoring enabled
   - Partner added to routing engine
