# API Gateway & Backend Routing Architecture

```text
+-----------------------------+
                    |        Frontend / Apps      |
                    |  (Web, Mobile, Partner UI)  |
                    +--------------+--------------+
                                   |
                                   v
                        HTTPS (REST/HTTP API)
                                   |
                    +--------------+--------------+
                    |         Amazon API Gateway  |
                    |  - Auth (JWT/IAM/API Key)   |
                    |  - Throttling & WAF         |
                    |  - Request/Response Maps    |
                    +--------------+--------------+
                                   |
             +---------------------+----------------------+
             |                    |                      |
             v                    v                      v
   +----------------+   +--------------------+   +--------------------+
   | AWS Lambda     |   |  VPC Link          |   |  Direct HTTP       |
   | (Fleet Read)   |   |  (ECS/EKS/Micro)   |   |  Backend (SaaS)    |
   +--------+-------+   +---------+----------+   +---------+----------+
            |                         |                      |
            v                         v                      v
   +----------------+        +----------------+      +----------------+
   | DynamoDB       |        | Internal APIs  |      | External APIs  |
   | fleet_locations|        | (REST/GRPC)    |      | (3P providers) |
   +----------------+        +----------------+      +----------------+

                    +-----------------------------+
                    |   Observability & Control   |
                    |  - CloudWatch Logs & Metrics|
                    |  - X-Ray Traces            |
                    |  - Alarms & Dashboards     |
                    +-----------------------------+
```
