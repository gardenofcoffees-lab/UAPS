# Fleet API Interaction Examples

This document outlines standard HTTP REST and WebSocket API interaction flows for the Fleet API.

## REST Examples

### Authentication (REST)
Pass the IDP JWT or an API Key.
```http
GET /fleet/locations HTTP/1.1
Host: api.example.com
Authorization: Bearer <JWT>
X-API-Key: <optional-api-key>
```

### Retrieving a List with Filters & Pagination
```http
GET /fleet/locations?mode=truck&limit=100 HTTP/1.1
Host: api.example.com
Authorization: Bearer <JWT>
```
**Response:**
```json
{
  "items": [
    {
      "id": "veh_123",
      "partnerId": "partner_abc",
      "mode": "truck",
      "lat": -1.2921,
      "lng": 36.8219,
      "heading": 90,
      "speedKph": 42,
      "updatedAt": "2026-04-16T15:01:00Z"
    }
  ],
  "count": 1,
  "nextCursor": null
}
```

If `nextCursor` contains a token, you can fetch the next page like so:
```http
GET /fleet/locations?cursor=<nextCursor>&limit=100
```

### Specific Vehicle Location
```http
GET /fleet/locations/veh_123 HTTP/1.1
Host: api.example.com
Authorization: Bearer <JWT>
```

### REST Error Payload Format
```json
{
  "error": "Forbidden",
  "message": "You are not allowed to access this resource",
  "status": 403,
  "correlationId": "c9f9b4b0-9c3a-4a1e-8f3a-2b8f0c1d1234"
}
```

---

## WebSocket Examples

### Connecting
For WebSocket upgrades, the JWT can be provided via a query parameter (frequently needed when standard headers cannot be injected before the upgrade request).
```http
wss://ws.example.com/fleet/locations/live?token=<JWT>
```

### Live Stream Lifecycle

**1. Subscribe** (Client ➔ Server)
```json
{
  "type": "subscribe",
  "subscriptionId": "sub-001",
  "filters": {
    "modes": ["truck", "moto"]
  }
}
```

**2. Subscribe Acknowledged** (Server ➔ Client)
```json
{
  "type": "subscribed",
  "subscriptionId": "sub-001"
}
```

**3. Stream Push** (Server ➔ Client)
```json
{
  "type": "locationUpdate",
  "subscriptionId": "sub-001",
  "items": [
    {
      "id": "veh_123",
      "partnerId": "partner_abc",
      "mode": "truck",
      "lat": -1.2921,
      "lng": 36.8219,
      "heading": 90,
      "speedKph": 42,
      "updatedAt": "2026-04-16T15:01:00Z"
    }
  ]
}
```

**4. Unsubscribe** (Client ➔ Server)
```json
{
  "type": "unsubscribe",
  "subscriptionId": "sub-001"
}
```

### WebSocket Error Payload Format
```json
{
  "type": "error",
  "subscriptionId": "sub-001",
  "error": "Forbidden",
  "message": "You are not allowed to subscribe to this partner",
  "correlationId": "c9f9b4b0-9c3a-4a1e-8f3a-2b8f0c1d1234"
}
```
