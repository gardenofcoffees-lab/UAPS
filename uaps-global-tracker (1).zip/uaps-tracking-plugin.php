<?php
/**
 * Plugin Name: UAPS Tracking Integration
 * Description: Securely store DHL API Key and integrate UAPS tracking into WordPress.
 * Version: 1.0.0
 * Author: UAPS
 */

if (!defined('ABSPATH')) {
    exit;
}

class UAPS_Tracking_Plugin {

    public function __construct() {
        add_action('admin_menu', array($this, 'add_settings_page'));
        add_action('admin_init', array($this, 'register_settings'));
        add_shortcode('uaps_tracking', array($this, 'render_tracking_shortcode'));
    }

    public function add_settings_page() {
        add_menu_page(
            'UAPS Settings',
            'UAPS Tracking',
            'manage_options',
            'uaps-settings',
            array($this, 'render_settings_page'),
            'dashicons-location-alt'
        );
    }

    public function register_settings() {
        register_setting('uaps_settings_group', 'uaps_dhl_api_key', array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => '',
        ));
        register_setting('uaps_settings_group', 'uaps_fedex_api_key', array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => '',
        ));
        register_setting('uaps_settings_group', 'uaps_ups_api_key', array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => '',
        ));
        register_setting('uaps_settings_group', 'uaps_usps_api_key', array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => '',
        ));
    }

    public function render_settings_page() {
        ?>
        <div class="wrap">
            <h1>UAPS Tracking Settings</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('uaps_settings_group');
                do_settings_sections('uaps-settings');
                ?>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row">DHL API Key</th>
                        <td>
                            <input type="password" name="uaps_dhl_api_key" value="<?php echo esc_attr(get_option('uaps_dhl_api_key')); ?>" class="regular-text" />
                            <p class="description">Enter your DHL API Key for secure tracking requests.</p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">FedEx API Key</th>
                        <td>
                            <input type="password" name="uaps_fedex_api_key" value="<?php echo esc_attr(get_option('uaps_fedex_api_key')); ?>" class="regular-text" />
                            <p class="description">Enter your FedEx API Key for secure tracking requests.</p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">UPS API Key</th>
                        <td>
                            <input type="password" name="uaps_ups_api_key" value="<?php echo esc_attr(get_option('uaps_ups_api_key')); ?>" class="regular-text" />
                            <p class="description">Enter your UPS API Key for secure tracking requests.</p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">USPS API Key</th>
                        <td>
                            <input type="password" name="uaps_usps_api_key" value="<?php echo esc_attr(get_option('uaps_usps_api_key')); ?>" class="regular-text" />
                            <p class="description">Enter your USPS API Key for secure tracking requests.</p>
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }

    public function render_tracking_shortcode($atts) {
        $dhl_key = get_option('uaps_dhl_api_key');
        $fedex_key = get_option('uaps_fedex_api_key');
        $ups_key = get_option('uaps_ups_api_key');
        $usps_key = get_option('uaps_usps_api_key');
        $app_url = "https://ais-dev-x2u3jmaswoilfspjwtzbgj-565249142813.us-east1.run.app"; // Dynamic URL would be better
        
        ob_start();
        ?>
        <div id="uaps-tracking-container" style="width: 100%; height: 800px; border: none; overflow: hidden; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.1);">
            <iframe 
                src="<?php echo esc_url($app_url); ?>?dhl_key=<?php echo esc_attr($dhl_key); ?>&fedex_key=<?php echo esc_attr($fedex_key); ?>&ups_key=<?php echo esc_attr($ups_key); ?>&usps_key=<?php echo esc_attr($usps_key); ?>" 
                width="100%" 
                height="100%" 
                style="border: none;"
                allow="geolocation"
            ></iframe>
        </div>
        <?php
        return ob_get_clean();
    }
}

new UAPS_Tracking_Plugin();
