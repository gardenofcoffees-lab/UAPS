import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import webpush from "web-push";
import http from "http";
import { WebSocketServer, WebSocket } from "ws";
import multer from "multer";
import fs from "fs";
import crypto from "crypto";
import * as grpc from "@grpc/grpc-js";
import * as protoLoader from "@grpc/proto-loader";
import { GoogleGenAI } from "@google/genai";

type Stop = {
  id: string;
  lat: number;
  lng: number;
  label: string;
  priority?: "high" | "normal";
};

type OptimizeRequest = {
  start: { lat: number; lng: number };
  stops: Stop[];
  vehicle: "bike" | "car" | "van";
  city: string;
};

function haversine(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
  const R = 6371;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const la1 = (a.lat * Math.PI) / 180;
  const la2 = (b.lat * Math.PI) / 180;
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(la1) * Math.cos(la2) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

// simple nearest‑neighbor TSP
function tspNearestNeighbor(start: { lat: number; lng: number }, stops: Stop[]) {
  const remaining = [...stops];
  const route: Stop[] = [];
  let current = { ...start, id: "start" };

  while (remaining.length) {
    let bestIdx = 0;
    let bestDist = Infinity;
    remaining.forEach((s, i) => {
      const d = haversine(current, s);
      if (d < bestDist) {
        bestDist = d;
        bestIdx = i;
      }
    });
    const next = remaining.splice(bestIdx, 1)[0];
    route.push(next);
    current = next;
  }

  return route;
}

type DeliveryStatus =
  | "NEW"
  | "ACCEPTED"
  | "PICKED_UP"
  | "IN_TRANSIT"
  | "DELIVERED"
  | "FAILED_SECURITY_EVENT";

interface Delivery {
  id: string;
  pickupAddress: string;
  dropoffAddress: string;
  senderName?: string;
  senderPhone?: string;
  receiverName?: string;
  receiverPhone?: string;
  status: string;
  courierId?: string;
  batchId?: string;
  dimensions?: string;
  weight?: string;
  handlingInstructions?: string;
  shipment_options?: {
    delivery_mode?: string;
    speed: string;
    delivery_window?: {
      start: string;
      end: string;
    };
    handling: string[];
    dropoff_mode: string;
    privacy_mode: string;
    sla_tier: string;
  };
  routing_constraints?: {
    fragile_handling?: string;
    delivery_window?: string;
    [key: string]: any;
  };
  risk_scores?: any;
  model_outputs?: any;
  routing_decision?: any;
  routing_weights?: {
    w_t: number;
    w_r: number;
    w_b: number;
    w_w: number;
    w_s: number;
  };
  mode_execution?: {
    actual_mode: string;
    handoff_point: any;
  };
  route_summary?: {
    distance_m: number;
    eta: string;
  };
  mode_rationale?: {
    reason: string;
    alternatives_considered: string[];
    final_score: number;
  };
  handoff_details?: {
    location: { lat: number; lon: number };
    timestamp: string;
  };
  ground_robot_route?: {
    route_id: string;
    robot_id: string;
    start: any;
    end: any;
    waypoints: any[];
    constraints: any;
    execution_telemetry: any;
  };
  dropoff_location?: {
    lat: number;
    lon: number;
    locker_id?: string;
  };
  summary?: any;
  createdAt: string;
  proofOfDelivery?: {
    signature?: string;
    photo?: string;
    timestamp: string;
  };
}

interface Batch {
  id: string;
  courierId: string;
  deliveryIds: string[];
}

let couriers: Record<string, Courier> = {
  "courier-123": {
    id: "courier-123",
    name: "Leslie Alexander",
    vehicle: "van",
    verified: true
  }
};

let batches: Record<string, Batch> = {};

interface CourierLocation {
  courierId: string;
  lat: number;
  lng: number;
  timestamp: string;
}

let deliveries: Delivery[] = [
  {
    id: "UAPS-KE-2026-12345678",
    pickupAddress: "Mombasa, Kenya",
    dropoffAddress: "Nairobi, Kenya",
    senderName: "Mombasa Port Authority",
    senderPhone: "+254 700 111 222",
    receiverName: "Aaron Abraha",
    receiverPhone: "+254 711 222 333",
    status: "IN_TRANSIT",
    courierId: "courier-123",
    weight: "5.5kg",
    dimensions: "40x30x20cm",
    createdAt: new Date(Date.now() - 86400000).toISOString()
  },
  {
    id: "UAPS-NG-2026-87654321",
    pickupAddress: "Abuja, Nigeria",
    dropoffAddress: "Lagos, Nigeria",
    senderName: "Abuja Tech Hub",
    senderPhone: "+234 800 123 4567",
    receiverName: "Lagos Logistics",
    receiverPhone: "+234 801 987 6543",
    status: "DELIVERED",
    courierId: "courier-123",
    weight: "2.0kg",
    dimensions: "20x20x10cm",
    createdAt: new Date(Date.now() - 172800000).toISOString(),
    proofOfDelivery: {
      timestamp: new Date(Date.now() - 7200000).toISOString(),
      signature: "https://picsum.photos/seed/sig/200/100",
      photo: "https://picsum.photos/seed/delivery/400/300"
    }
  },
  {
    id: "del-001",
    pickupAddress: "Madison Research Center, WI",
    dropoffAddress: "University Ave, Madison, WI",
    senderName: "UAPS Security Lab",
    receiverName: "Aaron Abraha",
    status: "FAILED_SECURITY_EVENT",
    courierId: "drone-42",
    weight: "1.2kg",
    dimensions: "15x15x15cm",
    createdAt: "2026-04-11T15:30:00Z"
  }
];

let packages = {
  "GLB-123456789": {
    status: "IN_TRANSIT",
    pickupAddress: "Lagos, Nigeria",
    dropoffAddress: "Nairobi, Kenya",
    senderName: "Global Partner",
    receiverName: "Aaron Abraha",
    events: [
      {
        timestamp: new Date(Date.now() - 86400000).toISOString(),
        location: { address: { addressLocality: "Lagos, NG" } },
        description: "Shipment dispatched from origin (DHL-KE-9981)",
        partnerInfo: { partnerId: "DHL-KE", localTrackingId: "DHL-KE-9981" }
      },
      {
        timestamp: new Date(Date.now() - 43200000).toISOString(),
        location: { address: { addressLocality: "Addis Ababa, ET" } },
        description: "Arrived at Hub (KQ-AIR-7712)",
        partnerInfo: { partnerId: "KQ-AIR", localTrackingId: "KQ-AIR-7712" }
      }
    ],
    partnerTrackingIds: ["DHL-KE-9981", "KQ-AIR-7712", "POSTA-UG-4411"],
    courierId: "courier-123"
  },
  "UAPS-KE-2026-12345678": {
    status: "IN_TRANSIT",
    pickupAddress: "Mombasa, Kenya",
    dropoffAddress: "Nairobi, Kenya",
    senderName: "Mombasa Port Authority",
    receiverName: "Aaron Abraha",
    events: [
      {
        timestamp: new Date(Date.now() - 86400000).toISOString(),
        location: { address: { addressLocality: "Mombasa, KE" } },
        description: "Package picked up by courier",
      },
      {
        timestamp: new Date().toISOString(),
        location: { address: { addressLocality: "Nairobi, KE" } },
        description: "In transit to Nairobi Hub",
      }
    ],
    courierId: "courier-123"
  },
  "UAPS-NG-2026-87654321": {
    status: "DELIVERED",
    pickupAddress: "Abuja, Nigeria",
    dropoffAddress: "Lagos, Nigeria",
    senderName: "Abuja Tech Hub",
    receiverName: "Lagos Logistics",
    events: [
      {
        timestamp: new Date(Date.now() - 14400000).toISOString(),
        location: { address: { addressLocality: "Abuja, NG" } },
        description: "Package picked up",
      },
      {
        timestamp: new Date(Date.now() - 7200000).toISOString(),
        location: { address: { addressLocality: "Lagos, NG" } },
        description: "Delivered to recipient",
      }
    ],
    proofOfDelivery: {
      timestamp: new Date(Date.now() - 7200000).toISOString(),
      signature: "https://picsum.photos/seed/sig/200/100",
      photo: "https://picsum.photos/seed/delivery/400/300"
    },
    courierId: "courier-123"
  },
  "UAPS-ET-2026-99999999": {
    status: "PICKED_UP",
    pickupAddress: "Addis Ababa, Ethiopia",
    dropoffAddress: "Djibouti City, Djibouti",
    senderName: "Ethiopian Airlines Cargo",
    receiverName: "Djibouti Port Authority",
    events: [
      {
        timestamp: new Date(Date.now() - 3600000).toISOString(),
        location: { address: { addressLocality: "Addis Ababa, ET" } },
        description: "Shipment picked up from cargo terminal",
      }
    ],
    partnerTrackingIds: ["ET-CARGO-7722"],
    courierId: "courier-123"
  },
  "del-001": {
    status: "FAILED_SECURITY_EVENT",
    pickupAddress: "Madison Research Center, WI",
    dropoffAddress: "University Ave, Madison, WI",
    senderName: "UAPS Security Lab",
    receiverName: "Aaron Abraha",
    events: [
      {
        timestamp: "2026-04-11T15:30:00Z",
        location: { address: { addressLocality: "Madison, WI" } },
        description: "Package picked up by drone-42",
      },
      {
        timestamp: "2026-04-11T16:05:12Z",
        location: { address: { addressLocality: "Madison, WI" } },
        description: "SECURITY INCIDENT: GPS Spoofing Detected",
      },
      {
        timestamp: "2026-04-11T16:10:45Z",
        location: { address: { addressLocality: "Madison, WI" } },
        description: "RTH Protocol Completed - Package NOT Delivered",
      }
    ],
    courierId: "drone-42"
  }
};

let courierLocations: Record<string, CourierLocation> = {
  "courier-123": {
    courierId: "courier-123",
    lat: -1.386389,
    lng: 36.867223,
    timestamp: new Date().toISOString()
  },
  "drone-42": {
    courierId: "drone-42",
    lat: 43.01501,
    lng: -89.41777,
    timestamp: "2026-04-11T16:10:45Z"
  }
};

let courierPaths: Record<string, { lat: number; lng: number; timestamp: number }[]> = {};
// { courierId: [ {lat, lng, timestamp}, ... ] }
let droneCommandStreams: Record<string, any> = {};

let packageStatusHistory: Record<string, { status: string; timestamp: number }[]> = {
  "GLB-123456789": [
    { status: "ACCEPTED", timestamp: Date.now() - 86400000 },
    { status: "PICKED_UP", timestamp: Date.now() - 43200000 },
    { status: "IN_TRANSIT", timestamp: Date.now() - 3600000 }
  ],
  "del-001": [
    { status: "ACCEPTED", timestamp: 1775921400000 }, // 2026-04-11T15:30:00Z
    { status: "PICKED_UP", timestamp: 1775921700000 },
    { status: "IN_TRANSIT", timestamp: 1775923200000 },
    { status: "FAILED_SECURITY_EVENT", timestamp: 1775923845000 } // 2026-04-11T16:10:45Z
  ]
};
// { trackingId: [ {status, timestamp}, ... ] }

let pushSubscribers: Record<string, any[]> = {};
// { trackingId: [subscriptionObjects] }

function notifyTrackingSubscribers(trackingId: string, message: string) {
  const subs = pushSubscribers[trackingId] || [];
  subs.forEach(sub => {
    try {
      webpush.sendNotification(sub, JSON.stringify({ message }));
    } catch (err) {
      console.error("Failed to send push notification:", err);
    }
  });
}

function updatePackageStatus(trackingId: string, status: string, proof?: any) {
  if (!packageStatusHistory[trackingId]) packageStatusHistory[trackingId] = [];
  const timestamp = Date.now();
  const isoTimestamp = new Date(timestamp).toISOString();
  packageStatusHistory[trackingId].push({ status, timestamp });

  // Find delivery to get courierId
  const delivery = deliveries.find(d => d.id === trackingId);
  const courierId = delivery?.courierId;

  // Update packages object if it exists for consistency
  if ((packages as any)[trackingId]) {
    const pkg = (packages as any)[trackingId];
    pkg.status = status;
    if (courierId) {
      pkg.courierId = courierId;
    }
    if (status === 'DELIVERED' && proof) {
      pkg.proofOfDelivery = proof;
    }

    if (!pkg.events) pkg.events = [];
    pkg.events.push({
      timestamp: isoTimestamp,
      location: {
        address: {
          addressLocality: status === 'IN_TRANSIT' ? 'In Transit' : 
                           status === 'DELIVERED' ? 'Destination' :
                           status === 'PICKED_UP' ? 'Origin' :
                           'Processing'
        }
      },
      description: status === 'IN_TRANSIT' ? 'Your package is on its way' : 
                   status === 'DELIVERED' ? 'Package delivered successfully' :
                   status === 'PICKED_UP' ? 'Package picked up by courier' :
                   status === 'ACCEPTED' ? 'Courier assigned to your package' :
                   'Package status updated'
    });
  }

  const statusObj = {
    status,
    description: status === 'IN_TRANSIT' ? 'Your package is on its way' : 
                 status === 'DELIVERED' ? 'Package delivered successfully' :
                 status === 'PICKED_UP' ? 'Package picked up by courier' :
                 status === 'ACCEPTED' ? 'Courier assigned to your package' :
                 'Package status updated',
    timestamp: isoTimestamp,
    location: {
      address: {
        addressLocality: status === 'IN_TRANSIT' ? 'In Transit' : 
                         status === 'DELIVERED' ? 'Destination' :
                         status === 'PICKED_UP' ? 'Origin' :
                         'Processing'
      }
    }
  };

  notifyTrackingSubscribers(trackingId, `Package ${trackingId} status updated to ${status}`);
  broadcastTrackingUpdate(trackingId, { type: "status_update", status: statusObj, timestamp });
  
  // Broadcast for TrackMyCourierMap
  if (delivery && delivery.courierId) {
    const courierLoc = courierLocations[delivery.courierId];
    const path = courierPaths[delivery.courierId] || [];
    broadcastTrackingUpdate(trackingId, {
      type: "tracking_update",
      courierLocation: courierLoc ? { lat: courierLoc.lat, lng: courierLoc.lng } : null,
      path: path.map(p => ({ lat: p.lat, lng: p.lng })),
      etaMinutes: 15, // Mock ETA
      status: status
    });
  }
}

// Initialize history for existing packages
// Initialize history for the main demo package

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface Courier {
  id: string;
  name: string;
  vehicle: string;
  photoUrl?: string;
  idDocumentUrl?: string;
  verified: boolean;
  metadata?: any;
}

function haversineKm(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
  return haversine(a, b);
}

async function startServer() {
  const app = express();
  const PORT = 3000;
  const server = http.createServer(app);
  const wss = new WebSocketServer({ server });

  // Multer setup for file uploads
  const uploadDir = path.join(process.cwd(), "uploads");
  if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir);
  }
  const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, uploadDir),
    filename: (req, file, cb) => cb(null, `${Date.now()}-${file.originalname}`)
  });
  const upload = multer({ storage });

  app.use(express.json());

  app.post("/api/courier/:id/verify", upload.fields([{ name: 'photo', maxCount: 1 }, { name: 'idDoc', maxCount: 1 }]), async (req, res) => {
    const courierId = req.params.id;
    const files = req.files as { [fieldname: string]: Express.Multer.File[] };

    if (!couriers[courierId]) {
      return res.status(404).json({ error: "Courier not found" });
    }

    const photoUrl = files['photo'] ? `/uploads/${files['photo'][0].filename}` : undefined;
    const idDocUrl = files['idDoc'] ? `/uploads/${files['idDoc'][0].filename}` : undefined;

    couriers[courierId].photoUrl = photoUrl;
    couriers[courierId].idDocumentUrl = idDocUrl;
    couriers[courierId].verified = false; // pending review

    res.json({ success: true });
  });

  app.post("/api/courier/:id/batch", async (req, res) => {
    const { deliveryIds } = req.body;
    const courierId = req.params.id;

    if (!couriers[courierId]) {
      return res.status(404).json({ error: "Courier not found" });
    }

    const batchId = "BATCH-" + Date.now();
    batches[batchId] = { id: batchId, courierId, deliveryIds };

    deliveryIds.forEach((dId: string) => {
      const delivery = deliveries.find(d => d.id === dId);
      if (delivery) {
        delivery.courierId = courierId;
        delivery.batchId = batchId;
      }
    });

    res.json(batches[batchId]);
  });

  app.use("/uploads", express.static(uploadDir));

  // Removed /api/eta backend route. Gemini calls should be made from the frontend.

  interface TrackingSocket extends WebSocket {
    trackingId?: string;
  }

  wss.on("connection", (socket: TrackingSocket) => {
    socket.on("message", (msg) => {
      try {
        const data = JSON.parse(msg.toString());
        if (data.type === "subscribe" && data.trackingId) {
          socket.trackingId = data.trackingId;
        }
      } catch (err) {
        console.error("WS Message Error:", err);
      }
    });
  });

  // Global helper to broadcast updates
  (global as any).broadcastTrackingUpdate = function(trackingId: string, payload: any) {
    wss.clients.forEach((client: any) => {
      const trackingClient = client as TrackingSocket;
      if (trackingClient.readyState === WebSocket.OPEN && trackingClient.trackingId === trackingId) {
        trackingClient.send(JSON.stringify(payload));
      }
    });
  };

  app.use(express.json());

  app.get("/api/couriers/locations", (req, res) => {
    const authHeader = req.headers.authorization;
    const expectedToken = process.env.PARTNER_TOKEN || "uaps_partner_secret_123";
    
    // Optional: Add auth check if requested, but for now just ensure it returns JSON
    if (authHeader && authHeader !== `Bearer ${expectedToken}`) {
      // If they provided a token, it must be correct
      // return res.status(401).json({ error: "Unauthorized" });
    }

    res.json(courierLocations);
  });

  // API Route for Tracking
  app.get("/api/track/:trackingNumber", async (req, res) => {
    const { trackingNumber } = req.params;

    // Check local packages first
    let pkg = (packages as any)[trackingNumber];
    let actualTrackingNumber = trackingNumber;

    // If not found by direct key, search in partnerTrackingIds
    if (!pkg) {
      const foundEntry = Object.entries(packages).find(([_, p]: [string, any]) => 
        p.partnerTrackingIds && p.partnerTrackingIds.includes(trackingNumber)
      );
      if (foundEntry) {
        actualTrackingNumber = foundEntry[0];
        pkg = foundEntry[1];
      }
    }

    if (pkg) {
      const courierLoc = courierLocations[pkg.courierId] || null;
      const history = packageStatusHistory[actualTrackingNumber] || [];
      
      // Use the latest status from history if available
      const latestStatus = history.length > 0 ? history[history.length - 1] : { status: pkg.status, timestamp: Date.now() };
      
      return res.json({
        shipments: [{
          id: actualTrackingNumber,
          partnerTrackingIds: pkg.partnerTrackingIds || [],
          statusHistory: history,
          proofOfDelivery: pkg.proofOfDelivery,
          sender: {
            name: pkg.senderName || "UAPS Customer",
            phone: pkg.senderPhone || "N/A"
          },
          receiver: {
            name: pkg.receiverName || "Aaron Abraha",
            phone: pkg.receiverPhone || "N/A"
          },
          destination: {
            address: {
              addressLocality: pkg.dropoffAddress?.split(',').slice(-2).join(',').trim() || "NBO, Kenya",
              streetAddress: pkg.dropoffAddress || "199-131 E 22nd St, Nairobi, 00100"
            },
            location: {
              lat: -1.286389,
              lng: 36.817223
            }
          },
          status: {
            status: latestStatus.status,
            description: latestStatus.status === 'IN_TRANSIT' ? 'Your package is on its way' : 
                         latestStatus.status === 'DELIVERED' ? 'Package delivered successfully' :
                         latestStatus.status === 'PICKED_UP' ? 'Package picked up by courier' :
                         latestStatus.status === 'ACCEPTED' ? 'Courier assigned to your package' :
                         'Package status updated',
            timestamp: new Date(latestStatus.timestamp).toISOString(),
            eta: latestStatus.status === 'IN_TRANSIT' ? 'Today, 4:30 PM' : 
                 latestStatus.status === 'DELIVERED' ? 'Arrived' : 'Calculating...',
            location: {
              address: {
                addressLocality: latestStatus.status === 'IN_TRANSIT' ? 'In Transit' : 
                                 latestStatus.status === 'DELIVERED' ? 'Delivered' :
                                 'Processing'
              }
            }
          },
          events: (pkg.events || []).map((e: any) => ({
            ...e,
            timestamp: e.timestamp
          })).reverse(),
          courier: {
            id: pkg.courierId,
            name: "Official UAPS Courier",
            phone: "+254 700 000 000",
            email: "courier@uaps.et",
            vehicle: "bike",
            location: courierLoc
          }
        }]
      });
    }
    
    // Screenshot Format Check: UA123456789XX (for demo purposes)
    const screenshotRegex = /^UA\d{9}[A-Z]{2}$/;
    
    if (screenshotRegex.test(trackingNumber)) {
      // Return mock data ONLY for the screenshot format
      return res.json({
        shipments: [{
          id: trackingNumber,
          service: "UAPS GLOBAL PRIORITY",
          origin: "NYC, USA",
          destination: {
            address: {
              addressLocality: "Nairobi, Kenya",
              streetAddress: "199-131 E 22nd St, Nairobi, 00100"
            }
          },
          status: {
            timestamp: new Date().toISOString(),
            location: {
              address: {
                addressLocality: "Nairobi, Kenya"
              }
            },
            statusCode: "TRANSIT",
            status: "IN TRANSIT",
            description: "Out for delivery in Nairobi, Kenya",
            eta: "Today, 5:45 PM"
          },
          courier: {
            name: "Leslie Alexander",
            phone: "+251 911 234 567",
            email: "leslie.a@uaps.et"
          },
          events: [
            {
              timestamp: new Date(Date.now() + 86400000 * 4).toISOString(),
              location: { address: { addressLocality: "Nairobi, Kenya" } },
              description: "Estimated Delivery"
            },
            {
              timestamp: new Date(Date.now() + 86400000 * 3).toISOString(),
              location: { address: { addressLocality: "Nairobi, Kenya" } },
              description: "In Transit to Nairobi, Kenya..."
            },
            {
              timestamp: new Date(Date.now() + 86400000 * 2).toISOString(),
              location: { address: { addressLocality: "Lagos, NG" } },
              description: "Customs cleared in Lagos, NG"
            },
            {
              timestamp: new Date(Date.now() + 86400000 * 2).toISOString(),
              location: { address: { addressLocality: "Lagos, NG" } },
              description: "Arrived at UAPS Gateway in Lagos, NG"
            },
            {
              timestamp: new Date(Date.now() + 86400000 * 1).toISOString(),
              location: { address: { addressLocality: "New York Hub" } },
              description: "Departed UPS New York Hub"
            },
            {
              timestamp: new Date(Date.now()).toISOString(),
              location: { address: { addressLocality: "NYC, USA" } },
              description: "Accepted by UPS"
            }
          ]
        }]
      });
    }

    const dhlApiKey = req.headers['x-dhl-api-key'] as string || process.env.DHL_API_KEY;
    const fedexApiKey = req.headers['x-fedex-api-key'] as string || process.env.FEDEX_API_KEY;
    const upsApiKey = req.headers['x-ups-api-key'] as string || process.env.UPS_API_KEY;
    const uspsApiKey = req.headers['x-usps-api-key'] as string || process.env.USPS_API_KEY;

    // Determine which API to use based on tracking number format
    // DHL is typically 10 digits, FedEx is typically 12, 15, 20, or 22 digits, UPS often starts with 1Z
    // USPS is typically 20-22 digits starting with 9
    const isFedex = /^\d{12,22}$/.test(trackingNumber) && trackingNumber.length !== 10 && !trackingNumber.startsWith('9');
    const isUps = /^1Z[A-Z0-9]{16}$/i.test(trackingNumber);
    const isUsps = /^(9\d{19,21})$/.test(trackingNumber);

    if (isUsps) {
      if (!uspsApiKey) {
        return res.status(500).json({ 
          error: "USPS API Key is not configured. Please add it in the Settings panel or the Secrets panel." 
        });
      }
      return res.json({
        shipments: [{
          id: trackingNumber,
          service: "USPS PRIORITY MAIL",
          destination: { address: { addressLocality: "Chicago, IL" } },
          status: {
            timestamp: new Date().toISOString(),
            location: { address: { addressLocality: "Washington, DC" } },
            description: "Delivered, Front Door/Porch",
            statusCode: "DELIVERED"
          },
          events: [
            {
              timestamp: new Date().toISOString(),
              location: { address: { addressLocality: "Washington, DC" } },
              description: "Delivered"
            },
            {
              timestamp: new Date(Date.now() - 3600000).toISOString(),
              location: { address: { addressLocality: "Washington, DC" } },
              description: "Out for Delivery"
            }
          ]
        }]
      });
    }

    if (isUps) {
      if (!upsApiKey) {
        return res.status(500).json({ 
          error: "UPS API Key is not configured. Please add it in the Settings panel or the Secrets panel." 
        });
      }
      return res.json({
        shipments: [{
          id: trackingNumber,
          service: "UPS GROUND",
          destination: { address: { addressLocality: "Atlanta, GA" } },
          status: {
            timestamp: new Date().toISOString(),
            location: { address: { addressLocality: "Louisville, KY" } },
            description: "Out for Delivery",
            statusCode: "DELIVERY"
          },
          events: [
            {
              timestamp: new Date().toISOString(),
              location: { address: { addressLocality: "Louisville, KY" } },
              description: "Arrived at UPS Facility"
            }
          ]
        }]
      });
    }

    if (isFedex) {
      if (!fedexApiKey) {
        return res.status(500).json({ 
          error: "FedEx API Key is not configured. Please add it in the Settings panel or the Secrets panel." 
        });
      }
      // Mock FedEx API call for now as we don't have the full FedEx API implementation details
      // but we use the key as requested
      return res.json({
        shipments: [{
          id: trackingNumber,
          service: "FEDEX GROUND",
          status: {
            timestamp: new Date().toISOString(),
            location: { address: { addressLocality: "Memphis, TN" } },
            description: "In Transit",
            statusCode: "TRANSIT"
          },
          events: [
            {
              timestamp: new Date().toISOString(),
              location: { address: { addressLocality: "Memphis, TN" } },
              description: "Arrived at FedEx Hub"
            }
          ]
        }]
      });
    }

    if (!dhlApiKey) {
      return res.status(500).json({ 
        error: "DHL API Key is not configured. Please add it in the Settings panel or the Secrets panel." 
      });
    }

    try {
      const response = await fetch(
        `https://api-eu.dhl.com/track/shipments?trackingNumber=${trackingNumber}`,
        {
          headers: {
            "DHL-API-Key": dhlApiKey,
            "Accept": "application/json"
          }
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        return res.status(response.status).json(errorData);
      }

      const data = await response.json();
      res.json(data);
    } catch (error) {
      console.error("DHL API Error:", error);
      res.status(500).json({ error: "Failed to fetch tracking data from DHL." });
    }
  });

  // Courier Jobs API
  app.get("/api/courier/jobs", (req, res) => {
    const courierId = req.query.courierId as string;
    const available = deliveries.filter((d) => d.status === "NEW");
    const mine = deliveries.filter((d) => d.courierId === courierId);
    res.json({ available, mine });
  });

  app.post("/api/courier/jobs/:id/accept", (req, res) => {
    const courierId = req.body.courierId as string;
    const job = deliveries.find((d) => d.id === req.params.id);
    if (!job || job.status !== "NEW") {
      return res.status(400).json({ error: "Job not available" });
    }
    job.status = "ACCEPTED";
    job.courierId = courierId;
    updatePackageStatus(job.id, job.status);
    res.json(job);
  });

  app.post("/api/courier/jobs/:id/status", (req, res) => {
    const { status, proof } = req.body as { status: DeliveryStatus; proof?: any };
    const job = deliveries.find((d) => d.id === req.params.id);
    if (!job) return res.status(404).json({ error: "Not found" });
    job.status = status;
    if (status === 'DELIVERED' && proof) {
      job.proofOfDelivery = {
        ...proof,
        timestamp: new Date().toISOString()
      };
    }
    updatePackageStatus(job.id, job.status, proof);
    res.json(job);
  });

  app.get("/api/track/:id/history", (req, res) => {
    res.json(packageStatusHistory[req.params.id] || []);
  });

  app.get("/api/shipments", (req, res) => {
    res.json(deliveries);
  });

  const countryToCode: Record<string, string> = {
    "algeria": "DZ",
    "angola": "AO",
    "benin": "BJ",
    "botswana": "BW",
    "burkina faso": "BF",
    "burundi": "BI",
    "cabo verde": "CV",
    "cameroon": "CM",
    "central african republic": "CF",
    "chad": "TD",
    "comoros": "KM",
    "congo": "CG",
    "democratic republic of the congo": "CD",
    "djibouti": "DJ",
    "egypt": "EG",
    "equatorial guinea": "GQ",
    "eritrea": "ER",
    "eswatini": "SZ",
    "ethiopia": "ET",
    "gabon": "GA",
    "gambia": "GM",
    "ghana": "GH",
    "guinea": "GN",
    "guinea-bissau": "GW",
    "ivory coast": "CI",
    "kenya": "KE",
    "lesotho": "LS",
    "liberia": "LR",
    "libya": "LY",
    "madagascar": "MG",
    "malawi": "MW",
    "mali": "ML",
    "mauritania": "MR",
    "mauritius": "MU",
    "morocco": "MA",
    "mozambique": "MZ",
    "namibia": "NA",
    "niger": "NE",
    "nigeria": "NG",
    "rwanda": "RW",
    "sao tome and principe": "ST",
    "senegal": "SN",
    "seychelles": "SC",
    "sierra leone": "SL",
    "somalia": "SO",
    "south africa": "ZA",
    "south sudan": "SS",
    "sudan": "SD",
    "tanzania": "TZ",
    "togo": "TG",
    "tunisia": "TN",
    "uganda": "UG",
    "zambia": "ZM",
    "zimbabwe": "ZW"
  };

  app.post("/api/shipments", (req, res) => {
    const { 
      pickupAddress, pickupCity, pickupCountry, senderName, senderPhone,
      dropoffAddress, dropoffCity, dropoffCountry, receiverName, receiverPhone,
      weight, dimensions, type,
      deliveryMode,
      speed, deliveryWindowStart, deliveryWindowEnd,
      handling, dropoffMode, privacyMode, slaTier
    } = req.body;
    
    // Detect country code from dropoffCountry or dropoffCity/Address
    let countryCode = "ER"; // Default
    const countryToSearch = (dropoffCountry || dropoffCity || dropoffAddress).toLowerCase();
    
    for (const [country, code] of Object.entries(countryToCode)) {
      if (countryToSearch.includes(country)) {
        countryCode = code;
        break;
      }
    }

    const year = new Date().getFullYear();
    const sequence = Math.floor(10000000 + Math.random() * 90000000).toString();
    const id = `UAPS-${countryCode}-${year}-${sequence}`;
    
    const fullPickup = `${pickupAddress}, ${pickupCity}, ${pickupCountry}`;
    const fullDropoff = `${dropoffAddress}, ${dropoffCity}, ${dropoffCountry}`;

    const shipment_options = {
      delivery_mode: deliveryMode || "AIR_DRONE",
      speed: speed || "STANDARD",
      delivery_window: deliveryWindowStart && deliveryWindowEnd ? {
        start: deliveryWindowStart,
        end: deliveryWindowEnd
      } : undefined,
      handling: handling || [],
      dropoff_mode: dropoffMode || "DOORSTEP",
      privacy_mode: privacyMode || "NORMAL",
      sla_tier: slaTier || "BRONZE"
    };

    const newDelivery: Delivery = {
      id,
      pickupAddress: fullPickup,
      dropoffAddress: fullDropoff,
      senderName,
      senderPhone,
      receiverName,
      receiverPhone,
      status: "NEW",
      weight,
      dimensions,
      handlingInstructions: handling?.join(', '),
      shipment_options,
      createdAt: new Date().toISOString()
    };
    deliveries.push(newDelivery);
    
    // Initialize package data
    (packages as any)[id] = {
      status: "NEW",
      pickupAddress: fullPickup,
      dropoffAddress: fullDropoff,
      senderName,
      senderPhone,
      receiverName,
      receiverPhone,
      weight,
      dimensions,
      shipment_options,
      events: [
        {
          timestamp: new Date().toISOString(),
          location: { address: { addressLocality: fullPickup.split(',').slice(-2).join(',').trim() } },
          description: "Shipment information received"
        }
      ]
    };
    updatePackageStatus(id, "NEW");
    
    res.json(newDelivery);
  });

  app.post("/api/drones/delivery/hybrid-plan", (req, res) => {
    const { delivery_id, hybrid_plan } = req.body;
    if (!delivery_id || !hybrid_plan) {
      return res.status(400).json({ error: "Missing delivery_id or hybrid_plan" });
    }
    res.json({
      status: "HYBRID_PLAN_ACCEPTED",
      delivery_id,
      processed_at: new Date().toISOString()
    });
  });

  app.post("/api/drones/delivery/events", (req, res) => {
    const event = req.body;
    if (!event.event_type || !event.delivery_id) {
      return res.status(400).json({ error: "Missing event_type or delivery_id" });
    }
    
    // In a real app, we would append this event to the delivery's audit trail.
    // For this mock, we just acknowledge receipt.
    res.json({
      status: "EVENT_RECORDED",
      event_id: event.event_id || `evt-${Date.now()}`,
      processed_at: new Date().toISOString()
    });
  });

  app.get("/api/deliveries/:id/risk-options", (req, res) => {
    res.json({
      delivery_id: req.params.id,
      risk: {
        type: "DELAY",
        mode: "TRUCK",
        probability: 0.78,
        expected_delay_min: 45
      },
      proposed_options: [
        {
          id: "KEEP_LATE",
          label: "Keep delivery today, ETA 18:30–19:15"
        },
        {
          id: "LOCKER_REDIRECT",
          label: "Redirect to secure locker nearby, ready by 17:45"
        },
        {
          id: "RESCHEDULE_TOMORROW",
          label: "Reschedule for tomorrow morning 9:00–11:00"
        }
      ],
      response_cutoff: "2026-04-11T16:30:00Z"
    });
  });

  app.post("/api/returns", (req, res) => {
    const { delivery_id } = req.body;
    res.json({
      return_id: `ret-${Date.now()}`,
      delivery_id: delivery_id || "del-123",
      status: "INITIATED",
      eligible_methods: [
        {
          method: "LOCKER",
          id: "locker-123",
          label: "Locker #123 · 0.4 miles · 24/7",
          eta_refund_days: 3
        },
        {
          method: "STORE",
          id: "store-789",
          label: "Partner Store · 1.2 miles",
          eta_refund_days: 5
        }
      ]
    });
  });

  app.post("/api/returns/:id/method", (req, res) => {
    const { method, location_id } = req.body;
    res.json({
      return_id: req.params.id,
      status: "READY_FOR_DROP_OFF",
      dropoff: {
        method: method || "LOCKER",
        location_id: location_id || "locker-123",
        qr_code: "base64-encoded",
        instructions: `Scan this code at ${method === 'STORE' ? 'Partner Store' : 'Locker'} #${location_id?.split('-')[1] || '123'}.`
      }
    });
  });

  app.post("/api/returns/:id/events", (req, res) => {
    const { event_type, source, location_id, timestamp } = req.body;
    if (event_type === "DROP_OFF_CONFIRMED") {
      res.json({
        return_id: req.params.id,
        status: "RECEIVED",
        digital_proof_of_return: {
          id: `dpor-${Date.now()}`,
          timestamp: timestamp || new Date().toISOString(),
          method: source || "LOCKER",
          location_id: location_id || "locker-123"
        }
      });
    } else {
      res.status(400).json({ error: "Unsupported event type" });
    }
  });

  app.get("/api/returns/:id", (req, res) => {
    res.json({
      return_id: req.params.id,
      delivery_id: "del-123",
      timestamp: "2026-04-11T10:12:00Z",
      method: "LOCKER",
      location: "Locker-123, Fitchburg WI",
      status: "RECEIVED"
    });
  });

  app.post("/api/feedback", (req, res) => {
    const feedback = req.body;
    if (!feedback.delivery_id) {
      return res.status(400).json({ error: "Missing delivery_id" });
    }
    res.json({
      feedback_id: feedback.feedback_id || `fb-${Date.now()}`,
      delivery_id: feedback.delivery_id,
      incentive: {
        awarded: true,
        points: 50
      },
      analysis_status: "PENDING"
    });
  });

  app.get("/api/feedback/rules", (req, res) => {
    res.json({
      rules: [
        {
          id: "base_feedback_reward",
          description: "Reward any completed feedback",
          conditions: {
            feedback_submitted: true
          },
          actions: {
            points: 50
          }
        },
        {
          id: "high_value_customer_bonus",
          conditions: {
            feedback_submitted: true,
            customer_segment: "HIGH_VALUE"
          },
          actions: {
            points_bonus: 25
          }
        },
        {
          id: "negative_feedback_service_recovery",
          conditions: {
            feedback_submitted: true,
            sentiment_score_lt: 0.3,
            severity_score_gt: 0.7
          },
          actions: {
            points: 100,
            create_case: true,
            case_priority: "HIGH"
          }
        }
      ]
    });
  });

  app.get("/api/feedback/:id", (req, res) => {
    res.json({
      feedback_id: req.params.id,
      delivery_id: "del-123",
      rating: 4,
      text: "Package was slightly dented but arrived early.",
      mode: "TRUCK",
      sentiment: {
        score: 0.72,
        label: "POSITIVE",
        emotion: "MIXED",
        topics: ["PACKAGE_DAMAGE", "EARLY_DELIVERY"]
      },
      incentive: {
        awarded: true,
        points: 50
      },
      created_at: "2026-04-11T16:20:00Z"
    });
  });

  app.post("/api/feedback/analyze", (req, res) => {
    res.json({
      sentiment_score: 0.18,
      sentiment_label: "NEGATIVE",
      emotion: "ANGER",
      topics: ["LATE_DELIVERY", "DRIVER_BEHAVIOR"],
      severity_score: 0.83
    });
  });

  app.post("/api/customers/:id/points/calculate", (req, res) => {
    const { delivery_id } = req.body;
    res.json({
      customer_id: req.params.id,
      delivery_id: delivery_id || "del-123",
      points_total: 150,
      rules_applied: [
        "base_feedback_reward",
        "high_value_customer_bonus",
        "negative_feedback_service_recovery"
      ]
    });
  });

  app.post("/api/customers/:id/points", (req, res) => {
    const { points_awarded, reason, delivery_id } = req.body;
    res.json({
      customer_id: req.params.id,
      points_awarded: points_awarded || 50,
      reason: reason || "POST_DELIVERY_FEEDBACK",
      delivery_id: delivery_id || "del-123",
      status: "POINTS_AWARDED",
      processed_at: new Date().toISOString()
    });
  });

  // --- Customer Experience & Journeys ---
  const customerProfiles: Record<string, any> = {
    "cust-123": {
      "customer_id": "cust-123",
      "identifiers": {
        "email": "user@example.com",
        "phone": "+1-555-123-4567",
        "external_ids": { "partner_a": "pA-999" }
      },
      "preferences": {
        "delivery_modes": ["LOCKER_FIRST", "HYBRID_ALLOWED"],
        "channels": ["PUSH", "EMAIL"],
        "language": "en-US",
        "quiet_hours": { "start": "21:00", "end": "07:00", "timezone": "America/Chicago" }
      },
      "loyalty": {
        "tier": "GOLD",
        "points": 12450,
        "since": "2024-01-01"
      },
      "flags": {
        "high_value": true,
        "at_risk": false
      },
      "sentiment_summary": {
        "score_90d": 0.78,
        "last_label": "POSITIVE"
      }
    }
  };

  const customerJourneys: Record<string, any> = {
    "jour-20260411-0003": {
      "journey_id": "jour-20260411-0003",
      "journey_type": "PROACTIVE_DELAY_HANDLING",
      "customer_id": "cust-123",
      "state": "COMPLETED",
      "started_at": "2026-04-11T15:20:00Z",
      "ended_at": "2026-04-11T16:35:00Z",
      "steps": [
        { "step_id": "STEP_DELAY_DETECTED", "ts": "2026-04-11T15:20:00Z" },
        { "step_id": "STEP_OFFER_LOCKER", "ts": "2026-04-11T15:22:00Z" },
        { "step_id": "STEP_CUSTOMER_ACCEPTED_LOCKER", "ts": "2026-04-11T15:24:00Z" }
      ]
    }
  };

  const interactions: Record<string, any> = {};

  let partnerApplications: any[] = [
    {
      id: "app-001",
      companyName: "Nairobi Express Logistics",
      operatingCountries: "Kenya, Uganda, Tanzania",
      contactEmail: "partners@nairobiexpress.co.ke",
      status: "pending",
      submittedAt: new Date(Date.now() - 86400000).toISOString()
    },
    {
      id: "app-002",
      companyName: "West Africa Freight",
      operatingCountries: "Nigeria, Ghana",
      contactEmail: "hello@wafreight.ng",
      status: "approved",
      submittedAt: new Date(Date.now() - 172800000).toISOString()
    }
  ];

  app.post("/api/partner-applications", (req, res) => {
    const newApp = {
      id: `app-${Date.now()}`,
      ...req.body,
      status: "pending",
      submittedAt: new Date().toISOString()
    };
    partnerApplications.push(newApp);
    res.json({ success: true, application: newApp });
  });

  app.get("/api/partner-applications", (req, res) => {
    res.json(partnerApplications);
  });

  app.patch("/api/partner-applications/:id/status", (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    const application = partnerApplications.find(app => app.id === id);
    if (!application) {
      return res.status(404).json({ error: "Application not found" });
    }
    application.status = status;
    res.json({ success: true, application });
  });

  app.get("/api/customers/:id", (req, res) => {
    const profile = customerProfiles[req.params.id];
    if (!profile) return res.status(404).json({ error: "Customer not found" });
    res.json(profile);
  });

  app.patch("/api/customers/:id/preferences", (req, res) => {
    const profile = customerProfiles[req.params.id];
    if (!profile) return res.status(404).json({ error: "Customer not found" });
    profile.preferences = { ...profile.preferences, ...req.body.preferences };
    res.json(profile);
  });

  app.get("/api/customers/:id/proactive-actions", (req, res) => {
    res.json({
      "customer_id": req.params.id,
      "actions": [
        {
          "id": "OFFER_LOCKER_REDIRECT",
          "priority": 1,
          "channel": "PUSH",
          "payload": {
            "locker_id": "locker-123",
            "eta": "2026-04-11T16:10:00Z"
          }
        },
        {
          "id": "OFFER_NEW_TIME_WINDOW",
          "priority": 2,
          "channel": "PUSH"
        }
      ]
    });
  });

  app.post("/api/journeys", (req, res) => {
    const journeyId = req.body.metadata?.journey_id || `jour-${Date.now()}`;
    customerJourneys[journeyId] = req.body;
    res.json({ success: true, journey_id: journeyId });
  });

  app.get("/api/journeys/:id", (req, res) => {
    const journey = customerJourneys[req.params.id];
    if (!journey) return res.status(404).json({ error: "Journey not found" });
    res.json(journey);
  });

  app.post("/api/interactions", (req, res) => {
    const interactionId = req.body.interaction_id || `int-${Date.now()}`;
    interactions[interactionId] = req.body;
    res.json({ success: true, interaction_id: interactionId });
  });

  app.get("/api/drones/delivery/policy", (req, res) => {
    res.json({
      version: "1.0.0",
      modes: ["AIR_DRONE", "GROUND_ROBOT", "HYBRID"],
      customer_preferences: {
        AIR_ONLY: {
          allowed_modes: ["AIR_DRONE"],
          auto_switch_allowed: false
        },
        GROUND_ONLY: {
          allowed_modes: ["GROUND_ROBOT"],
          auto_switch_allowed: true
        },
        HYBRID_ALLOWED: {
          allowed_modes: ["AIR_DRONE", "GROUND_ROBOT", "HYBRID"],
          auto_switch_allowed: true
        },
        BEST_AVAILABLE: {
          allowed_modes: ["AIR_DRONE", "GROUND_ROBOT", "HYBRID"],
          auto_switch_allowed: true
        }
      },
      thresholds: {
        weather: {
          air_max: 25,
          ground_max: 40
        },
        battery: {
          air_min_pct: 20,
          ground_min_pct: 10
        }
      },
      cutoff_policy: {
        allow_customer_changes_before_cutoff: true,
        allow_safety_changes_after_cutoff: true,
        final_approach_customer_changes_allowed: false
      },
      rules: [
        {
          id: "weather_air_exceeds_ground_ok",
          description: "Switch from air to ground/hybrid when air unsafe but ground safe",
          from_modes: ["AIR_DRONE"],
          to_modes: ["GROUND_ROBOT", "HYBRID"],
          conditions: {
            "weather.air_risk_score_gt_threshold": true,
            "weather.ground_risk_score_le_threshold": true,
            safety_override: true
          },
          customer_preference_allowed: [
            "GROUND_ONLY",
            "HYBRID_ALLOWED",
            "BEST_AVAILABLE"
          ],
          requires_explicit_consent: false
        },
        {
          id: "air_only_customer_preference",
          description: "Customer selected air-only; any mode change requires consent unless safety override",
          from_modes: ["AIR_DRONE"],
          to_modes: ["GROUND_ROBOT", "HYBRID"],
          conditions: {
            safety_override: false
          },
          customer_preference_allowed: ["AIR_ONLY"],
          requires_explicit_consent: true
        },
        {
          id: "weather_all_unsafe",
          description: "Abort when both air and ground unsafe",
          from_modes: ["AIR_DRONE", "GROUND_ROBOT", "HYBRID"],
          to_modes: [],
          conditions: {
            "weather.air_risk_score_gt_threshold": true,
            "weather.ground_risk_score_gt_threshold": true
          },
          forced_action: "ABORT",
          requires_explicit_consent: false
        },
        {
          id: "cutoff_exceeded",
          description: "After cutoff, only safety-driven changes allowed",
          from_modes: ["AIR_DRONE", "GROUND_ROBOT", "HYBRID"],
          to_modes: ["AIR_DRONE", "GROUND_ROBOT", "HYBRID"],
          conditions: {
            "time.after_cutoff": true
          },
          allow_customer_initiated_changes: false,
          allow_safety_initiated_changes: true
        }
      ]
    });
  });

  app.get("/api/drones/delivery/:id/weather-risk", (req, res) => {
    res.json({
      air_risk_score: 32,
      ground_risk_score: 8,
      thresholds: { air_max: 25, ground_max: 40 }
    });
  });

  app.get("/api/shipments/:id/preferences", (req, res) => {
    res.json({
      customer_preference: "HYBRID_ALLOWED",
      set_at: "2026-04-10T12:00:00Z"
    });
  });

  app.get("/api/drones/delivery/:id/audit", (req, res) => {
    const id = req.params.id;
    if (id === "del-002") {
      return res.json({
        delivery_id: "del-002",
        initial_mode: "AIR_DRONE",
        final_mode: "HYBRID",
        mode_change_reason: "WEATHER_RISK + CUSTOMER_PREFERENCE",
        weather_risk_at_change: {
          air_risk_score: 32,
          ground_risk_score: 8,
          thresholds: { air_max: 25, ground_max: 40 }
        },
        customer_preference: "HYBRID_OR_GROUND_ALLOWED",
        timeline: {
          mode_change_ts: "2026-04-11T15:20:00Z",
          handoff_ts: "2026-04-11T15:32:00Z",
          final_delivery_ts: "2026-04-11T15:47:30Z"
        }
      });
    }

    res.json({
      delivery_id: id,
      customer_options_history: [
        {
          event_type: "delivery_options_change",
          event_id: "opt-20260411-0007",
          requested_changes: {
            dropoff_mode: "SECURE_LOCKER",
            dropoff_location: { lat: 43.015, lon: -89.417, locker_id: "locker-123" }
          },
          decision: "ACCEPTED",
          cutoff_status: "WITHIN_CUTOFF",
          ts: "2026-04-11T15:45:00Z"
        }
      ],
      route_versions: [
        { route_id: "route-123", reason_ended: "CUSTOMER_OPTIONS_CHANGE" },
        { route_id: "route-124", reason_started: "CUSTOMER_OPTIONS_CHANGE" }
      ],
      locker_details: {
        locker_id: "locker-123",
        handoff_ts: "2026-04-11T16:08:30Z",
        auth_success: true
      }
    });
  });

  app.get("/api/shipments/:id/audit", (req, res) => {
    const id = req.params.id;
    
    // Mock audit response based on the requested schema
    res.json({
      delivery_id: id,
      customer_options_history: [
        {
          event_type: "delivery_options_change",
          event_id: "opt-20260411-0007",
          requested_changes: {
            dropoff_mode: "SECURE_LOCKER",
            dropoff_location: { lat: 43.015, lon: -89.417, locker_id: "locker-123" }
          },
          decision: "ACCEPTED",
          cutoff_status: "WITHIN_CUTOFF",
          ts: "2026-04-11T15:45:00Z"
        }
      ],
      route_versions: [
        { route_id: "route-123", reason_ended: "CUSTOMER_OPTIONS_CHANGE" },
        { route_id: "route-124", reason_started: "CUSTOMER_OPTIONS_CHANGE" }
      ],
      locker_details: {
        locker_id: "locker-123",
        handoff_ts: "2026-04-11T16:08:30Z",
        auth_success: true
      }
    });
  });

  app.patch("/api/shipments/:id", (req, res) => {
    const id = req.params.id;
    const { requested_changes } = req.body;
    
    const pkg = (packages as any)[id];
    if (!pkg) {
      return res.status(404).json({ error: "Shipment not found" });
    }

    if (requested_changes) {
      if (!pkg.shipment_options) {
        pkg.shipment_options = {};
      }
      if (requested_changes.delivery_window) {
        pkg.shipment_options.delivery_window = requested_changes.delivery_window;
      }
      if (requested_changes.dropoff_mode) {
        pkg.shipment_options.dropoff_mode = requested_changes.dropoff_mode;
      }
      if (requested_changes.dropoff_location) {
        pkg.dropoff_location = requested_changes.dropoff_location;
      }
      
      pkg.events.push({
        timestamp: new Date().toISOString(),
        location: { address: { addressLocality: "System" } },
        description: "Shipment details modified by customer"
      });
    }

    const delivery = deliveries.find(d => d.id === id);
    if (delivery) {
      if (!delivery.shipment_options) delivery.shipment_options = { speed: "STANDARD", handling: [], dropoff_mode: "DOORSTEP", privacy_mode: "NORMAL", sla_tier: "BRONZE" };
      if (requested_changes?.delivery_window) {
        delivery.shipment_options.delivery_window = requested_changes.delivery_window;
      }
      if (requested_changes?.dropoff_mode) {
        delivery.shipment_options.dropoff_mode = requested_changes.dropoff_mode;
      }
    }

    res.json({
      delivery_id: id,
      status: "OPTIONS_ACCEPTED",
      effective_changes: requested_changes || {},
      new_eta: new Date(Date.now() + 86400000).toISOString(), // +1 day
      cutoff_status: "WITHIN_CUTOFF"
    });
  });

  app.post("/api/ai/hs-code", async (req, res) => {
    const { description } = req.body;
    if (!description) {
      return res.status(400).json({ error: "Description is required" });
    }

    try {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey || apiKey === "MY_GEMINI_API_KEY" || apiKey.trim() === "") {
        console.error("GEMINI_API_KEY is missing or invalid in environment variables.");
        return res.status(500).json({ 
          error: "AI service is not configured. Please ensure GEMINI_API_KEY is set in the Secrets panel." 
        });
      }

      const genAI = new GoogleGenAI({ apiKey });

      const prompt = `As a customs expert, provide the most accurate 6-digit HS Code (Harmonized System Code) for the following item description: "${description}". 
      Respond ONLY with the 6-digit code (e.g., 8471.30). If you are unsure, provide the most likely category.`;

      const result = await genAI.models.generateContent({
        model: "gemini-1.5-flash",
        contents: [{ role: 'user', parts: [{ text: prompt }] }],
        config: {
          temperature: 0.2,
        }
      });
      
      const text = result.text || "";
      
      // Extract just the code if the AI added extra text
      const hsCodeMatch = text.match(/\d{4}\.\d{2}/) || text.match(/\d{6}/);
      const hsCode = hsCodeMatch ? hsCodeMatch[0] : text.trim();

      res.json({ hsCode });
    } catch (error: any) {
      console.error("AI HS Code Error:", error);
      
      // Check for specific API key errors
      if (error.message?.includes("API key not valid") || error.status === "INVALID_ARGUMENT") {
        return res.status(500).json({ 
          error: "The provided Gemini API key is invalid. Please check your configuration in the Secrets panel." 
        });
      }

      res.status(500).json({ error: "Failed to generate HS Code. Please try again later." });
    }
  });

  app.post("/api/orders/drone", (req, res) => {
    const order = req.body;
    
    // Basic validation
    if (!order.partner_id || !order.pickup || !order.dropoff) {
      return res.status(400).json({ error: "Invalid order schema. partner_id, pickup, and dropoff are required." });
    }

    const id = order.external_order_id ? `DDP-${order.partner_id}-${order.external_order_id}` : `DDP-${order.partner_id}-${Date.now()}`;
    
    // Store in deliveries for consistency with other systems
    const newDelivery: Delivery = {
      id,
      pickupAddress: order.pickup.address || order.pickup.full_address,
      dropoffAddress: order.dropoff.address || order.dropoff.full_address,
      status: "NEW",
      weight: order.package?.weight_kg ? `${order.package.weight_kg}kg` : "0kg",
      dimensions: order.package?.dimensions_cm ? `${order.package.dimensions_cm.l}x${order.package.dimensions_cm.w}x${order.package.dimensions_cm.h}cm` : "N/A",
      handlingInstructions: order.shipment_options?.handling?.join(', '),
      shipment_options: order.shipment_options,
      createdAt: new Date().toISOString()
    };
    deliveries.push(newDelivery);

    // Store in packages for tracking
    (packages as any)[id] = {
      ...order,
      status: "NEW",
      events: [
        {
          timestamp: new Date().toISOString(),
          location: { address: { addressLocality: order.pickup.address } },
          description: "Drone delivery order received and validated"
        }
      ]
    };

    updatePackageStatus(id, "NEW");

    res.status(201).json({
      success: true,
      order_id: id,
      status: "ACCEPTED",
      estimated_pickup: order.shipment_options?.delivery_window?.start || new Date(Date.now() + 15 * 60000).toISOString(),
      tracking_url: `/track/${id}`,
      shipment_options: order.shipment_options
    });
  });

  app.post("/api/deliveries/status", (req, res) => {
    const { 
      delivery_id, 
      status, 
      estimated_decision_time,
      current_phase,
      eta,
      assigned_drone_id,
      last_known_position,
      weather_risk_score,
      safety_events
    } = req.body;
    
    if (!delivery_id || !status) {
      return res.status(400).json({ error: "Missing delivery_id or status" });
    }

    // Update global tracking if it exists
    const pkg = (packages as any)[delivery_id];
    if (pkg) {
      pkg.status = status;
      if (current_phase) pkg.current_phase = current_phase;
      if (eta) pkg.eta = eta;
      if (assigned_drone_id) pkg.assigned_drone_id = assigned_drone_id;
      if (weather_risk_score !== undefined) pkg.weather_risk_score = weather_risk_score;

      const eventDescription = `Status updated to ${status}${current_phase ? ` (${current_phase})` : ''}${estimated_decision_time ? `. Estimated decision by ${estimated_decision_time}` : ''}`;
      
      pkg.events.push({
        timestamp: new Date().toISOString(),
        description: eventDescription,
        metadata: { 
          estimated_decision_time, 
          current_phase, 
          eta, 
          assigned_drone_id, 
          last_known_position, 
          weather_risk_score, 
          safety_events 
        }
      });

      // Log safety events as separate high-priority events
      if (safety_events && Array.isArray(safety_events)) {
        safety_events.forEach((se: any) => {
          pkg.events.push({
            timestamp: se.timestamp || new Date().toISOString(),
            description: `Safety Alert: ${se.type}`,
            type: "SAFETY_ALERT",
            severity: "HIGH"
          });
        });
      }

      updatePackageStatus(delivery_id, status);
    }

    // Update local delivery list
    const delivery = deliveries.find(d => d.id === delivery_id);
    if (delivery) {
      delivery.status = status;
      if (assigned_drone_id) {
        delivery.courierId = assigned_drone_id;
        // Ensure drone exists in couriers list
        if (!couriers[assigned_drone_id]) {
          couriers[assigned_drone_id] = {
            id: assigned_drone_id,
            name: `Autonomous Drone ${assigned_drone_id.split('-')[1] || assigned_drone_id}`,
            vehicle: "drone",
            verified: true
          };
        }
      }
    }

    // Update drone telemetry and location tracking
    if (assigned_drone_id && last_known_position) {
      const { lat, lon, alt_m, timestamp } = last_known_position;
      const lng = lon; // Map lon to lng for internal consistency
      
      if (!courierPaths[assigned_drone_id]) courierPaths[assigned_drone_id] = [];
      courierPaths[assigned_drone_id].push({ lat, lng, timestamp: Date.now() });

      courierLocations[assigned_drone_id] = {
        courierId: assigned_drone_id,
        lat,
        lng,
        timestamp: timestamp || new Date().toISOString()
      };

      // Broadcast telemetry update via WebSocket
      broadcastTrackingUpdate(delivery_id, { 
        type: "telemetry_update", 
        courierId: assigned_drone_id, 
        location: { lat, lng, alt_m, timestamp },
        weather_risk_score,
        current_phase
      });
    }

    res.json({ 
      success: true, 
      delivery_id, 
      status, 
      updatedAt: new Date().toISOString() 
    });
  });

  app.post("/api/deliveries/complete", (req, res) => {
    const { 
      delivery_id, 
      flight_path, 
      weather, 
      battery_summary, 
      safety_summary, 
      shipment_options,
      package: packageDetails 
    } = req.body;

    if (!delivery_id) {
      return res.status(400).json({ error: "Missing delivery_id" });
    }

    const pkg = (packages as any)[delivery_id];
    if (pkg) {
      pkg.status = "DELIVERED";
      pkg.summary = {
        flight_path,
        weather,
        battery_summary,
        safety_summary,
        packageDetails
      };
      
      if (shipment_options) {
        pkg.shipment_options = shipment_options;
      }
      
      pkg.events.push({
        timestamp: packageDetails?.delivered_at || new Date().toISOString(),
        description: "Delivery completed successfully",
        type: "DELIVERY_COMPLETE",
        metadata: { 
          authentication_passed: packageDetails?.authentication_passed,
          battery_consumed: battery_summary ? (battery_summary.start_soc_pct - battery_summary.end_soc_pct) : null
        }
      });

      if (safety_summary?.events) {
        safety_summary.events.forEach((se: any) => {
          pkg.events.push({
            timestamp: se.timestamp,
            description: `Flight Event: ${se.type} (${se.severity})`,
            type: "FLIGHT_EVENT"
          });
        });
      }

      updatePackageStatus(delivery_id, "DELIVERED");
    }

    const delivery = deliveries.find(d => d.id === delivery_id);
    if (delivery) {
      delivery.status = "DELIVERED";
      delivery.proofOfDelivery = {
        timestamp: packageDetails?.delivered_at || new Date().toISOString()
      };
    }

    res.json({
      success: true,
      delivery_id,
      status: "DELIVERED",
      completedAt: packageDetails?.delivered_at || new Date().toISOString()
    });
  });

  app.post("/api/deliveries/routing", (req, res) => {
    const { 
      delivery_id, 
      shipment_options, 
      routing_constraints, 
      risk_scores, 
      model_outputs,
      routing_decision,
      routing_weights,
      mode_execution,
      route_summary,
      mode_rationale,
      handoff_details,
      route_id,
      robot_id,
      start,
      end,
      waypoints,
      constraints,
      execution_telemetry,
      flight_path,
      weather,
      battery_summary,
      safety_events
    } = req.body;

    if (!delivery_id) {
      return res.status(400).json({ error: "Missing delivery_id" });
    }

    const pkg = (packages as any)[delivery_id];
    if (pkg) {
      if (shipment_options) pkg.shipment_options = shipment_options;
      if (routing_constraints) pkg.routing_constraints = routing_constraints;
      if (risk_scores) pkg.risk_scores = risk_scores;
      if (model_outputs) pkg.model_outputs = model_outputs;
      if (routing_decision) pkg.routing_decision = routing_decision;
      if (routing_weights) pkg.routing_weights = routing_weights;
      if (mode_execution) pkg.mode_execution = mode_execution;
      if (route_summary) pkg.route_summary = route_summary;
      if (mode_rationale) pkg.mode_rationale = mode_rationale;
      if (handoff_details) pkg.handoff_details = handoff_details;
      
      if (route_id || robot_id || start || end || waypoints || constraints || execution_telemetry) {
        pkg.ground_robot_route = {
          route_id: route_id || pkg.ground_robot_route?.route_id,
          robot_id: robot_id || pkg.ground_robot_route?.robot_id,
          start: start || pkg.ground_robot_route?.start,
          end: end || pkg.ground_robot_route?.end,
          waypoints: waypoints || pkg.ground_robot_route?.waypoints,
          constraints: constraints || pkg.ground_robot_route?.constraints,
          execution_telemetry: execution_telemetry || pkg.ground_robot_route?.execution_telemetry
        };
      }
      
      // Update summary if flight data is provided
      if (flight_path || weather || battery_summary || safety_events) {
        if (!pkg.summary) pkg.summary = {};
        if (flight_path) pkg.summary.flight_path = flight_path;
        if (weather) pkg.summary.weather = weather;
        if (battery_summary) pkg.summary.battery_summary = battery_summary;
        if (safety_events) {
          if (!pkg.summary.safety_summary) pkg.summary.safety_summary = { events: [] };
          pkg.summary.safety_summary.events = [...(pkg.summary.safety_summary.events || []), ...safety_events];
        }
      }

      pkg.events.push({
        timestamp: new Date().toISOString(),
        description: "Routing decision and telemetry updated",
        type: "ROUTING_UPDATE",
        metadata: { routing_constraints, risk_scores, routing_decision }
      });
    }

    const delivery = deliveries.find(d => d.id === delivery_id);
    if (delivery) {
      if (shipment_options) delivery.shipment_options = shipment_options;
      if (routing_constraints) delivery.routing_constraints = routing_constraints;
      if (risk_scores) delivery.risk_scores = risk_scores;
      if (model_outputs) delivery.model_outputs = model_outputs;
      if (routing_decision) delivery.routing_decision = routing_decision;
      if (routing_weights) delivery.routing_weights = routing_weights;
      if (mode_execution) delivery.mode_execution = mode_execution;
      if (route_summary) delivery.route_summary = route_summary;
      if (mode_rationale) delivery.mode_rationale = mode_rationale;
      if (handoff_details) delivery.handoff_details = handoff_details;
      
      if (route_id || robot_id || start || end || waypoints || constraints || execution_telemetry) {
        delivery.ground_robot_route = {
          route_id: route_id || delivery.ground_robot_route?.route_id,
          robot_id: robot_id || delivery.ground_robot_route?.robot_id,
          start: start || delivery.ground_robot_route?.start,
          end: end || delivery.ground_robot_route?.end,
          waypoints: waypoints || delivery.ground_robot_route?.waypoints,
          constraints: constraints || delivery.ground_robot_route?.constraints,
          execution_telemetry: execution_telemetry || delivery.ground_robot_route?.execution_telemetry
        };
      }
      
      if (flight_path || weather || battery_summary || safety_events) {
        if (!delivery.summary) delivery.summary = {};
        if (flight_path) delivery.summary.flight_path = flight_path;
        if (weather) delivery.summary.weather = weather;
        if (battery_summary) delivery.summary.battery_summary = battery_summary;
      }
    }

    res.json({
      success: true,
      delivery_id,
      message: "Routing data updated successfully"
    });
  });

  app.post("/api/deliveries/safety-event", (req, res) => {
    const { delivery_id, event } = req.body;
    if (!delivery_id || !event) {
      return res.status(400).json({ error: "Missing delivery_id or event" });
    }
    const pkg = (packages as any)[delivery_id];
    if (pkg) {
      if (!pkg.summary) pkg.summary = {};
      if (!pkg.summary.safety_summary) pkg.summary.safety_summary = { events: [] };
      pkg.summary.safety_summary.events.push({
        ...event,
        timestamp: event.timestamp || new Date().toISOString()
      });
      
      // Also add to main events log
      pkg.events.push({
        timestamp: event.timestamp || new Date().toISOString(),
        description: `Safety Event: ${event.description || event.risk_id}`,
        type: "SAFETY_EVENT",
        metadata: event
      });
      
      res.json({ success: true });
    } else {
      res.status(404).json({ error: "Delivery not found" });
    }
  });

  app.post("/api/drones/telemetry/batch", (req, res) => {
    const { drone_id, firmware_version, batch_timestamp, records } = req.body;

    if (!drone_id || !records || !Array.isArray(records)) {
      return res.status(400).json({ error: "Invalid telemetry batch" });
    }

    // Update drone registry
    if (!couriers[drone_id]) {
      couriers[drone_id] = {
        id: drone_id,
        name: `Autonomous Drone ${drone_id.split('-')[1] || drone_id}`,
        vehicle: "drone",
        verified: true
      };
    }

    // Process records
    records.forEach((record: any) => {
      const { lat, lon, alt_m } = record.position;
      const lng = lon;
      const timestamp = record.ts;

      // Update path
      if (!courierPaths[drone_id]) courierPaths[drone_id] = [];
      courierPaths[drone_id].push({ lat, lng, timestamp: Date.now() });

      // Update current location
      courierLocations[drone_id] = {
        courierId: drone_id,
        lat,
        lng,
        timestamp: timestamp || new Date().toISOString()
      };

      // Broadcast to all active deliveries assigned to this drone
      deliveries.forEach(d => {
        if (d.courierId === drone_id && d.status !== 'DELIVERED') {
          broadcastTrackingUpdate(d.id, {
            type: "telemetry_update",
            courierId: drone_id,
            location: { lat, lng, alt_m, timestamp },
            velocity: record.velocity,
            orientation: record.orientation,
            battery: record.battery,
            sensors: record.sensors,
            weather: record.weather_local,
            safety: record.safety,
            remote_id: record.remote_id
          });
        }
      });
    });

    res.json({
      status: "ACCEPTED",
      records_ingested: records.length,
      batch_id: `TLM-${drone_id}-${Date.now()}`
    });
  });

  app.post("/api/drones/command", (req, res) => {
    const { 
      command_id, 
      type, 
      reason, 
      effective_from, 
      payload,
      delivery_id,
      drone_id 
    } = req.body;

    if (!command_id || !type) {
      return res.status(400).json({ error: "Missing command_id or type" });
    }

    // Log the command in the global tracking system if a delivery_id is provided
    if (delivery_id) {
      const pkg = (packages as any)[delivery_id];
      if (pkg) {
        pkg.events.push({
          timestamp: new Date().toISOString(),
          description: `Command Issued: ${type} (${reason || 'No reason provided'})`,
          type: "COMMAND_ISSUED",
          metadata: { command_id, type, reason, effective_from, payload }
        });

        // If it's a route update, update the planned path in the package summary
        if (type === "UPDATE_ROUTE" && payload?.new_route) {
          if (!pkg.summary) pkg.summary = {};
          if (!pkg.summary.flight_path) pkg.summary.flight_path = {};
          pkg.summary.flight_path.planned = payload.new_route.map((p: any) => ({
            lat: p.lat,
            lng: p.lon || p.lng,
            alt_m: p.alt_m
          }));
        }
      }
    }

    // Broadcast the command via WebSockets
    const targetId = delivery_id || drone_id;
    if (targetId) {
      broadcastTrackingUpdate(targetId, {
        type: "drone_command",
        command_id,
        command_type: type,
        reason,
        effective_from,
        payload
      });
    }

    res.json({
      status: "QUEUED",
      command_id,
      issued_at: new Date().toISOString(),
      target: targetId || "BROADCAST"
    });
  });

  app.post("/api/drones/register", (req, res) => {
    const { 
      drone_id, 
      hardware, 
      sensors, 
      batteries, 
      regulatory 
    } = req.body;

    if (!drone_id) {
      return res.status(400).json({ error: "Missing drone_id" });
    }

    // Update or create drone in the couriers registry
    couriers[drone_id] = {
      id: drone_id,
      name: `Autonomous Drone ${drone_id.split('-')[1] || drone_id}`,
      vehicle: "drone",
      verified: true,
      metadata: {
        hardware,
        sensors,
        batteries,
        regulatory,
        registeredAt: new Date().toISOString()
      }
    };

    res.json({
      drone_id,
      status: "ACTIVE"
    });
  });

  app.post("/api/drones/status", (req, res) => {
    const { 
      drone_id, 
      status, 
      current_firmware, 
      battery, 
      last_maintenance, 
      compliance 
    } = req.body;

    if (!drone_id) {
      return res.status(400).json({ error: "Missing drone_id" });
    }

    // Update the drone's operational status in the registry
    if (couriers[drone_id]) {
      couriers[drone_id].metadata = {
        ...couriers[drone_id].metadata,
        operationalStatus: status,
        current_firmware,
        battery_health: battery,
        last_maintenance,
        compliance,
        lastStatusUpdate: new Date().toISOString()
      };
    }

    // Broadcast status update via WebSockets
    broadcastTrackingUpdate(drone_id, {
      type: "drone_status_update",
      drone_id,
      status,
      compliance
    });

    res.json({
      drone_id,
      status: "ACCEPTED",
      processed_at: new Date().toISOString()
    });
  });

  app.post("/api/drones/delivery/request", (req, res) => {
    const { 
      delivery_id, 
      pickup, 
      dropoff, 
      package: pkg_info, 
      sla 
    } = req.body;

    if (!delivery_id || !pickup || !dropoff) {
      return res.status(400).json({ error: "Missing delivery_id, pickup, or dropoff" });
    }

    // Register the delivery in the global tracking system
    (packages as any)[delivery_id] = {
      id: delivery_id,
      status: "REQUESTED",
      origin: { lat: pickup.lat, lng: pickup.lon || pickup.lng },
      destination: { lat: dropoff.lat, lng: dropoff.lon || dropoff.lng },
      events: [{
        timestamp: new Date().toISOString(),
        description: "Delivery Request Received",
        type: "REQUEST_RECEIVED",
        metadata: { pickup, dropoff, package: pkg_info, sla }
      }],
      summary: {
        weight_kg: pkg_info?.weight_kg,
        sla_tier: sla?.tier,
        deadline: sla?.latest_delivery_time
      }
    };

    // Broadcast the new delivery request via WebSockets
    broadcastTrackingUpdate(delivery_id, {
      type: "delivery_requested",
      delivery_id,
      pickup,
      dropoff,
      sla
    });

    res.json({
      delivery_id,
      status: "ACCEPTED",
      estimated_dispatch: new Date(Date.now() + 300000).toISOString() // +5 mins
    });
  });

  app.post("/api/drones/delivery/reroute", (req, res) => {
    const { 
      delivery_id, 
      current_drone_position, 
      new_dropoff, 
      constraints 
    } = req.body;

    if (!delivery_id || !current_drone_position || !new_dropoff) {
      return res.status(400).json({ error: "Missing required fields for reroute" });
    }

    // Simulate locker validation failure
    if (
      new_dropoff.mode === "SECURE_LOCKER" &&
      new_dropoff.locker_id === "locker-123"
    ) {
      return res.status(400).json({
        status: "OPTIONS_REJECTED",
        reason: "LOCKER_UNAVAILABLE_OR_INVALID"
      });
    }

    const pkg = (packages as any)[delivery_id];
    if (pkg) {
      pkg.dropoff_location = new_dropoff.location;
      if (!pkg.shipment_options) pkg.shipment_options = {};
      pkg.shipment_options.dropoff_mode = new_dropoff.mode;
      
      pkg.events.push({
        timestamp: new Date().toISOString(),
        description: "In-flight reroute requested and approved",
        type: "IN_FLIGHT_REROUTE",
        metadata: { new_dropoff, constraints }
      });
    }

    res.json({
      route_id: `route-${Math.floor(Math.random() * 1000)}`,
      eta: new Date(Date.now() + 1200000).toISOString(), // +20 mins
      waypoints: [
        current_drone_position,
        { lat: (current_drone_position.lat + new_dropoff.location.lat) / 2, lon: (current_drone_position.lon + new_dropoff.location.lon) / 2, alt_m: 100 },
        { lat: new_dropoff.location.lat, lon: new_dropoff.location.lon, alt_m: 0 }
      ],
      feasible: true
    });
  });

  app.post("/api/drones/mission/update", (req, res) => {
    const { mission_id, version, route_id, dropoff_mode, dropoff_location } = req.body;

    if (!mission_id || !version || !route_id) {
      return res.status(400).json({ error: "Missing required fields" });
    }

    if (dropoff_mode === "SECURE_LOCKER") {
      // Reject if locker_id is missing or invalid
      if (!dropoff_location?.locker_id || dropoff_location.locker_id === "locker-123") {
        return res.status(400).json({
          status: "OPTIONS_REJECTED",
          reason: "LOCKER_UNAVAILABLE_OR_INVALID"
        });
      }
    }

    res.json({
      mission_id,
      version: version + 1,
      status: "MISSION_UPDATED",
      processed_at: new Date().toISOString()
    });
  });

  app.post("/api/drones/route/optimize", (req, res) => {
    const { 
      delivery_id, 
      assigned_drone_id, 
      composite_risk_score, 
      route, 
      constraints, 
      explainability 
    } = req.body;

    if (!delivery_id || !assigned_drone_id || !route?.waypoints) {
      return res.status(400).json({ error: "Missing delivery_id, assigned_drone_id, or route waypoints" });
    }

    // Update the delivery in the global tracking system
    const pkg = (packages as any)[delivery_id];
    if (pkg) {
      if (!pkg.summary) pkg.summary = {};
      if (!pkg.summary.flight_path) pkg.summary.flight_path = {};
      
      pkg.summary.flight_path.planned = route.waypoints.map((p: any) => ({
        lat: p.lat,
        lng: p.lon || p.lng,
        alt_m: p.alt_m
      }));

      pkg.summary.risk_score = composite_risk_score;
      pkg.summary.constraints = constraints;
      pkg.summary.explainability = explainability;

      if (!pkg.events) pkg.events = [];
      pkg.events.push({
        timestamp: new Date().toISOString(),
        description: `Route Optimized (Risk Score: ${composite_risk_score})`,
        type: "ROUTE_OPTIMIZED",
        metadata: { assigned_drone_id, composite_risk_score, constraints, explainability }
      });
    }

    // Broadcast the route optimization via WebSockets
    broadcastTrackingUpdate(delivery_id, {
      type: "route_optimized",
      delivery_id,
      assigned_drone_id,
      composite_risk_score,
      route,
      constraints,
      explainability
    });

    res.json({
      delivery_id,
      status: "OPTIMIZED",
      composite_risk_score,
      optimized_at: new Date().toISOString()
    });
  });

  app.post("/api/drones/delivery/evidence", (req, res) => {
    const { 
      delivery_id, 
      flight_logs_ref, 
      telemetry_ref, 
      weather_ref, 
      safety_events_ref, 
      firmware_ref, 
      routing_decision_ref, 
      hash_chain_root, 
      created_at 
    } = req.body;

    if (!delivery_id || !hash_chain_root) {
      return res.status(400).json({ error: "Missing delivery_id or hash_chain_root" });
    }

    // Update the delivery in the global tracking system with evidence references
    const pkg = (packages as any)[delivery_id];
    if (pkg) {
      if (!pkg.evidence) pkg.evidence = {};
      pkg.evidence = {
        flight_logs_ref,
        telemetry_ref,
        weather_ref,
        safety_events_ref,
        firmware_ref,
        routing_decision_ref,
        hash_chain_root,
        archived_at: created_at || new Date().toISOString()
      };

      if (!pkg.events) pkg.events = [];
      pkg.events.push({
        timestamp: new Date().toISOString(),
        description: "Delivery Evidence & Audit Logs Archived",
        type: "EVIDENCE_ARCHIVED",
        metadata: { hash_chain_root, archived_at: created_at }
      });
    }

    // Broadcast the evidence archival via WebSockets
    broadcastTrackingUpdate(delivery_id, {
      type: "evidence_archived",
      delivery_id,
      hash_chain_root,
      archived_at: created_at
    });

    res.json({
      delivery_id,
      status: "ARCHIVED",
      hash_chain_root,
      archived_at: new Date().toISOString()
    });
  });

  app.post("/api/governance/models/register", (req, res) => {
    const { 
      model_id, 
      type, 
      version, 
      owner, 
      intended_use, 
      not_intended_use, 
      performance, 
      safety, 
      security, 
      evidence_refs 
    } = req.body;

    if (!model_id || !version || !owner) {
      return res.status(400).json({ error: "Missing model_id, version, or owner" });
    }

    // Broadcast the model registration via WebSockets
    broadcastTrackingUpdate("GOVERNANCE", {
      type: "model_registered",
      model_id,
      model_type: type,
      version,
      owner,
      registered_at: new Date().toISOString()
    });

    res.json({
      model_id,
      status: "REGISTERED",
      version,
      registered_at: new Date().toISOString()
    });
  });

  app.post("/api/drones/telemetry", (req, res) => {
    const { 
      drone_id, 
      ts, 
      seq, 
      position, 
      velocity, 
      battery, 
      weather_local, 
      safety_mode, 
      delivery_id, 
      signature_valid 
    } = req.body;

    if (!drone_id || !position) {
      return res.status(400).json({ error: "Missing drone_id or position" });
    }

    const { lat, lon, alt_m } = position;
    const lng = lon;
    const timestamp = ts || new Date().toISOString();

    // Update drone registry
    if (!couriers[drone_id]) {
      couriers[drone_id] = {
        id: drone_id,
        name: `Autonomous Drone ${drone_id.split('-')[1] || drone_id}`,
        vehicle: "drone",
        verified: true
      };
    }

    // Update path
    if (!courierPaths[drone_id]) courierPaths[drone_id] = [];
    courierPaths[drone_id].push({ lat, lng, timestamp: Date.now() });

    // Update current location
    courierLocations[drone_id] = {
      courierId: drone_id,
      lat,
      lng,
      timestamp
    };

    // Update the delivery in the global tracking system if a delivery_id is provided
    if (delivery_id) {
      const pkg = (packages as any)[delivery_id];
      if (pkg) {
        if (!pkg.summary) pkg.summary = {};
        if (!pkg.summary.telemetry) pkg.summary.telemetry = {};
        
        pkg.summary.telemetry.current = {
          position: { lat, lon, alt_m },
          velocity,
          battery,
          weather_local,
          safety_mode,
          seq,
          ts: timestamp
        };

        // Broadcast to the specific delivery
        broadcastTrackingUpdate(delivery_id, {
          type: "telemetry_update",
          drone_id,
          delivery_id,
          telemetry: pkg.summary.telemetry.current
        });
      }
    }

    // Broadcast global telemetry update for the drone
    broadcastTrackingUpdate(drone_id, {
      type: "drone_telemetry",
      drone_id,
      telemetry: {
        position: { lat, lon, alt_m },
        velocity,
        battery,
        weather_local,
        safety_mode,
        seq,
        ts: timestamp
      }
    });

    res.json({
      status: "ACCEPTED",
      seq,
      processed_at: new Date().toISOString()
    });
  });

  app.post("/api/drones/safety/event", (req, res) => {
    const { 
      event_id, 
      drone_id, 
      delivery_id, 
      type, 
      severity, 
      ts, 
      inputs, 
      action_taken, 
      result 
    } = req.body;

    if (!event_id || !drone_id || !type || !severity) {
      return res.status(400).json({ error: "Missing event_id, drone_id, type, or severity" });
    }

    // Log the safety event in the global tracking system if a delivery_id is provided
    if (delivery_id) {
      const pkg = (packages as any)[delivery_id];
      if (pkg) {
        if (!pkg.events) pkg.events = [];
        pkg.events.push({
          timestamp: ts || new Date().toISOString(),
          description: `Safety Event: ${type} (${severity}) - ${action_taken}: ${result}`,
          type: "SAFETY_EVENT",
          metadata: { event_id, drone_id, severity, inputs, action_taken, result }
        });

        // Broadcast to the specific delivery
        broadcastTrackingUpdate(delivery_id, {
          type: "safety_event",
          event_id,
          drone_id,
          delivery_id,
          event_type: type,
          severity,
          action_taken,
          result
        });
      }
    }

    // Broadcast global safety alert for the drone
    broadcastTrackingUpdate(drone_id, {
      type: "drone_safety_alert",
      event_id,
      drone_id,
      event_type: type,
      severity,
      ts: ts || new Date().toISOString(),
      action_taken,
      result
    });

    res.json({
      event_id,
      status: "LOGGED",
      processed_at: new Date().toISOString()
    });
  });

  app.post("/api/drones/command", (req, res) => {
    const { drone_id, type, reason, payload_base64 } = req.body;

    if (!drone_id || !type) {
      return res.status(400).json({ error: "Missing drone_id or type" });
    }

    const command_id = `cmd-${crypto.randomBytes(4).toString('hex')}`;
    const payload = payload_base64 ? Buffer.from(payload_base64, 'base64') : Buffer.alloc(0);

    const command = {
      command_id,
      type,
      reason: reason || "Manual override",
      payload
    };

    // Check if drone has an active gRPC stream
    const stream = droneCommandStreams[drone_id];
    if (stream) {
      try {
        stream.write(command);
        console.log(`Command ${command_id} sent to drone ${drone_id} via gRPC stream.`);
        
        // Log the command in the global tracking system (mocking association with a delivery if possible)
        // In a real app, we'd find the active delivery for this drone
        
        res.json({
          status: "SENT",
          command_id,
          drone_id,
          channel: "gRPC"
        });
      } catch (error) {
        console.error(`Failed to write to drone ${drone_id} stream:`, error);
        res.status(500).json({ error: "Failed to send command via stream" });
      }
    } else {
      res.status(404).json({ 
        error: "Drone not connected", 
        message: "No active gRPC command stream found for this drone." 
      });
    }
  });

  app.post("/api/drones/route/compute", async (req, res) => {
    const { start, end, delivery_id, handoff_point, air_leg, ground_leg } = req.body;

    if (handoff_point && air_leg && ground_leg) {
      // Handle hybrid route compute
      return res.json({
        mode: "HYBRID",
        route_id: "route-210",
        air_leg: { route_id: "air-210a", eta: "2026-04-11T15:32:00Z" },
        ground_leg: { route_id: "gr-210b", eta: "2026-04-11T15:48:00Z" },
        overall_eta: "2026-04-11T15:48:00Z",
        feasible: true
      });
    }

    if (!start || !end) {
      return res.status(400).json({ error: "Missing start or end waypoints" });
    }

    // In a real app, this would call the gRPC service internally
    // For this implementation, we'll simulate the gRPC call logic
    const waypoints = [
      start,
      { 
        lat: (start.lat + end.lat) / 2 + 0.001, 
        lon: (start.lon + end.lon) / 2 + 0.001, 
        alt_m: Math.max(start.alt_m, end.alt_m, 50) 
      },
      end
    ];

    const estimated_time_sec = 300;

    if (delivery_id) {
      const pkg = (packages as any)[delivery_id];
      if (pkg) {
        if (!pkg.events) pkg.events = [];
        pkg.events.push({
          timestamp: new Date().toISOString(),
          description: "Autonomous route computed via gRPC RoutingEngine",
          type: "ROUTE_COMPUTED",
          metadata: { waypoints, estimated_time_sec }
        });

        broadcastTrackingUpdate(delivery_id, {
          type: "route_computed",
          delivery_id,
          plan: { waypoints, estimated_time_sec }
        });
      }
    }

    res.json({
      status: "COMPUTED",
      delivery_id,
      plan: { waypoints, estimated_time_sec }
    });
  });

  app.post("/api/drones/safety/report", (req, res) => {
    const { drone_id, type, severity, timestamp_ms } = req.body;

    if (!drone_id || !type || !severity) {
      return res.status(400).json({ error: "Missing required safety event fields" });
    }

    const event_id = `evt-${crypto.randomBytes(4).toString('hex')}`;
    const ts = timestamp_ms || Date.now();

    console.warn(`REST SAFETY REPORT [${severity}] from ${drone_id}: ${type}`);

    broadcastTrackingUpdate(drone_id, {
      type: "safety_event",
      drone_id,
      event: {
        event_id,
        type,
        severity,
        ts: new Date(Number(ts)).toISOString()
      }
    });

    res.json({
      status: "REPORTED",
      event_id,
      drone_id
    });
  });

  // --- Partner API v1 (OpenAPI Implementation) ---

  app.post("/v1/deliveries", (req, res) => {
    const { pickup, dropoff, package: pkgInfo, partner_id, external_order_id } = req.body;

    if (!pickup || !dropoff || !pkgInfo) {
      return res.status(400).json({ error: "Missing required fields: pickup, dropoff, or package" });
    }

    const delivery_id = `DDP-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
    const now = new Date().toISOString();

    const newPackage = {
      status: "NEW",
      pickupAddress: pickup.address || `${pickup.lat}, ${pickup.lng}`,
      dropoffAddress: dropoff.address || `${dropoff.lat}, ${dropoff.lng}`,
      senderName: partner_id || "Partner",
      receiverName: "Recipient",
      events: [
        {
          timestamp: now,
          description: "Delivery request created via Partner API",
          type: "CREATED",
          location: pickup
        }
      ],
      partnerTrackingIds: external_order_id ? [external_order_id] : [],
      metadata: {
        weight_kg: pkgInfo.weight_kg,
        dimensions: pkgInfo.dimensions,
        contents: pkgInfo.contents,
        pickup_coords: pickup,
        dropoff_coords: dropoff
      }
    };

    (packages as any)[delivery_id] = newPackage;

    console.log(`Partner API: Created delivery ${delivery_id} for partner ${partner_id}`);

    res.json({
      delivery_id,
      status: "NEW",
      estimated_arrival: new Date(Date.now() + 3600000).toISOString() // Mock 1 hour
    });
  });

  app.get("/v1/deliveries/:id", (req, res) => {
    const { id } = req.params;
    const pkg = (packages as any)[id];

    if (!pkg) {
      return res.status(404).json({ error: "Delivery not found" });
    }

    // Map internal 'packages' structure to OpenAPI 'DeliveryStatus' schema
    const response = {
      id,
      status: pkg.status,
      current_location: pkg.events[pkg.events.length - 1]?.location || { lat: 0, lng: 0 },
      estimated_arrival: new Date(Date.now() + 1800000).toISOString(), // Mock 30 mins remaining
      events: pkg.events.map((e: any) => ({
        timestamp: e.timestamp,
        description: e.description,
        type: e.type || "STATUS_UPDATE"
      }))
    };

    res.json(response);
  });

  app.post("/api/partner/webhook", async (req, res) => {
    const event = req.body;
    const result = handlePartnerEvent(event);
    if (result.error) return res.status(400).json({ error: result.error });
    res.json({ success: true, eventId: event.eventId });
  });

  app.post("/partner/webhook/delivery-outcome", async (req, res) => {
    const { 
      globalTrackingId, 
      outcome, 
      finalStatus,
      timestamp, 
      deliveredAt,
      proof, 
      recipient,
      proofOfDeliveryUrl,
      partnerId, 
      location 
    } = req.body;

    const effectiveOutcome = outcome || finalStatus;
    const effectiveTimestamp = timestamp || deliveredAt;
    const effectiveProof = proof || (recipient || proofOfDeliveryUrl ? { 
      recipient, 
      photo: proofOfDeliveryUrl,
      timestamp: effectiveTimestamp || new Date().toISOString()
    } : undefined);

    if (!globalTrackingId || !effectiveOutcome) {
      return res.status(400).json({
        status: "rejected",
        error: "INVALID_SCHEMA",
        details: ["missing field: globalTrackingId or outcome/finalStatus"]
      });
    }

    const pkg = (packages as any)[globalTrackingId];
    if (!pkg) {
      return res.status(404).json({
        status: "rejected",
        error: "PACKAGE_NOT_FOUND"
      });
    }

    // Map outcome to internal status
    const statusMap: Record<string, string> = {
      "SUCCESS": "DELIVERED",
      "DELIVERED": "DELIVERED",
      "FAILED": "FAILED",
      "RETURNED": "RETURNED"
    };

    const targetStatus = statusMap[effectiveOutcome.toUpperCase()] || effectiveOutcome.toUpperCase();
    
    updatePackageStatus(globalTrackingId, targetStatus, effectiveProof);

    // Add event
    if (!pkg.events) pkg.events = [];
    pkg.events.push({
      timestamp: effectiveTimestamp || new Date().toISOString(),
      location: location || { address: { addressLocality: "Unknown" } },
      description: `Delivery outcome reported by partner: ${effectiveOutcome}`,
      partnerInfo: { partnerId, localTrackingId: pkg.partnerTrackingIds?.[0] }
    });

    res.json({
      status: "accepted",
      globalTrackingId,
      newStatus: targetStatus,
      processedAt: new Date().toISOString()
    });
  });

  app.post("/ingest/event", async (req, res) => {
    const authHeader = req.headers.authorization;
    const partnerIdHeader = req.headers['x-partner-id'];
    const signatureHeader = req.headers['x-signature'];
    
    const expectedToken = process.env.PARTNER_TOKEN || "uaps_partner_secret_123";
    const signingSecret = process.env.PARTNER_SIGNING_SECRET || "uaps_signing_key_456";

    // 1. Bearer Token Check
    if (!authHeader || authHeader !== `Bearer ${expectedToken}`) {
      return res.status(401).json({ 
        status: "rejected",
        error: "INVALID_AUTH_TOKEN" 
      });
    }

    // 2. Partner ID Check
    if (!partnerIdHeader) {
      return res.status(400).json({ 
        status: "rejected",
        error: "MISSING_PARTNER_ID" 
      });
    }

    const authorizedPartners = ["DHL-KE", "KQ-AIR", "POSTA-UG", "FEDEX-NG", "UPS-ET", "PARTNER-P1-ABC", "PARTNER-P2-XYZ"];
    if (!authorizedPartners.includes(partnerIdHeader as string)) {
      return res.status(403).json({
        status: "rejected",
        error: "UNAUTHORIZED_PARTNER"
      });
    }

    // 3. Signature Verification
    if (!signatureHeader) {
      return res.status(400).json({ 
        status: "rejected",
        error: "MISSING_SIGNATURE" 
      });
    }

    const payload = JSON.stringify(req.body);
    const expectedSignature = crypto.createHash('sha256').update(payload + signingSecret).digest('hex');
    
    if (signatureHeader !== expectedSignature) {
      return res.status(401).json({ 
        status: "rejected",
        error: "INVALID_SIGNATURE" 
      });
    }

    const event = req.body;
    // Inject partnerId from header if missing in payload
    if (!event.partnerId && partnerIdHeader) {
      event.partnerId = partnerIdHeader;
    }

    const result = handlePartnerEvent(event);
    if (result.error) {
      if (result.missingFields) {
        return res.status(400).json({
          status: "rejected",
          error: "INVALID_SCHEMA",
          details: result.missingFields.map((f: string) => `missing field: ${f}`)
        });
      }
      return res.status(400).json({ 
        status: "rejected",
        error: result.error.toUpperCase().replace(/\s+/g, '_') 
      });
    }
    
    // Generate a ledger hash for the event to simulate immutable record
    const ledgerHash = crypto.createHash('sha256')
      .update(JSON.stringify(event) + Date.now().toString())
      .digest('hex');

    res.json({ 
      status: "accepted",
      ledgerHash: `0x${ledgerHash}`,
      receivedAt: new Date().toISOString(),
      eventId: event.eventId 
    });
  });

  function handlePartnerEvent(event: any) {
    const { globalTrackingId, eventType, location, timestamp, partnerId, metadata } = event;

    const missingFields = [];
    if (!globalTrackingId) missingFields.push("globalTrackingId");
    if (!eventType) missingFields.push("eventType");

    if (missingFields.length > 0) {
      return { error: "Missing required fields", missingFields };
    }

    const pkg = (packages as any)[globalTrackingId];
    if (!pkg) {
      // For demo purposes, if it doesn't exist, create a mock package
      (packages as any)[globalTrackingId] = {
        status: "IN_TRANSIT",
        pickupAddress: "Lagos, Nigeria",
        dropoffAddress: "Nairobi, Kenya",
        senderName: "Global Partner",
        receiverName: "UAPS Customer",
        events: [],
        partnerTrackingIds: []
      };
    }

    const targetPkg = (packages as any)[globalTrackingId];

    // Maintain a list of partner tracking IDs
    const localId = metadata?.localTrackingId || event.localTrackingId;
    if (localId) {
      if (!targetPkg.partnerTrackingIds) targetPkg.partnerTrackingIds = [];
      if (!targetPkg.partnerTrackingIds.includes(localId)) {
        targetPkg.partnerTrackingIds.push(localId);
      }
    }

    // Map partner event types to descriptions
    const eventDescriptions: Record<string, string> = {
      "DISPATCHED": "Shipment dispatched from origin",
      "ARRIVED_AT_HUB": `Arrived at ${metadata?.hubCode || 'Partner Hub'} (${partnerId})`,
      "DEPARTED_FROM_HUB": `Departed from ${metadata?.hubCode || 'Partner Hub'} (${partnerId})`,
      "DEPARTED_HUB": `Departed from ${metadata?.hubCode || 'Partner Hub'} (${partnerId})`,
      "IN_TRANSIT": `In transit via ${metadata?.vehicleId || 'Partner Vehicle'}`,
      "CUSTOMS_IN": "Arrived at Customs",
      "CUSTOMS_OUT": "Cleared Customs",
      "OUT_FOR_DELIVERY": "Out for delivery",
      "FAILED_ATTEMPT": "Delivery attempt failed",
      "DELIVERED": "Delivered by partner",
      "EXCEPTION": `Shipment exception: ${metadata?.reason || 'Unknown issue'}`,
      "CUSTOMS_CLEARED": "Cleared customs",
      "CUSTOMS_HOLD": "Held at customs"
    };

    const description = eventDescriptions[eventType] || `Status updated: ${eventType}`;
    
    const newEvent = {
      timestamp: timestamp || new Date().toISOString(),
      location: {
        address: {
          addressLocality: location ? `${location.city}, ${location.country}` : "Partner Facility"
        },
        geo: location ? { latitude: location.lat, longitude: location.lng } : undefined
      },
      description,
      partnerInfo: {
        partnerId,
        localTrackingId: metadata?.localTrackingId || event.localTrackingId
      }
    };

    if (!targetPkg.events) targetPkg.events = [];
    targetPkg.events.push(newEvent);
    
    // Update status if it's a major status change
    if (eventType === "DELIVERED") {
      updatePackageStatus(globalTrackingId, "DELIVERED");
    } else if (["OUT_FOR_DELIVERY", "IN_TRANSIT", "DISPATCHED", "ARRIVED_AT_HUB", "DEPARTED_HUB", "DEPARTED_FROM_HUB", "CUSTOMS_IN", "CUSTOMS_OUT"].includes(eventType)) {
      updatePackageStatus(globalTrackingId, "IN_TRANSIT");
    } else if (eventType === "FAILED_ATTEMPT" || eventType === "EXCEPTION") {
      updatePackageStatus(globalTrackingId, "EXCEPTION");
    } else {
      // Just broadcast the new event
      broadcastTrackingUpdate(globalTrackingId, { 
        type: "status_update", 
        status: newEvent, 
        timestamp: Date.now() 
      });
    }

    return { success: true };
  }

  app.post("/api/subscribe", (req, res) => {
    const { trackingId, subscription } = req.body;
    if (!pushSubscribers[trackingId]) pushSubscribers[trackingId] = [];
    pushSubscribers[trackingId].push(subscription);
    res.json({ success: true });
  });

  app.post("/api/courier/location", (req, res) => {
    const { courierId, lat, lng } = req.body as { courierId: string; lat: number; lng: number };
    if (!courierId) return res.status(400).json({ error: "Missing courierId" });
    
    if (!courierPaths[courierId]) courierPaths[courierId] = [];
    const timestamp = new Date().toISOString();
    courierPaths[courierId].push({ lat, lng, timestamp: Date.now() });

    courierLocations[courierId] = {
      courierId,
      lat,
      lng,
      timestamp
    };

    // Find all active deliveries for this courier and broadcast location
    deliveries.forEach(d => {
      if (d.courierId === courierId && d.status !== 'DELIVERED') {
        broadcastTrackingUpdate(d.id, { 
          type: "location_update", 
          courierId, 
          location: { lat, lng, timestamp } 
        });

        // Broadcast for TrackMyCourierMap
        broadcastTrackingUpdate(d.id, {
          type: "tracking_update",
          courierLocation: { lat, lng },
          path: courierPaths[courierId].map(p => ({ lat: p.lat, lng: p.lng })),
          etaMinutes: 12, // Mock ETA
          status: d.status
        });
      }
    });

    res.json({ success: true });
  });

  app.get("/api/courier/path/:id", (req, res) => {
    res.json(courierPaths[req.params.id] || []);
  });

  app.get("/api/courier/location/:id", (req, res) => {
    const id = req.params.id;
    res.json(courierLocations[id] || null);
  });

  // AI Route Optimization Endpoint (Mock for now to follow Gemini-on-frontend best practices)
  app.post("/api/optimize-route", (req, res) => {
    const { start, end } = req.body;
    
    // Simple mock: return a few points between start and end
    // In a real app, you would call Gemini from the frontend instead.
    const route = [
      { lat: 6.45, lng: 3.39 }, // Lagos
      { lat: 6.33, lng: 5.62 }, // Benin City
      { lat: 5.60, lng: -0.18 } // Accra
    ];
    
    res.json({ route });
  });

  app.post("/api/optimize-multistop", async (req, res) => {
    // Removed backend Gemini logic. Frontend should call Gemini directly.
    res.status(501).json({ error: "Please use the frontend routeService for multi-stop optimization." });
  });

  // API Gateway VTL mapping template simulation middleware
  app.use("/api", (req, res, next) => {
    const originalJson = res.json;
    res.json = function (body) {
      // Avoid double-wrapping if already mapped
      if (body && Object.keys(body).length === 2 && body.status === "ok" && body.data !== undefined) {
        return originalJson.call(this, body);
      }
      // Apply the VTL mapping: { "status": "ok", "data": $input.json('$') }
      return originalJson.call(this, {
        status: "ok",
        data: body
      });
    };
    next();
  });

  app.get("/api/governance/metrics", (req, res) => {
    res.json({
      trustScore: 94.2 + (Math.random() - 0.5),
      fairness: {
        deviation: 0.02 + (Math.random() * 0.01),
        parity: 0.98 - (Math.random() * 0.02)
      },
      reliability: {
        sla: 99.98,
        latency: 42 + Math.floor(Math.random() * 5)
      },
      security: {
        abuseAttempts: Math.floor(Math.random() * 15),
        hygiene: 98
      }
    });
  });

  app.get("/api/partners/:partner_id/shipments", (req, res) => {
    const { partner_id } = req.params;
    // Mock shipments data based on partner
    const shipments = [
      {
        id: "shp-901",
        tracking_id: "UAPS-778899",
        status: "IN_TRANSIT",
        origin: "Mombasa, Kenya",
        destination: "Kigali, Rwanda",
        updated_at: new Date(Date.now() - 3600000).toISOString()
      },
      {
        id: "shp-902",
        tracking_id: "UAPS-445566",
        status: "DELIVERED",
        origin: "Dar es Salaam, Tanzania",
        destination: "Bujumbura, Burundi",
        updated_at: new Date(Date.now() - 86400000).toISOString()
      },
      {
        id: "shp-903",
        tracking_id: "UAPS-112233",
        status: "CUSTOMS_CLEARED",
        origin: "Lome, Togo",
        destination: "Ouagadougou, BFA",
        updated_at: new Date(Date.now() - 7200000).toISOString()
      }
    ];
    res.json(shipments);
  });

  app.get("/api/partners/scorecards", (req, res) => {
    res.json([
      {
        partner_id: "AGL",
        name: "AGL Logistics",
        overall_score: 92,
        certification_level: "ELITE",
        metrics: {
          operational: 88,
          compliance: 95,
          cx: 90
        },
        corridors: [
          { corridor: "Northern Corridor", performance: 89, risk_score: 0.18 },
          { corridor: "Central Corridor", performance: 94, risk_score: 0.22 }
        ]
      },
      {
        partner_id: "RELOAD",
        name: "Reload Logistics",
        overall_score: 88,
        certification_level: "ADVANCED",
        metrics: {
          operational: 84,
          compliance: 90,
          cx: 85
        },
        corridors: [
          { corridor: "Central Corridor", performance: 91, risk_score: 0.24 },
          { corridor: "Lome-Ouaga", performance: 86, risk_score: 0.35 }
        ]
      },
      {
        partner_id: "MAERSK",
        name: "Maersk",
        overall_score: 95,
        certification_level: "ELITE",
        metrics: {
          operational: 96,
          compliance: 98,
          cx: 91
        },
        corridors: [
          { corridor: "Sea Route (Rotterdam-Lome)", performance: 97, risk_score: 0.12 }
        ]
      }
    ]);
  });

  // --- Pan-Africa Multimodal Routing API Mock Endpoints ---
  const routingRouter = express.Router();
  
  routingRouter.post("/routing/plan", (req, res) => {
    // Return 400 if constraints violate rules
    if (req.body.constraints?.forbidden_modes?.includes("AIR")) {
      return res.status(400).json({
        code: "INVALID_CONSTRAINT",
        message: "Forbidden mode: AIR",
        details: {
          field: "constraints.forbidden_modes"
        }
      });
    }

    res.json({
      route_id: "route-456",
      legs: [
        {
          leg_id: "leg-001",
          mode: "SEA",
          from: "Rotterdam",
          to: "Lome",
          partner: "Maersk",
          corridor: "west-africa-sea",
          eta: "2026-04-10T09:00:00Z",
          risk_score: 0.12,
          reliability_score: 0.89
        },
        {
          leg_id: "leg-002",
          mode: "ROAD",
          from: "Lome",
          to: "Kigali",
          partner: "Reload Logistics",
          corridor: "central-001",
          eta: "2026-04-17T09:00:00Z",
          risk_score: 0.24,
          reliability_score: 0.81
        }
      ],
      eta: "2026-04-17T09:00:00Z",
      risk_score: 0.24,
      reliability_score: 0.81,
      score: 0.63,
      time_days: 17,
      cost_index: 1.0,
      corridor_summary: [
        { corridor: "west-africa-sea", risk_score: 0.12, primary_partner: "Maersk" },
        { corridor: "central-001", risk_score: 0.24, primary_partner: "Reload Logistics" }
      ]
    });
  });

  routingRouter.post("/routing/reroute", (req, res) => {
    res.json({
      previous_route_id: req.body.route_id || "route-456",
      reason: req.body.reason || "RISK_INCREASE",
      route_id: "route-789",
      legs: [
        { leg_id: "leg-003", mode: "AIR", from: "Rotterdam", to: "Kigali", corridor: "air-hub", partner: "KQ-AIR", eta: "2026-04-18T12:00:00Z", time_days: 2, cost_index: 3.5, risk_score: 0.05, reliability_score: 0.98 }
      ],
      eta: "2026-04-18T12:00:00Z",
      time_days: 12,
      cost_index: 2.1,
      risk_score: 0.19,
      reliability_score: 0.92,
      score: 88.1,
      corridor_summary: [
        { corridor: "air-hub", risk_score: 0.05, primary_partner: "KQ-AIR" }
      ]
    });
  });

  routingRouter.get("/routing/routes/:route_id", (req, res) => {
    res.json({
      route_id: req.params.route_id,
      legs: [
        {
          leg_id: "leg-001",
          mode: "SEA",
          from: "Rotterdam",
          to: "Lome",
          partner: "Maersk",
          corridor: "west-africa-sea",
          eta: "2026-04-10T09:00:00Z",
          risk_score: 0.12,
          reliability_score: 0.89
        },
        {
          leg_id: "leg-002",
          mode: "ROAD",
          from: "Lome",
          to: "Kigali",
          partner: "Reload Logistics",
          corridor: "central-001",
          eta: "2026-04-17T09:00:00Z",
          risk_score: 0.24,
          reliability_score: 0.81
        }
      ],
      eta: "2026-04-17T09:00:00Z",
      risk_score: 0.24,
      reliability_score: 0.81,
      score: 0.63,
      time_days: 17,
      cost_index: 1.0,
      corridor_summary: [
        { corridor: "west-africa-sea", risk_score: 0.12, primary_partner: "Maersk" },
        { corridor: "central-001", risk_score: 0.24, primary_partner: "Reload Logistics" }
      ]
    });
  });

  routingRouter.get("/routing/corridors", (req, res) => {
    res.json([
      {
        corridor_id: "northern-001",
        name: "Northern Corridor",
        countries: ["Kenya", "Uganda", "Rwanda", "DRC"],
        risk_score: 0.41,
        factors: { border_delay: 0.22, weather: 0.11, security: 0.08 },
        border_points: [
          { name: "Malaba", wait_time_hours: 4.5 },
          { name: "Busia", wait_time_hours: 3.2 }
        ],
        recommended: false
      },
      {
        corridor_id: "central-001",
        name: "Central Corridor",
        countries: ["Tanzania", "Rwanda", "Burundi"],
        risk_score: 0.21,
        factors: { border_delay: 0.12, weather: 0.05, security: 0.04 },
        border_points: [
          { name: "Rusumo", wait_time_hours: 1.8 }
        ],
        recommended: true
      }
    ]);
  });

  routingRouter.get("/routing/corridors/:corridor_id", (req, res) => {
    const isNorthern = req.params.corridor_id.includes("northern");
    res.json({
      corridor_id: req.params.corridor_id,
      name: isNorthern ? "Northern Corridor" : "Central Corridor",
      countries: isNorthern ? ["Kenya", "Uganda", "Rwanda"] : ["Tanzania", "Rwanda"],
      risk_score: isNorthern ? 0.41 : 0.21,
      factors: isNorthern ? { border_delay: 0.22, weather: 0.11, security: 0.08 } : { border_delay: 0.12, weather: 0.05, security: 0.04 },
      border_points: isNorthern ? [
        { name: "Malaba", wait_time_hours: 4.5 }
      ] : [
        { name: "Rusumo", wait_time_hours: 1.8 }
      ],
      recommended: !isNorthern
    });
  });

  routingRouter.get("/routing/modes", (req, res) => {
    res.json([
      {
        mode: "ROAD",
        partners: ["AGL", "Reload Logistics"],
        corridors: ["central-001", "northern-001"],
        max_weight_kg: 28000
      }
    ]);
  });

  routingRouter.post("/routing/evaluate", (req, res) => {
    res.json({
      route_id: "route-456",
      still_compliant: false,
      current_risk_score: 0.47,
      recommendation: "REROUTE",
      reason: "Risk threshold exceeded"
    });
  });

  routingRouter.get("/fleet", (req, res) => {
    res.json(Object.values(couriers));
  });

  routingRouter.get("/fleet/:id", (req, res) => {
    const courier = couriers[req.params.id];
    if (courier) {
      res.json(courier);
    } else {
      res.status(404).json({ error: "Vehicle/Fleet item not found" });
    }
  });

  routingRouter.get("/health", (req, res) => {
    res.json({ status: "ok" });
  });

  app.use("/api/v1", routingRouter);

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  // --- Simulation Loop for Live Dashboard ---
  const mockDrones = ["DRONE-001", "DRONE-002", "DRONE-003", "DRONE-004"];
  const droneStates: Record<string, any> = {};

  mockDrones.forEach(id => {
    droneStates[id] = {
      lat: -1.286389 + (Math.random() - 0.5) * 0.1,
      lng: 36.817223 + (Math.random() - 0.5) * 0.1,
      alt: 50 + Math.random() * 20,
      battery: 95 - Math.random() * 10,
      velocity: 10 + Math.random() * 5
    };
  });

  setInterval(() => {
    mockDrones.forEach(id => {
      const state = droneStates[id];
      // Move slightly
      state.lat += (Math.random() - 0.5) * 0.001;
      state.lng += (Math.random() - 0.5) * 0.001;
      state.alt = Math.max(10, Math.min(120, state.alt + (Math.random() - 0.5) * 2));
      state.battery = Math.max(0, state.battery - 0.01);
      state.velocity = Math.max(0, state.velocity + (Math.random() - 0.5));

      // Update registry
      courierLocations[id] = {
        courierId: id,
        lat: state.lat,
        lng: state.lng,
        timestamp: new Date().toISOString()
      };

      if (!courierPaths[id]) courierPaths[id] = [];
      courierPaths[id].push({ lat: state.lat, lng: state.lng, timestamp: Date.now() });
      if (courierPaths[id].length > 100) courierPaths[id].shift();

      // Broadcast telemetry
      broadcastTrackingUpdate(id, {
        type: "telemetry_update",
        courierId: id,
        location: { 
          lat: state.lat, 
          lng: state.lng, 
          alt_m: state.alt, 
          timestamp: new Date().toISOString() 
        },
        battery: { soc_pct: Math.round(state.battery), temp_c: 35 + Math.random() * 5 },
        velocity: { vx_mps: state.velocity },
        safety: { current_mode: "AUTO" }
      });

      // Occasionally broadcast gRPC telemetry
      if (Math.random() > 0.8) {
        broadcastTrackingUpdate(id, {
          type: "telemetry_update_grpc",
          courierId: id,
          location: { 
            lat: state.lat, 
            lng: state.lng, 
            alt_m: state.alt, 
            timestamp: new Date().toISOString() 
          },
          battery: { soc_pct: Math.round(state.battery), temp_c: 35 + Math.random() * 5 },
          velocity: { vx_mps: state.velocity },
          safety: { current_mode: "AUTO" }
        });
      }
    });
  }, 3000);

  // Occasional Safety Events
  setInterval(() => {
    if (Math.random() > 0.7) {
      const droneId = mockDrones[Math.floor(Math.random() * mockDrones.length)];
      const types = ["GEOFENCE_VIOLATION", "LOW_BATTERY", "SIGNAL_LOSS", "OBSTACLE_DETECTED"];
      const type = types[Math.floor(Math.random() * types.length)];
      
      broadcastTrackingUpdate(droneId, {
        type: "safety_event",
        drone_id: droneId,
        event: {
          event_id: `evt-${crypto.randomBytes(2).toString('hex')}`,
          type,
          severity: Math.random() > 0.5 ? "MEDIUM" : "HIGH",
          ts: new Date().toISOString()
        }
      });
    }
  }, 10000);

  server.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });

  // gRPC Server Implementation
  const PROTO_PATH = path.join(process.cwd(), "telemetry.proto");
  const packageDefinition = protoLoader.loadSync(PROTO_PATH, {
    keepCase: true,
    longs: String,
    enums: String,
    defaults: true,
    oneofs: true,
  });
  const telemetryProto: any = grpc.loadPackageDefinition(packageDefinition);

  const COMMAND_PROTO_PATH = path.join(process.cwd(), "commands.proto");
  const commandPackageDefinition = protoLoader.loadSync(COMMAND_PROTO_PATH, {
    keepCase: true,
    longs: String,
    enums: String,
    defaults: true,
    oneofs: true,
  });
  const commandProto: any = grpc.loadPackageDefinition(commandPackageDefinition);

  const ROUTING_PROTO_PATH = path.join(process.cwd(), "routing.proto");
  const routingPackageDefinition = protoLoader.loadSync(ROUTING_PROTO_PATH, {
    keepCase: true,
    longs: String,
    enums: String,
    defaults: true,
    oneofs: true,
  });
  const routingProto: any = grpc.loadPackageDefinition(routingPackageDefinition);

  const SAFETY_PROTO_PATH = path.join(process.cwd(), "safety.proto");
  const safetyPackageDefinition = protoLoader.loadSync(SAFETY_PROTO_PATH, {
    keepCase: true,
    longs: String,
    enums: String,
    defaults: true,
    oneofs: true,
  });
  const safetyProto: any = grpc.loadPackageDefinition(safetyPackageDefinition);

  const grpcServer = new grpc.Server();

  grpcServer.addService(telemetryProto.TelemetryIngest.service, {
    StreamTelemetry: (call: any, callback: any) => {
      let recordsIngested = 0;
      
      call.on("data", (record: any) => {
        recordsIngested++;
        const { drone_id, timestamp_ms, seq, position, velocity, battery } = record;
        
        if (!drone_id || !position) return;

        const { lat, lon, alt_m } = position;
        const lng = lon;
        const timestamp = new Date(Number(timestamp_ms)).toISOString();

        // Update drone registry
        if (!couriers[drone_id]) {
          couriers[drone_id] = {
            id: drone_id,
            name: `Autonomous Drone ${drone_id.split('-')[1] || drone_id}`,
            vehicle: "drone",
            verified: true
          };
        }

        // Update path
        if (!courierPaths[drone_id]) courierPaths[drone_id] = [];
        courierPaths[drone_id].push({ lat, lng, timestamp: Date.now() });

        // Update current location
        courierLocations[drone_id] = {
          courierId: drone_id,
          lat,
          lng,
          timestamp
        };

        // Broadcast global telemetry update for the drone
        broadcastTrackingUpdate(drone_id, {
          type: "drone_telemetry_grpc",
          drone_id,
          telemetry: {
            position: { lat, lon, alt_m },
            velocity,
            battery,
            seq,
            ts: timestamp,
            source: "gRPC"
          }
        });
      });

      call.on("end", () => {
        callback(null, { accepted: true, records_ingested: recordsIngested });
      });
    },
  });

  grpcServer.addService(commandProto.CommandService.service, {
    SendCommand: (call: any, callback: any) => {
      const { command_id, type, reason, payload } = call.request;
      // In a real app, we might route this to a specific drone's active stream
      // For now, we'll just log it and return success
      console.log(`Received command ${command_id} of type ${type} for manual routing.`);
      callback(null, { 
        command_id, 
        drone_id: "system", 
        success: true, 
        message: "Command received by orchestrator" 
      });
    },
    StreamCommands: (call: any) => {
      const { drone_id } = call.request;
      if (!drone_id) {
        call.end();
        return;
      }
      
      console.log(`Drone ${drone_id} connected for command streaming.`);
      droneCommandStreams[drone_id] = call;

      call.on("cancelled", () => {
        console.log(`Drone ${drone_id} command stream cancelled.`);
        delete droneCommandStreams[drone_id];
      });
    },
    AckCommand: (call: any, callback: any) => {
      const { command_id, drone_id, success, message } = call.request;
      console.log(`Command ${command_id} ack from ${drone_id}: ${success ? 'SUCCESS' : 'FAILURE'} - ${message}`);
      
      // Broadcast the ack to the UI
      broadcastTrackingUpdate(drone_id, {
        type: "command_ack",
        command_id,
        drone_id,
        success,
        message
      });

      callback(null, { success: true });
    },
  });

  grpcServer.addService(routingProto.RoutingEngine.service, {
    ComputeRoute: (call: any, callback: any) => {
      const { start, end, delivery_id } = call.request;
      
      if (!start || !end) {
        return callback({
          code: grpc.status.INVALID_ARGUMENT,
          message: "Start and end waypoints are required."
        });
      }

      console.log(`Computing route for delivery ${delivery_id || 'unspecified'}...`);

      // Simple linear interpolation for mock routing
      const waypoints = [
        start,
        { 
          lat: (start.lat + end.lat) / 2 + 0.001, 
          lon: (start.lon + end.lon) / 2 + 0.001, 
          alt_m: Math.max(start.alt_m, end.alt_m, 50) 
        },
        end
      ];

      const estimated_time_sec = 300; // 5 minutes mock

      // Broadcast the routing decision if delivery_id is present
      if (delivery_id) {
        broadcastTrackingUpdate(delivery_id, {
          type: "route_computed_grpc",
          delivery_id,
          plan: {
            waypoints,
            estimated_time_sec
          }
        });
      }

      callback(null, { waypoints, estimated_time_sec });
    },
  });

  grpcServer.addService(safetyProto.SafetyEngine.service, {
    ReportSafetyEvent: (call: any, callback: any) => {
      const { event_id, drone_id, type, severity, timestamp_ms } = call.request;
      
      console.warn(`SAFETY EVENT [${severity}] from ${drone_id}: ${type} (ID: ${event_id})`);

      // Broadcast to UI
      broadcastTrackingUpdate(drone_id, {
        type: "safety_event_grpc",
        drone_id,
        event: {
          event_id,
          type,
          severity,
          ts: new Date(Number(timestamp_ms)).toISOString()
        }
      });

      // Also log to the global safety events if possible
      // In a real app, we'd persist this to Firestore
      
      callback(null, { success: true });
    },
  });

  const GRPC_PORT = 3001;
  grpcServer.bindAsync(`0.0.0.0:${GRPC_PORT}`, grpc.ServerCredentials.createInsecure(), (err, port) => {
    if (err) {
      console.error(`gRPC server failed to bind: ${err.message}`);
      return;
    }
    console.log(`gRPC server running on port ${port}`);
  });
}

function broadcastTrackingUpdate(trackingId: string, payload: any) {
  if ((global as any).broadcastTrackingUpdate) {
    (global as any).broadcastTrackingUpdate(trackingId, payload);
  }
}

startServer();
