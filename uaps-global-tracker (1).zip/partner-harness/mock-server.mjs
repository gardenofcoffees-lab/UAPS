import express from "express";

const app = express();

app.use(express.json());

// Mock database
const mockFleet = [
  {
    id: "veh_mock_1",
    partnerId: "partner_abc",
    mode: "truck",
    lat: -1.2921,
    lng: 36.8219,
    heading: 90,
    speedKph: 42,
    updatedAt: "2026-04-16T15:00:00Z"
  },
  {
    id: "veh_mock_2",
    partnerId: "partner_abc",
    mode: "moto",
    lat: -1.2951,
    lng: 36.8259,
    heading: 120,
    speedKph: 35,
    updatedAt: "2026-04-16T14:00:00Z"
  },
  {
    id: "veh_mock_3",
    partnerId: "partner_xyz",
    mode: "drone",
    lat: -1.2821,
    lng: 36.8119,
    heading: 0,
    speedKph: 60,
    updatedAt: "2026-04-16T15:10:00Z"
  }
];

// Simple JWT extraction mock
function extractPartnerFromAuth(req) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return null; // For simplicity, assume unauthenticated or require other auth
  }
  const token = authHeader.split(" ")[1];
  // In a real system, verify JWT and extract claims.partnerId
  // Mock: if token is "ey...", assume partner_abc, else test-token
  if (token === "valid-token-abc") return "partner_abc";
  if (token === "valid-token-xyz") return "partner_xyz";
  return null;
}

app.get("/fleet/locations", (req, res) => {
  res.set({
    "X-RateLimit-Limit": "1000",
    "X-RateLimit-Remaining": "999",
    "X-RateLimit-Reset": `${Math.floor(Date.now() / 1000) + 60}`
  });

  const callerPartnerId = extractPartnerFromAuth(req) || "partner_abc"; // default for testing if no auth passed
  
  if (req.headers.authorization === "Bearer invalid-token") {
      return res.status(401).json({ error: "Unauthorized" });
  }

  const { partnerId, updatedSince, limit } = req.query;

  // Enforce PTC-Auth-001 / ISS-023: A partner cannot request data for another partner
  if (partnerId && partnerId !== callerPartnerId) {
    return res.status(403).json({ error: "Forbidden", message: "Cannot access other partner telemetry" });
  }

  const effectivePartnerId = partnerId || callerPartnerId;

  // Filter by partner
  let results = mockFleet.filter(v => v.partnerId === effectivePartnerId);

  // Filter by updatedSince (REST-004 fix)
  if (updatedSince) {
    const sinceTime = new Date(updatedSince).getTime();
    results = results.filter(v => new Date(v.updatedAt).getTime() > sinceTime);
  }

  // Handle limit
  const maxLimit = limit ? parseInt(limit, 10) : 100;
  
  res.json({
    items: results.slice(0, maxLimit),
    count: results.length,
    nextCursor: null
  });
});

app.listen(3000, "0.0.0.0", () => console.log("Mock server on :3000"));
