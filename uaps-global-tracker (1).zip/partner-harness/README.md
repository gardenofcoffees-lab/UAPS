# Partner Test Harness

The `partner-harness` directory contains tools, mock servers, and automated integration tests designed to validate external UI and service integrations with our Fleet Locations API.

## Structure

```text
partner-harness/
  config.yaml               # Shared configuration for tests (base URLs, auth tokens)
  tests/
    auth.test.ts            # Validates JWT, API key, and IAM mechanisms 
    rest_locations.test.ts  # Validates GET /fleet/locations logic
    websocket_live.test.ts  # Validates WS connection & live streams
    security.test.ts        # Validates partner scoping/tenant protection
  schemas/
    FleetLocation.json      # JSON Schemas generated from OpenAPI
    ErrorResponse.json
  package.json
  mock-server.mjs           # Express mock responding with static fleet data
```

## Running the Mock Server

Starting the mock server will spin up a Node Express instance on port 3000 simulating the `GET /fleet/locations` API Gateway response:
```bash
npm start
```

## Running the Integration Tests

You can run automated integration tests using the defined configurations:
```bash
npm test -- --config=config.yaml
# or if using pytest directly
pytest --config config.yaml
```
