import fs from 'fs';
import path from 'path';

function processDirectory(dir) {
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const fullPath = path.join(dir, file);
    if (fs.statSync(fullPath).isDirectory()) {
      processDirectory(fullPath);
    } else if (fullPath.endsWith('.tsx') || fullPath.endsWith('.ts')) {
      let content = fs.readFileSync(fullPath, 'utf8');
      let modified = false;

      // regex for standard extraction: const variable = await res.json();
      const regex = /(const|let)\s+(\w+)\s*=\s*await\s+([a-zA-Z0-9_]+)\.json\(\)\s*;/g;
      
      content = content.replace(regex, (match, keyword, varName, resObj) => {
        // Skip if already modified in PartnerTrustIndex or others
        if (varName === 'body') return match;
        modified = true;
        return `const __${varName}Body = await ${resObj}.json();\n      ${keyword} ${varName} = __${varName}Body.data || __${varName}Body;`;
      });

      if (modified) {
        fs.writeFileSync(fullPath, content, 'utf8');
        console.log(`Updated ${fullPath}`);
      }
    }
  }
}

processDirectory('./src');
console.log('Update complete.');
