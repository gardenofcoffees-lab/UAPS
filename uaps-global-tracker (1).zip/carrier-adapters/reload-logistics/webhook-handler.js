const { normalizeEvent } = require('./event-normalizer');
const { validateSchema } = require('./schema-validator');

async function handleWebhook(req, res) {
  try {
    const rawEvent = req.body;
    
    // 1. Normalize the raw carrier event
    const normalized = normalizeEvent(rawEvent);
    
    // 2. Validate against our standard schema
    validateSchema(normalized);
    
    // 3. Process the event (e.g., save to DB, emit to event bus)
    console.log("Successfully processed event:", normalized);
    
    res.status(200).json({ 
      success: true, 
      event_id: normalized.event_id 
    });
  } catch (error) {
    console.error("Webhook processing error:", error);
    res.status(400).json({ 
      success: false, 
      error: error.message 
    });
  }
}

module.exports = { handleWebhook };
