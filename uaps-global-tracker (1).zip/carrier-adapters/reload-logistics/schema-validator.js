function validateSchema(normalizedEvent) {
  const requiredFields = ['event_id', 'type', 'timestamp', 'shipment_id', 'location'];
  
  for (const field of requiredFields) {
    if (!normalizedEvent[field]) {
      throw new Error(`Validation failed: Missing required field '${field}'`);
    }
  }
  
  return true;
}

module.exports = { validateSchema };
