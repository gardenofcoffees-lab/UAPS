const mapping = require('./mapping.json');

function mapEventType(status) {
  for (const [key, values] of Object.entries(mapping.events)) {
    if (values.includes(status)) return key;
  }
  return "UNKNOWN";
}

function normalizeLocation(location) {
  if (!location) return "Unknown";
  if (typeof location === 'string') return location;
  return location[mapping.locations.border] || location[mapping.locations.port] || "Unknown";
}

function normalizeEvent(raw) {
  return {
    event_id: raw.id,
    type: mapEventType(raw.status),
    timestamp: raw.time,
    shipment_id: raw.shipmentRef,
    location: normalizeLocation(raw.location),
    payload: raw.details
  }
}

module.exports = { normalizeEvent, mapEventType, normalizeLocation };
